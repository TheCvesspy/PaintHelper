# Acrilex
![Acrilex](../logos/Acrilex.png "Acrilex")

|Name|Code|Set|R|G|B|Hex|
|---|---|---|---|---|---|---|
|Acqua Marina|803|Acrilex Paints|129|200|209|![#81C8D1](https://placehold.co/15x15/81C8D1/81C8D1.png) `#81C8D1`|
|Amarelo Bebe|808|Acrilex Paints|248|246|183|![#F8F6B7](https://placehold.co/15x15/F8F6B7/F8F6B7.png) `#F8F6B7`|
|Amarelo Cadmio|536|Acrilex Paints|246|153|54|![#F69936](https://placehold.co/15x15/F69936/F69936.png) `#F69936`|
|Amarelo Limao|504|Acrilex Paints|244|238|66|![#F4EE42](https://placehold.co/15x15/F4EE42/F4EE42.png) `#F4EE42`|
|Amarelo Ocre|564|Acrilex Paints|223|146|73|![#DF9249](https://placehold.co/15x15/DF9249/DF9249.png) `#DF9249`|
|Amarelo Ouro|505|Acrilex Paints|254|186|17|![#FEBA11](https://placehold.co/15x15/FEBA11/FEBA11.png) `#FEBA11`|
|Amarelo Pêssego|929|Acrilex Paints|250|225|208|![#FAE1D0](https://placehold.co/15x15/FAE1D0/FAE1D0.png) `#FAE1D0`|
|Ameixa|913|Acrilex Paints|135|73|97|![#874961](https://placehold.co/15x15/874961/874961.png) `#874961`|
|Amendoa|831|Acrilex Paints|220|108|64|![#DC6C40](https://placehold.co/15x15/DC6C40/DC6C40.png) `#DC6C40`|
|Areia|817|Acrilex Paints|244|221|202|![#F4DDCA](https://placehold.co/15x15/F4DDCA/F4DDCA.png) `#F4DDCA`|
|Areia Lunar|879|Acrilex Paints|179|190|174|![#B3BEAE](https://placehold.co/15x15/B3BEAE/B3BEAE.png) `#B3BEAE`|
|Areia Rosada|929|Acrilex Paints|242|179|156|![#F2B39C](https://placehold.co/15x15/F2B39C/F2B39C.png) `#F2B39C`|
|Arándano|914|Acrilex Paints|144|61|72|![#903D48](https://placehold.co/15x15/903D48/903D48.png) `#903D48`|
|Azul|559|Acrilex Paints|44|118|183|![#2C76B7](https://placehold.co/15x15/2C76B7/2C76B7.png) `#2C76B7`|
|Azul Bali|921|Acrilex Paints|130|168|211|![#82A8D3](https://placehold.co/15x15/82A8D3/82A8D3.png) `#82A8D3`|
|Azul Celeste|503|Acrilex Paints|72|181|226|![#48B5E2](https://placehold.co/15x15/48B5E2/48B5E2.png) `#48B5E2`|
|Azul Country|825|Acrilex Paints|142|163|202|![#8EA3CA](https://placehold.co/15x15/8EA3CA/8EA3CA.png) `#8EA3CA`|
|Azul Hortênsia|579|Acrilex Paints|175|218|231|![#AFDAE7](https://placehold.co/15x15/AFDAE7/AFDAE7.png) `#AFDAE7`|
|Azul Intenso|578|Acrilex Paints|56|71|152|![#384798](https://placehold.co/15x15/384798/384798.png) `#384798`|
|Azul Marinho|544|Acrilex Paints|52|68|110|![#34446E](https://placehold.co/15x15/34446E/34446E.png) `#34446E`|
|Azul Piscina|823|Acrilex Paints|32|149|173|![#2095AD](https://placehold.co/15x15/2095AD/2095AD.png) `#2095AD`|
|Azul Seco|824|Acrilex Paints|84|95|120|![#545F78](https://placehold.co/15x15/545F78/545F78.png) `#545F78`|
|Azul Turquesa|501|Acrilex Paints|59|83|131|![#3B5383](https://placehold.co/15x15/3B5383/3B5383.png) `#3B5383`|
|Azul Água|919|Acrilex Paints|222|242|253|![#DEF2FD](https://placehold.co/15x15/DEF2FD/DEF2FD.png) `#DEF2FD`|
|Branco|519|Acrilex Paints|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Camurça|525|Acrilex Paints|254|208|130|![#FED082](https://placehold.co/15x15/FED082/FED082.png) `#FED082`|
|Camurça Queimado|818|Acrilex Paints|222|178|143|![#DEB28F](https://placehold.co/15x15/DEB28F/DEB28F.png) `#DEB28F`|
|Capuccino|585|Acrilex Paints|175|143|119|![#AF8F77](https://placehold.co/15x15/AF8F77/AF8F77.png) `#AF8F77`|
|Caramelo|569|Acrilex Paints|182|128|49|![#B68031](https://placehold.co/15x15/B68031/B68031.png) `#B68031`|
|Cenoura|576|Acrilex Paints|241|91|42|![#F15B2A](https://placehold.co/15x15/F15B2A/F15B2A.png) `#F15B2A`|
|Cereja|826|Acrilex Paints|153|55|60|![#99373C](https://placehold.co/15x15/99373C/99373C.png) `#99373C`|
|Cerâmica|506|Acrilex Paints|167|81|67|![#A75143](https://placehold.co/15x15/A75143/A75143.png) `#A75143`|
|Cinza|933|Acrilex Paints|210|218|220|![#D2DADC](https://placehold.co/15x15/D2DADC/D2DADC.png) `#D2DADC`|
|Concreto|819|Acrilex Paints|168|154|130|![#A89A82](https://placehold.co/15x15/A89A82/A89A82.png) `#A89A82`|
|Coral|586|Acrilex Paints|236|94|87|![#EC5E57](https://placehold.co/15x15/EC5E57/EC5E57.png) `#EC5E57`|
|Creme|903|Acrilex Paints|252|250|231|![#FCFAE7](https://placehold.co/15x15/FCFAE7/FCFAE7.png) `#FCFAE7`|
|Fuchsia|804|Acrilex Paints|205|44|112|![#CD2C70](https://placehold.co/15x15/CD2C70/CD2C70.png) `#CD2C70`|
|Goiaba Queimada|805|Acrilex Paints|205|79|87|![#CD4F57](https://placehold.co/15x15/CD4F57/CD4F57.png) `#CD4F57`|
|Grafite|530|Acrilex Paints|87|89|89|![#575959](https://placehold.co/15x15/575959/575959.png) `#575959`|
|Laranja|517|Acrilex Paints|238|59|35|![#EE3B23](https://placehold.co/15x15/EE3B23/EE3B23.png) `#EE3B23`|
|Lavanda|587|Acrilex Paints|190|204|232|![#BECCE8](https://placehold.co/15x15/BECCE8/BECCE8.png) `#BECCE8`|
|Lilás|528|Acrilex Paints|230|209|223|![#E6D1DF](https://placehold.co/15x15/E6D1DF/E6D1DF.png) `#E6D1DF`|
|Lilás Bebê|809|Acrilex Paints|233|229|240|![#E9E5F0](https://placehold.co/15x15/E9E5F0/E9E5F0.png) `#E9E5F0`|
|Magenta|549|Acrilex Paints|194|72|130|![#C24882](https://placehold.co/15x15/C24882/C24882.png) `#C24882`|
|Marrom|531|Acrilex Paints|174|102|80|![#AE6650](https://placehold.co/15x15/AE6650/AE6650.png) `#AE6650`|
|Marrom Escuro|526|Acrilex Paints|129|85|71|![#815547](https://placehold.co/15x15/815547/815547.png) `#815547`|
|Melao|895|Acrilex Paints|251|177|71|![#FBB147](https://placehold.co/15x15/FBB147/FBB147.png) `#FBB147`|
|Mineral|893|Acrilex Paints|238|245|212|![#EEF5D4](https://placehold.co/15x15/EEF5D4/EEF5D4.png) `#EEF5D4`|
|Ocre|904|Acrilex Paints|228|208|160|![#E4D0A0](https://placehold.co/15x15/E4D0A0/E4D0A0.png) `#E4D0A0`|
|Orquídea|915|Acrilex Paints|217|180|205|![#D9B4CD](https://placehold.co/15x15/D9B4CD/D9B4CD.png) `#D9B4CD`|
|Perola|892|Acrilex Paints|255|249|219|![#FFF9DB](https://placehold.co/15x15/FFF9DB/FFF9DB.png) `#FFF9DB`|
|Pink|527|Acrilex Paints|242|128|154|![#F2809A](https://placehold.co/15x15/F2809A/F2809A.png) `#F2809A`|
|Preto|520|Acrilex Paints|30|27|23|![#1E1B17](https://placehold.co/15x15/1E1B17/1E1B17.png) `#1E1B17`|
|Púrpura|550|Acrilex Paints|154|62|63|![#9A3E3F](https://placehold.co/15x15/9A3E3F/9A3E3F.png) `#9A3E3F`|
|Roma|827|Acrilex Paints|213|46|59|![#D52E3B](https://placehold.co/15x15/D52E3B/D52E3B.png) `#D52E3B`|
|Rosa|537|Acrilex Paints|249|191|199|![#F9BFC7](https://placehold.co/15x15/F9BFC7/F9BFC7.png) `#F9BFC7`|
|Rosa Antigo|828|Acrilex Paints|241|118|130|![#F17682](https://placehold.co/15x15/F17682/F17682.png) `#F17682`|
|Rosa Bebe|813|Acrilex Paints|253|232|231|![#FDE8E7](https://placehold.co/15x15/FDE8E7/FDE8E7.png) `#FDE8E7`|
|Rosa Ciclame|581|Acrilex Paints|191|111|125|![#BF6F7D](https://placehold.co/15x15/BF6F7D/BF6F7D.png) `#BF6F7D`|
|Rosa Cotton|894|Acrilex Paints|249|197|195|![#F9C5C3](https://placehold.co/15x15/F9C5C3/F9C5C3.png) `#F9C5C3`|
|Rosa Escuro|542|Acrilex Paints|238|155|180|![#EE9BB4](https://placehold.co/15x15/EE9BB4/EE9BB4.png) `#EE9BB4`|
|Rosa Primavera|910|Acrilex Paints|240|179|196|![#F0B3C4](https://placehold.co/15x15/F0B3C4/F0B3C4.png) `#F0B3C4`|
|Roxo|918|Acrilex Paints|116|104|168|![#7468A8](https://placehold.co/15x15/7468A8/7468A8.png) `#7468A8`|
|Rústico|896|Acrilex Paints|71|50|27|![#47321B](https://placehold.co/15x15/47321B/47321B.png) `#47321B`|
|Saara|835|Acrilex Paints|240|234|211|![#F0EAD3](https://placehold.co/15x15/F0EAD3/F0EAD3.png) `#F0EAD3`|
|Salmão|518|Acrilex Paints|247|156|131|![#F79C83](https://placehold.co/15x15/F79C83/F79C83.png) `#F79C83`|
|Salmão Bebê|812|Acrilex Paints|253|227|218|![#FDE3DA](https://placehold.co/15x15/FDE3DA/FDE3DA.png) `#FDE3DA`|
|Siena Natural|539|Acrilex Paints|181|101|60|![#B5653C](https://placehold.co/15x15/B5653C/B5653C.png) `#B5653C`|
|Sépia|551|Acrilex Paints|82|72|59|![#52483B](https://placehold.co/15x15/52483B/52483B.png) `#52483B`|
|Tangerina|801|Acrilex Paints|243|118|63|![#F3763F](https://placehold.co/15x15/F3763F/F3763F.png) `#F3763F`|
|Telha|932|Acrilex Paints|194|65|55|![#C24137](https://placehold.co/15x15/C24137/C24137.png) `#C24137`|
|Terra Queimada|514|Acrilex Paints|157|73|78|![#9D494E](https://placehold.co/15x15/9D494E/9D494E.png) `#9D494E`|
|Turquesa|577|Acrilex Paints|86|195|191|![#56C3BF](https://placehold.co/15x15/56C3BF/56C3BF.png) `#56C3BF`|
|Tutti-Frutti|909|Acrilex Paints|246|178|208|![#F6B2D0](https://placehold.co/15x15/F6B2D0/F6B2D0.png) `#F6B2D0`|
|Verde Agua|821|Acrilex Paints|184|224|214|![#B8E0D6](https://placehold.co/15x15/B8E0D6/B8E0D6.png) `#B8E0D6`|
|Verde Alecrim|898|Acrilex Paints|214|228|125|![#D6E47D](https://placehold.co/15x15/D6E47D/D6E47D.png) `#D6E47D`|
|Verde Country|822|Acrilex Paints|14|161|139|![#0EA18B](https://placehold.co/15x15/0EA18B/0EA18B.png) `#0EA18B`|
|Verde Esmeralda|571|Acrilex Paints|0|68|51|![#004433](https://placehold.co/15x15/004433/004433.png) `#004433`|
|Verde Folha|510|Acrilex Paints|81|185|77|![#51B94D](https://placehold.co/15x15/51B94D/51B94D.png) `#51B94D`|
|Verde Grama|582|Acrilex Paints|43|111|66|![#2B6F42](https://placehold.co/15x15/2B6F42/2B6F42.png) `#2B6F42`|
|Verde Maçã|802|Acrilex Paints|165|190|57|![#A5BE39](https://placehold.co/15x15/A5BE39/A5BE39.png) `#A5BE39`|
|Verde Musgo|513|Acrilex Paints|64|100|52|![#406434](https://placehold.co/15x15/406434/406434.png) `#406434`|
|Verde Oliva|545|Acrilex Paints|106|111|70|![#6A6F46](https://placehold.co/15x15/6A6F46/6A6F46.png) `#6A6F46`|
|Verde Pistache|570|Acrilex Paints|157|165|72|![#9DA548](https://placehold.co/15x15/9DA548/9DA548.png) `#9DA548`|
|Verde Primavera|820|Acrilex Paints|228|239|198|![#E4EFC6](https://placehold.co/15x15/E4EFC6/E4EFC6.png) `#E4EFC6`|
|Verde Soft|897|Acrilex Paints|247|248|218|![#F7F8DA](https://placehold.co/15x15/F7F8DA/F7F8DA.png) `#F7F8DA`|
|Vermelho|555|Acrilex Paints|213|42|43|![#D52A2B](https://placehold.co/15x15/D52A2B/D52A2B.png) `#D52A2B`|
|Vermelho Escarlate|508|Acrilex Paints|172|47|51|![#AC2F33](https://placehold.co/15x15/AC2F33/AC2F33.png) `#AC2F33`|
|Vermelho Fogo|507|Acrilex Paints|229|74|52|![#E54A34](https://placehold.co/15x15/E54A34/E54A34.png) `#E54A34`|
|Vermelho Vivo|541|Acrilex Paints|231|50|45|![#E7322D](https://placehold.co/15x15/E7322D/E7322D.png) `#E7322D`|
|Vinho|565|Acrilex Paints|104|51|72|![#683348](https://placehold.co/15x15/683348/683348.png) `#683348`|
|Violeta|516|Acrilex Paints|153|118|180|![#9976B4](https://placehold.co/15x15/9976B4/9976B4.png) `#9976B4`|
|Violeta Cobalto|540|Acrilex Paints|59|46|103|![#3B2E67](https://placehold.co/15x15/3B2E67/3B2E67.png) `#3B2E67`|
|Violeta Escuro|917|Acrilex Paints|101|49|108|![#65316C](https://placehold.co/15x15/65316C/65316C.png) `#65316C`|
|Violeta Gris|916|Acrilex Paints|151|143|172|![#978FAC](https://placehold.co/15x15/978FAC/978FAC.png) `#978FAC`|
<p align="center"><img src="../logos/logo_rnd.png" height="70" /></p>
<p align="center">Made available by <a href="https://miniaturepainterpro.app/">Miniature Painter Pro</a></p>
<p align="center">
<a href="https://play.google.com/store/apps/details?id=com.rfsp.paintmaster"> <img src="../logos/Android.png" height="30" /></a>
<a href="https://apps.apple.com/us/app/miniature-painter-pro/id1495938928"> <img src="../logos/iOS.png" height="30" /></a>
</p>
