# Coat D Armes
![CoatDArmes](../logos/CoatDArmes.png "CoatDArmes")

|Name|Code|Set|R|G|B|Hex|
|---|---|---|---|---|---|---|
|Amethest Purple|160|Fantasy Range|103|90|146|![#675A92](https://placehold.co/15x15/675A92/675A92.png) `#675A92`|
|Angel Green|155|Fantasy Range|59|65|63|![#3B413F](https://placehold.co/15x15/3B413F/3B413F.png) `#3B413F`|
|Angel Red|149|Fantasy Range|254|83|57|![#FE5339](https://placehold.co/15x15/FE5339/FE5339.png) `#FE5339`|
|Aquamarine|132|Fantasy Range|58|114|137|![#3A7289](https://placehold.co/15x15/3A7289/3A7289.png) `#3A7289`|
|Armour|153|Fantasy Range - Ink Wash|109|116|109|![#6D746D](https://placehold.co/15x15/6D746D/6D746D.png) `#6D746D`|
|Army Green|521|World War II Range|76|89|71|![#4C5947](https://placehold.co/15x15/4C5947/4C5947.png) `#4C5947`|
|Barbarian Leather|116|Fantasy Range|139|93|67|![#8B5D43](https://placehold.co/15x15/8B5D43/8B5D43.png) `#8B5D43`|
|Bavarian Blue|239|Military Range|47|156|241|![#2F9CF1](https://placehold.co/15x15/2F9CF1/2F9CF1.png) `#2F9CF1`|
|Beaten Copper|163|Fantasy Range|201|111|77|![#C96F4D](https://placehold.co/15x15/C96F4D/C96F4D.png) `#C96F4D`|
|Beige Brown|529|World War II Range|138|101|75|![#8A654B](https://placehold.co/15x15/8A654B/8A654B.png) `#8A654B`|
|Billous Brown|130|Fantasy Range|201|134|81|![#C98651](https://placehold.co/15x15/C98651/C98651.png) `#C98651`|
|Black|102|Military Range|0|0|0|![#000000](https://placehold.co/15x15/000000/000000.png) `#000000`|
|Black|102|Fantasy Range|0|0|0|![#000000](https://placehold.co/15x15/000000/000000.png) `#000000`|
|Black|154|Fantasy Range - Ink Wash|100|107|100|![#646B64](https://placehold.co/15x15/646B64/646B64.png) `#646B64`|
|Black Green|515|World War II Range|64|80|70|![#405046](https://placehold.co/15x15/405046/405046.png) `#405046`|
|Blood Red|104|Fantasy Range|216|63|55|![#D83F37](https://placehold.co/15x15/D83F37/D83F37.png) `#D83F37`|
|Bogey Green|121|Fantasy Range|72|113|73|![#487149](https://placehold.co/15x15/487149/487149.png) `#487149`|
|Bone|112|Fantasy Range|244|218|167|![#F4DAA7](https://placehold.co/15x15/F4DAA7/F4DAA7.png) `#F4DAA7`|
|Brass|131|Fantasy Range|202|160|122|![#CAA07A](https://placehold.co/15x15/CAA07A/CAA07A.png) `#CAA07A`|
|Brick Red|509|World War II Range|121|77|64|![#794D40](https://placehold.co/15x15/794D40/794D40.png) `#794D40`|
|Bright Gold|107|Fantasy Range|171|160|115|![#ABA073](https://placehold.co/15x15/ABA073/ABA073.png) `#ABA073`|
|British Khaki|501|World War II Range|122|104|68|![#7A6844](https://placehold.co/15x15/7A6844/7A6844.png) `#7A6844`|
|British Scarlet|238|Military Range|245|51|60|![#F5333C](https://placehold.co/15x15/F5333C/F5333C.png) `#F5333C`|
|Bronze|232|Military Range|209|192|176|![#D1C0B0](https://placehold.co/15x15/D1C0B0/D1C0B0.png) `#D1C0B0`|
|Buff|228|Military Range|222|209|157|![#DED19D](https://placehold.co/15x15/DED19D/DED19D.png) `#DED19D`|
|Burnt Orange|147|Fantasy Range|255|128|65|![#FF8041](https://placehold.co/15x15/FF8041/FF8041.png) `#FF8041`|
|Camouflage Green|230|Military Range|107|132|92|![#6B845C](https://placehold.co/15x15/6B845C/6B845C.png) `#6B845C`|
|Chainmail|109|Fantasy Range|186|184|195|![#BAB8C3](https://placehold.co/15x15/BAB8C3/BAB8C3.png) `#BAB8C3`|
|Chesnut Brown|219|Military Range|84|62|49|![#543E31](https://placehold.co/15x15/543E31/543E31.png) `#543E31`|
|Chocolate Brown|519|World War II Range|90|84|68|![#5A5444](https://placehold.co/15x15/5A5444/5A5444.png) `#5A5444`|
|Dark Blue|207|Military Range|72|80|143|![#48508F](https://placehold.co/15x15/48508F/48508F.png) `#48508F`|
|Dark Earth|234|Military Range|85|88|79|![#55584F](https://placehold.co/15x15/55584F/55584F.png) `#55584F`|
|Dark Earth|402|Brushscape Range|66|65|47|![#42412F](https://placehold.co/15x15/42412F/42412F.png) `#42412F`|
|Dark Elf Green|111|Fantasy Range|57|74|68|![#394A44](https://placehold.co/15x15/394A44/394A44.png) `#394A44`|
|Dark Flesh|216|Military Range|62|55|62|![#3E373E](https://placehold.co/15x15/3E373E/3E373E.png) `#3E373E`|
|Dark Green|209|Military Range|69|106|89|![#456A59](https://placehold.co/15x15/456A59/456A59.png) `#456A59`|
|Dark Green|405|Brushscape Range|53|97|74|![#35614A](https://placehold.co/15x15/35614A/35614A.png) `#35614A`|
|Dark Grey|212|Military Range|82|103|96|![#526760](https://placehold.co/15x15/526760/526760.png) `#526760`|
|Dark Leather|534|World War II Range|94|83|61|![#5E533D](https://placehold.co/15x15/5E533D/5E533D.png) `#5E533D`|
|Dark Sand|229|Military Range|202|184|118|![#CAB876](https://placehold.co/15x15/CAB876/CAB876.png) `#CAB876`|
|Dark Sand|404|Brushscape Range|125|118|64|![#7D7640](https://placehold.co/15x15/7D7640/7D7640.png) `#7D7640`|
|Deadly Nightshade|161|Fantasy Range|64|75|79|![#404B4F](https://placehold.co/15x15/404B4F/404B4F.png) `#404B4F`|
|Desert Sand|506|World War II Range|223|169|107|![#DFA96B](https://placehold.co/15x15/DFA96B/DFA96B.png) `#DFA96B`|
|Desert Yellow|517|World War II Range|225|201|111|![#E1C96F](https://placehold.co/15x15/E1C96F/E1C96F.png) `#E1C96F`|
|Dusky Yellow|146|Fantasy Range|253|202|49|![#FDCA31](https://placehold.co/15x15/FDCA31/FDCA31.png) `#FDCA31`|
|Dwarven Bronze|143|Fantasy Range|214|164|139|![#D6A48B](https://placehold.co/15x15/D6A48B/D6A48B.png) `#D6A48B`|
|Dwarven Flesh|124|Fantasy Range|213|140|123|![#D58C7B](https://placehold.co/15x15/D58C7B/D58C7B.png) `#D58C7B`|
|Elven Flesh|123|Fantasy Range|255|168|138|![#FFA88A](https://placehold.co/15x15/FFA88A/FFA88A.png) `#FFA88A`|
|Elven Grey|122|Fantasy Range|206|215|212|![#CED7D4](https://placehold.co/15x15/CED7D4/CED7D4.png) `#CED7D4`|
|Emerald Green|164|Fantasy Range|57|140|84|![#398C54](https://placehold.co/15x15/398C54/398C54.png) `#398C54`|
|Enchanted Blue|127|Fantasy Range|123|116|170|![#7B74AA](https://placehold.co/15x15/7B74AA/7B74AA.png) `#7B74AA`|
|Enchanted Green|128|Fantasy Range|142|184|148|![#8EB894](https://placehold.co/15x15/8EB894/8EB894.png) `#8EB894`|
|Enchanted Silver|106|Fantasy Range|174|178|189|![#AEB2BD](https://placehold.co/15x15/AEB2BD/AEB2BD.png) `#AEB2BD`|
|Faded Khaki|537|World War II Range|131|130|112|![#838270](https://placehold.co/15x15/838270/838270.png) `#838270`|
|Faded Olive|513|World War II Range|111|146|106|![#6F926A](https://placehold.co/15x15/6F926A/6F926A.png) `#6F926A`|
|Fester Blue|166|Fantasy Range|55|105|140|![#37698C](https://placehold.co/15x15/37698C/37698C.png) `#37698C`|
|Festering Brown|126|Fantasy Range|181|149|92|![#B5955C](https://placehold.co/15x15/B5955C/B5955C.png) `#B5955C`|
|Field Blue|518|World War II Range|97|111|111|![#616F6F](https://placehold.co/15x15/616F6F/616F6F.png) `#616F6F`|
|Field Drab|502|World War II Range|121|120|100|![#797864](https://placehold.co/15x15/797864/797864.png) `#797864`|
|Field Grey|227|World War II Range|90|102|88|![#5A6658](https://placehold.co/15x15/5A6658/5A6658.png) `#5A6658`|
|Field Grey|227|Military Range|90|102|88|![#5A6658](https://placehold.co/15x15/5A6658/5A6658.png) `#5A6658`|
|Flame Orange|105|Fantasy Range|232|118|81|![#E87651](https://placehold.co/15x15/E87651/E87651.png) `#E87651`|
|Flesh|213|Military Range|255|244|206|![#FFF4CE](https://placehold.co/15x15/FFF4CE/FFF4CE.png) `#FFF4CE`|
|Forest Green|536|World War II Range|75|134|52|![#4B8634](https://placehold.co/15x15/4B8634/4B8634.png) `#4B8634`|
|Goblin Green|108|Fantasy Range|101|124|82|![#657C52](https://placehold.co/15x15/657C52/657C52.png) `#657C52`|
|Golden Yellow|159|Fantasy Range|254|177|1|![#FEB101](https://placehold.co/15x15/FEB101/FEB101.png) `#FEB101`|
|Grass Green|208|Military Range|104|144|92|![#68905C](https://placehold.co/15x15/68905C/68905C.png) `#68905C`|
|Grass Green|401|Brushscape Range|121|152|85|![#799855](https://placehold.co/15x15/799855/799855.png) `#799855`|
|Green Grey|505|World War II Range|76|102|93|![#4C665D](https://placehold.co/15x15/4C665D/4C665D.png) `#4C665D`|
|Grey Primer|141|Fantasy Range|138|88|77|![#8A584D](https://placehold.co/15x15/8A584D/8A584D.png) `#8A584D`|
|Gun Metal|142|Fantasy Range|145|127|117|![#917F75](https://placehold.co/15x15/917F75/917F75.png) `#917F75`|
|Hairy Brown|120|Fantasy Range|108|76|61|![#6C4C3D](https://placehold.co/15x15/6C4C3D/6C4C3D.png) `#6C4C3D`|
|Hawk Turquoise|165|Fantasy Range|2|145|185|![#0291B9](https://placehold.co/15x15/0291B9/0291B9.png) `#0291B9`|
|Hideous Blue|167|Fantasy Range|63|126|170|![#3F7EAA](https://placehold.co/15x15/3F7EAA/3F7EAA.png) `#3F7EAA`|
|High Elf Blue|117|Fantasy Range|61|103|153|![#3D6799](https://placehold.co/15x15/3D6799/3D6799.png) `#3D6799`|
|Horse Tone – Bay|224|Military Range|219|126|85|![#DB7E55](https://placehold.co/15x15/DB7E55/DB7E55.png) `#DB7E55`|
|Horse Tone – Brown|235|Military Range|102|92|67|![#665C43](https://placehold.co/15x15/665C43/665C43.png) `#665C43`|
|Horse Tone – Chesnut|223|Military Range|117|79|76|![#754F4C](https://placehold.co/15x15/754F4C/754F4C.png) `#754F4C`|
|Horse Tone – Dun|221|Military Range|188|157|102|![#BC9D66](https://placehold.co/15x15/BC9D66/BC9D66.png) `#BC9D66`|
|Horse Tone – Grey|236|Military Range|176|187|183|![#B0BBB7](https://placehold.co/15x15/B0BBB7/B0BBB7.png) `#B0BBB7`|
|Horse Tone – Roan|222|Military Range|173|152|135|![#AD9887](https://placehold.co/15x15/AD9887/AD9887.png) `#AD9887`|
|Ink Wash Yellow|168|Fantasy Range - Ink Wash|255|253|50|![#FFFD32](https://placehold.co/15x15/FFFD32/FFFD32.png) `#FFFD32`|
|Iron Grey|516|World War II Range|71|85|85|![#475555](https://placehold.co/15x15/475555/475555.png) `#475555`|
|Italian Red Earth|532|World War II Range|214|108|48|![#D66C30](https://placehold.co/15x15/D66C30/D66C30.png) `#D66C30`|
|Jade Green|158|Fantasy Range|20|157|139|![#149D8B](https://placehold.co/15x15/149D8B/149D8B.png) `#149D8B`|
|Japanese Uniform|531|World War II Range|181|152|22|![#B59816](https://placehold.co/15x15/B59816/B59816.png) `#B59816`|
|Jungle Green|535|World War II Range|63|132|49|![#3F8431](https://placehold.co/15x15/3F8431/3F8431.png) `#3F8431`|
|Khaki|225|Military Range|192|185|115|![#C0B973](https://placehold.co/15x15/C0B973/C0B973.png) `#C0B973`|
|Leather Brown|217|Military Range|190|142|102|![#BE8E66](https://placehold.co/15x15/BE8E66/BE8E66.png) `#BE8E66`|
|Leprous Brown|156|Fantasy Range|252|123|55|![#FC7B37](https://placehold.co/15x15/FC7B37/FC7B37.png) `#FC7B37`|
|Light Blue|206|Military Range|99|119|180|![#6377B4](https://placehold.co/15x15/6377B4/6377B4.png) `#6377B4`|
|Light Earth|403|Brushscape Range|111|112|81|![#6F7051](https://placehold.co/15x15/6F7051/6F7051.png) `#6F7051`|
|Light Grey|211|Military Range|252|253|247|![#FCFDF7](https://placehold.co/15x15/FCFDF7/FCFDF7.png) `#FCFDF7`|
|Light Sand|408|Brushscape Range|231|207|161|![#E7CFA1](https://placehold.co/15x15/E7CFA1/E7CFA1.png) `#E7CFA1`|
|Linen|233|Military Range|242|233|194|![#F2E9C2](https://placehold.co/15x15/F2E9C2/F2E9C2.png) `#F2E9C2`|
|Lupin Grey|151|Fantasy Range|190|224|249|![#BEE0F9](https://placehold.co/15x15/BEE0F9/BEE0F9.png) `#BEE0F9`|
|Magic Metal|113|Fantasy Range|98|66|43|![#62422B](https://placehold.co/15x15/62422B/62422B.png) `#62422B`|
|Marine Blue|148|Fantasy Range|47|103|164|![#2F67A4](https://placehold.co/15x15/2F67A4/2F67A4.png) `#2F67A4`|
|Mid Grey|231|Military Range|178|167|165|![#B2A7A5](https://placehold.co/15x15/B2A7A5/B2A7A5.png) `#B2A7A5`|
|Mid Stone|510|World War II Range|154|124|51|![#9A7C33](https://placehold.co/15x15/9A7C33/9A7C33.png) `#9A7C33`|
|Military Green|503|World War II Range|61|92|77|![#3D5C4D](https://placehold.co/15x15/3D5C4D/3D5C4D.png) `#3D5C4D`|
|Muddy Green|406|Brushscape Range|67|74|33|![#434A21](https://placehold.co/15x15/434A21/434A21.png) `#434A21`|
|Nauseous Blue|162|Fantasy Range|61|74|144|![#3D4A90](https://placehold.co/15x15/3D4A90/3D4A90.png) `#3D4A90`|
|Olive|226|Military Range|84|103|75|![#54674B](https://placehold.co/15x15/54674B/54674B.png) `#54674B`|
|Olive|226|World War II Range|84|103|75|![#54674B](https://placehold.co/15x15/54674B/54674B.png) `#54674B`|
|Olive Drab|508|World War II Range|84|87|68|![#545744](https://placehold.co/15x15/545744/545744.png) `#545744`|
|Orange|105|Military Range|232|118|81|![#E87651](https://placehold.co/15x15/E87651/E87651.png) `#E87651`|
|Oriental Flesh|215|Military Range|246|199|127|![#F6C77F](https://placehold.co/15x15/F6C77F/F6C77F.png) `#F6C77F`|
|Pale Green|514|World War II Range|123|183|131|![#7BB783](https://placehold.co/15x15/7BB783/7BB783.png) `#7BB783`|
|Pale Sand|522|World War II Range|231|205|144|![#E7CD90](https://placehold.co/15x15/E7CD90/E7CD90.png) `#E7CD90`|
|Panzer Grey|504|World War II Range|58|69|61|![#3A453D](https://placehold.co/15x15/3A453D/3A453D.png) `#3A453D`|
|Poison Purple|118|Fantasy Range|93|69|105|![#5D4569](https://placehold.co/15x15/5D4569/5D4569.png) `#5D4569`|
|Purple|210|Military Range|199|75|109|![#C74B6D](https://placehold.co/15x15/C74B6D/C74B6D.png) `#C74B6D`|
|Putrid Green|125|Fantasy Range|165|177|131|![#A5B183](https://placehold.co/15x15/A5B183/A5B183.png) `#A5B183`|
|Rat Brown|119|Fantasy Range|126|73|65|![#7E4941](https://placehold.co/15x15/7E4941/7E4941.png) `#7E4941`|
|Red|104|Military Range|216|63|55|![#D83F37](https://placehold.co/15x15/D83F37/D83F37.png) `#D83F37`|
|Red Brown|520|World War II Range|121|73|61|![#79493D](https://placehold.co/15x15/79493D/79493D.png) `#79493D`|
|Royal Blue|110|Fantasy Range|50|70|105|![#324669](https://placehold.co/15x15/324669/324669.png) `#324669`|
|Ruby Red|145|Fantasy Range|254|0|0|![#FE0000](https://placehold.co/15x15/FE0000/FE0000.png) `#FE0000`|
|Russet Red|237|Military Range|186|66|68|![#BA4244](https://placehold.co/15x15/BA4244/BA4244.png) `#BA4244`|
|Russian Brown|528|World War II Range|122|132|97|![#7A8461](https://placehold.co/15x15/7A8461/7A8461.png) `#7A8461`|
|Russian Green|530|World War II Range|77|93|56|![#4D5D38](https://placehold.co/15x15/4D5D38/4D5D38.png) `#4D5D38`|
|Sandy Brown|407|Brushscape Range|133|100|59|![#85643B](https://placehold.co/15x15/85643B/85643B.png) `#85643B`|
|Scorpion Green|152|Fantasy Range|79|198|10|![#4FC60A](https://placehold.co/15x15/4FC60A/4FC60A.png) `#4FC60A`|
|Sea Grey|507|World War II Range|151|201|192|![#97C9C0](https://placehold.co/15x15/97C9C0/97C9C0.png) `#97C9C0`|
|Shadow Grey|150|Fantasy Range|99|127|164|![#637FA4](https://placehold.co/15x15/637FA4/637FA4.png) `#637FA4`|
|Shocking Pink|144|Fantasy Range|223|168|199|![#DFA8C7](https://placehold.co/15x15/DFA8C7/DFA8C7.png) `#DFA8C7`|
|Silver|220|Military Range|213|217|228|![#D5D9E4](https://placehold.co/15x15/D5D9E4/D5D9E4.png) `#D5D9E4`|
|Slate Grey|533|World War II Range|85|99|99|![#556363](https://placehold.co/15x15/556363/556363.png) `#556363`|
|Sun Yellow|103|Military Range|255|255|0|![#FFFF00](https://placehold.co/15x15/FFFF00/FFFF00.png) `#FFFF00`|
|Sun Yellow|103|Fantasy Range|255|255|0|![#FFFF00](https://placehold.co/15x15/FFFF00/FFFF00.png) `#FFFF00`|
|Suntanned Flesh|214|Military Range|221|167|143|![#DDA78F](https://placehold.co/15x15/DDA78F/DDA78F.png) `#DDA78F`|
|Super Wash Black|169|Fantasy Range - Ink Wash|0|0|0|![#000000](https://placehold.co/15x15/000000/000000.png) `#000000`|
|Super Wash Blue|172|Fantasy Range|56|72|97|![#384861](https://placehold.co/15x15/384861/384861.png) `#384861`|
|Super Wash Dark Brown|177|Fantasy Range - Ink Wash|102|88|75|![#66584B](https://placehold.co/15x15/66584B/66584B.png) `#66584B`|
|Super Wash Green|170|Fantasy Range|129|171|123|![#81AB7B](https://placehold.co/15x15/81AB7B/81AB7B.png) `#81AB7B`|
|Super Wash Light Brown|175|Fantasy Range - Ink Wash|108|70|69|![#6C4645](https://placehold.co/15x15/6C4645/6C4645.png) `#6C4645`|
|Super Wash Mid Brown|176|Fantasy Range - Ink Wash|130|93|66|![#825D42](https://placehold.co/15x15/825D42/825D42.png) `#825D42`|
|Super Wash Purple|174|Fantasy Range - Ink Wash|95|62|91|![#5F3E5B](https://placehold.co/15x15/5F3E5B/5F3E5B.png) `#5F3E5B`|
|Super Wash Red|171|Fantasy Range|156|81|88|![#9C5158](https://placehold.co/15x15/9C5158/9C5158.png) `#9C5158`|
|Super Wash Yellow|173|Fantasy Range - Ink Wash|255|255|105|![#FFFF69](https://placehold.co/15x15/FFFF69/FFFF69.png) `#FFFF69`|
|Tan Earth|524|World War II Range|145|130|75|![#91824B](https://placehold.co/15x15/91824B/91824B.png) `#91824B`|
|Tank Blue Grey|511|World War II Range|77|91|91|![#4D5B5B](https://placehold.co/15x15/4D5B5B/4D5B5B.png) `#4D5B5B`|
|Tank Drab|527|World War II Range|108|109|77|![#6C6D4D](https://placehold.co/15x15/6C6D4D/6C6D4D.png) `#6C6D4D`|
|Tank Green|512|World War II Range|57|125|74|![#397D4A](https://placehold.co/15x15/397D4A/397D4A.png) `#397D4A`|
|Tank Light Grey|526|World War II Range|240|245|239|![#F0F5EF](https://placehold.co/15x15/F0F5EF/F0F5EF.png) `#F0F5EF`|
|Tanned Flesh|115|Fantasy Range|221|154|101|![#DD9A65](https://placehold.co/15x15/DD9A65/DD9A65.png) `#DD9A65`|
|Unbleached Wool|240|Military Range|217|224|183|![#D9E0B7](https://placehold.co/15x15/D9E0B7/D9E0B7.png) `#D9E0B7`|
|Uniform Grey|525|World War II Range|106|136|147|![#6A8893](https://placehold.co/15x15/6A8893/6A8893.png) `#6A8893`|
|Urban Grey|409|Brushscape Range|109|92|85|![#6D5C55](https://placehold.co/15x15/6D5C55/6D5C55.png) `#6D5C55`|
|Us Dark Green|523|World War II Range|69|91|79|![#455B4F](https://placehold.co/15x15/455B4F/455B4F.png) `#455B4F`|
|Vampire Red|129|Fantasy Range|179|46|31|![#B32E1F](https://placehold.co/15x15/B32E1F/B32E1F.png) `#B32E1F`|
|Warlock Purple|157|Fantasy Range|198|56|94|![#C6385E](https://placehold.co/15x15/C6385E/C6385E.png) `#C6385E`|
|White|101|Fantasy Range|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|White|101|Military Range|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Wizard Blue|114|Fantasy Range|57|98|152|![#396298](https://placehold.co/15x15/396298/396298.png) `#396298`|
|Wood Brown|218|Military Range|89|55|28|![#59371C](https://placehold.co/15x15/59371C/59371C.png) `#59371C`|
<p align="center"><img src="../logos/logo_rnd.png" height="70" /></p>
<p align="center">Made available by <a href="https://miniaturepainterpro.app/">Miniature Painter Pro</a></p>
<p align="center">
<a href="https://play.google.com/store/apps/details?id=com.rfsp.paintmaster"> <img src="../logos/Android.png" height="30" /></a>
<a href="https://apps.apple.com/us/app/miniature-painter-pro/id1495938928"> <img src="../logos/iOS.png" height="30" /></a>
</p>
