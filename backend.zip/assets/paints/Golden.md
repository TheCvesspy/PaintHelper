# Golden
![Golden](../logos/Golden.png "Golden")

|Name|Code|Set|R|G|B|Hex|
|---|---|---|---|---|---|---|
|Alizarin Crimson Hue|7450|OPEN Acrylics|153|64|63|![#99403F](https://placehold.co/15x15/99403F/99403F.png) `#99403F`|
|Alizarin Crimson Hue|1450|Heavy Body|156|62|64|![#9C3E40](https://placehold.co/15x15/9C3E40/9C3E40.png) `#9C3E40`|
|Alizarin Crimson Hue|2435|Fluid|102|38|49|![#662631](https://placehold.co/15x15/662631/662631.png) `#662631`|
|Alizarin Crimson Hue|8521|High Flow|102|38|49|![#662631](https://placehold.co/15x15/662631/662631.png) `#662631`|
|Anthraquinone Blue|8522|High Flow|35|29|60|![#231D3C](https://placehold.co/15x15/231D3C/231D3C.png) `#231D3C`|
|Anthraquinone Blue|1005|Heavy Body|24|37|81|![#182551](https://placehold.co/15x15/182551/182551.png) `#182551`|
|Anthraquinone Blue|7005|OPEN Acrylics|23|31|77|![#171F4D](https://placehold.co/15x15/171F4D/171F4D.png) `#171F4D`|
|Anthraquinone Blue|2005|Fluid|35|29|60|![#231D3C](https://placehold.co/15x15/231D3C/231D3C.png) `#231D3C`|
|Azurite Hue|1464|Heavy Body|64|120|167|![#4078A7](https://placehold.co/15x15/4078A7/4078A7.png) `#4078A7`|
|Benzimidazolone Yellow Light|1009|Heavy Body|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Benzimidazolone Yellow Light|8554|High Flow|247|233|37|![#F7E925](https://placehold.co/15x15/F7E925/F7E925.png) `#F7E925`|
|Benzimidazolone Yellow Light|2009|Fluid|247|233|37|![#F7E925](https://placehold.co/15x15/F7E925/F7E925.png) `#F7E925`|
|Benzimidazolone Yellow Light|7009|OPEN Acrylics|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Benzimidazolone Yellow Medium|8553|High Flow|255|217|29|![#FFD91D](https://placehold.co/15x15/FFD91D/FFD91D.png) `#FFD91D`|
|Benzimidazolone Yellow Medium|2008|Fluid|255|217|29|![#FFD91D](https://placehold.co/15x15/FFD91D/FFD91D.png) `#FFD91D`|
|Benzimidazolone Yellow Medium|1008|Heavy Body|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Benzimidazolone Yellow Medium|7008|OPEN Acrylics|239|219|75|![#EFDB4B](https://placehold.co/15x15/EFDB4B/EFDB4B.png) `#EFDB4B`|
|Bismuth Vanadate Yellow|1007|Heavy Body|255|242|86|![#FFF256](https://placehold.co/15x15/FFF256/FFF256.png) `#FFF256`|
|Bismuth Vanadate Yellow|6510|SoFlat Matte Acrylic Colors|255|234|3|![#FFEA03](https://placehold.co/15x15/FFEA03/FFEA03.png) `#FFEA03`|
|Bismuth Vanadate Yellow|7007|OPEN Acrylics|255|242|86|![#FFF256](https://placehold.co/15x15/FFF256/FFF256.png) `#FFF256`|
|Black|6745|SoFlat Matte Acrylic Colors|31|36|32|![#1F2420](https://placehold.co/15x15/1F2420/1F2420.png) `#1F2420`|
|Blue Violet|6605|SoFlat Matte Acrylic Colors|46|53|105|![#2E3569](https://placehold.co/15x15/2E3569/2E3569.png) `#2E3569`|
|Bone Black|7010|OPEN Acrylics|42|41|37|![#2A2925](https://placehold.co/15x15/2A2925/2A2925.png) `#2A2925`|
|Bone Black|1010|Heavy Body|60|59|55|![#3C3B37](https://placehold.co/15x15/3C3B37/3C3B37.png) `#3C3B37`|
|Bone Black|2010|Fluid|44|44|43|![#2C2C2B](https://placehold.co/15x15/2C2C2B/2C2C2B.png) `#2C2C2B`|
|Burnt Sienna|1020|Heavy Body|85|47|38|![#552F26](https://placehold.co/15x15/552F26/552F26.png) `#552F26`|
|Burnt Sienna|7020|OPEN Acrylics|86|48|39|![#563027](https://placehold.co/15x15/563027/563027.png) `#563027`|
|Burnt Sienna|6730|SoFlat Matte Acrylic Colors|131|50|21|![#833215](https://placehold.co/15x15/833215/833215.png) `#833215`|
|Burnt Sienna|8523|High Flow|122|64|41|![#7A4029](https://placehold.co/15x15/7A4029/7A4029.png) `#7A4029`|
|Burnt Sienna|2020|Fluid|122|64|41|![#7A4029](https://placehold.co/15x15/7A4029/7A4029.png) `#7A4029`|
|Burnt Umber|1030|Heavy Body|56|42|39|![#382A27](https://placehold.co/15x15/382A27/382A27.png) `#382A27`|
|Burnt Umber|7030|OPEN Acrylics|52|43|38|![#342B26](https://placehold.co/15x15/342B26/342B26.png) `#342B26`|
|Burnt Umber|6735|SoFlat Matte Acrylic Colors|64|43|26|![#402B1A](https://placehold.co/15x15/402B1A/402B1A.png) `#402B1A`|
|Burnt Umber Light|1035|Heavy Body|56|41|36|![#382924](https://placehold.co/15x15/382924/382924.png) `#382924`|
|Burnt Umber Light|2035|Fluid|98|75|68|![#624B44](https://placehold.co/15x15/624B44/624B44.png) `#624B44`|
|Cadmium Orange|7070|OPEN Acrylics|253|69|0|![#FD4500](https://placehold.co/15x15/FD4500/FD4500.png) `#FD4500`|
|Cadmium Orange|6530|SoFlat Matte Acrylic Colors|254|103|14|![#FE670E](https://placehold.co/15x15/FE670E/FE670E.png) `#FE670E`|
|Cadmium Orange|1070|Heavy Body|253|69|0|![#FD4500](https://placehold.co/15x15/FD4500/FD4500.png) `#FD4500`|
|Cadmium Primrose|6505|SoFlat Matte Acrylic Colors|254|241|22|![#FEF116](https://placehold.co/15x15/FEF116/FEF116.png) `#FEF116`|
|Cadmium Red Dark|6565|SoFlat Matte Acrylic Colors|138|31|23|![#8A1F17](https://placehold.co/15x15/8A1F17/8A1F17.png) `#8A1F17`|
|Cadmium Red Dark|1080|Heavy Body|137|24|28|![#89181C](https://placehold.co/15x15/89181C/89181C.png) `#89181C`|
|Cadmium Red Dark|7080|OPEN Acrylics|138|25|29|![#8A191D](https://placehold.co/15x15/8A191D/8A191D.png) `#8A191D`|
|Cadmium Red Light|6545|SoFlat Matte Acrylic Colors|239|45|17|![#EF2D11](https://placehold.co/15x15/EF2D11/EF2D11.png) `#EF2D11`|
|Cadmium Red Light|7090|OPEN Acrylics|218|76|65|![#DA4C41](https://placehold.co/15x15/DA4C41/DA4C41.png) `#DA4C41`|
|Cadmium Red Light|1090|Heavy Body|217|75|65|![#D94B41](https://placehold.co/15x15/D94B41/D94B41.png) `#D94B41`|
|Cadmium Red Medium|7100|OPEN Acrylics|185|27|28|![#B91B1C](https://placehold.co/15x15/B91B1C/B91B1C.png) `#B91B1C`|
|Cadmium Red Medium|1100|Heavy Body|192|28|29|![#C01C1D](https://placehold.co/15x15/C01C1D/C01C1D.png) `#C01C1D`|
|Cadmium Red Medium Hue|1552|Heavy Body|213|5|5|![#D50505](https://placehold.co/15x15/D50505/D50505.png) `#D50505`|
|Cadmium Red Medium Hue|2425|Fluid|192|67|64|![#C04340](https://placehold.co/15x15/C04340/C04340.png) `#C04340`|
|Cadmium Yellow Dark|1110|Heavy Body|255|194|17|![#FFC211](https://placehold.co/15x15/FFC211/FFC211.png) `#FFC211`|
|Cadmium Yellow Dark|7110|OPEN Acrylics|254|193|14|![#FEC10E](https://placehold.co/15x15/FEC10E/FEC10E.png) `#FEC10E`|
|Cadmium Yellow Light|1120|Heavy Body|255|237|65|![#FFED41](https://placehold.co/15x15/FFED41/FFED41.png) `#FFED41`|
|Cadmium Yellow Medium|1130|Heavy Body|255|241|44|![#FFF12C](https://placehold.co/15x15/FFF12C/FFF12C.png) `#FFF12C`|
|Cadmium Yellow Medium|6520|SoFlat Matte Acrylic Colors|255|210|0|![#FFD200](https://placehold.co/15x15/FFD200/FFD200.png) `#FFD200`|
|Cadmium Yellow Medium|7130|OPEN Acrylics|255|241|44|![#FFF12C](https://placehold.co/15x15/FFF12C/FFF12C.png) `#FFF12C`|
|Cadmium Yellow Medium Hue|1554|Heavy Body|255|236|58|![#FFEC3A](https://placehold.co/15x15/FFEC3A/FFEC3A.png) `#FFEC3A`|
|Cadmium Yellow Medium Hue|2428|Fluid|253|196|19|![#FDC413](https://placehold.co/15x15/FDC413/FDC413.png) `#FDC413`|
|Cadmium Yellow Primrose|1135|Heavy Body|248|238|135|![#F8EE87](https://placehold.co/15x15/F8EE87/F8EE87.png) `#F8EE87`|
|Cadmium Yellow Primrose|7135|OPEN Acrylics|249|240|136|![#F9F088](https://placehold.co/15x15/F9F088/F9F088.png) `#F9F088`|
|Carbon Black|2040|Fluid|23|21|18|![#171512](https://placehold.co/15x15/171512/171512.png) `#171512`|
|Carbon Black|1040|Heavy Body|34|34|32|![#222220](https://placehold.co/15x15/222220/222220.png) `#222220`|
|Carbon Black|7040|OPEN Acrylics|55|55|54|![#373736](https://placehold.co/15x15/373736/373736.png) `#373736`|
|Carbon Black|8524|High Flow|23|21|18|![#171512](https://placehold.co/15x15/171512/171512.png) `#171512`|
|Cerulean Blue Deep|2051|Fluid|0|84|141|![#00548D](https://placehold.co/15x15/00548D/00548D.png) `#00548D`|
|Cerulean Blue Deep|1051|Heavy Body|29|56|99|![#1D3863](https://placehold.co/15x15/1D3863/1D3863.png) `#1D3863`|
|Cerulean Blue Hue|8526|High Flow|0|88|174|![#0058AE](https://placehold.co/15x15/0058AE/0058AE.png) `#0058AE`|
|Cerulean Blue Hue|6630|SoFlat Matte Acrylic Colors|3|99|175|![#0363AF](https://placehold.co/15x15/0363AF/0363AF.png) `#0363AF`|
|Cerulean Blue, Chromium|7050|OPEN Acrylics|59|122|225|![#3B7AE1](https://placehold.co/15x15/3B7AE1/3B7AE1.png) `#3B7AE1`|
|Cerulean Blue, Chromium|2050|Fluid|0|88|174|![#0058AE](https://placehold.co/15x15/0058AE/0058AE.png) `#0058AE`|
|Cerulean Blue, Chromium|1050|Heavy Body|75|136|227|![#4B88E3](https://placehold.co/15x15/4B88E3/4B88E3.png) `#4B88E3`|
|Chromium Oxide Green|1060|Heavy Body|65|97|58|![#41613A](https://placehold.co/15x15/41613A/41613A.png) `#41613A`|
|Chromium Oxide Green|7060|OPEN Acrylics|65|100|60|![#41643C](https://placehold.co/15x15/41643C/41643C.png) `#41643C`|
|Chromium Oxide Green|2060|Fluid|60|107|59|![#3C6B3B](https://placehold.co/15x15/3C6B3B/3C6B3B.png) `#3C6B3B`|
|Chromium Oxide Green Dark|7061|OPEN Acrylics|54|80|51|![#365033](https://placehold.co/15x15/365033/365033.png) `#365033`|
|Chromium Oxide Green Dark|1061|Heavy Body|43|67|43|![#2B432B](https://placehold.co/15x15/2B432B/2B432B.png) `#2B432B`|
|Cobalt Blue|2140|Fluid|0|82|180|![#0052B4](https://placehold.co/15x15/0052B4/0052B4.png) `#0052B4`|
|Cobalt Blue|1140|Heavy Body|31|82|209|![#1F52D1](https://placehold.co/15x15/1F52D1/1F52D1.png) `#1F52D1`|
|Cobalt Blue|7140|OPEN Acrylics|21|70|198|![#1546C6](https://placehold.co/15x15/1546C6/1546C6.png) `#1546C6`|
|Cobalt Blue Hue|1556|Heavy Body|32|73|178|![#2049B2](https://placehold.co/15x15/2049B2/2049B2.png) `#2049B2`|
|Cobalt Green|1142|Heavy Body|72|112|101|![#487065](https://placehold.co/15x15/487065/487065.png) `#487065`|
|Cobalt Green|7142|OPEN Acrylics|67|105|94|![#43695E](https://placehold.co/15x15/43695E/43695E.png) `#43695E`|
|Cobalt Teal|2145|Fluid|0|50|154|![#00329A](https://placehold.co/15x15/00329A/00329A.png) `#00329A`|
|Cobalt Teal|7145|OPEN Acrylics|86|154|182|![#569AB6](https://placehold.co/15x15/569AB6/569AB6.png) `#569AB6`|
|Cobalt Teal|1145|Heavy Body|58|157|186|![#3A9DBA](https://placehold.co/15x15/3A9DBA/3A9DBA.png) `#3A9DBA`|
|Cobalt Teal|6645|SoFlat Matte Acrylic Colors|0|166|166|![#00A6A6](https://placehold.co/15x15/00A6A6/00A6A6.png) `#00A6A6`|
|Cobalt Turquoise|1144|Heavy Body|36|79|96|![#244F60](https://placehold.co/15x15/244F60/244F60.png) `#244F60`|
|Cobalt Turquoise|7144|OPEN Acrylics|36|82|98|![#245262](https://placehold.co/15x15/245262/245262.png) `#245262`|
|Cobalt Turquoise|2144|Fluid|0|102|119|![#006677](https://placehold.co/15x15/006677/006677.png) `#006677`|
|Cobalt Violet Hue|1465|Heavy Body|81|32|54|![#512036](https://placehold.co/15x15/512036/512036.png) `#512036`|
|Dark Green|6665|SoFlat Matte Acrylic Colors|65|93|68|![#415D44](https://placehold.co/15x15/415D44/415D44.png) `#415D44`|
|Diarylide Yellow|7147|OPEN Acrylics|254|191|24|![#FEBF18](https://placehold.co/15x15/FEBF18/FEBF18.png) `#FEBF18`|
|Diarylide Yellow|8527|High Flow|255|164|1|![#FFA401](https://placehold.co/15x15/FFA401/FFA401.png) `#FFA401`|
|Diarylide Yellow|2147|Fluid|255|164|1|![#FFA401](https://placehold.co/15x15/FFA401/FFA401.png) `#FFA401`|
|Diarylide Yellow|1147|Heavy Body|253|188|22|![#FDBC16](https://placehold.co/15x15/FDBC16/FDBC16.png) `#FDBC16`|
|Dioxazine Purple|1150|Heavy Body|31|30|61|![#1F1E3D](https://placehold.co/15x15/1F1E3D/1F1E3D.png) `#1F1E3D`|
|Dioxazine Purple|2150|Fluid|39|33|66|![#272142](https://placehold.co/15x15/272142/272142.png) `#272142`|
|Dioxazine Purple|7150|OPEN Acrylics|25|27|48|![#191B30](https://placehold.co/15x15/191B30/191B30.png) `#191B30`|
|Dioxazine Violet Deep|6600|SoFlat Matte Acrylic Colors|33|32|50|![#212032](https://placehold.co/15x15/212032/212032.png) `#212032`|
|Fluorescent Blue|4605|Fluorescent & Phosphorescent Colors|1|140|254|![#018CFE](https://placehold.co/15x15/018CFE/018CFE.png) `#018CFE`|
|Fluorescent Blue|8566|High Flow|1|140|254|![#018CFE](https://placehold.co/15x15/018CFE/018CFE.png) `#018CFE`|
|Fluorescent Chartreuse|8567|High Flow|220|226|2|![#DCE202](https://placehold.co/15x15/DCE202/DCE202.png) `#DCE202`|
|Fluorescent Chartreuse|4615|Fluorescent & Phosphorescent Colors|220|226|2|![#DCE202](https://placehold.co/15x15/DCE202/DCE202.png) `#DCE202`|
|Fluorescent Green|8568|High Flow|80|217|58|![#50D93A](https://placehold.co/15x15/50D93A/50D93A.png) `#50D93A`|
|Fluorescent Green|4620|Fluorescent & Phosphorescent Colors|80|217|58|![#50D93A](https://placehold.co/15x15/50D93A/50D93A.png) `#50D93A`|
|Fluorescent Green|6795|SoFlat Matte Acrylic Colors|1|252|93|![#01FC5D](https://placehold.co/15x15/01FC5D/01FC5D.png) `#01FC5D`|
|Fluorescent Magenta|4625|Fluorescent & Phosphorescent Colors|255|0|160|![#FF00A0](https://placehold.co/15x15/FF00A0/FF00A0.png) `#FF00A0`|
|Fluorescent Orange|6775|SoFlat Matte Acrylic Colors|255|149|14|![#FF950E](https://placehold.co/15x15/FF950E/FF950E.png) `#FF950E`|
|Fluorescent Orange|4630|Fluorescent & Phosphorescent Colors|255|118|0|![#FF7600](https://placehold.co/15x15/FF7600/FF7600.png) `#FF7600`|
|Fluorescent Orange|8569|High Flow|255|118|0|![#FF7600](https://placehold.co/15x15/FF7600/FF7600.png) `#FF7600`|
|Fluorescent Orange-Yellow|4640|Fluorescent & Phosphorescent Colors|255|174|41|![#FFAE29](https://placehold.co/15x15/FFAE29/FFAE29.png) `#FFAE29`|
|Fluorescent Pink|4645|Fluorescent & Phosphorescent Colors|255|20|163|![#FF14A3](https://placehold.co/15x15/FF14A3/FF14A3.png) `#FF14A3`|
|Fluorescent Pink|6785|SoFlat Matte Acrylic Colors|254|64|138|![#FE408A](https://placehold.co/15x15/FE408A/FE408A.png) `#FE408A`|
|Fluorescent Pink|8570|High Flow|255|20|163|![#FF14A3](https://placehold.co/15x15/FF14A3/FF14A3.png) `#FF14A3`|
|Fluorescent Red|6780|SoFlat Matte Acrylic Colors|253|93|71|![#FD5D47](https://placehold.co/15x15/FD5D47/FD5D47.png) `#FD5D47`|
|Fluorescent Red|4650|Fluorescent & Phosphorescent Colors|253|66|69|![#FD4245](https://placehold.co/15x15/FD4245/FD4245.png) `#FD4245`|
|Fluorescent Violet|6790|SoFlat Matte Acrylic Colors|210|19|187|![#D213BB](https://placehold.co/15x15/D213BB/D213BB.png) `#D213BB`|
|Fluorescent Yellow|6770|SoFlat Matte Acrylic Colors|245|255|60|![#F5FF3C](https://placehold.co/15x15/F5FF3C/F5FF3C.png) `#F5FF3C`|
|Graphite Gray|1160|Heavy Body|70|69|67|![#464543](https://placehold.co/15x15/464543/464543.png) `#464543`|
|Green Gold|1170|Heavy Body|87|97|34|![#576122](https://placehold.co/15x15/576122/576122.png) `#576122`|
|Green Gold|2170|Fluid|102|116|0|![#667400](https://placehold.co/15x15/667400/667400.png) `#667400`|
|Green Gold|8528|High Flow|102|116|0|![#667400](https://placehold.co/15x15/667400/667400.png) `#667400`|
|Green Gold|7170|OPEN Acrylics|128|128|40|![#808028](https://placehold.co/15x15/808028/808028.png) `#808028`|
|Hansa Yellow Opaque|2191|Fluid|255|213|0|![#FFD500](https://placehold.co/15x15/FFD500/FFD500.png) `#FFD500`|
|Hansa Yellow Opaque|1191|Heavy Body|255|244|54|![#FFF436](https://placehold.co/15x15/FFF436/FFF436.png) `#FFF436`|
|Hansa Yellow Opaque|7191|OPEN Acrylics|255|244|54|![#FFF436](https://placehold.co/15x15/FFF436/FFF436.png) `#FFF436`|
|Hookers Green Hue|1454|Heavy Body|34|38|39|![#222627](https://placehold.co/15x15/222627/222627.png) `#222627`|
|India Yellow Hue|2436|Fluid|220|118|0|![#DC7600](https://placehold.co/15x15/DC7600/DC7600.png) `#DC7600`|
|India Yellow Hue|1455|Heavy Body|255|160|30|![#FFA01E](https://placehold.co/15x15/FFA01E/FFA01E.png) `#FFA01E`|
|India Yellow Hue|7455|OPEN Acrylics|245|154|22|![#F59A16](https://placehold.co/15x15/F59A16/F59A16.png) `#F59A16`|
|Iridescent Copper (Fine)|8571|High Flow|255|221|51|![#FFDD33](https://placehold.co/15x15/FFDD33/FFDD33.png) `#FFDD33`|
|Iridescent Gold (Fine)|8572|High Flow|255|221|51|![#FFDD33](https://placehold.co/15x15/FFDD33/FFDD33.png) `#FFDD33`|
|Iridescent Pearl (Fine)|8574|High Flow|255|221|51|![#FFDD33](https://placehold.co/15x15/FFDD33/FFDD33.png) `#FFDD33`|
|Iridescent Silver (Fine)|8573|High Flow|255|221|51|![#FFDD33](https://placehold.co/15x15/FFDD33/FFDD33.png) `#FFDD33`|
|Jenkins Green|1195|Heavy Body|30|36|36|![#1E2424](https://placehold.co/15x15/1E2424/1E2424.png) `#1E2424`|
|Jenkins Green|2195|Fluid|13|33|0|![#0D2100](https://placehold.co/15x15/0D2100/0D2100.png) `#0D2100`|
|Jenkins Green|7195|OPEN Acrylics|25|30|33|![#191E21](https://placehold.co/15x15/191E21/191E21.png) `#191E21`|
|Light Bismuth Yellow|1574|Heavy Body|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Light Green (blue Shade)|1558|Heavy Body|85|198|108|![#55C66C](https://placehold.co/15x15/55C66C/55C66C.png) `#55C66C`|
|Light Green (yellow Shade)|1560|Heavy Body|130|216|115|![#82D873](https://placehold.co/15x15/82D873/82D873.png) `#82D873`|
|Light Magenta|1562|Heavy Body|253|135|159|![#FD879F](https://placehold.co/15x15/FD879F/FD879F.png) `#FD879F`|
|Light Orange|1575|Heavy Body|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Light Phthalo Blue|1577|Heavy Body|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Light Phthalo Green|1578|Heavy Body|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Light Turquoise (phthalo)|1564|Heavy Body|40|118|131|![#287683](https://placehold.co/15x15/287683/287683.png) `#287683`|
|Light Ultramarine Blue|1566|Heavy Body|103|151|235|![#6797EB](https://placehold.co/15x15/6797EB/6797EB.png) `#6797EB`|
|Light Ultramarine Blue|7566|OPEN Acrylics|101|149|233|![#6595E9](https://placehold.co/15x15/6595E9/6595E9.png) `#6595E9`|
|Light Violet|1568|Heavy Body|98|91|169|![#625BA9](https://placehold.co/15x15/625BA9/625BA9.png) `#625BA9`|
|Manganese Blue Hue|2437|Fluid|1|96|162|![#0160A2](https://placehold.co/15x15/0160A2/0160A2.png) `#0160A2`|
|Manganese Blue Hue|7457|OPEN Acrylics|98|153|207|![#6299CF](https://placehold.co/15x15/6299CF/6299CF.png) `#6299CF`|
|Manganese Blue Hue|1457|Heavy Body|84|137|196|![#5489C4](https://placehold.co/15x15/5489C4/5489C4.png) `#5489C4`|
|Mars Black|1200|Heavy Body|39|39|37|![#272725](https://placehold.co/15x15/272725/272725.png) `#272725`|
|Mars Yellow|7202|OPEN Acrylics|150|63|44|![#963F2C](https://placehold.co/15x15/963F2C/963F2C.png) `#963F2C`|
|Mars Yellow|1202|Heavy Body|145|60|39|![#913C27](https://placehold.co/15x15/913C27/913C27.png) `#913C27`|
|Mars Yellow Deep|6705|SoFlat Matte Acrylic Colors|175|123|50|![#AF7B32](https://placehold.co/15x15/AF7B32/AF7B32.png) `#AF7B32`|
|Medium Magenta|1570|Heavy Body|206|61|126|![#CE3D7E](https://placehold.co/15x15/CE3D7E/CE3D7E.png) `#CE3D7E`|
|Medium Violet|1572|Heavy Body|60|44|80|![#3C2C50](https://placehold.co/15x15/3C2C50/3C2C50.png) `#3C2C50`|
|N2 Neutral Gray|1442|Heavy Body|67|60|54|![#433C36](https://placehold.co/15x15/433C36/433C36.png) `#433C36`|
|N3 Neutral Gray|1443|Heavy Body|58|57|53|![#3A3935](https://placehold.co/15x15/3A3935/3A3935.png) `#3A3935`|
|N4 Neutral Gray|1444|Heavy Body|74|74|72|![#4A4A48](https://placehold.co/15x15/4A4A48/4A4A48.png) `#4A4A48`|
|N5 Neutral Gray|7445|OPEN Acrylics|109|105|104|![#6D6968](https://placehold.co/15x15/6D6968/6D6968.png) `#6D6968`|
|N5 Neutral Gray|8533|High Flow|132|133|137|![#848589](https://placehold.co/15x15/848589/848589.png) `#848589`|
|N5 Neutral Gray|1445|Heavy Body|111|107|106|![#6F6B6A](https://placehold.co/15x15/6F6B6A/6F6B6A.png) `#6F6B6A`|
|N6 Neutral Gray|1446|Heavy Body|151|147|146|![#979392](https://placehold.co/15x15/979392/979392.png) `#979392`|
|N7 Neutral Gray|1447|Heavy Body|187|183|182|![#BBB7B6](https://placehold.co/15x15/BBB7B6/BBB7B6.png) `#BBB7B6`|
|N8 Neutral Gray|1448|Heavy Body|227|223|222|![#E3DFDE](https://placehold.co/15x15/E3DFDE/E3DFDE.png) `#E3DFDE`|
|Naphthol Pink|6570|SoFlat Matte Acrylic Colors|237|67|80|![#ED4350](https://placehold.co/15x15/ED4350/ED4350.png) `#ED4350`|
|Naphthol Red Light|8532|High Flow|200|62|52|![#C83E34](https://placehold.co/15x15/C83E34/C83E34.png) `#C83E34`|
|Naphthol Red Light|2210|Fluid|200|62|52|![#C83E34](https://placehold.co/15x15/C83E34/C83E34.png) `#C83E34`|
|Naphthol Red Light|7210|OPEN Acrylics|230|2|3|![#E60203](https://placehold.co/15x15/E60203/E60203.png) `#E60203`|
|Naphthol Red Light|6550|SoFlat Matte Acrylic Colors|239|41|15|![#EF290F](https://placehold.co/15x15/EF290F/EF290F.png) `#EF290F`|
|Naphthol Red Light|1210|Heavy Body|232|10|9|![#E80A09](https://placehold.co/15x15/E80A09/E80A09.png) `#E80A09`|
|Naphthol Red Medium|7220|OPEN Acrylics|149|8|16|![#950810](https://placehold.co/15x15/950810/950810.png) `#950810`|
|Naphthol Red Medium|1220|Heavy Body|161|6|20|![#A10614](https://placehold.co/15x15/A10614/A10614.png) `#A10614`|
|Naphthol Red Medium|2220|Fluid|163|40|50|![#A32832](https://placehold.co/15x15/A32832/A32832.png) `#A32832`|
|Naples Yellow Deep|6695|SoFlat Matte Acrylic Colors|234|164|53|![#EAA435](https://placehold.co/15x15/EAA435/EAA435.png) `#EAA435`|
|Naples Yellow Hue|7459|OPEN Acrylics|240|205|113|![#F0CD71](https://placehold.co/15x15/F0CD71/F0CD71.png) `#F0CD71`|
|Naples Yellow Hue|1459|Heavy Body|243|208|116|![#F3D074](https://placehold.co/15x15/F3D074/F3D074.png) `#F3D074`|
|Naples Yellow Hue|2438|Fluid|223|192|123|![#DFC07B](https://placehold.co/15x15/DFC07B/DFC07B.png) `#DFC07B`|
|Nickel Azo Yellow|1225|Heavy Body|195|107|18|![#C36B12](https://placehold.co/15x15/C36B12/C36B12.png) `#C36B12`|
|Nickel Azo Yellow|8534|High Flow|175|121|27|![#AF791B](https://placehold.co/15x15/AF791B/AF791B.png) `#AF791B`|
|Nickel Azo Yellow|2225|Fluid|175|121|27|![#AF791B](https://placehold.co/15x15/AF791B/AF791B.png) `#AF791B`|
|Nickel Azo Yellow|7225|OPEN Acrylics|228|152|42|![#E4982A](https://placehold.co/15x15/E4982A/E4982A.png) `#E4982A`|
|Pale Yellow|6500|SoFlat Matte Acrylic Colors|252|239|111|![#FCEF6F](https://placehold.co/15x15/FCEF6F/FCEF6F.png) `#FCEF6F`|
|Payne's Gray|1240|Heavy Body|40|44|55|![#282C37](https://placehold.co/15x15/282C37/282C37.png) `#282C37`|
|Payne's Gray|7240|OPEN Acrylics|38|43|49|![#262B31](https://placehold.co/15x15/262B31/262B31.png) `#262B31`|
|Payne's Gray|6750|SoFlat Matte Acrylic Colors|21|27|27|![#151B1B](https://placehold.co/15x15/151B1B/151B1B.png) `#151B1B`|
|Payne's Gray|2240|Fluid|44|49|73|![#2C3149](https://placehold.co/15x15/2C3149/2C3149.png) `#2C3149`|
|Permanent Green|6660|SoFlat Matte Acrylic Colors|2|116|65|![#027441](https://placehold.co/15x15/027441/027441.png) `#027441`|
|Permanent Green Light|1250|Heavy Body|23|84|69|![#175445](https://placehold.co/15x15/175445/175445.png) `#175445`|
|Permanent Green Light|2250|Fluid|0|119|64|![#007740](https://placehold.co/15x15/007740/007740.png) `#007740`|
|Permanent Green Light|8535|High Flow|0|119|64|![#007740](https://placehold.co/15x15/007740/007740.png) `#007740`|
|Permanent Green Light|7250|OPEN Acrylics|26|84|70|![#1A5446](https://placehold.co/15x15/1A5446/1A5446.png) `#1A5446`|
|Permanent Maroon|7252|OPEN Acrylics|62|27|25|![#3E1B19](https://placehold.co/15x15/3E1B19/3E1B19.png) `#3E1B19`|
|Permanent Maroon|1252|Heavy Body|93|28|34|![#5D1C22](https://placehold.co/15x15/5D1C22/5D1C22.png) `#5D1C22`|
|Permanent Violet Dark|7253|OPEN Acrylics|58|26|47|![#3A1A2F](https://placehold.co/15x15/3A1A2F/3A1A2F.png) `#3A1A2F`|
|Permanent Violet Dark|8536|High Flow|68|33|70|![#442146](https://placehold.co/15x15/442146/442146.png) `#442146`|
|Permanent Violet Dark|1253|Heavy Body|58|26|50|![#3A1A32](https://placehold.co/15x15/3A1A32/3A1A32.png) `#3A1A32`|
|Permanent Violet Dark|2253|Fluid|68|33|70|![#442146](https://placehold.co/15x15/442146/442146.png) `#442146`|
|Permanent Yellow|6515|SoFlat Matte Acrylic Colors|255|233|0|![#FFE900](https://placehold.co/15x15/FFE900/FFE900.png) `#FFE900`|
|Permanent Yellow Deep|6525|SoFlat Matte Acrylic Colors|255|175|2|![#FFAF02](https://placehold.co/15x15/FFAF02/FFAF02.png) `#FFAF02`|
|Phosphorescent Green|4900|Fluorescent & Phosphorescent Colors|204|255|153|![#CCFF99](https://placehold.co/15x15/CCFF99/CCFF99.png) `#CCFF99`|
|Phthalo Blue (Green Shade)|8537|High Flow|0|0|80|![#000050](https://placehold.co/15x15/000050/000050.png) `#000050`|
|Phthalo Blue (Green Shade)|2255|Fluid|0|0|80|![#000050](https://placehold.co/15x15/000050/000050.png) `#000050`|
|Phthalo Blue (Red Shade)|2260|Fluid|0|47|124|![#002F7C](https://placehold.co/15x15/002F7C/002F7C.png) `#002F7C`|
|Phthalo Blue (green Shade)|1255|Heavy Body|11|51|113|![#0B3371](https://placehold.co/15x15/0B3371/0B3371.png) `#0B3371`|
|Phthalo Blue (green Shade)|7255|OPEN Acrylics|16|53|123|![#10357B](https://placehold.co/15x15/10357B/10357B.png) `#10357B`|
|Phthalo Blue (green Shade)|6620|SoFlat Matte Acrylic Colors|47|58|112|![#2F3A70](https://placehold.co/15x15/2F3A70/2F3A70.png) `#2F3A70`|
|Phthalo Blue (red Shade)|1260|Heavy Body|14|65|170|![#0E41AA](https://placehold.co/15x15/0E41AA/0E41AA.png) `#0E41AA`|
|Phthalo Blue (red Shade)|7260|OPEN Acrylics|27|67|162|![#1B43A2](https://placehold.co/15x15/1B43A2/1B43A2.png) `#1B43A2`|
|Phthalo Green (Blue Shade)|2270|Fluid|0|41|50|![#002932](https://placehold.co/15x15/002932/002932.png) `#002932`|
|Phthalo Green (Blue Shade)|8538|High Flow|0|41|50|![#002932](https://placehold.co/15x15/002932/002932.png) `#002932`|
|Phthalo Green (Yellow Shade)|2275|Fluid|0|56|47|![#00382F](https://placehold.co/15x15/00382F/00382F.png) `#00382F`|
|Phthalo Green (blue Shade)|6650|SoFlat Matte Acrylic Colors|7|77|66|![#074D42](https://placehold.co/15x15/074D42/074D42.png) `#074D42`|
|Phthalo Green (blue Shade)|1270|Heavy Body|24|90|89|![#185A59](https://placehold.co/15x15/185A59/185A59.png) `#185A59`|
|Phthalo Green (blue Shade)|7270|OPEN Acrylics|11|55|58|![#0B373A](https://placehold.co/15x15/0B373A/0B373A.png) `#0B373A`|
|Phthalo Green (yellow Shade)|7275|OPEN Acrylics|20|104|71|![#146847](https://placehold.co/15x15/146847/146847.png) `#146847`|
|Phthalo Green (yellow Shade)|1275|Heavy Body|27|139|89|![#1B8B59](https://placehold.co/15x15/1B8B59/1B8B59.png) `#1B8B59`|
|Primary Cyan|2420|Fluid|0|78|172|![#004EAC](https://placehold.co/15x15/004EAC/004EAC.png) `#004EAC`|
|Primary Cyan|1500|Heavy Body|25|62|142|![#193E8E](https://placehold.co/15x15/193E8E/193E8E.png) `#193E8E`|
|Primary Magenta|2421|Fluid|186|26|34|![#BA1A22](https://placehold.co/15x15/BA1A22/BA1A22.png) `#BA1A22`|
|Primary Magenta|1510|Heavy Body|214|22|37|![#D61625](https://placehold.co/15x15/D61625/D61625.png) `#D61625`|
|Primary Yellow|1530|Heavy Body|254|244|58|![#FEF43A](https://placehold.co/15x15/FEF43A/FEF43A.png) `#FEF43A`|
|Primary Yellow|2422|Fluid|255|209|21|![#FFD115](https://placehold.co/15x15/FFD115/FFD115.png) `#FFD115`|
|Prussian Blue Hue|1460|Heavy Body|26|37|65|![#1A2541](https://placehold.co/15x15/1A2541/1A2541.png) `#1A2541`|
|Prussian Blue Hue|7460|OPEN Acrylics|34|47|81|![#222F51](https://placehold.co/15x15/222F51/222F51.png) `#222F51`|
|Prussian Blue Hue|2439|Fluid|37|25|71|![#251947](https://placehold.co/15x15/251947/251947.png) `#251947`|
|Pyrrole Orange|1276|Heavy Body|255|41|4|![#FF2904](https://placehold.co/15x15/FF2904/FF2904.png) `#FF2904`|
|Pyrrole Orange|2276|Fluid|243|73|30|![#F3491E](https://placehold.co/15x15/F3491E/F3491E.png) `#F3491E`|
|Pyrrole Orange|7276|OPEN Acrylics|253|41|1|![#FD2901](https://placehold.co/15x15/FD2901/FD2901.png) `#FD2901`|
|Pyrrole Orange|8539|High Flow|243|73|30|![#F3491E](https://placehold.co/15x15/F3491E/F3491E.png) `#F3491E`|
|Pyrrole Red|7277|OPEN Acrylics|189|0|4|![#BD0004](https://placehold.co/15x15/BD0004/BD0004.png) `#BD0004`|
|Pyrrole Red|6555|SoFlat Matte Acrylic Colors|211|48|29|![#D3301D](https://placehold.co/15x15/D3301D/D3301D.png) `#D3301D`|
|Pyrrole Red|2277|Fluid|194|55|57|![#C23739](https://placehold.co/15x15/C23739/C23739.png) `#C23739`|
|Pyrrole Red|1277|Heavy Body|197|0|3|![#C50003](https://placehold.co/15x15/C50003/C50003.png) `#C50003`|
|Pyrrole Red Dark|1278|Heavy Body|141|16|24|![#8D1018](https://placehold.co/15x15/8D1018/8D1018.png) `#8D1018`|
|Pyrrole Red Dark|7278|OPEN Acrylics|134|7|16|![#860710](https://placehold.co/15x15/860710/860710.png) `#860710`|
|Pyrrole Red Light|1279|Heavy Body|233|21|9|![#E91509](https://placehold.co/15x15/E91509/E91509.png) `#E91509`|
|Pyrrole Red Light|2279|Fluid|209|62|55|![#D13E37](https://placehold.co/15x15/D13E37/D13E37.png) `#D13E37`|
|Quinacridone  Nickel Azo Gold|7301|OPEN Acrylics|218|78|25|![#DA4E19](https://placehold.co/15x15/DA4E19/DA4E19.png) `#DA4E19`|
|Quinacridone  Nickel Azo Gold|8542|High Flow|137|63|38|![#893F26](https://placehold.co/15x15/893F26/893F26.png) `#893F26`|
|Quinacridone  Nickel Azo Gold|1301|Heavy Body|233|97|37|![#E96125](https://placehold.co/15x15/E96125/E96125.png) `#E96125`|
|Quinacridone  Nickel Azo Gold|2301|Fluid|137|63|38|![#893F26](https://placehold.co/15x15/893F26/893F26.png) `#893F26`|
|Quinacridone Magenta|8540|High Flow|135|4|18|![#870412](https://placehold.co/15x15/870412/870412.png) `#870412`|
|Quinacridone Magenta|7305|OPEN Acrylics|97|19|33|![#611321](https://placehold.co/15x15/611321/611321.png) `#611321`|
|Quinacridone Magenta|2305|Fluid|135|4|18|![#870412](https://placehold.co/15x15/870412/870412.png) `#870412`|
|Quinacridone Magenta|1305|Heavy Body|153|20|49|![#991431](https://placehold.co/15x15/991431/991431.png) `#991431`|
|Quinacridone Red|7310|OPEN Acrylics|191|2|24|![#BF0218](https://placehold.co/15x15/BF0218/BF0218.png) `#BF0218`|
|Quinacridone Red|2310|Fluid|185|29|20|![#B91D14](https://placehold.co/15x15/B91D14/B91D14.png) `#B91D14`|
|Quinacridone Red|1310|Heavy Body|184|1|19|![#B80113](https://placehold.co/15x15/B80113/B80113.png) `#B80113`|
|Quinacridone Red|8541|High Flow|185|29|20|![#B91D14](https://placehold.co/15x15/B91D14/B91D14.png) `#B91D14`|
|Quinacridone Violet|2330|Fluid|135|0|29|![#87001D](https://placehold.co/15x15/87001D/87001D.png) `#87001D`|
|Quinacridone Violet|1330|Heavy Body|92|24|35|![#5C1823](https://placehold.co/15x15/5C1823/5C1823.png) `#5C1823`|
|Raw Sienna|7340|OPEN Acrylics|145|90|49|![#915A31](https://placehold.co/15x15/915A31/915A31.png) `#915A31`|
|Raw Sienna|1340|Heavy Body|158|90|51|![#9E5A33](https://placehold.co/15x15/9E5A33/9E5A33.png) `#9E5A33`|
|Raw Sienna|2340|Fluid|167|120|70|![#A77846](https://placehold.co/15x15/A77846/A77846.png) `#A77846`|
|Raw Sienna|8543|High Flow|167|120|70|![#A77846](https://placehold.co/15x15/A77846/A77846.png) `#A77846`|
|Raw Umber|7350|OPEN Acrylics|50|45|41|![#322D29](https://placehold.co/15x15/322D29/322D29.png) `#322D29`|
|Raw Umber|8544|High Flow|74|67|62|![#4A433E](https://placehold.co/15x15/4A433E/4A433E.png) `#4A433E`|
|Raw Umber|2350|Fluid|74|67|62|![#4A433E](https://placehold.co/15x15/4A433E/4A433E.png) `#4A433E`|
|Raw Umber|1350|Heavy Body|48|45|40|![#302D28](https://placehold.co/15x15/302D28/302D28.png) `#302D28`|
|Raw Umber|6740|SoFlat Matte Acrylic Colors|45|42|25|![#2D2A19](https://placehold.co/15x15/2D2A19/2D2A19.png) `#2D2A19`|
|Red Oxide|2360|Fluid|144|70|58|![#90463A](https://placehold.co/15x15/90463A/90463A.png) `#90463A`|
|Red Oxide|7360|OPEN Acrylics|109|45|36|![#6D2D24](https://placehold.co/15x15/6D2D24/6D2D24.png) `#6D2D24`|
|Red Oxide|6720|SoFlat Matte Acrylic Colors|116|41|22|![#742916](https://placehold.co/15x15/742916/742916.png) `#742916`|
|Red Oxide|1360|Heavy Body|106|42|33|![#6A2A21](https://placehold.co/15x15/6A2A21/6A2A21.png) `#6A2A21`|
|Red Violet|6595|SoFlat Matte Acrylic Colors|111|53|104|![#6F3568](https://placehold.co/15x15/6F3568/6F3568.png) `#6F3568`|
|Sap Green Hue|2440|Fluid|36|45|20|![#242D14](https://placehold.co/15x15/242D14/242D14.png) `#242D14`|
|Sap Green Hue|7461|OPEN Acrylics|92|91|66|![#5C5B42](https://placehold.co/15x15/5C5B42/5C5B42.png) `#5C5B42`|
|Sap Green Hue|1461|Heavy Body|86|86|64|![#565640](https://placehold.co/15x15/565640/565640.png) `#565640`|
|Sap Green Hue|8545|High Flow|36|45|20|![#242D14](https://placehold.co/15x15/242D14/242D14.png) `#242D14`|
|Sepia|8546|High Flow|60|40|20|![#3C2814](https://placehold.co/15x15/3C2814/3C2814.png) `#3C2814`|
|Smalt Hue|1467|Heavy Body|74|90|149|![#4A5A95](https://placehold.co/15x15/4A5A95/4A5A95.png) `#4A5A95`|
|Teal|1369|Heavy Body|246|246|244|![#F6F6F4](https://placehold.co/15x15/F6F6F4/F6F6F4.png) `#F6F6F4`|
|Teal|8547|High Flow|0|188|193|![#00BCC1](https://placehold.co/15x15/00BCC1/00BCC1.png) `#00BCC1`|
|Teal|7369|OPEN Acrylics|58|157|186|![#3A9DBA](https://placehold.co/15x15/3A9DBA/3A9DBA.png) `#3A9DBA`|
|Teal|2369|Fluid|0|188|193|![#00BCC1](https://placehold.co/15x15/00BCC1/00BCC1.png) `#00BCC1`|
|Terre Verte Hue|7468|OPEN Acrylics|118|130|92|![#76825C](https://placehold.co/15x15/76825C/76825C.png) `#76825C`|
|Terre Verte Hue|1468|Heavy Body|149|161|123|![#95A17B](https://placehold.co/15x15/95A17B/95A17B.png) `#95A17B`|
|Titan Buff|8548|High Flow|224|212|186|![#E0D4BA](https://placehold.co/15x15/E0D4BA/E0D4BA.png) `#E0D4BA`|
|Titan Buff|7370|OPEN Acrylics|243|228|199|![#F3E4C7](https://placehold.co/15x15/F3E4C7/F3E4C7.png) `#F3E4C7`|
|Titan Buff|2370|Fluid|224|212|186|![#E0D4BA](https://placehold.co/15x15/E0D4BA/E0D4BA.png) `#E0D4BA`|
|Titan Buff|1370|Heavy Body|246|231|200|![#F6E7C8](https://placehold.co/15x15/F6E7C8/F6E7C8.png) `#F6E7C8`|
|Titan Green Pale|7371|OPEN Acrylics|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Titan Green Pale|2371|Fluid|186|192|155|![#BAC09B](https://placehold.co/15x15/BAC09B/BAC09B.png) `#BAC09B`|
|Titan Green Pale|1371|Heavy Body|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Titan Mars Pale|1576|Heavy Body|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Titan Violet Pale|1573|Heavy Body|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Titanate Yellow|1375|Heavy Body|255|245|150|![#FFF596](https://placehold.co/15x15/FFF596/FFF596.png) `#FFF596`|
|Titanium White|6755|SoFlat Matte Acrylic Colors|242|246|249|![#F2F6F9](https://placehold.co/15x15/F2F6F9/F2F6F9.png) `#F2F6F9`|
|Titanium White|8549|High Flow|254|254|254|![#FEFEFE](https://placehold.co/15x15/FEFEFE/FEFEFE.png) `#FEFEFE`|
|Titanium White|7380|OPEN Acrylics|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Titanium White|1380|Heavy Body|254|254|254|![#FEFEFE](https://placehold.co/15x15/FEFEFE/FEFEFE.png) `#FEFEFE`|
|Titanium White|2380|Fluid|254|254|254|![#FEFEFE](https://placehold.co/15x15/FEFEFE/FEFEFE.png) `#FEFEFE`|
|Transparent Benzimidazolone Yellow Medium|8555|High Flow|255|221|51|![#FFDD33](https://placehold.co/15x15/FFDD33/FFDD33.png) `#FFDD33`|
|Transparent Brown Iron Oxide|7383|OPEN Acrylics|118|44|17|![#762C11](https://placehold.co/15x15/762C11/762C11.png) `#762C11`|
|Transparent Brown Iron Oxide|1383|Heavy Body|112|44|25|![#702C19](https://placehold.co/15x15/702C19/702C19.png) `#702C19`|
|Transparent Brown Iron Oxide|8562|High Flow|77|49|17|![#4D3111](https://placehold.co/15x15/4D3111/4D3111.png) `#4D3111`|
|Transparent Dioxazine Purple|8556|High Flow|39|7|134|![#270786](https://placehold.co/15x15/270786/270786.png) `#270786`|
|Transparent Naphthol Red Light|8558|High Flow|237|88|78|![#ED584E](https://placehold.co/15x15/ED584E/ED584E.png) `#ED584E`|
|Transparent Phthalo Blue GS|8559|High Flow|2|78|172|![#024EAC](https://placehold.co/15x15/024EAC/024EAC.png) `#024EAC`|
|Transparent Phthalo Green BS|8560|High Flow|5|195|131|![#05C383](https://placehold.co/15x15/05C383/05C383.png) `#05C383`|
|Transparent Quinacridone Red|8561|High Flow|217|12|69|![#D90C45](https://placehold.co/15x15/D90C45/D90C45.png) `#D90C45`|
|Transparent Red Iron Oxide|7385|OPEN Acrylics|154|24|0|![#9A1800](https://placehold.co/15x15/9A1800/9A1800.png) `#9A1800`|
|Transparent Red Iron Oxide|8563|High Flow|132|48|30|![#84301E](https://placehold.co/15x15/84301E/84301E.png) `#84301E`|
|Transparent Red Iron Oxide|2385|Fluid|132|48|30|![#84301E](https://placehold.co/15x15/84301E/84301E.png) `#84301E`|
|Transparent Red Iron Oxide|1385|Heavy Body|181|48|17|![#B53011](https://placehold.co/15x15/B53011/B53011.png) `#B53011`|
|Transparent Shading Gray|8564|High Flow|193|192|171|![#C1C0AB](https://placehold.co/15x15/C1C0AB/C1C0AB.png) `#C1C0AB`|
|Transparent Yellow Iron Oxide|7386|OPEN Acrylics|246|174|54|![#F6AE36](https://placehold.co/15x15/F6AE36/F6AE36.png) `#F6AE36`|
|Transparent Yellow Iron Oxide|8565|High Flow|169|91|21|![#A95B15](https://placehold.co/15x15/A95B15/A95B15.png) `#A95B15`|
|Transparent Yellow Iron Oxide|2386|Fluid|169|91|21|![#A95B15](https://placehold.co/15x15/A95B15/A95B15.png) `#A95B15`|
|Transparent Yellow Iron Oxide|1386|Heavy Body|239|170|49|![#EFAA31](https://placehold.co/15x15/EFAA31/EFAA31.png) `#EFAA31`|
|Turquoise|6640|SoFlat Matte Acrylic Colors|0|98|111|![#00626F](https://placehold.co/15x15/00626F/00626F.png) `#00626F`|
|Turquoise (Phthalo)|8550|High Flow|0|34|57|![#002239](https://placehold.co/15x15/002239/002239.png) `#002239`|
|Turquoise (Phthalo)|2390|Fluid|0|34|57|![#002239](https://placehold.co/15x15/002239/002239.png) `#002239`|
|Turquoise (phthalo)|1390|Heavy Body|15|21|43|![#0F152B](https://placehold.co/15x15/0F152B/0F152B.png) `#0F152B`|
|Ultramarine Blue|2400|Fluid|28|27|124|![#1C1B7C](https://placehold.co/15x15/1C1B7C/1C1B7C.png) `#1C1B7C`|
|Ultramarine Blue|8551|High Flow|28|27|124|![#1C1B7C](https://placehold.co/15x15/1C1B7C/1C1B7C.png) `#1C1B7C`|
|Ultramarine Blue|7400|OPEN Acrylics|68|84|156|![#44549C](https://placehold.co/15x15/44549C/44549C.png) `#44549C`|
|Ultramarine Blue|1400|Heavy Body|64|81|155|![#40519B](https://placehold.co/15x15/40519B/40519B.png) `#40519B`|
|Ultramarine Blue|6610|SoFlat Matte Acrylic Colors|0|40|206|![#0028CE](https://placehold.co/15x15/0028CE/0028CE.png) `#0028CE`|
|Ultramarine Violet|2401|Fluid|75|64|105|![#4B4069](https://placehold.co/15x15/4B4069/4B4069.png) `#4B4069`|
|Ultramarine Violet|1401|Heavy Body|62|57|123|![#3E397B](https://placehold.co/15x15/3E397B/3E397B.png) `#3E397B`|
|Ultramarine Violet|7401|OPEN Acrylics|44|42|92|![#2C2A5C](https://placehold.co/15x15/2C2A5C/2C2A5C.png) `#2C2A5C`|
|VanDyke Brown Hue|2442|Fluid|59|51|48|![#3B3330](https://placehold.co/15x15/3B3330/3B3330.png) `#3B3330`|
|Vandyke Brown Hue|1462|Heavy Body|51|41|32|![#332920](https://placehold.co/15x15/332920/332920.png) `#332920`|
|Vandyke Brown Hue|7462|OPEN Acrylics|76|53|45|![#4C352D](https://placehold.co/15x15/4C352D/4C352D.png) `#4C352D`|
|Vat Orange|2403|Fluid|214|68|9|![#D64409](https://placehold.co/15x15/D64409/D64409.png) `#D64409`|
|Vat Orange|1403|Heavy Body|251|49|0|![#FB3100](https://placehold.co/15x15/FB3100/FB3100.png) `#FB3100`|
|Violet Oxide|1405|Heavy Body|77|37|35|![#4D2523](https://placehold.co/15x15/4D2523/4D2523.png) `#4D2523`|
|Violet Oxide|2405|Fluid|107|63|62|![#6B3F3E](https://placehold.co/15x15/6B3F3E/6B3F3E.png) `#6B3F3E`|
|Violet Oxide|7405|OPEN Acrylics|80|40|38|![#502826](https://placehold.co/15x15/502826/502826.png) `#502826`|
|Viridian Green Hue|2443|Fluid|0|77|72|![#004D48](https://placehold.co/15x15/004D48/004D48.png) `#004D48`|
|Viridian Green Hue|1469|Heavy Body|43|71|82|![#2B4752](https://placehold.co/15x15/2B4752/2B4752.png) `#2B4752`|
|Viridian Green Hue|7469|OPEN Acrylics|48|118|118|![#307676](https://placehold.co/15x15/307676/307676.png) `#307676`|
|Yellow Green|6675|SoFlat Matte Acrylic Colors|172|231|53|![#ACE735](https://placehold.co/15x15/ACE735/ACE735.png) `#ACE735`|
|Yellow Ochre|2407|Fluid|183|139|56|![#B78B38](https://placehold.co/15x15/B78B38/B78B38.png) `#B78B38`|
|Yellow Ochre|1407|Heavy Body|201|131|74|![#C9834A](https://placehold.co/15x15/C9834A/C9834A.png) `#C9834A`|
|Yellow Ochre|7407|OPEN Acrylics|211|137|82|![#D38952](https://placehold.co/15x15/D38952/D38952.png) `#D38952`|
|Yellow Oxide|1410|Heavy Body|207|140|53|![#CF8C35](https://placehold.co/15x15/CF8C35/CF8C35.png) `#CF8C35`|
|Yellow Oxide|6700|SoFlat Matte Acrylic Colors|205|149|28|![#CD951C](https://placehold.co/15x15/CD951C/CD951C.png) `#CD951C`|
|Yellow Oxide|8552|High Flow|197|160|69|![#C5A045](https://placehold.co/15x15/C5A045/C5A045.png) `#C5A045`|
|Yellow Oxide|2410|Fluid|197|160|69|![#C5A045](https://placehold.co/15x15/C5A045/C5A045.png) `#C5A045`|
|Yellow Oxide|7410|OPEN Acrylics|218|147|57|![#DA9339](https://placehold.co/15x15/DA9339/DA9339.png) `#DA9339`|
|Zinc White|1415|Heavy Body|202|211|226|![#CAD3E2](https://placehold.co/15x15/CAD3E2/CAD3E2.png) `#CAD3E2`|
|Zinc White|2415|Fluid|254|254|254|![#FEFEFE](https://placehold.co/15x15/FEFEFE/FEFEFE.png) `#FEFEFE`|
|Zinc White|7415|OPEN Acrylics|159|172|189|![#9FACBD](https://placehold.co/15x15/9FACBD/9FACBD.png) `#9FACBD`|
<p align="center"><img src="../logos/logo_rnd.png" height="70" /></p>
<p align="center">Made available by <a href="https://miniaturepainterpro.app/">Miniature Painter Pro</a></p>
<p align="center">
<a href="https://play.google.com/store/apps/details?id=com.rfsp.paintmaster"> <img src="../logos/Android.png" height="30" /></a>
<a href="https://apps.apple.com/us/app/miniature-painter-pro/id1495938928"> <img src="../logos/iOS.png" height="30" /></a>
</p>
