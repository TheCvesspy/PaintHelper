# Italeri
![Italeri](../logos/Italeri.png "Italeri")

|Name|Code|Set|R|G|B|Hex|
|---|---|---|---|---|---|---|
|Aluminium|4677AP|Italeri Acrylic Paint|137|140|133|![#898C85](https://placehold.co/15x15/898C85/898C85.png) `#898C85`|
|Armor Sand|4711AP|Italeri Acrylic Paint|153|146|92|![#99925C](https://placehold.co/15x15/99925C/99925C.png) `#99925C`|
|Azure Blue|4308AP|Italeri Acrylic Paint|67|133|197|![#4385C5](https://placehold.co/15x15/4385C5/4385C5.png) `#4385C5`|
|Black|4768AP|Italeri Acrylic Paint|0|0|0|![#000000](https://placehold.co/15x15/000000/000000.png) `#000000`|
|Black|4695AP|Italeri Acrylic Paint|0|0|0|![#000000](https://placehold.co/15x15/000000/000000.png) `#000000`|
|Blue Angels Blue|4687AP|Italeri Acrylic Paint|30|44|79|![#1E2C4F](https://placehold.co/15x15/1E2C4F/1E2C4F.png) `#1E2C4F`|
|Brass|4672AP|Italeri Acrylic Paint|170|125|44|![#AA7D2C](https://placehold.co/15x15/AA7D2C/AA7D2C.png) `#AA7D2C`|
|Bruno Mimetico|4644AP|Italeri Acrylic Paint|131|104|84|![#836854](https://placehold.co/15x15/836854/836854.png) `#836854`|
|Clear Acryl|4636AP|Italeri Acrylic Paint|249|249|249|![#F9F9F9](https://placehold.co/15x15/F9F9F9/F9F9F9.png) `#F9F9F9`|
|Clear Acryl|4637AP|Italeri Acrylic Paint|249|249|249|![#F9F9F9](https://placehold.co/15x15/F9F9F9/F9F9F9.png) `#F9F9F9`|
|Clear Acryl|4638AP|Italeri Acrylic Paint|249|249|249|![#F9F9F9](https://placehold.co/15x15/F9F9F9/F9F9F9.png) `#F9F9F9`|
|Dark Earth|4303AP|Italeri Acrylic Paint|122|89|54|![#7A5936](https://placehold.co/15x15/7A5936/7A5936.png) `#7A5936`|
|Dark Earth Ana 617|4846AP|Italeri Acrylic Paint|132|105|84|![#846954](https://placehold.co/15x15/846954/846954.png) `#846954`|
|Dark Ghost Gray|4761AP|Italeri Acrylic Paint|126|142|154|![#7E8E9A](https://placehold.co/15x15/7E8E9A/7E8E9A.png) `#7E8E9A`|
|Dark Gray|4754AP|Italeri Acrylic Paint|101|119|118|![#657776](https://placehold.co/15x15/657776/657776.png) `#657776`|
|Dark Green|4726AP|Italeri Acrylic Paint|92|103|80|![#5C6750](https://placehold.co/15x15/5C6750/5C6750.png) `#5C6750`|
|Dark Gull Gray|4755AP|Italeri Acrylic Paint|85|107|113|![#556B71](https://placehold.co/15x15/556B71/556B71.png) `#556B71`|
|Dark Slate Grey|4311AP|Italeri Acrylic Paint|45|49|34|![#2D3122](https://placehold.co/15x15/2D3122/2D3122.png) `#2D3122`|
|Dark Tan|4709AP|Italeri Acrylic Paint|158|118|91|![#9E765B](https://placehold.co/15x15/9E765B/9E765B.png) `#9E765B`|
|Dunkelgrün RLM 71|4781AP|Italeri Acrylic Paint|53|69|49|![#354531](https://placehold.co/15x15/354531/354531.png) `#354531`|
|Earth Red|4707AP|Italeri Acrylic Paint|133|95|48|![#855F30](https://placehold.co/15x15/855F30/855F30.png) `#855F30`|
|Euro I Dark Green|4729AP|Italeri Acrylic Paint|59|102|87|![#3B6657](https://placehold.co/15x15/3B6657/3B6657.png) `#3B6657`|
|Extra Dark Sea Grey|4312AP|Italeri Acrylic Paint|53|63|58|![#353F3A](https://placehold.co/15x15/353F3A/353F3A.png) `#353F3A`|
|Field Drab|4708AP|Italeri Acrylic Paint|114|91|60|![#725B3C](https://placehold.co/15x15/725B3C/725B3C.png) `#725B3C`|
|Flat Brown 383|4858AP|Italeri Acrylic Paint|79|66|57|![#4F4239](https://placehold.co/15x15/4F4239/4F4239.png) `#4F4239`|
|Flat Desert Tan|4859AP|Italeri Acrylic Paint|177|159|123|![#B19F7B](https://placehold.co/15x15/B19F7B/B19F7B.png) `#B19F7B`|
|Flat Green|4862AP|Italeri Acrylic Paint|99|103|80|![#636750](https://placehold.co/15x15/636750/636750.png) `#636750`|
|Flat Green 383|4857AP|Italeri Acrylic Paint|62|75|57|![#3E4B39](https://placehold.co/15x15/3E4B39/3E4B39.png) `#3E4B39`|
|Flat Grey Green RLM. 66|4853AP|Italeri Acrylic Paint|91|94|95|![#5B5E5F](https://placehold.co/15x15/5B5E5F/5B5E5F.png) `#5B5E5F`|
|Flat Italian Interior Green|4855AP|Italeri Acrylic Paint|168|187|154|![#A8BB9A](https://placehold.co/15x15/A8BB9A/A8BB9A.png) `#A8BB9A`|
|Flat Ocean Grey|4854AP|Italeri Acrylic Paint|116|121|123|![#74797B](https://placehold.co/15x15/74797B/74797B.png) `#74797B`|
|Flat Rubber|4861AP|Italeri Acrylic Paint|88|91|91|![#585B5B](https://placehold.co/15x15/585B5B/585B5B.png) `#585B5B`|
|Flat Sandgelb RAL.1002|4860AP|Italeri Acrylic Paint|198|166|100|![#C6A664](https://placehold.co/15x15/C6A664/C6A664.png) `#C6A664`|
|Flat Sky Type's|4856AP|Italeri Acrylic Paint|182|196|171|![#B6C4AB](https://placehold.co/15x15/B6C4AB/B6C4AB.png) `#B6C4AB`|
|French Blue|4659AP|Italeri Acrylic Paint|0|104|173|![#0068AD](https://placehold.co/15x15/0068AD/0068AD.png) `#0068AD`|
|Giallo Mimetico 3|4645AP|Italeri Acrylic Paint|201|151|59|![#C9973B](https://placehold.co/15x15/C9973B/C9973B.png) `#C9973B`|
|Giallo Mimetico 4|4646AP|Italeri Acrylic Paint|166|130|73|![#A68249](https://placehold.co/15x15/A68249/A68249.png) `#A68249`|
|Gold|4671AP|Italeri Acrylic Paint|234|177|36|![#EAB124](https://placehold.co/15x15/EAB124/EAB124.png) `#EAB124`|
|Grau RLM 02|4770AP|Italeri Acrylic Paint|100|91|66|![#645B42](https://placehold.co/15x15/645B42/645B42.png) `#645B42`|
|Graugrün RLM 74|4784AP|Italeri Acrylic Paint|50|59|59|![#323B3B](https://placehold.co/15x15/323B3B/323B3B.png) `#323B3B`|
|Grauviolett RLM 75|4785AP|Italeri Acrylic Paint|108|106|101|![#6C6A65](https://placehold.co/15x15/6C6A65/6C6A65.png) `#6C6A65`|
|Green|4669AP|Italeri Acrylic Paint|0|109|68|![#006D44](https://placehold.co/15x15/006D44/006D44.png) `#006D44`|
|Guards Red|4632AP|Italeri Acrylic Paint|196|33|39|![#C42127](https://placehold.co/15x15/C42127/C42127.png) `#C42127`|
|Gull Gray|4763AP|Italeri Acrylic Paint|225|225|215|![#E1E1D7](https://placehold.co/15x15/E1E1D7/E1E1D7.png) `#E1E1D7`|
|Gun Metal|4681AP|Italeri Acrylic Paint|47|55|57|![#2F3739](https://placehold.co/15x15/2F3739/2F3739.png) `#2F3739`|
|Gunship Gray|4752AP|Italeri Acrylic Paint|29|52|58|![#1D343A](https://placehold.co/15x15/1D343A/1D343A.png) `#1D343A`|
|Hellblau RLM 65|4778AP|Italeri Acrylic Paint|139|184|178|![#8BB8B2](https://placehold.co/15x15/8BB8B2/8BB8B2.png) `#8BB8B2`|
|Insigna Red|4714AP|Italeri Acrylic Paint|167|30|41|![#A71E29](https://placehold.co/15x15/A71E29/A71E29.png) `#A71E29`|
|Insigna Yellow|4721AP|Italeri Acrylic Paint|254|224|0|![#FEE000](https://placehold.co/15x15/FEE000/FEE000.png) `#FEE000`|
|Interior Green|4736AP|Italeri Acrylic Paint|109|97|41|![#6D6129](https://placehold.co/15x15/6D6129/6D6129.png) `#6D6129`|
|Interior Grey Green|4301AP|Italeri Acrylic Paint|50|94|47|![#325E2F](https://placehold.co/15x15/325E2F/325E2F.png) `#325E2F`|
|Leather|4674AP|Italeri Acrylic Paint|147|62|49|![#933E31](https://placehold.co/15x15/933E31/933E31.png) `#933E31`|
|Lichtblau RLM 76|4786AP|Italeri Acrylic Paint|200|213|210|![#C8D5D2](https://placehold.co/15x15/C8D5D2/C8D5D2.png) `#C8D5D2`|
|Light Blue|4650AP|Italeri Acrylic Paint|61|193|199|![#3DC1C7](https://placehold.co/15x15/3DC1C7/3DC1C7.png) `#3DC1C7`|
|Light Brown|4305AP|Italeri Acrylic Paint|162|113|86|![#A27156](https://placehold.co/15x15/A27156/A27156.png) `#A27156`|
|Light Flesh|4390AP|Italeri Acrylic Paint|224|198|143|![#E0C68F](https://placehold.co/15x15/E0C68F/E0C68F.png) `#E0C68F`|
|Light Ghost Gray|4762AP|Italeri Acrylic Paint|151|167|178|![#97A7B2](https://placehold.co/15x15/97A7B2/97A7B2.png) `#97A7B2`|
|Light Gray|4765AP|Italeri Acrylic Paint|239|238|239|![#EFEEEF](https://placehold.co/15x15/EFEEEF/EFEEEF.png) `#EFEEEF`|
|Light Green|4309AP|Italeri Acrylic Paint|102|112|47|![#66702F](https://placehold.co/15x15/66702F/66702F.png) `#66702F`|
|Marrone Mimetico|4640AP|Italeri Acrylic Paint|132|54|48|![#843630](https://placehold.co/15x15/843630/843630.png) `#843630`|
|Marrone Mimetico 2|4641AP|Italeri Acrylic Paint|114|91|60|![#725B3C](https://placehold.co/15x15/725B3C/725B3C.png) `#725B3C`|
|Medium Blue|4307AP|Italeri Acrylic Paint|0|88|169|![#0058A9](https://placehold.co/15x15/0058A9/0058A9.png) `#0058A9`|
|Medium Brown|4306AP|Italeri Acrylic Paint|143|81|65|![#8F5141](https://placehold.co/15x15/8F5141/8F5141.png) `#8F5141`|
|Medium Gray|4746AP|Italeri Acrylic Paint|113|120|123|![#71787B](https://placehold.co/15x15/71787B/71787B.png) `#71787B`|
|Medium Green I|4314AP|Italeri Acrylic Paint|75|101|83|![#4B6553](https://placehold.co/15x15/4B6553/4B6553.png) `#4B6553`|
|Medium Green II|4734AP|Italeri Acrylic Paint|72|99|63|![#48633F](https://placehold.co/15x15/48633F/48633F.png) `#48633F`|
|Medium Sea Grey|4313AP|Italeri Acrylic Paint|142|148|147|![#8E9493](https://placehold.co/15x15/8E9493/8E9493.png) `#8E9493`|
|Middle Stone|4304AP|Italeri Acrylic Paint|168|127|72|![#A87F48](https://placehold.co/15x15/A87F48/A87F48.png) `#A87F48`|
|Military Green|4852AP|Italeri Acrylic Paint|88|81|56|![#585138](https://placehold.co/15x15/585138/585138.png) `#585138`|
|Nocciola Chiaro|4643AP|Italeri Acrylic Paint|158|118|91|![#9E765B](https://placehold.co/15x15/9E765B/9E765B.png) `#9E765B`|
|Non Specular Blue Grey|4766AP|Italeri Acrylic Paint|62|96|102|![#3E6066](https://placehold.co/15x15/3E6066/3E6066.png) `#3E6066`|
|Non Specular Intermediate Blue|4639AP|Italeri Acrylic Paint|96|124|127|![#607C7F](https://placehold.co/15x15/607C7F/607C7F.png) `#607C7F`|
|Non Specular Sea Blue|4604AP|Italeri Acrylic Paint|50|57|61|![#32393D](https://placehold.co/15x15/32393D/32393D.png) `#32393D`|
|Olive Drab|4315AP|Italeri Acrylic Paint|87|92|68|![#575C44](https://placehold.co/15x15/575C44/575C44.png) `#575C44`|
|Olive Drab Ana 613|4842AP|Italeri Acrylic Paint|62|68|47|![#3E442F](https://placehold.co/15x15/3E442F/3E442F.png) `#3E442F`|
|Olive Drab US Army|4728AP|Italeri Acrylic Paint|63|71|66|![#3F4742](https://placehold.co/15x15/3F4742/3F4742.png) `#3F4742`|
|Orange|4682AP|Italeri Acrylic Paint|229|92|0|![#E55C00](https://placehold.co/15x15/E55C00/E55C00.png) `#E55C00`|
|Orange|4302AP|Italeri Acrylic Paint|232|73|37|![#E84925](https://placehold.co/15x15/E84925/E84925.png) `#E84925`|
|Pale Green|4739AP|Italeri Acrylic Paint|100|168|121|![#64A879](https://placehold.co/15x15/64A879/64A879.png) `#64A879`|
|Panzer Dunkelgelb 1943|4796AP|Italeri Acrylic Paint|162|146|76|![#A2924C](https://placehold.co/15x15/A2924C/A2924C.png) `#A2924C`|
|Panzer Olivgrün 1943|4798AP|Italeri Acrylic Paint|0|70|31|![#00461F](https://placehold.co/15x15/00461F/00461F.png) `#00461F`|
|Pz. Schokobraun RAL 8017|4797AP|Italeri Acrylic Paint|61|38|36|![#3D2624](https://placehold.co/15x15/3D2624/3D2624.png) `#3D2624`|
|Pz. Schwarzgrau RAL 7021|4795AP|Italeri Acrylic Paint|36|64|59|![#24403B](https://placehold.co/15x15/24403B/24403B.png) `#24403B`|
|Red|4605AP|Italeri Acrylic Paint|193|48|39|![#C13027](https://placehold.co/15x15/C13027/C13027.png) `#C13027`|
|Red|4606AP|Italeri Acrylic Paint|213|43|39|![#D52B27](https://placehold.co/15x15/D52B27/D52B27.png) `#D52B27`|
|Russian Armor Green|4807AP|Italeri Acrylic Paint|61|83|70|![#3D5346](https://placehold.co/15x15/3D5346/3D5346.png) `#3D5346`|
|Rust|4675AP|Italeri Acrylic Paint|130|52|48|![#823430](https://placehold.co/15x15/823430/823430.png) `#823430`|
|Sand|4720AP|Italeri Acrylic Paint|185|158|108|![#B99E6C](https://placehold.co/15x15/B99E6C/B99E6C.png) `#B99E6C`|
|Sandgelb RLM 79|4789AP|Italeri Acrylic Paint|170|121|88|![#AA7958](https://placehold.co/15x15/AA7958/AA7958.png) `#AA7958`|
|Schwarzgrün RLM 70|4780AP|Italeri Acrylic Paint|23|50|51|![#173233](https://placehold.co/15x15/173233/173233.png) `#173233`|
|Silver|4678AP|Italeri Acrylic Paint|197|206|203|![#C5CECB](https://placehold.co/15x15/C5CECB/C5CECB.png) `#C5CECB`|
|Skin Tone Tint Base - Light|4601AP|Italeri Acrylic Paint|245|186|134|![#F5BA86](https://placehold.co/15x15/F5BA86/F5BA86.png) `#F5BA86`|
|Skin Tone Warm Tint|4603AP|Italeri Acrylic Paint|223|171|110|![#DFAB6E](https://placehold.co/15x15/DFAB6E/DFAB6E.png) `#DFAB6E`|
|Steel|4679AP|Italeri Acrylic Paint|123|124|116|![#7B7C74](https://placehold.co/15x15/7B7C74/7B7C74.png) `#7B7C74`|
|US Army / Mar.Gulf Arm Sand|4812AP|Italeri Acrylic Paint|187|122|71|![#BB7A47](https://placehold.co/15x15/BB7A47/BB7A47.png) `#BB7A47`|
|Verde Mimetico 2|4723AP|Italeri Acrylic Paint|47|72|63|![#2F483F](https://placehold.co/15x15/2F483F/2F483F.png) `#2F483F`|
|White|4696AP|Italeri Acrylic Paint|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|White|4769AP|Italeri Acrylic Paint|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Wood|4673AP|Italeri Acrylic Paint|180|143|65|![#B48F41](https://placehold.co/15x15/B48F41/B48F41.png) `#B48F41`|
|Yellow|4642AP|Italeri Acrylic Paint|243|154|31|![#F39A1F](https://placehold.co/15x15/F39A1F/F39A1F.png) `#F39A1F`|
<p align="center"><img src="../logos/logo_rnd.png" height="70" /></p>
<p align="center">Made available by <a href="https://miniaturepainterpro.app/">Miniature Painter Pro</a></p>
<p align="center">
<a href="https://play.google.com/store/apps/details?id=com.rfsp.paintmaster"> <img src="../logos/Android.png" height="30" /></a>
<a href="https://apps.apple.com/us/app/miniature-painter-pro/id1495938928"> <img src="../logos/iOS.png" height="30" /></a>
</p>
