# Mr Hobby
![MrHobby](../logos/MrHobby.png "MrHobby")

|Name|Code|Set|R|G|B|Hex|
|---|---|---|---|---|---|---|
||UG1|Mr Color Gundam Color|241|247|250|![#F1F7FA](https://placehold.co/15x15/F1F7FA/F1F7FA.png) `#F1F7FA`|
|A.E.U.G'.s MS Blue|UG14|Mr Color Gundam Color|66|123|191|![#427BBF](https://placehold.co/15x15/427BBF/427BBF.png) `#427BBF`|
|A.E.U.G'.s MS Blue|SG14|Gundam Color Spray|66|123|191|![#427BBF](https://placehold.co/15x15/427BBF/427BBF.png) `#427BBF`|
|Air Superiority Blue|74|Mr Color|0|109|121|![#006D79](https://placehold.co/15x15/006D79/006D79.png) `#006D79`|
|Aircraft Gray|H57|Aqueous Hobby Color|114|154|150|![#729A96](https://placehold.co/15x15/729A96/729A96.png) `#729A96`|
|Aircraft Gray|N57|Acrysion|114|154|150|![#729A96](https://placehold.co/15x15/729A96/729A96.png) `#729A96`|
|Aircraft Gray|73|Mr Color|114|154|150|![#729A96](https://placehold.co/15x15/729A96/729A96.png) `#729A96`|
|Aircraft Gray Green Bs283|364|Mr Color|104|130|93|![#68825D](https://placehold.co/15x15/68825D/68825D.png) `#68825D`|
|Aluminium|218|Mr Metal Color|164|164|165|![#A4A4A5](https://placehold.co/15x15/A4A4A5/A4A4A5.png) `#A4A4A5`|
|Amethyst Purple|XC04|Mr Crystal Color|193|191|228|![#C1BFE4](https://placehold.co/15x15/C1BFE4/C1BFE4.png) `#C1BFE4`|
|Azure Blue|370|Mr Color|88|133|179|![#5885B3](https://placehold.co/15x15/5885B3/5885B3.png) `#5885B3`|
|Barley Gray Bs4800/18b21|334|Mr Color|130|150|147|![#829693](https://placehold.co/15x15/829693/829693.png) `#829693`|
|Barley Gray Bs4800/18b21 A|H334|Aqueous Hobby Color|77|145|154|![#4D919A](https://placehold.co/15x15/4D919A/4D919A.png) `#4D919A`|
|Black|H2|Aqueous Hobby Color|0|0|0|![#000000](https://placehold.co/15x15/000000/000000.png) `#000000`|
|Black|SP2|Mr Color Spray|0|0|0|![#000000](https://placehold.co/15x15/000000/000000.png) `#000000`|
|Black|2|Mr Color|0|0|0|![#000000](https://placehold.co/15x15/000000/000000.png) `#000000`|
|Black|N2|Acrysion|0|0|0|![#000000](https://placehold.co/15x15/000000/000000.png) `#000000`|
|Black Brown|H462|Aqueous Hobby Color|78|60|51|![#4E3C33](https://placehold.co/15x15/4E3C33/4E3C33.png) `#4E3C33`|
|Blue|SP5|Mr Color Spray|0|84|167|![#0054A7](https://placehold.co/15x15/0054A7/0054A7.png) `#0054A7`|
|Blue|H5|Aqueous Hobby Color|0|78|162|![#004EA2](https://placehold.co/15x15/004EA2/004EA2.png) `#004EA2`|
|Blue|5|Mr Color|0|78|162|![#004EA2](https://placehold.co/15x15/004EA2/004EA2.png) `#004EA2`|
|Blue|N5|Acrysion|0|78|162|![#004EA2](https://placehold.co/15x15/004EA2/004EA2.png) `#004EA2`|
|Blue Fs15044|326|Mr Color|30|48|70|![#1E3046](https://placehold.co/15x15/1E3046/1E3046.png) `#1E3046`|
|Blue Fs15044 A|H326|Aqueous Hobby Color|31|49|52|![#1F3134](https://placehold.co/15x15/1F3134/1F3134.png) `#1F3134`|
|Blue Fs15050|328|Mr Color|25|52|81|![#193451](https://placehold.co/15x15/193451/193451.png) `#193451`|
|Blue Fs15050 A|H328|Aqueous Hobby Color|30|48|66|![#1E3042](https://placehold.co/15x15/1E3042/1E3042.png) `#1E3042`|
|Blue Fs35622|H314|Aqueous Hobby Color|230|244|243|![#E6F4F3](https://placehold.co/15x15/E6F4F3/E6F4F3.png) `#E6F4F3`|
|Blue Fs35622|314|Mr Color|235|245|236|![#EBF5EC](https://placehold.co/15x15/EBF5EC/EBF5EC.png) `#EBF5EC`|
|Blue Gold|GX210|Mr Metallic Color GX|181|152|88|![#B59858](https://placehold.co/15x15/B59858/B59858.png) `#B59858`|
|Blue Gray|H42|Aqueous Hobby Color|50|106|139|![#326A8B](https://placehold.co/15x15/326A8B/326A8B.png) `#326A8B`|
|Blue Gray Fs35189|367|Mr Color|112|146|154|![#70929A](https://placehold.co/15x15/70929A/70929A.png) `#70929A`|
|Brass|219|Mr Metal Color|151|88|41|![#975829](https://placehold.co/15x15/975829/975829.png) `#975829`|
|Bright Blue|SP65|Mr Color Spray|0|64|152|![#004098](https://placehold.co/15x15/004098/004098.png) `#004098`|
|Bright Blue|65|Mr Color|0|64|152|![#004098](https://placehold.co/15x15/004098/004098.png) `#004098`|
|Bright Blue|N15|Acrysion|0|64|152|![#004098](https://placehold.co/15x15/004098/004098.png) `#004098`|
|Bright Blue|H15|Aqueous Hobby Color|0|64|152|![#004098](https://placehold.co/15x15/004098/004098.png) `#004098`|
|Bright Green|N26|Acrysion|0|153|68|![#009944](https://placehold.co/15x15/009944/009944.png) `#009944`|
|Bright Green|66|Mr Color|0|153|68|![#009944](https://placehold.co/15x15/009944/009944.png) `#009944`|
|Bright Green|H26|Aqueous Hobby Color|0|153|68|![#009944](https://placehold.co/15x15/009944/009944.png) `#009944`|
|Bright Green|SP66|Mr Color Spray|0|153|68|![#009944](https://placehold.co/15x15/009944/009944.png) `#009944`|
|Bronze|216|Mr Metal Color|55|136|84|![#378854](https://placehold.co/15x15/378854/378854.png) `#378854`|
|Bronzegrun|519|Mr Color|60|76|55|![#3C4C37](https://placehold.co/15x15/3C4C37/3C4C37.png) `#3C4C37`|
|Brown|N7|Acrysion|202|58|41|![#CA3A29](https://placehold.co/15x15/CA3A29/CA3A29.png) `#CA3A29`|
|Brown|7|Mr Color|202|58|41|![#CA3A29](https://placehold.co/15x15/CA3A29/CA3A29.png) `#CA3A29`|
|Brown|H7|Aqueous Hobby Color|202|58|41|![#CA3A29](https://placehold.co/15x15/CA3A29/CA3A29.png) `#CA3A29`|
|Brown 3606|517|Mr Color|79|58|41|![#4F3A29](https://placehold.co/15x15/4F3A29/4F3A29.png) `#4F3A29`|
|Brown Fs30219|310|Mr Color|114|98|78|![#72624E](https://placehold.co/15x15/72624E/72624E.png) `#72624E`|
|Brown Fs30219|H310|Aqueous Hobby Color|73|75|60|![#494B3C](https://placehold.co/15x15/494B3C/494B3C.png) `#494B3C`|
|Burnt Iron|N76|Acrysion|77|79|82|![#4D4F52](https://placehold.co/15x15/4D4F52/4D4F52.png) `#4D4F52`|
|Burnt Iron|H76|Aqueous Hobby Color|136|128|132|![#888084](https://placehold.co/15x15/888084/888084.png) `#888084`|
|Burnt Iron|61|Mr Color|77|79|82|![#4D4F52](https://placehold.co/15x15/4D4F52/4D4F52.png) `#4D4F52`|
|Carmine Red|H367|Aqueous Hobby Color|168|44|41|![#A82C29](https://placehold.co/15x15/A82C29/A82C29.png) `#A82C29`|
|Cement Gray|H455|Aqueous Hobby Color|177|169|145|![#B1A991](https://placehold.co/15x15/B1A991/B1A991.png) `#B1A991`|
|Chalky White|H451|Aqueous Hobby Color|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Character Blue|110|Mr Color|0|64|152|![#004098](https://placehold.co/15x15/004098/004098.png) `#004098`|
|Character Blue|SP110|Mr Color Spray|0|64|152|![#004098](https://placehold.co/15x15/004098/004098.png) `#004098`|
|Character Flesh (1)|SP111|Mr Color Spray|252|227|214|![#FCE3D6](https://placehold.co/15x15/FCE3D6/FCE3D6.png) `#FCE3D6`|
|Character Flesh (1)|111|Mr Color|252|227|214|![#FCE3D6](https://placehold.co/15x15/FCE3D6/FCE3D6.png) `#FCE3D6`|
|Character Flesh (2)|SP112|Mr Color Spray|246|188|184|![#F6BCB8](https://placehold.co/15x15/F6BCB8/F6BCB8.png) `#F6BCB8`|
|Character Flesh (2)|112|Mr Color|246|188|184|![#F6BCB8](https://placehold.co/15x15/F6BCB8/F6BCB8.png) `#F6BCB8`|
|Character Red|SP108|Mr Color Spray|200|22|30|![#C8161E](https://placehold.co/15x15/C8161E/C8161E.png) `#C8161E`|
|Character Red|108|Mr Color|200|22|30|![#C8161E](https://placehold.co/15x15/C8161E/C8161E.png) `#C8161E`|
|Character White|107|Mr Color|245|246|244|![#F5F6F4](https://placehold.co/15x15/F5F6F4/F5F6F4.png) `#F5F6F4`|
|Character White|SP107|Mr Color Spray|245|246|244|![#F5F6F4](https://placehold.co/15x15/F5F6F4/F5F6F4.png) `#F5F6F4`|
|Character Yellow|SP109|Mr Color Spray|240|131|0|![#F08300](https://placehold.co/15x15/F08300/F08300.png) `#F08300`|
|Character Yellow|109|Mr Color|240|131|0|![#F08300](https://placehold.co/15x15/F08300/F08300.png) `#F08300`|
|Chiara Yellow|GX4|Mr Color GX|255|225|0|![#FFE100](https://placehold.co/15x15/FFE100/FFE100.png) `#FFE100`|
|Chocolate Brown T|H406|Aqueous Hobby Color|73|47|50|![#492F32](https://placehold.co/15x15/492F32/492F32.png) `#492F32`|
|Chromate Yellow Primer Fs33481|352|Mr Color|186|163|16|![#BAA310](https://placehold.co/15x15/BAA310/BAA310.png) `#BAA310`|
|Chrome Green|H464|Aqueous Hobby Color|86|103|58|![#56673A](https://placehold.co/15x15/56673A/56673A.png) `#56673A`|
|Chrome Silver|211|Mr Metal Color|164|164|165|![#A4A4A5](https://placehold.co/15x15/A4A4A5/A4A4A5.png) `#A4A4A5`|
|Clear|H30|Aqueous Hobby Color|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Clear|SP46|Mr Color Spray|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Clear|46|Mr Color|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Clear|N30|Acrysion|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Clear Black|GX101|Mr Clear Color GX|117|131|153|![#758399](https://placehold.co/15x15/758399/758399.png) `#758399`|
|Clear Blue|SP50|Mr Color Spray|0|160|233|![#00A0E9](https://placehold.co/15x15/00A0E9/00A0E9.png) `#00A0E9`|
|Clear Blue|H93|Aqueous Hobby Color|0|160|233|![#00A0E9](https://placehold.co/15x15/00A0E9/00A0E9.png) `#00A0E9`|
|Clear Blue|50|Mr Color|0|160|233|![#00A0E9](https://placehold.co/15x15/00A0E9/00A0E9.png) `#00A0E9`|
|Clear Blue|N93|Acrysion|0|160|233|![#00A0E9](https://placehold.co/15x15/00A0E9/00A0E9.png) `#00A0E9`|
|Clear Brown|GX109|Mr Clear Color GX|212|157|49|![#D49D31](https://placehold.co/15x15/D49D31/D49D31.png) `#D49D31`|
|Clear Gold|GX111|Mr Clear Color GX|183|131|30|![#B7831E](https://placehold.co/15x15/B7831E/B7831E.png) `#B7831E`|
|Clear Green|N94|Acrysion|0|153|68|![#009944](https://placehold.co/15x15/009944/009944.png) `#009944`|
|Clear Green|138|Mr Color|0|153|68|![#009944](https://placehold.co/15x15/009944/009944.png) `#009944`|
|Clear Green|GX104|Mr Clear Color GX|2|168|97|![#02A861](https://placehold.co/15x15/02A861/02A861.png) `#02A861`|
|Clear Orange|SP49|Mr Color Spray|235|97|0|![#EB6100](https://placehold.co/15x15/EB6100/EB6100.png) `#EB6100`|
|Clear Orange|N92|Acrysion|235|97|0|![#EB6100](https://placehold.co/15x15/EB6100/EB6100.png) `#EB6100`|
|Clear Orange|GX106|Mr Clear Color GX|236|91|0|![#EC5B00](https://placehold.co/15x15/EC5B00/EC5B00.png) `#EC5B00`|
|Clear Orange|49|Mr Color|235|97|0|![#EB6100](https://placehold.co/15x15/EB6100/EB6100.png) `#EB6100`|
|Clear Orange|H92|Aqueous Hobby Color|235|97|0|![#EB6100](https://placehold.co/15x15/EB6100/EB6100.png) `#EB6100`|
|Clear Pale Brown|SM215|Mr Color Lascivus|244|162|106|![#F4A26A](https://placehold.co/15x15/F4A26A/F4A26A.png) `#F4A26A`|
|Clear Pale Orange|SM214|Mr Color Lascivus|251|211|160|![#FBD3A0](https://placehold.co/15x15/FBD3A0/FBD3A0.png) `#FBD3A0`|
|Clear Pale Red|SM213|Mr Color Lascivus|250|207|199|![#FACFC7](https://placehold.co/15x15/FACFC7/FACFC7.png) `#FACFC7`|
|Clear Pink|GX105|Mr Clear Color GX|223|84|146|![#DF5492](https://placehold.co/15x15/DF5492/DF5492.png) `#DF5492`|
|Clear Purple|GX107|Mr Clear Color GX|91|78|163|![#5B4EA3](https://placehold.co/15x15/5B4EA3/5B4EA3.png) `#5B4EA3`|
|Clear Red|N90|Acrysion|230|0|18|![#E60012](https://placehold.co/15x15/E60012/E60012.png) `#E60012`|
|Clear Red|47|Mr Color|230|0|18|![#E60012](https://placehold.co/15x15/E60012/E60012.png) `#E60012`|
|Clear Red|H90|Aqueous Hobby Color|230|0|18|![#E60012](https://placehold.co/15x15/E60012/E60012.png) `#E60012`|
|Clear Red|SP47|Mr Color Spray|230|0|18|![#E60012](https://placehold.co/15x15/E60012/E60012.png) `#E60012`|
|Clear Silver|GX110|Mr Clear Color GX|191|186|175|![#BFBAAF](https://placehold.co/15x15/BFBAAF/BFBAAF.png) `#BFBAAF`|
|Clear Violet|GX108|Mr Clear Color GX|69|37|138|![#45258A](https://placehold.co/15x15/45258A/45258A.png) `#45258A`|
|Clear Yellow|48|Mr Color|255|217|0|![#FFD900](https://placehold.co/15x15/FFD900/FFD900.png) `#FFD900`|
|Clear Yellow|N91|Acrysion|255|217|0|![#FFD900](https://placehold.co/15x15/FFD900/FFD900.png) `#FFD900`|
|Clear Yellow|SP48|Mr Color Spray|255|217|0|![#FFD900](https://placehold.co/15x15/FFD900/FFD900.png) `#FFD900`|
|Clear Yellow|H91|Aqueous Hobby Color|255|217|0|![#FFD900](https://placehold.co/15x15/FFD900/FFD900.png) `#FFD900`|
|Cobalt Blue|N35|Acrysion|29|32|136|![#1D2088](https://placehold.co/15x15/1D2088/1D2088.png) `#1D2088`|
|Cobalt Blue|80|Mr Color|29|32|136|![#1D2088](https://placehold.co/15x15/1D2088/1D2088.png) `#1D2088`|
|Cobalt Blue|H465|Aqueous Hobby Color|0|53|89|![#003559](https://placehold.co/15x15/003559/003559.png) `#003559`|
|Cobalt Blue|H35|Aqueous Hobby Color|29|32|136|![#1D2088](https://placehold.co/15x15/1D2088/1D2088.png) `#1D2088`|
|Cobalt Blue|SP80|Mr Color Spray|29|32|136|![#1D2088](https://placehold.co/15x15/1D2088/1D2088.png) `#1D2088`|
|Cockpit Color (Kawanishi)|384|Mr Color|123|127|62|![#7B7F3E](https://placehold.co/15x15/7B7F3E/7B7F3E.png) `#7B7F3E`|
|Cockpit Color (Mitsubishi)|126|Mr Color|70|99|65|![#466341](https://placehold.co/15x15/466341/466341.png) `#466341`|
|Cockpit Color (Nakajima)|127|Mr Color|169|182|120|![#A9B678](https://placehold.co/15x15/A9B678/A9B678.png) `#A9B678`|
|Cockpit Color (Nakajima)|N127|Acrysion|169|182|120|![#A9B678](https://placehold.co/15x15/A9B678/A9B678.png) `#A9B678`|
|Cocoa Brown|H17|Aqueous Hobby Color|85|46|49|![#552E31](https://placehold.co/15x15/552E31/552E31.png) `#552E31`|
|Cocoa Milk|SM212|Mr Color Lascivus|169|128|113|![#A98071](https://placehold.co/15x15/A98071/A98071.png) `#A98071`|
|Cool White|GX1|Mr Color GX|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Copper|215|Mr Metal Color|201|101|73|![#C96549](https://placehold.co/15x15/C96549/C96549.png) `#C96549`|
|Copper|10|Mr Color|206|114|42|![#CE722A](https://placehold.co/15x15/CE722A/CE722A.png) `#CE722A`|
|Copper|H10|Aqueous Hobby Color|206|114|42|![#CE722A](https://placehold.co/15x15/CE722A/CE722A.png) `#CE722A`|
|Copper|N10|Acrysion|206|114|42|![#CE722A](https://placehold.co/15x15/CE722A/CE722A.png) `#CE722A`|
|Cowling Color|125|Mr Color|0|0|0|![#000000](https://placehold.co/15x15/000000/000000.png) `#000000`|
|Cream Yellow|N34|Acrysion|230|166|0|![#E6A600](https://placehold.co/15x15/E6A600/E6A600.png) `#E6A600`|
|Cream Yellow|H34|Aqueous Hobby Color|230|166|0|![#E6A600](https://placehold.co/15x15/E6A600/E6A600.png) `#E6A600`|
|Cyan|CR1|Primary Color Pigments|0|160|233|![#00A0E9](https://placehold.co/15x15/00A0E9/00A0E9.png) `#00A0E9`|
|Dark Earth|N72|Acrysion|79|73|60|![#4F493C](https://placehold.co/15x15/4F493C/4F493C.png) `#4F493C`|
|Dark Earth|22|Mr Color|79|73|60|![#4F493C](https://placehold.co/15x15/4F493C/4F493C.png) `#4F493C`|
|Dark Earth|H72|Aqueous Hobby Color|139|120|68|![#8B7844](https://placehold.co/15x15/8B7844/8B7844.png) `#8B7844`|
|Dark Earth Bs381c/450|369|Mr Color|96|81|50|![#605132](https://placehold.co/15x15/605132/605132.png) `#605132`|
|Dark Gray "Dunkel Grau"|513|Mr Color|62|79|95|![#3E4F5F](https://placehold.co/15x15/3E4F5F/3E4F5F.png) `#3E4F5F`|
|Dark Gray (1)|31|Mr Color|144|150|148|![#909694](https://placehold.co/15x15/909694/909694.png) `#909694`|
|Dark Gray (1)|SP31|Mr Color Spray|61|113|93|![#3D715D](https://placehold.co/15x15/3D715D/3D715D.png) `#3D715D`|
|Dark Gray (1)|H82|Aqueous Hobby Color|159|159|155|![#9F9F9B](https://placehold.co/15x15/9F9F9B/9F9F9B.png) `#9F9F9B`|
|Dark Gray (2)|32|Mr Color|58|85|90|![#3A555A](https://placehold.co/15x15/3A555A/3A555A.png) `#3A555A`|
|Dark Gray (2)|SP32|Mr Color Spray|58|85|90|![#3A555A](https://placehold.co/15x15/3A555A/3A555A.png) `#3A555A`|
|Dark Gray (2)|H83|Aqueous Hobby Color|114|112|109|![#72706D](https://placehold.co/15x15/72706D/72706D.png) `#72706D`|
|Dark Gray T|H401|Aqueous Hobby Color|17|60|65|![#113C41](https://placehold.co/15x15/113C41/113C41.png) `#113C41`|
|Dark Green|H320|Aqueous Hobby Color|10|64|56|![#0A4038](https://placehold.co/15x15/0A4038/0A4038.png) `#0A4038`|
|Dark Green|70|Mr Color|33|66|58|![#21423A](https://placehold.co/15x15/21423A/21423A.png) `#21423A`|
|Dark Green|SP70|Mr Color Spray|33|66|58|![#21423A](https://placehold.co/15x15/21423A/21423A.png) `#21423A`|
|Dark Green|320|Mr Color|60|85|69|![#3C5545](https://placehold.co/15x15/3C5545/3C5545.png) `#3C5545`|
|Dark Green|H36|Aqueous Hobby Color|49|72|54|![#314836](https://placehold.co/15x15/314836/314836.png) `#314836`|
|Dark Green|H73|Aqueous Hobby Color|65|93|71|![#415D47](https://placehold.co/15x15/415D47/415D47.png) `#415D47`|
|Dark Green|N73|Acrysion|33|66|58|![#21423A](https://placehold.co/15x15/21423A/21423A.png) `#21423A`|
|Dark Green (2)|23|Mr Color|65|93|71|![#415D47](https://placehold.co/15x15/415D47/415D47.png) `#415D47`|
|Dark Green (Kawanishi)|383|Mr Color|0|71|59|![#00473B](https://placehold.co/15x15/00473B/00473B.png) `#00473B`|
|Dark Green (Kawasaki)|130|Mr Color|73|93|64|![#495D40](https://placehold.co/15x15/495D40/495D40.png) `#495D40`|
|Dark Green (Mitsubishi)|SP124|Mr Color Spray|0|66|59|![#00423B](https://placehold.co/15x15/00423B/00423B.png) `#00423B`|
|Dark Green (Mitsubishi)|124|Mr Color|0|78|32|![#004E20](https://placehold.co/15x15/004E20/004E20.png) `#004E20`|
|Dark Green (Nakajima)|129|Mr Color|69|100|77|![#45644D](https://placehold.co/15x15/45644D/45644D.png) `#45644D`|
|Dark Green (Nakajima)|SP129|Mr Color Spray|69|100|77|![#45644D](https://placehold.co/15x15/45644D/45644D.png) `#45644D`|
|Dark Green 3414|516|Mr Color|63|71|53|![#3F4735](https://placehold.co/15x15/3F4735/3F4735.png) `#3F4735`|
|Dark Green Bs381c/641|330|Mr Color|48|72|71|![#304847](https://placehold.co/15x15/304847/304847.png) `#304847`|
|Dark Green Bs381c/641 A|H330|Aqueous Hobby Color|25|55|55|![#193737](https://placehold.co/15x15/193737/193737.png) `#193737`|
|Dark Green Bs641|361|Mr Color|58|63|52|![#3A3F34](https://placehold.co/15x15/3A3F34/3A3F34.png) `#3A3F34`|
|Dark Iron|214|Mr Metal Color|0|0|0|![#000000](https://placehold.co/15x15/000000/000000.png) `#000000`|
|Dark Seagray|H75|Aqueous Hobby Color|112|129|104|![#708168](https://placehold.co/15x15/708168/708168.png) `#708168`|
|Dark Seagray|25|Mr Color|114|122|94|![#727A5E](https://placehold.co/15x15/727A5E/727A5E.png) `#727A5E`|
|Dark Seagray Bs381c 638|331|Mr Color|74|86|90|![#4A565A](https://placehold.co/15x15/4A565A/4A565A.png) `#4A565A`|
|Dark Seagray Bs381c/638 A|H331|Aqueous Hobby Color|10|63|67|![#0A3F43](https://placehold.co/15x15/0A3F43/0A3F43.png) `#0A3F43`|
|Dark Yellow|H403|Aqueous Hobby Color|203|176|71|![#CBB047](https://placehold.co/15x15/CBB047/CBB047.png) `#CBB047`|
|Dark Yellow|C39|Mr Color Modulation Set|166|132|64|![#A68440](https://placehold.co/15x15/A68440/A68440.png) `#A68440`|
|Dark Yellow|N79|Acrysion|191|157|90|![#BF9D5A](https://placehold.co/15x15/BF9D5A/BF9D5A.png) `#BF9D5A`|
|Dark Yellow (Sandy Yellow)|SP39|Mr Color Spray|191|157|90|![#BF9D5A](https://placehold.co/15x15/BF9D5A/BF9D5A.png) `#BF9D5A`|
|Dark Yellow (Sandy Yellow)|39|Mr Color|191|157|90|![#BF9D5A](https://placehold.co/15x15/BF9D5A/BF9D5A.png) `#BF9D5A`|
|Dark Yellow Highlight 1|CMC04|Mr Color Modulation Set|207|164|93|![#CFA45D](https://placehold.co/15x15/CFA45D/CFA45D.png) `#CFA45D`|
|Dark Yellow Highlight 2|CMC05|Mr Color Modulation Set|218|184|108|![#DAB86C](https://placehold.co/15x15/DAB86C/DAB86C.png) `#DAB86C`|
|Dark Yellow Shadow|CMC06|Mr Color Modulation Set|106|82|37|![#6A5225](https://placehold.co/15x15/6A5225/6A5225.png) `#6A5225`|
|Darkgray (1)|N82|Acrysion|144|150|148|![#909694](https://placehold.co/15x15/909694/909694.png) `#909694`|
|Darkgray (2)|N83|Acrysion|58|85|90|![#3A555A](https://placehold.co/15x15/3A555A/3A555A.png) `#3A555A`|
|Deep Clear Blue|GX103|Mr Clear Color GX|0|119|198|![#0077C6](https://placehold.co/15x15/0077C6/0077C6.png) `#0077C6`|
|Deep Clear Red|GX102|Mr Clear Color GX|203|35|47|![#CB232F](https://placehold.co/15x15/CB232F/CB232F.png) `#CB232F`|
|Diamond Silver|XC01|Mr Crystal Color|193|210|230|![#C1D2E6](https://placehold.co/15x15/C1D2E6/C1D2E6.png) `#C1D2E6`|
|Duck Egg Green|26|Mr Color|215|225|172|![#D7E1AC](https://placehold.co/15x15/D7E1AC/D7E1AC.png) `#D7E1AC`|
|Dust Brown|H456|Aqueous Hobby Color|106|72|50|![#6A4832](https://placehold.co/15x15/6A4832/6A4832.png) `#6A4832`|
|Earth Brown|H457|Aqueous Hobby Color|118|87|48|![#765730](https://placehold.co/15x15/765730/765730.png) `#765730`|
|Earth Green|132|Mr Color|104|89|50|![#685932](https://placehold.co/15x15/685932/685932.png) `#685932`|
|Emerald Green|H46|Aqueous Hobby Color|0|160|81|![#00A051](https://placehold.co/15x15/00A051/00A051.png) `#00A051`|
|Emerald Green|N46|Acrysion|0|160|81|![#00A051](https://placehold.co/15x15/00A051/00A051.png) `#00A051`|
|Engine Gray Fs16081|339|Mr Color|25|71|81|![#194751](https://placehold.co/15x15/194751/194751.png) `#194751`|
|Engine Gray Fs16081 A|H339|Aqueous Hobby Color|24|55|58|![#18373A](https://placehold.co/15x15/18373A/18373A.png) `#18373A`|
|Extra Dark Seagray Bs381c 640|333|Mr Color|25|71|81|![#194751](https://placehold.co/15x15/194751/194751.png) `#194751`|
|Extra Dark Seagray Bs381c/640 A|H333|Aqueous Hobby Color|12|62|69|![#0C3E45](https://placehold.co/15x15/0C3E45/0C3E45.png) `#0C3E45`|
|Faded Gray "Blassgrau"|515|Mr Color|90|124|134|![#5A7C86](https://placehold.co/15x15/5A7C86/5A7C86.png) `#5A7C86`|
|Field Gray (1)|H32|Aqueous Hobby Color|17|60|65|![#113C41](https://placehold.co/15x15/113C41/113C41.png) `#113C41`|
|Field Gray (2)|H48|Aqueous Hobby Color|43|78|73|![#2B4E49](https://placehold.co/15x15/2B4E49/2B4E49.png) `#2B4E49`|
|Field Gray (2)|52|Mr Color|43|78|73|![#2B4E49](https://placehold.co/15x15/2B4E49/2B4E49.png) `#2B4E49`|
|Field Green Fs34097|340|Mr Color|40|84|60|![#28543C](https://placehold.co/15x15/28543C/28543C.png) `#28543C`|
|Field Green Fs34097 A|H340|Aqueous Hobby Color|7|66|57|![#074239](https://placehold.co/15x15/074239/074239.png) `#074239`|
|Flat Base|30|Mr Color|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Flat Base|H40|Aqueous Hobby Color|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Flat Base|N40|Acrysion|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Flat Base Rough|188|Mr Color|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Flat Base Smooth|189|Mr Color|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Flat Black|N12|Acrysion|0|0|0|![#000000](https://placehold.co/15x15/000000/000000.png) `#000000`|
|Flat Black|H12|Aqueous Hobby Color|0|0|0|![#000000](https://placehold.co/15x15/000000/000000.png) `#000000`|
|Flat Black|SP33|Mr Color Spray|0|0|0|![#000000](https://placehold.co/15x15/000000/000000.png) `#000000`|
|Flat Black|33|Mr Color|0|0|0|![#000000](https://placehold.co/15x15/000000/000000.png) `#000000`|
|Flat Clear|182|Mr Color|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Flat Clear|H20|Aqueous Hobby Color|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Flat Clear|N20|Acrysion|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Flat Clear|SP30|Mr Color Spray|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Flat Red|H13|Aqueous Hobby Color|216|12|24|![#D80C18](https://placehold.co/15x15/D80C18/D80C18.png) `#D80C18`|
|Flat Red|N13|Acrysion|216|12|24|![#D80C18](https://placehold.co/15x15/D80C18/D80C18.png) `#D80C18`|
|Flat White|62|Mr Color|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Flat White|H11|Aqueous Hobby Color|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Flat White|SP62|Mr Color Spray|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Flat White|N11|Acrysion|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Flesh|N44|Acrysion|230|179|120|![#E6B378](https://placehold.co/15x15/E6B378/E6B378.png) `#E6B378`|
|Flesh|H44|Aqueous Hobby Color|230|179|120|![#E6B378](https://placehold.co/15x15/E6B378/E6B378.png) `#E6B378`|
|Flesh|51|Mr Color|230|179|120|![#E6B378](https://placehold.co/15x15/E6B378/E6B378.png) `#E6B378`|
|Fluorescent Green|175|Mr Color|0|153|68|![#009944](https://placehold.co/15x15/009944/009944.png) `#009944`|
|Fluorescent Green|N100|Acrysion|0|153|68|![#009944](https://placehold.co/15x15/009944/009944.png) `#009944`|
|Fluorescent Orange|173|Mr Color|231|36|16|![#E72410](https://placehold.co/15x15/E72410/E72410.png) `#E72410`|
|Fluorescent Orange|N98|Acrysion|231|36|16|![#E72410](https://placehold.co/15x15/E72410/E72410.png) `#E72410`|
|Fluorescent Pink|N99|Acrysion|229|0|106|![#E5006A](https://placehold.co/15x15/E5006A/E5006A.png) `#E5006A`|
|Fluorescent Pink|174|Mr Color|229|0|106|![#E5006A](https://placehold.co/15x15/E5006A/E5006A.png) `#E5006A`|
|Fluorescent Red|171|Mr Color|230|0|18|![#E60012](https://placehold.co/15x15/E60012/E60012.png) `#E60012`|
|Fluorescent Red|N101|Acrysion|230|0|18|![#E60012](https://placehold.co/15x15/E60012/E60012.png) `#E60012`|
|Fluorescent Yellow|N97|Acrysion|255|241|0|![#FFF100](https://placehold.co/15x15/FFF100/FFF100.png) `#FFF100`|
|Fluorescent Yellow|172|Mr Color|255|241|0|![#FFF100](https://placehold.co/15x15/FFF100/FFF100.png) `#FFF100`|
|German Gray|N32|Acrysion|17|60|65|![#113C41](https://placehold.co/15x15/113C41/113C41.png) `#113C41`|
|German Gray|40|Mr Color|17|60|65|![#113C41](https://placehold.co/15x15/113C41/113C41.png) `#113C41`|
|German Gray|SP40|Mr Color Spray|17|60|65|![#113C41](https://placehold.co/15x15/113C41/113C41.png) `#113C41`|
|German Gray|C40|Mr Color Modulation Set|40|39|55|![#282737](https://placehold.co/15x15/282737/282737.png) `#282737`|
|German Gray Highlight 1|CMC07|Mr Color Modulation Set|68|74|84|![#444A54](https://placehold.co/15x15/444A54/444A54.png) `#444A54`|
|German Gray Highlight 2|CMC08|Mr Color Modulation Set|93|101|102|![#5D6566](https://placehold.co/15x15/5D6566/5D6566.png) `#5D6566`|
|German Gray Shadow|CMC09|Mr Color Modulation Set|18|15|23|![#120F17](https://placehold.co/15x15/120F17/120F17.png) `#120F17`|
|Glear Green|H94|Aqueous Hobby Color|0|153|68|![#009944](https://placehold.co/15x15/009944/009944.png) `#009944`|
|Gloss Seablue Fs151042|365|Mr Color|0|0|28|![#00001C](https://placehold.co/15x15/00001C/00001C.png) `#00001C`|
|Gold|N9|Acrysion|223|182|3|![#DFB603](https://placehold.co/15x15/DFB603/DFB603.png) `#DFB603`|
|Gold|H9|Aqueous Hobby Color|223|182|3|![#DFB603](https://placehold.co/15x15/DFB603/DFB603.png) `#DFB603`|
|Gold|SP9|Mr Color Spray|223|182|3|![#DFB603](https://placehold.co/15x15/DFB603/DFB603.png) `#DFB603`|
|Gold|9|Mr Color|223|182|3|![#DFB603](https://placehold.co/15x15/DFB603/DFB603.png) `#DFB603`|
|Gold|217|Mr Metal Color|217|174|0|![#D9AE00](https://placehold.co/15x15/D9AE00/D9AE00.png) `#D9AE00`|
|Grass Color|523|Mr Color|76|92|70|![#4C5C46](https://placehold.co/15x15/4C5C46/4C5C46.png) `#4C5C46`|
|Gray|H22|Aqueous Hobby Color|84|101|114|![#546572](https://placehold.co/15x15/546572/546572.png) `#546572`|
|Gray "Grau"|514|Mr Color|78|114|127|![#4E727F](https://placehold.co/15x15/4E727F/4E727F.png) `#4E727F`|
|Gray Fs16440|H315|Aqueous Hobby Color|174|194|174|![#AEC2AE](https://placehold.co/15x15/AEC2AE/AEC2AE.png) `#AEC2AE`|
|Gray Fs16440|315|Mr Color|155|173|164|![#9BADA4](https://placehold.co/15x15/9BADA4/9BADA4.png) `#9BADA4`|
|Gray Fs26440|H325|Aqueous Hobby Color|170|187|164|![#AABBA4](https://placehold.co/15x15/AABBA4/AABBA4.png) `#AABBA4`|
|Gray Fs26440|325|Mr Color|167|177|164|![#A7B1A4](https://placehold.co/15x15/A7B1A4/A7B1A4.png) `#A7B1A4`|
|Gray Fs36081|301|Mr Color|37|60|69|![#253C45](https://placehold.co/15x15/253C45/253C45.png) `#253C45`|
|Gray Fs36081|H301|Aqueous Hobby Color|23|56|59|![#17383B](https://placehold.co/15x15/17383B/17383B.png) `#17383B`|
|Gray Fs36118|305|Mr Color|64|106|104|![#406A68](https://placehold.co/15x15/406A68/406A68.png) `#406A68`|
|Gray Fs36118|H305|Aqueous Hobby Color|39|93|88|![#275D58](https://placehold.co/15x15/275D58/275D58.png) `#275D58`|
|Gray Fs36231|317|Mr Color|109|121|106|![#6D796A](https://placehold.co/15x15/6D796A/6D796A.png) `#6D796A`|
|Gray Fs36231|H317|Aqueous Hobby Color|62|92|84|![#3E5C54](https://placehold.co/15x15/3E5C54/3E5C54.png) `#3E5C54`|
|Gray Fs36270|H306|Aqueous Hobby Color|110|113|115|![#6E7173](https://placehold.co/15x15/6E7173/6E7173.png) `#6E7173`|
|Gray Fs36270|306|Mr Color|104|136|135|![#688887](https://placehold.co/15x15/688887/688887.png) `#688887`|
|Gray Fs36320|H307|Aqueous Hobby Color|43|132|140|![#2B848C](https://placehold.co/15x15/2B848C/2B848C.png) `#2B848C`|
|Gray Fs36320|307|Mr Color|104|136|143|![#68888F](https://placehold.co/15x15/68888F/68888F.png) `#68888F`|
|Gray Fs36375|308|Mr Color|128|158|159|![#809E9F](https://placehold.co/15x15/809E9F/809E9F.png) `#809E9F`|
|Gray Fs36375|H308|Aqueous Hobby Color|70|160|169|![#46A0A9](https://placehold.co/15x15/46A0A9/46A0A9.png) `#46A0A9`|
|Gray Fs36622|H311|Aqueous Hobby Color|248|251|237|![#F8FBED](https://placehold.co/15x15/F8FBED/F8FBED.png) `#F8FBED`|
|Gray Fs36622|311|Mr Color|235|236|213|![#EBECD5](https://placehold.co/15x15/EBECD5/EBECD5.png) `#EBECD5`|
|Gray Green|128|Mr Color|178|182|168|![#B2B6A8](https://placehold.co/15x15/B2B6A8/B2B6A8.png) `#B2B6A8`|
|Grayish Blue Fs35237|337|Mr Color|58|113|121|![#3A7179](https://placehold.co/15x15/3A7179/3A7179.png) `#3A7179`|
|Grayish Blue Fs35237 A|H337|Aqueous Hobby Color|0|110|91|![#006E5B](https://placehold.co/15x15/006E5B/006E5B.png) `#006E5B`|
|Green|6|Mr Color|0|104|48|![#006830](https://placehold.co/15x15/006830/006830.png) `#006830`|
|Green|SP6|Mr Color Spray|0|104|48|![#006830](https://placehold.co/15x15/006830/006830.png) `#006830`|
|Green|N6|Acrysion|0|141|70|![#008D46](https://placehold.co/15x15/008D46/008D46.png) `#008D46`|
|Green|H6|Aqueous Hobby Color|0|141|70|![#008D46](https://placehold.co/15x15/008D46/008D46.png) `#008D46`|
|Green Brown T|H402|Aqueous Hobby Color|191|157|90|![#BF9D5A](https://placehold.co/15x15/BF9D5A/BF9D5A.png) `#BF9D5A`|
|Green Fs34079|H309|Aqueous Hobby Color|13|68|64|![#0D4440](https://placehold.co/15x15/0D4440/0D4440.png) `#0D4440`|
|Green Fs34079|309|Mr Color|38|84|80|![#265450](https://placehold.co/15x15/265450/265450.png) `#265450`|
|Green Fs34092|H302|Aqueous Hobby Color|0|69|64|![#004540](https://placehold.co/15x15/004540/004540.png) `#004540`|
|Green Fs34092|302|Mr Color|38|84|80|![#265450](https://placehold.co/15x15/265450/265450.png) `#265450`|
|Green Fs34102|H303|Aqueous Hobby Color|41|82|69|![#295245](https://placehold.co/15x15/295245/295245.png) `#295245`|
|Green Fs34102|303|Mr Color|72|93|80|![#485D50](https://placehold.co/15x15/485D50/485D50.png) `#485D50`|
|Green Fs34227|H312|Aqueous Hobby Color|0|128|76|![#00804C](https://placehold.co/15x15/00804C/00804C.png) `#00804C`|
|Green Fs34227|312|Mr Color|45|132|93|![#2D845D](https://placehold.co/15x15/2D845D/2D845D.png) `#2D845D`|
|Ground Color|522|Mr Color|77|72|70|![#4D4846](https://placehold.co/15x15/4D4846/4D4846.png) `#4D4846`|
|Gun Chrome|104|Mr Color|178|191|196|![#B2BFC4](https://placehold.co/15x15/B2BFC4/B2BFC4.png) `#B2BFC4`|
|Harmann Red|GX3|Mr Color GX|230|0|18|![#E60012](https://placehold.co/15x15/E60012/E60012.png) `#E60012`|
|Hay Color|524|Mr Color|134|121|59|![#86793B](https://placehold.co/15x15/86793B/86793B.png) `#86793B`|
|Hemp Bs4800/10b21|336|Mr Color|105|142|106|![#698E6A](https://placehold.co/15x15/698E6A/698E6A.png) `#698E6A`|
|Hemp Bs4800/10b21 A|H336|Aqueous Hobby Color|77|132|82|![#4D8452](https://placehold.co/15x15/4D8452/4D8452.png) `#4D8452`|
|Hull Red|SP29|Mr Color Spray|85|46|52|![#552E34](https://placehold.co/15x15/552E34/552E34.png) `#552E34`|
|Hull Red|29|Mr Color|85|46|52|![#552E34](https://placehold.co/15x15/552E34/552E34.png) `#552E34`|
|Hull Red|N17|Acrysion|85|46|52|![#552E34](https://placehold.co/15x15/552E34/552E34.png) `#552E34`|
|IDF Grau 1 (-1981 Shinai)|528|Mr Color|201|179|132|![#C9B384](https://placehold.co/15x15/C9B384/C9B384.png) `#C9B384`|
|IDF Gray2 (-1981 Golan)|529|Mr Color|135|126|105|![#877E69](https://placehold.co/15x15/877E69/877E69.png) `#877E69`|
|IDF Gray3 (Modern)|530|Mr Color|124|115|88|![#7C7358](https://placehold.co/15x15/7C7358/7C7358.png) `#7C7358`|
|IJN Gray|H61|Aqueous Hobby Color|116|142|152|![#748E98](https://placehold.co/15x15/748E98/748E98.png) `#748E98`|
|IJN Gray (Mitsubishi)|N61|Acrysion|166|187|199|![#A6BBC7](https://placehold.co/15x15/A6BBC7/A6BBC7.png) `#A6BBC7`|
|IJN Gray (Mitsubishi)|SP35|Mr Color Spray|166|187|199|![#A6BBC7](https://placehold.co/15x15/A6BBC7/A6BBC7.png) `#A6BBC7`|
|IJN Gray (Mitsubishi)|35|Mr Color|0|0|0|![#000000](https://placehold.co/15x15/000000/000000.png) `#000000`|
|IJN Gray Green (Nakajima)|56|Mr Color|112|161|154|![#70A19A](https://placehold.co/15x15/70A19A/70A19A.png) `#70A19A`|
|IJN Gray Green (Nakajima)|N62|Acrysion|112|161|154|![#70A19A](https://placehold.co/15x15/70A19A/70A19A.png) `#70A19A`|
|IJN Green|H59|Aqueous Hobby Color|0|56|31|![#00381F](https://placehold.co/15x15/00381F/00381F.png) `#00381F`|
|IJN Green (Nakajima)|15|Mr Color|0|56|31|![#00381F](https://placehold.co/15x15/00381F/00381F.png) `#00381F`|
|IJN Green (Nakajima)|N36|Acrysion|0|56|31|![#00381F](https://placehold.co/15x15/00381F/00381F.png) `#00381F`|
|IJN Green (Nakajima)|SP15|Mr Color Spray|49|72|54|![#314836](https://placehold.co/15x15/314836/314836.png) `#314836`|
|IJN Hull Color/Kure|601|Mr Color|139|142|146|![#8B8E92](https://placehold.co/15x15/8B8E92/8B8E92.png) `#8B8E92`|
|IJN Hull Color/Maizuru|603|Mr Color|160|163|172|![#A0A3AC](https://placehold.co/15x15/A0A3AC/A0A3AC.png) `#A0A3AC`|
|IJN Hull Color/Sasebo|602|Mr Color|110|112|109|![#6E706D](https://placehold.co/15x15/6E706D/6E706D.png) `#6E706D`|
|IJN Linoleum Deck Color|606|Mr Color|111|76|64|![#6F4C40](https://placehold.co/15x15/6F4C40/6F4C40.png) `#6F4C40`|
|IJN Type21 Camoflage Color|604|Mr Color|82|125|63|![#527D3F](https://placehold.co/15x15/527D3F/527D3F.png) `#527D3F`|
|IJN Type22 Camoflage Color|605|Mr Color|133|175|108|![#85AF6C](https://placehold.co/15x15/85AF6C/85AF6C.png) `#85AF6C`|
|Ice Silver|GX214|Mr Metallic Color GX|116|122|146|![#747A92](https://placehold.co/15x15/747A92/747A92.png) `#747A92`|
|Ija Gray|H62|Aqueous Hobby Color|134|160|146|![#86A092](https://placehold.co/15x15/86A092/86A092.png) `#86A092`|
|Ija Green|H60|Aqueous Hobby Color|0|82|58|![#00523A](https://placehold.co/15x15/00523A/00523A.png) `#00523A`|
|Ija Green|16|Mr Color|0|77|57|![#004D39](https://placehold.co/15x15/004D39/004D39.png) `#004D39`|
|Ija Green|N60|Acrysion|0|77|57|![#004D39](https://placehold.co/15x15/004D39/004D39.png) `#004D39`|
|Ija Green|SP16|Mr Color Spray|0|77|57|![#004D39](https://placehold.co/15x15/004D39/004D39.png) `#004D39`|
|Interior Blue (Soviet)|392|Mr Color|0|155|189|![#009BBD](https://placehold.co/15x15/009BBD/009BBD.png) `#009BBD`|
|Interior Green|27|Mr Color|182|168|17|![#B6A811](https://placehold.co/15x15/B6A811/B6A811.png) `#B6A811`|
|Interior Green|H58|Aqueous Hobby Color|182|168|17|![#B6A811](https://placehold.co/15x15/B6A811/B6A811.png) `#B6A811`|
|Interior Green|N58|Acrysion|182|168|17|![#B6A811](https://placehold.co/15x15/B6A811/B6A811.png) `#B6A811`|
|Interior Turquoise Green (Soviet)|391|Mr Color|0|163|138|![#00A38A](https://placehold.co/15x15/00A38A/00A38A.png) `#00A38A`|
|Intermediate Blue|72|Mr Color|14|77|89|![#0E4D59](https://placehold.co/15x15/0E4D59/0E4D59.png) `#0E4D59`|
|Intermediate Blue|H56|Aqueous Hobby Color|14|77|89|![#0E4D59](https://placehold.co/15x15/0E4D59/0E4D59.png) `#0E4D59`|
|Intermediate Blue|N56|Acrysion|14|77|89|![#0E4D59](https://placehold.co/15x15/0E4D59/0E4D59.png) `#0E4D59`|
|Intermediate Blue Fs35164|366|Mr Color|94|120|139|![#5E788B](https://placehold.co/15x15/5E788B/5E788B.png) `#5E788B`|
|Iron|212|Mr Metal Color|25|63|69|![#193F45](https://placehold.co/15x15/193F45/193F45.png) `#193F45`|
|JMSDF 2704 Gray N5|607|Mr Color|122|128|131|![#7A8083](https://placehold.co/15x15/7A8083/7A8083.png) `#7A8083`|
|JMSDF 2705 Dark Gray N4|608|Mr Color|89|93|95|![#595D5F](https://placehold.co/15x15/595D5F/595D5F.png) `#595D5F`|
|JMSDF Cleated Deck Color|609|Mr Color|66|67|69|![#424345](https://placehold.co/15x15/424345/424345.png) `#424345`|
|Japanese Brown|526|Mr Color|135|100|75|![#87644B](https://placehold.co/15x15/87644B/87644B.png) `#87644B`|
|Japanese Green|525|Mr Color|25|73|56|![#194938](https://placehold.co/15x15/194938/194938.png) `#194938`|
|Japanese Khaki|527|Mr Color|161|126|78|![#A17E4E](https://placehold.co/15x15/A17E4E/A17E4E.png) `#A17E4E`|
|Japanese Navalrsenal Color Kure|SJ01|Mr Color Spray|108|123|131|![#6C7B83](https://placehold.co/15x15/6C7B83/6C7B83.png) `#6C7B83`|
|Japanese Navalrsenal Color Sasebo|SJ02|Mr Color Spray|81|79|79|![#514F4F](https://placehold.co/15x15/514F4F/514F4F.png) `#514F4F`|
|Jasdf Deep Ocean Blue|375|Mr Color|37|43|69|![#252B45](https://placehold.co/15x15/252B45/252B45.png) `#252B45`|
|Jasdf Radome Gray|376|Mr Color|192|202|198|![#C0CAC6](https://placehold.co/15x15/C0CAC6/C0CAC6.png) `#C0CAC6`|
|Jasdf Shallow Ocean Blue|374|Mr Color|80|129|170|![#5081AA](https://placehold.co/15x15/5081AA/5081AA.png) `#5081AA`|
|Khaki|55|Mr Color|78|80|53|![#4E5035](https://placehold.co/15x15/4E5035/4E5035.png) `#4E5035`|
|Khaki|H81|Aqueous Hobby Color|104|89|50|![#685932](https://placehold.co/15x15/685932/685932.png) `#685932`|
|Khaki|N81|Acrysion|78|80|53|![#4E5035](https://placehold.co/15x15/4E5035/4E5035.png) `#4E5035`|
|Khaki Brown|H404|Aqueous Hobby Color|159|130|55|![#9F8237](https://placehold.co/15x15/9F8237/9F8237.png) `#9F8237`|
|Khaki Green|54|Mr Color|33|66|58|![#21423A](https://placehold.co/15x15/21423A/21423A.png) `#21423A`|
|Khaki Green|N80|Acrysion|33|66|58|![#21423A](https://placehold.co/15x15/21423A/21423A.png) `#21423A`|
|Khaki Green|H80|Aqueous Hobby Color|0|71|56|![#004738](https://placehold.co/15x15/004738/004738.png) `#004738`|
|Lederbraun|520|Mr Color|84|57|35|![#543923](https://placehold.co/15x15/543923/543923.png) `#543923`|
|Light Aircraft Gray Bs381c/627 A|H332|Aqueous Hobby Color|91|145|139|![#5B918B](https://placehold.co/15x15/5B918B/5B918B.png) `#5B918B`|
|Light Blue|20|Mr Color|79|186|161|![#4FBAA1](https://placehold.co/15x15/4FBAA1/4FBAA1.png) `#4FBAA1`|
|Light Blue|H323|Aqueous Hobby Color|0|168|235|![#00A8EB](https://placehold.co/15x15/00A8EB/00A8EB.png) `#00A8EB`|
|Light Blue|H45|Aqueous Hobby Color|0|185|239|![#00B9EF](https://placehold.co/15x15/00B9EF/00B9EF.png) `#00B9EF`|
|Light Blue|N45|Acrysion|0|185|239|![#00B9EF](https://placehold.co/15x15/00B9EF/00B9EF.png) `#00B9EF`|
|Light Blue|323|Mr Color|0|175|236|![#00AFEC](https://placehold.co/15x15/00AFEC/00AFEC.png) `#00AFEC`|
|Light Brown|321|Mr Color|180|146|106|![#B4926A](https://placehold.co/15x15/B4926A/B4926A.png) `#B4926A`|
|Light Brown|H321|Aqueous Hobby Color|111|130|81|![#6F8251](https://placehold.co/15x15/6F8251/6F8251.png) `#6F8251`|
|Light Gray|324|Mr Color|141|169|164|![#8DA9A4](https://placehold.co/15x15/8DA9A4/8DA9A4.png) `#8DA9A4`|
|Light Gray|SP97|Mr Color Spray|179|190|178|![#B3BEB2](https://placehold.co/15x15/B3BEB2/B3BEB2.png) `#B3BEB2`|
|Light Gray|97|Mr Color|179|190|178|![#B3BEB2](https://placehold.co/15x15/B3BEB2/B3BEB2.png) `#B3BEB2`|
|Light Gray|H324|Aqueous Hobby Color|140|176|162|![#8CB0A2](https://placehold.co/15x15/8CB0A2/8CB0A2.png) `#8CB0A2`|
|Light Gray Fs36495|338|Mr Color|190|195|196|![#BEC3C4](https://placehold.co/15x15/BEC3C4/BEC3C4.png) `#BEC3C4`|
|Light Gray Fs36495 A|H338|Aqueous Hobby Color|190|207|196|![#BECFC4](https://placehold.co/15x15/BECFC4/BECFC4.png) `#BECFC4`|
|Light Green|H319|Aqueous Hobby Color|0|77|64|![#004D40](https://placehold.co/15x15/004D40/004D40.png) `#004D40`|
|Light Green|319|Mr Color|0|109|88|![#006D58](https://placehold.co/15x15/006D58/006D58.png) `#006D58`|
|Light Gull Gray|H51|Aqueous Hobby Color|190|195|196|![#BEC3C4](https://placehold.co/15x15/BEC3C4/BEC3C4.png) `#BEC3C4`|
|Light Gull Gray|11|Mr Color|190|195|196|![#BEC3C4](https://placehold.co/15x15/BEC3C4/BEC3C4.png) `#BEC3C4`|
|Light Gull Gray|SP11|Mr Color Spray|190|195|196|![#BEC3C4](https://placehold.co/15x15/BEC3C4/BEC3C4.png) `#BEC3C4`|
|Light Gull Gray|N51|Acrysion|190|195|196|![#BEC3C4](https://placehold.co/15x15/BEC3C4/BEC3C4.png) `#BEC3C4`|
|Lightircraft Gray Bs381c 627|332|Mr Color|157|163|153|![#9DA399](https://placehold.co/15x15/9DA399/9DA399.png) `#9DA399`|
|Lime Green|H50|Aqueous Hobby Color|145|182|113|![#91B671](https://placehold.co/15x15/91B671/91B671.png) `#91B671`|
|Lime Green|N50|Acrysion|145|182|113|![#91B671](https://placehold.co/15x15/91B671/91B671.png) `#91B671`|
|MS Blue|UG3|Mr Color Gundam Color|250|192|0|![#FAC000](https://placehold.co/15x15/FAC000/FAC000.png) `#FAC000`|
|MS Blue|SG3|Gundam Color Spray|250|192|0|![#FAC000](https://placehold.co/15x15/FAC000/FAC000.png) `#FAC000`|
|MS Char's Pink|UG11|Mr Color Gundam Color|134|37|68|![#862544](https://placehold.co/15x15/862544/862544.png) `#862544`|
|MS Char's Pink|SG11|Gundam Color Spray|134|37|68|![#862544](https://placehold.co/15x15/862544/862544.png) `#862544`|
|MS Char's Red|UG12|Mr Color Gundam Color|208|18|27|![#D0121B](https://placehold.co/15x15/D0121B/D0121B.png) `#D0121B`|
|MS Char's Red|SG12|Gundam Color Spray|208|18|27|![#D0121B](https://placehold.co/15x15/D0121B/D0121B.png) `#D0121B`|
|MS Deep Green|SG8|Gundam Color Spray|166|136|189|![#A688BD](https://placehold.co/15x15/A688BD/A688BD.png) `#A688BD`|
|MS Deep Green|UG8|Mr Color Gundam Color|166|136|189|![#A688BD](https://placehold.co/15x15/A688BD/A688BD.png) `#A688BD`|
|MS Green|SG7|Gundam Color Spray|66|106|78|![#426A4E](https://placehold.co/15x15/426A4E/426A4E.png) `#426A4E`|
|MS Green|UG7|Mr Color Gundam Color|66|106|78|![#426A4E](https://placehold.co/15x15/426A4E/426A4E.png) `#426A4E`|
|MS Light Blue|UG15|Mr Color Gundam Color|0|0|17|![#000011](https://placehold.co/15x15/000011/000011.png) `#000011`|
|MS Light Blue|SG15|Gundam Color Spray|0|0|17|![#000011](https://placehold.co/15x15/000011/000011.png) `#000011`|
|MS Phantom Gray|UG16|Mr Color Gundam Color|8|1|24|![#080118](https://placehold.co/15x15/080118/080118.png) `#080118`|
|MS Purple|UG9|Mr Color Gundam Color|88|91|105|![#585B69](https://placehold.co/15x15/585B69/585B69.png) `#585B69`|
|MS Purple|SG9|Gundam Color Spray|88|91|105|![#585B69](https://placehold.co/15x15/585B69/585B69.png) `#585B69`|
|MS Red|SG5|Gundam Color Spray|50|50|50|![#323232](https://placehold.co/15x15/323232/323232.png) `#323232`|
|MS Red|UG5|Mr Color Gundam Color|50|50|50|![#323232](https://placehold.co/15x15/323232/323232.png) `#323232`|
|MS Sazabi Red|UG13|Mr Color Gundam Color|0|62|151|![#003E97](https://placehold.co/15x15/003E97/003E97.png) `#003E97`|
|MS Sazabi Red|SG13|Gundam Color Spray|0|62|151|![#003E97](https://placehold.co/15x15/003E97/003E97.png) `#003E97`|
|MS Titans Blue 1|UG17|Mr Color Gundam Color|2|7|88|![#020758](https://placehold.co/15x15/020758/020758.png) `#020758`|
|MS Titans Blue 2|UG18|Gundam Color for Builders|222|239|224|![#DEEFE0](https://placehold.co/15x15/DEEFE0/DEEFE0.png) `#DEEFE0`|
|MS White|UG2|Mr Color Gundam Color|0|72|155|![#00489B](https://placehold.co/15x15/00489B/00489B.png) `#00489B`|
|MS White|SG2|Gundam Color Spray|0|72|155|![#00489B](https://placehold.co/15x15/00489B/00489B.png) `#00489B`|
|MS Yellow|SG4|Gundam Color Spray|201|34|32|![#C92220](https://placehold.co/15x15/C92220/C92220.png) `#C92220`|
|MS Yellow|UG4|Mr Color Gundam Color|201|34|32|![#C92220](https://placehold.co/15x15/C92220/C92220.png) `#C92220`|
|Machine Gray|H458|Aqueous Hobby Color|72|75|68|![#484B44](https://placehold.co/15x15/484B44/484B44.png) `#484B44`|
|Madder Red|68|Mr Color|216|12|24|![#D80C18](https://placehold.co/15x15/D80C18/D80C18.png) `#D80C18`|
|Madder Red|SP68|Mr Color Spray|216|12|24|![#D80C18](https://placehold.co/15x15/D80C18/D80C18.png) `#D80C18`|
|Magenta|CR2|Primary Color Pigments|228|0|127|![#E4007F](https://placehold.co/15x15/E4007F/E4007F.png) `#E4007F`|
|Mahogany|42|Mr Color|60|48|50|![#3C3032](https://placehold.co/15x15/3C3032/3C3032.png) `#3C3032`|
|Mahogany|H84|Aqueous Hobby Color|60|48|50|![#3C3032](https://placehold.co/15x15/3C3032/3C3032.png) `#3C3032`|
|Mahogany|N84|Acrysion|60|48|50|![#3C3032](https://placehold.co/15x15/3C3032/3C3032.png) `#3C3032`|
|Mahogany|SP42|Mr Color Spray|60|48|50|![#3C3032](https://placehold.co/15x15/3C3032/3C3032.png) `#3C3032`|
|Medium Seagray Bs381c 637|335|Mr Color|94|118|120|![#5E7678](https://placehold.co/15x15/5E7678/5E7678.png) `#5E7678`|
|Medium Seagray Bs381c/637 A|H335|Aqueous Hobby Color|54|93|85|![#365D55](https://placehold.co/15x15/365D55/365D55.png) `#365D55`|
|Medium Seagray Bs637|363|Mr Color|129|147|154|![#81939A](https://placehold.co/15x15/81939A/81939A.png) `#81939A`|
|Metal Black|78|Mr Color|0|0|0|![#000000](https://placehold.co/15x15/000000/000000.png) `#000000`|
|Metal Black|SP78|Mr Color Spray|0|0|0|![#000000](https://placehold.co/15x15/000000/000000.png) `#000000`|
|Metal Black|H28|Aqueous Hobby Color|0|0|0|![#000000](https://placehold.co/15x15/000000/000000.png) `#000000`|
|Metal Black|N28|Acrysion|0|0|0|![#000000](https://placehold.co/15x15/000000/000000.png) `#000000`|
|Metal Black|GX201|Mr Metallic Color GX|96|95|101|![#605F65](https://placehold.co/15x15/605F65/605F65.png) `#605F65`|
|Metal Bloody Red|GX215|Mr Metallic Color GX|117|41|53|![#752935](https://placehold.co/15x15/752935/752935.png) `#752935`|
|Metal Blue|GX204|Mr Metallic Color GX|55|126|189|![#377EBD](https://placehold.co/15x15/377EBD/377EBD.png) `#377EBD`|
|Metal Dark Blue|GX216|Mr Metallic Color GX|37|63|114|![#253F72](https://placehold.co/15x15/253F72/253F72.png) `#253F72`|
|Metal Green|GX205|Mr Metallic Color GX|60|167|162|![#3CA7A2](https://placehold.co/15x15/3CA7A2/3CA7A2.png) `#3CA7A2`|
|Metal Peach|GX212|Mr Metallic Color GX|176|97|100|![#B06164](https://placehold.co/15x15/B06164/B06164.png) `#B06164`|
|Metal Purple|GX206|Mr Metallic Color GX|161|124|159|![#A17C9F](https://placehold.co/15x15/A17C9F/A17C9F.png) `#A17C9F`|
|Metal Red|GX202|Mr Metallic Color GX|207|95|94|![#CF5F5E](https://placehold.co/15x15/CF5F5E/CF5F5E.png) `#CF5F5E`|
|Metal Violet|GX207|Mr Metallic Color GX|127|90|167|![#7F5AA7](https://placehold.co/15x15/7F5AA7/7F5AA7.png) `#7F5AA7`|
|Metal Yellow|GX203|Mr Metallic Color GX|177|168|70|![#B1A846](https://placehold.co/15x15/B1A846/B1A846.png) `#B1A846`|
|Metal Yellow Green|GX211|Mr Metallic Color GX|145|157|109|![#919D6D](https://placehold.co/15x15/919D6D/919D6D.png) `#919D6D`|
|Metallic Blue|76|Mr Color|0|78|162|![#004EA2](https://placehold.co/15x15/004EA2/004EA2.png) `#004EA2`|
|Metallic Blue|SP76|Mr Color Spray|0|78|162|![#004EA2](https://placehold.co/15x15/004EA2/004EA2.png) `#004EA2`|
|Metallic Blue|N88|Acrysion|0|78|162|![#004EA2](https://placehold.co/15x15/004EA2/004EA2.png) `#004EA2`|
|Metallic Blue|H88|Aqueous Hobby Color|0|79|153|![#004F99](https://placehold.co/15x15/004F99/004F99.png) `#004F99`|
|Metallic Blue Green|H63|Aqueous Hobby Color|0|94|91|![#005E5B](https://placehold.co/15x15/005E5B/005E5B.png) `#005E5B`|
|Metallic Blue Green|57|Mr Color|0|117|107|![#00756B](https://placehold.co/15x15/00756B/00756B.png) `#00756B`|
|Metallic Blue Green|N63|Acrysion|0|117|107|![#00756B](https://placehold.co/15x15/00756B/00756B.png) `#00756B`|
|Metallic Green|N89|Acrysion|0|137|79|![#00894F](https://placehold.co/15x15/00894F/00894F.png) `#00894F`|
|Metallic Green|77|Mr Color|0|137|79|![#00894F](https://placehold.co/15x15/00894F/00894F.png) `#00894F`|
|Metallic Green|SP77|Mr Color Spray|0|137|79|![#00894F](https://placehold.co/15x15/00894F/00894F.png) `#00894F`|
|Metallic Green|H89|Aqueous Hobby Color|0|137|93|![#00895D](https://placehold.co/15x15/00895D/00895D.png) `#00895D`|
|Metallic Red|75|Mr Color|176|31|36|![#B01F24](https://placehold.co/15x15/B01F24/B01F24.png) `#B01F24`|
|Metallic Red|SP75|Mr Color Spray|176|31|36|![#B01F24](https://placehold.co/15x15/B01F24/B01F24.png) `#B01F24`|
|Metallic Red|N87|Acrysion|176|31|36|![#B01F24](https://placehold.co/15x15/B01F24/B01F24.png) `#B01F24`|
|Metallic Red|H87|Aqueous Hobby Color|167|57|74|![#A7394A](https://placehold.co/15x15/A7394A/A7394A.png) `#A7394A`|
|Middle Stone|H71|Aqueous Hobby Color|180|146|65|![#B49241](https://placehold.co/15x15/B49241/B49241.png) `#B49241`|
|Middle Stone|21|Mr Color|180|146|65|![#B49241](https://placehold.co/15x15/B49241/B49241.png) `#B49241`|
|Middle Stone|N71|Acrysion|180|146|65|![#B49241](https://placehold.co/15x15/B49241/B49241.png) `#B49241`|
|Midnight Blue|N55|Acrysion|32|66|70|![#204246](https://placehold.co/15x15/204246/204246.png) `#204246`|
|Midnight Blue|H55|Aqueous Hobby Color|0|0|0|![#000000](https://placehold.co/15x15/000000/000000.png) `#000000`|
|Midnight Blue|71|Mr Color|32|66|70|![#204246](https://placehold.co/15x15/204246/204246.png) `#204246`|
|Moonstone Pearl|XC08|Mr Crystal Color|192|208|233|![#C0D0E9](https://placehold.co/15x15/C0D0E9/C0D0E9.png) `#C0D0E9`|
|Morrie Green|GX6|Mr Color GX|0|104|48|![#006830](https://placehold.co/15x15/006830/006830.png) `#006830`|
|Mud|H341|Aqueous Hobby Color|84|53|50|![#543532](https://placehold.co/15x15/543532/543532.png) `#543532`|
|Navy Blue|SP14|Mr Color Spray|0|70|82|![#004652](https://placehold.co/15x15/004652/004652.png) `#004652`|
|Navy Blue|14|Mr Color|0|70|82|![#004652](https://placehold.co/15x15/004652/004652.png) `#004652`|
|Navy Blue|N54|Acrysion|0|70|82|![#004652](https://placehold.co/15x15/004652/004652.png) `#004652`|
|Navy Blue|H54|Aqueous Hobby Color|0|70|82|![#004652](https://placehold.co/15x15/004652/004652.png) `#004652`|
|Neutral Gray|H53|Aqueous Hobby Color|84|101|114|![#546572](https://placehold.co/15x15/546572/546572.png) `#546572`|
|Neutral Gray|SP13|Mr Color Spray|117|133|140|![#75858C](https://placehold.co/15x15/75858C/75858C.png) `#75858C`|
|Neutral Gray|13|Mr Color|117|133|140|![#75858C](https://placehold.co/15x15/75858C/75858C.png) `#75858C`|
|Neutral Gray|N22|Acrysion|84|101|114|![#546572](https://placehold.co/15x15/546572/546572.png) `#546572`|
|Ocean Gray|362|Mr Color|91|103|107|![#5B676B](https://placehold.co/15x15/5B676B/5B676B.png) `#5B676B`|
|Off White|SP69|Mr Color Spray|249|248|244|![#F9F8F4](https://placehold.co/15x15/F9F8F4/F9F8F4.png) `#F9F8F4`|
|Off White|N21|Acrysion|249|248|244|![#F9F8F4](https://placehold.co/15x15/F9F8F4/F9F8F4.png) `#F9F8F4`|
|Off White|H21|Aqueous Hobby Color|249|248|244|![#F9F8F4](https://placehold.co/15x15/F9F8F4/F9F8F4.png) `#F9F8F4`|
|Off White|69|Mr Color|249|248|244|![#F9F8F4](https://placehold.co/15x15/F9F8F4/F9F8F4.png) `#F9F8F4`|
|Oil|H342|Aqueous Hobby Color|76|73|72|![#4C4948](https://placehold.co/15x15/4C4948/4C4948.png) `#4C4948`|
|Olive Drab (1)|N52|Acrysion|106|93|40|![#6A5D28](https://placehold.co/15x15/6A5D28/6A5D28.png) `#6A5D28`|
|Olive Drab (1)|SP12|Mr Color Spray|104|89|50|![#685932](https://placehold.co/15x15/685932/685932.png) `#685932`|
|Olive Drab (1)|12|Mr Color|104|89|50|![#685932](https://placehold.co/15x15/685932/685932.png) `#685932`|
|Olive Drab (1)|H52|Aqueous Hobby Color|106|93|40|![#6A5D28](https://placehold.co/15x15/6A5D28/6A5D28.png) `#6A5D28`|
|Olive Drab (2)|H78|Aqueous Hobby Color|49|72|54|![#314836](https://placehold.co/15x15/314836/314836.png) `#314836`|
|Olive Drab (2)|38|Mr Color|49|72|54|![#314836](https://placehold.co/15x15/314836/314836.png) `#314836`|
|Olive Drab (2)|N78|Acrysion|49|72|54|![#314836](https://placehold.co/15x15/314836/314836.png) `#314836`|
|Olive Drab (2)|SP38|Mr Color Spray|49|72|54|![#314836](https://placehold.co/15x15/314836/314836.png) `#314836`|
|Olive Drab 2|C38|Mr Color Modulation Set|54|57|47|![#36392F](https://placehold.co/15x15/36392F/36392F.png) `#36392F`|
|Olive Drab 2314|518|Mr Color|57|50|27|![#39321B](https://placehold.co/15x15/39321B/39321B.png) `#39321B`|
|Olive Drab Fs34087|304|Mr Color|55|60|52|![#373C34](https://placehold.co/15x15/373C34/373C34.png) `#373C34`|
|Olive Drab Fs34087|H304|Aqueous Hobby Color|40|58|53|![#283A35](https://placehold.co/15x15/283A35/283A35.png) `#283A35`|
|Olive Drab Highlight 1|CMC01|Mr Color Modulation Set|73|81|66|![#495142](https://placehold.co/15x15/495142/495142.png) `#495142`|
|Olive Drab Highlight 2|CMC02|Mr Color Modulation Set|88|95|75|![#585F4B](https://placehold.co/15x15/585F4B/585F4B.png) `#585F4B`|
|Olive Drab Shadow|CMC03|Mr Color Modulation Set|30|35|27|![#1E231B](https://placehold.co/15x15/1E231B/1E231B.png) `#1E231B`|
|Olive Green|H405|Aqueous Hobby Color|65|93|71|![#415D47](https://placehold.co/15x15/415D47/415D47.png) `#415D47`|
|Orange|59|Mr Color|232|56|13|![#E8380D](https://placehold.co/15x15/E8380D/E8380D.png) `#E8380D`|
|Orange|N14|Acrysion|232|56|13|![#E8380D](https://placehold.co/15x15/E8380D/E8380D.png) `#E8380D`|
|Orange|H14|Aqueous Hobby Color|232|56|13|![#E8380D](https://placehold.co/15x15/E8380D/E8380D.png) `#E8380D`|
|Orange Yellow|58|Mr Color|238|120|0|![#EE7800](https://placehold.co/15x15/EE7800/EE7800.png) `#EE7800`|
|Orange Yellow|N24|Acrysion|238|120|0|![#EE7800](https://placehold.co/15x15/EE7800/EE7800.png) `#EE7800`|
|Orange Yellow|SP58|Mr Color Spray|238|120|0|![#EE7800](https://placehold.co/15x15/EE7800/EE7800.png) `#EE7800`|
|Orange Yellow|H24|Aqueous Hobby Color|238|120|0|![#EE7800](https://placehold.co/15x15/EE7800/EE7800.png) `#EE7800`|
|Oxide Green|H461|Aqueous Hobby Color|224|241|239|![#E0F1EF](https://placehold.co/15x15/E0F1EF/E0F1EF.png) `#E0F1EF`|
|Pale Green|H41|Aqueous Hobby Color|164|213|193|![#A4D5C1](https://placehold.co/15x15/A4D5C1/A4D5C1.png) `#A4D5C1`|
|Phthalo Cyanine Blue|H322|Aqueous Hobby Color|30|45|86|![#1E2D56](https://placehold.co/15x15/1E2D56/1E2D56.png) `#1E2D56`|
|Phthalo Cyanne Blue|322|Mr Color|25|52|81|![#193451](https://placehold.co/15x15/193451/193451.png) `#193451`|
|Pink|SP63|Mr Color Spray|235|109|148|![#EB6D94](https://placehold.co/15x15/EB6D94/EB6D94.png) `#EB6D94`|
|Pink|N19|Acrysion|235|109|148|![#EB6D94](https://placehold.co/15x15/EB6D94/EB6D94.png) `#EB6D94`|
|Pink|63|Mr Color|235|109|148|![#EB6D94](https://placehold.co/15x15/EB6D94/EB6D94.png) `#EB6D94`|
|Pink|H19|Aqueous Hobby Color|235|109|148|![#EB6D94](https://placehold.co/15x15/EB6D94/EB6D94.png) `#EB6D94`|
|Plate Silver Next|SM08|Mr Color Super Metallic|232|231|231|![#E8E7E7](https://placehold.co/15x15/E8E7E7/E8E7E7.png) `#E8E7E7`|
|Purple|N39|Acrysion|60|34|128|![#3C2280](https://placehold.co/15x15/3C2280/3C2280.png) `#3C2280`|
|Purple|67|Mr Color|60|34|128|![#3C2280](https://placehold.co/15x15/3C2280/3C2280.png) `#3C2280`|
|Purple|H39|Aqueous Hobby Color|60|34|128|![#3C2280](https://placehold.co/15x15/3C2280/3C2280.png) `#3C2280`|
|Purple|SP67|Mr Color Spray|60|34|128|![#3C2280](https://placehold.co/15x15/3C2280/3C2280.png) `#3C2280`|
|Purple Red|H466|Aqueous Hobby Color|155|8|10|![#9B080A](https://placehold.co/15x15/9B080A/9B080A.png) `#9B080A`|
|RLM02 Gray|H70|Aqueous Hobby Color|137|134|105|![#898669](https://placehold.co/15x15/898669/898669.png) `#898669`|
|RLM02 Gray|N70|Acrysion|159|157|137|![#9F9D89](https://placehold.co/15x15/9F9D89/9F9D89.png) `#9F9D89`|
|RLM04 Yellow|H413|Aqueous Hobby Color|247|171|0|![#F7AB00](https://placehold.co/15x15/F7AB00/F7AB00.png) `#F7AB00`|
|RLM23 Red|H414|Aqueous Hobby Color|200|17|61|![#C8113D](https://placehold.co/15x15/C8113D/C8113D.png) `#C8113D`|
|RLM65 Light Blue|SP115|Mr Color Spray|119|154|168|![#779AA8](https://placehold.co/15x15/779AA8/779AA8.png) `#779AA8`|
|RLM65 Light Blue|N67|Acrysion|119|154|168|![#779AA8](https://placehold.co/15x15/779AA8/779AA8.png) `#779AA8`|
|RLM65 Light Blue|H67|Aqueous Hobby Color|126|180|190|![#7EB4BE](https://placehold.co/15x15/7EB4BE/7EB4BE.png) `#7EB4BE`|
|RLM66 Black Gray A|H416|Aqueous Hobby Color|31|30|29|![#1F1E1D](https://placehold.co/15x15/1F1E1D/1F1E1D.png) `#1F1E1D`|
|RLM70 Black Green|H65|Aqueous Hobby Color|31|49|52|![#1F3134](https://placehold.co/15x15/1F3134/1F3134.png) `#1F3134`|
|RLM71 Dark Green|H64|Aqueous Hobby Color|61|68|55|![#3D4437](https://placehold.co/15x15/3D4437/3D4437.png) `#3D4437`|
|RLM74 Dark Gray|H68|Aqueous Hobby Color|76|73|72|![#4C4948](https://placehold.co/15x15/4C4948/4C4948.png) `#4C4948`|
|RLM74 Gray Green|N68|Acrysion|5|60|62|![#053C3E](https://placehold.co/15x15/053C3E/053C3E.png) `#053C3E`|
|RLM75 Gray|H69|Aqueous Hobby Color|101|100|100|![#656464](https://placehold.co/15x15/656464/656464.png) `#656464`|
|RLM75 Gray Violet|N69|Acrysion|72|93|86|![#485D56](https://placehold.co/15x15/485D56/485D56.png) `#485D56`|
|RLM76 Light Blue|SP117|Mr Color Spray|191|213|212|![#BFD5D4](https://placehold.co/15x15/BFD5D4/BFD5D4.png) `#BFD5D4`|
|RLM76 Light Blue A|H417|Aqueous Hobby Color|198|222|228|![#C6DEE4](https://placehold.co/15x15/C6DEE4/C6DEE4.png) `#C6DEE4`|
|RLM78 Light Blue A|H418|Aqueous Hobby Color|120|174|198|![#78AEC6](https://placehold.co/15x15/78AEC6/78AEC6.png) `#78AEC6`|
|RLM79 Sand Yellow|N66|Acrysion|159|130|55|![#9F8237](https://placehold.co/15x15/9F8237/9F8237.png) `#9F8237`|
|RLM79 Sandy Brown|H66|Aqueous Hobby Color|170|133|70|![#AA8546](https://placehold.co/15x15/AA8546/AA8546.png) `#AA8546`|
|RLM80 Olive Green A|H420|Aqueous Hobby Color|76|86|53|![#4C5635](https://placehold.co/15x15/4C5635/4C5635.png) `#4C5635`|
|RLM81 Brown Violet A|H421|Aqueous Hobby Color|75|86|73|![#4B5649](https://placehold.co/15x15/4B5649/4B5649.png) `#4B5649`|
|RLM82 Light Green A|H422|Aqueous Hobby Color|64|112|56|![#407038](https://placehold.co/15x15/407038/407038.png) `#407038`|
|RLM83 Dark Green A|H423|Aqueous Hobby Color|21|97|78|![#15614E](https://placehold.co/15x15/15614E/15614E.png) `#15614E`|
|RX-78 Blue|UG20|Gundam Color for Builders|231|45|28|![#E72D1C](https://placehold.co/15x15/E72D1C/E72D1C.png) `#E72D1C`|
|RX-78 Red|UG21|Gundam Color for Builders|249|183|0|![#F9B700](https://placehold.co/15x15/F9B700/F9B700.png) `#F9B700`|
|RX-78 White|UG19|Gundam Color for Builders|0|152|214|![#0098D6](https://placehold.co/15x15/0098D6/0098D6.png) `#0098D6`|
|RX-78 Yellow|SG1|Gundam Color Spray|241|247|250|![#F1F7FA](https://placehold.co/15x15/F1F7FA/F1F7FA.png) `#F1F7FA`|
|Radome|318|Mr Color|252|214|140|![#FCD68C](https://placehold.co/15x15/FCD68C/FCD68C.png) `#FCD68C`|
|Radome|H318|Aqueous Hobby Color|255|225|116|![#FFE174](https://placehold.co/15x15/FFE174/FFE174.png) `#FFE174`|
|Red|SP3|Mr Color Spray|230|0|18|![#E60012](https://placehold.co/15x15/E60012/E60012.png) `#E60012`|
|Red|H3|Aqueous Hobby Color|230|0|18|![#E60012](https://placehold.co/15x15/E60012/E60012.png) `#E60012`|
|Red|N3|Acrysion|230|0|18|![#E60012](https://placehold.co/15x15/E60012/E60012.png) `#E60012`|
|Red|3|Mr Color|230|0|18|![#E60012](https://placehold.co/15x15/E60012/E60012.png) `#E60012`|
|Red (IJNircraftmarking)|385|Mr Color|182|0|13|![#B6000D](https://placehold.co/15x15/B6000D/B6000D.png) `#B6000D`|
|Red Brown|H47|Aqueous Hobby Color|108|44|47|![#6C2C2F](https://placehold.co/15x15/6C2C2F/6C2C2F.png) `#6C2C2F`|
|Red Brown|SP41|Mr Color Spray|73|47|50|![#492F32](https://placehold.co/15x15/492F32/492F32.png) `#492F32`|
|Red Brown|41|Mr Color|73|47|50|![#492F32](https://placehold.co/15x15/492F32/492F32.png) `#492F32`|
|Red Brown|N47|Acrysion|108|44|47|![#6C2C2F](https://placehold.co/15x15/6C2C2F/6C2C2F.png) `#6C2C2F`|
|Red Brown (1)|H460|Aqueous Hobby Color|140|65|43|![#8C412B](https://placehold.co/15x15/8C412B/8C412B.png) `#8C412B`|
|Red Brown (2)|H463|Aqueous Hobby Color|124|66|47|![#7C422F](https://placehold.co/15x15/7C422F/7C422F.png) `#7C422F`|
|Red Brown Ii|131|Mr Color|80|29|17|![#501D11](https://placehold.co/15x15/501D11/501D11.png) `#501D11`|
|Red Fs11136|327|Mr Color|158|35|40|![#9E2328](https://placehold.co/15x15/9E2328/9E2328.png) `#9E2328`|
|Red Fs11136 A|H327|Aqueous Hobby Color|162|35|39|![#A22327](https://placehold.co/15x15/A22327/A22327.png) `#A22327`|
|Red Gold|GX209|Mr Metallic Color GX|185|144|94|![#B9905E](https://placehold.co/15x15/B9905E/B9905E.png) `#B9905E`|
|Red Madder|N86|Acrysion|216|12|24|![#D80C18](https://placehold.co/15x15/D80C18/D80C18.png) `#D80C18`|
|Red Madder|H86|Aqueous Hobby Color|216|12|24|![#D80C18](https://placehold.co/15x15/D80C18/D80C18.png) `#D80C18`|
|Rlm02 Gray|60|Mr Color|159|157|137|![#9F9D89](https://placehold.co/15x15/9F9D89/9F9D89.png) `#9F9D89`|
|Rlm04 Yellow|113|Mr Color|247|171|0|![#F7AB00](https://placehold.co/15x15/F7AB00/F7AB00.png) `#F7AB00`|
|Rlm23 Red|114|Mr Color|200|17|61|![#C8113D](https://placehold.co/15x15/C8113D/C8113D.png) `#C8113D`|
|Rlm65 Light Blue|115|Mr Color|119|154|168|![#779AA8](https://placehold.co/15x15/779AA8/779AA8.png) `#779AA8`|
|Rlm66 Black Gray|116|Mr Color|62|58|57|![#3E3A39](https://placehold.co/15x15/3E3A39/3E3A39.png) `#3E3A39`|
|Rlm70 Black Green|18|Mr Color|35|60|80|![#233C50](https://placehold.co/15x15/233C50/233C50.png) `#233C50`|
|Rlm71 Dark Green|17|Mr Color|89|90|79|![#595A4F](https://placehold.co/15x15/595A4F/595A4F.png) `#595A4F`|
|Rlm74 Gray Green|36|Mr Color|5|60|62|![#053C3E](https://placehold.co/15x15/053C3E/053C3E.png) `#053C3E`|
|Rlm75 Gray Violet|37|Mr Color|72|93|86|![#485D56](https://placehold.co/15x15/485D56/485D56.png) `#485D56`|
|Rlm76 Light Blue|117|Mr Color|191|213|212|![#BFD5D4](https://placehold.co/15x15/BFD5D4/BFD5D4.png) `#BFD5D4`|
|Rlm78 Light Blue|118|Mr Color|129|167|182|![#81A7B6](https://placehold.co/15x15/81A7B6/81A7B6.png) `#81A7B6`|
|Rlm79 Sand Yellow|119|Mr Color|148|112|84|![#947054](https://placehold.co/15x15/947054/947054.png) `#947054`|
|Rlm80 Olive Green|120|Mr Color|0|60|42|![#003C2A](https://placehold.co/15x15/003C2A/003C2A.png) `#003C2A`|
|Rlm81 Brown Violet|121|Mr Color|89|90|79|![#595A4F](https://placehold.co/15x15/595A4F/595A4F.png) `#595A4F`|
|Rlm82 Light Green|122|Mr Color|93|131|82|![#5D8352](https://placehold.co/15x15/5D8352/5D8352.png) `#5D8352`|
|Rlm83 Dark Green|123|Mr Color|38|84|74|![#26544A](https://placehold.co/15x15/26544A/26544A.png) `#26544A`|
|Rough Gold|GX217|Mr Metallic Color GX|187|154|76|![#BB9A4C](https://placehold.co/15x15/BB9A4C/BB9A4C.png) `#BB9A4C`|
|Rough Gray|H345|Aqueous Hobby Color|89|87|87|![#595757](https://placehold.co/15x15/595757/595757.png) `#595757`|
|Rough Sand|H346|Aqueous Hobby Color|190|139|94|![#BE8B5E](https://placehold.co/15x15/BE8B5E/BE8B5E.png) `#BE8B5E`|
|Rough Silver|GX208|Mr Metallic Color GX|181|181|181|![#B5B5B5](https://placehold.co/15x15/B5B5B5/B5B5B5.png) `#B5B5B5`|
|Ruby Red|XC03|Mr Crystal Color|202|198|215|![#CAC6D7](https://placehold.co/15x15/CAC6D7/CAC6D7.png) `#CAC6D7`|
|Russet|N33|Acrysion|129|41|48|![#812930](https://placehold.co/15x15/812930/812930.png) `#812930`|
|Russet|81|Mr Color|119|42|49|![#772A31](https://placehold.co/15x15/772A31/772A31.png) `#772A31`|
|Russet|H33|Aqueous Hobby Color|129|41|45|![#81292D](https://placehold.co/15x15/81292D/81292D.png) `#81292D`|
|Russet|SP81|Mr Color Spray|119|42|49|![#772A31](https://placehold.co/15x15/772A31/772A31.png) `#772A31`|
|Russian Green|CMC10|Mr Color Modulation Set|64|112|56|![#407038](https://placehold.co/15x15/407038/407038.png) `#407038`|
|Russian Green "4bo"|511|Mr Color|69|93|47|![#455D2F](https://placehold.co/15x15/455D2F/455D2F.png) `#455D2F`|
|Russian Green "4bo" 1947|512|Mr Color|90|96|47|![#5A602F](https://placehold.co/15x15/5A602F/5A602F.png) `#5A602F`|
|Russian Green (1)|135|Mr Color|20|148|74|![#14944A](https://placehold.co/15x15/14944A/14944A.png) `#14944A`|
|Russian Green (2)|136|Mr Color|32|90|66|![#205A42](https://placehold.co/15x15/205A42/205A42.png) `#205A42`|
|Russian Green Highlight 1|CMC11|Mr Color Modulation Set|93|131|82|![#5D8352](https://placehold.co/15x15/5D8352/5D8352.png) `#5D8352`|
|Russian Green Highlight 2|CMC12|Mr Color Modulation Set|145|182|113|![#91B671](https://placehold.co/15x15/91B671/91B671.png) `#91B671`|
|Russian Green Shadow|CMC13|Mr Color Modulation Set|19|60|54|![#133C36](https://placehold.co/15x15/133C36/133C36.png) `#133C36`|
|Russianircraft Blueii|393|Mr Color|0|0|1|![#000001](https://placehold.co/15x15/000001/000001.png) `#000001`|
|Rust Red|H453|Aqueous Hobby Color|196|100|31|![#C4641F](https://placehold.co/15x15/C4641F/C4641F.png) `#C4641F`|
|Sail Color|45|Mr Color|192|183|127|![#C0B77F](https://placehold.co/15x15/C0B77F/C0B77F.png) `#C0B77F`|
|Sail Color|N85|Acrysion|192|183|127|![#C0B77F](https://placehold.co/15x15/C0B77F/C0B77F.png) `#C0B77F`|
|Sail Color|H85|Aqueous Hobby Color|192|183|127|![#C0B77F](https://placehold.co/15x15/C0B77F/C0B77F.png) `#C0B77F`|
|Salmon Pink|H29|Aqueous Hobby Color|234|85|65|![#EA5541](https://placehold.co/15x15/EA5541/EA5541.png) `#EA5541`|
|Sand Yellow|H459|Aqueous Hobby Color|214|174|88|![#D6AE58](https://placehold.co/15x15/D6AE58/D6AE58.png) `#D6AE58`|
|Sandy Brown|19|Mr Color|159|130|55|![#9F8237](https://placehold.co/15x15/9F8237/9F8237.png) `#9F8237`|
|Sandy Yellow (Dark Yellow)|H79|Aqueous Hobby Color|191|157|90|![#BF9D5A](https://placehold.co/15x15/BF9D5A/BF9D5A.png) `#BF9D5A`|
|Sapphire Blue|XC05|Mr Crystal Color|176|195|225|![#B0C3E1](https://placehold.co/15x15/B0C3E1/B0C3E1.png) `#B0C3E1`|
|Semi Gloss Black|SP92|Mr Color Spray|0|0|0|![#000000](https://placehold.co/15x15/000000/000000.png) `#000000`|
|Semi Gloss Black|92|Mr Color|0|0|0|![#000000](https://placehold.co/15x15/000000/000000.png) `#000000`|
|Semi-gloss Super Clear|181|Mr Color|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Shine Red|H23|Aqueous Hobby Color|230|0|18|![#E60012](https://placehold.co/15x15/E60012/E60012.png) `#E60012`|
|Shine Red|N23|Acrysion|230|0|18|![#E60012](https://placehold.co/15x15/E60012/E60012.png) `#E60012`|
|Shine Red|79|Mr Color|230|0|18|![#E60012](https://placehold.co/15x15/E60012/E60012.png) `#E60012`|
|Shine Red|SP79|Mr Color Spray|230|0|18|![#E60012](https://placehold.co/15x15/E60012/E60012.png) `#E60012`|
|Shine Silver|SP90|Mr Color Spray|211|211|212|![#D3D3D4](https://placehold.co/15x15/D3D3D4/D3D3D4.png) `#D3D3D4`|
|Shine Silver|90|Mr Color|211|211|212|![#D3D3D4](https://placehold.co/15x15/D3D3D4/D3D3D4.png) `#D3D3D4`|
|Silver|N8|Acrysion|220|221|221|![#DCDDDD](https://placehold.co/15x15/DCDDDD/DCDDDD.png) `#DCDDDD`|
|Silver|8|Mr Color|220|221|221|![#DCDDDD](https://placehold.co/15x15/DCDDDD/DCDDDD.png) `#DCDDDD`|
|Silver|H8|Aqueous Hobby Color|220|221|221|![#DCDDDD](https://placehold.co/15x15/DCDDDD/DCDDDD.png) `#DCDDDD`|
|Silver|SP8|Mr Color Spray|220|221|221|![#DCDDDD](https://placehold.co/15x15/DCDDDD/DCDDDD.png) `#DCDDDD`|
|Sky (Duck Egg Green)|H74|Aqueous Hobby Color|215|225|172|![#D7E1AC](https://placehold.co/15x15/D7E1AC/D7E1AC.png) `#D7E1AC`|
|Sky Blue|34|Mr Color|0|140|214|![#008CD6](https://placehold.co/15x15/008CD6/008CD6.png) `#008CD6`|
|Sky Blue|SP34|Mr Color Spray|0|140|214|![#008CD6](https://placehold.co/15x15/008CD6/008CD6.png) `#008CD6`|
|Sky Blue|N25|Acrysion|0|140|214|![#008CD6](https://placehold.co/15x15/008CD6/008CD6.png) `#008CD6`|
|Sky Blue|H25|Aqueous Hobby Color|0|140|214|![#008CD6](https://placehold.co/15x15/008CD6/008CD6.png) `#008CD6`|
|Sky Bs381c/210|368|Mr Color|172|190|153|![#ACBE99](https://placehold.co/15x15/ACBE99/ACBE99.png) `#ACBE99`|
|Smoke Blue|H96|Aqueous Hobby Color|211|237|251|![#D3EDFB](https://placehold.co/15x15/D3EDFB/D3EDFB.png) `#D3EDFB`|
|Smoke Gray|SP101|Mr Color Spray|60|45|30|![#3C2D1E](https://placehold.co/15x15/3C2D1E/3C2D1E.png) `#3C2D1E`|
|Smoke Gray|101|Mr Color|60|45|30|![#3C2D1E](https://placehold.co/15x15/3C2D1E/3C2D1E.png) `#3C2D1E`|
|Smoke Gray|N95|Acrysion|60|45|30|![#3C2D1E](https://placehold.co/15x15/3C2D1E/3C2D1E.png) `#3C2D1E`|
|Smoke Gray|H95|Aqueous Hobby Color|114|98|84|![#726254](https://placehold.co/15x15/726254/726254.png) `#726254`|
|Soot|H343|Aqueous Hobby Color|0|0|0|![#000000](https://placehold.co/15x15/000000/000000.png) `#000000`|
|Soot Black|H452|Aqueous Hobby Color|0|0|0|![#000000](https://placehold.co/15x15/000000/000000.png) `#000000`|
|Stainless|213|Mr Metal Color|81|79|79|![#514F4F](https://placehold.co/15x15/514F4F/514F4F.png) `#514F4F`|
|Steel|N18|Acrysion|0|0|0|![#000000](https://placehold.co/15x15/000000/000000.png) `#000000`|
|Steel|SP28|Mr Color Spray|0|0|0|![#000000](https://placehold.co/15x15/000000/000000.png) `#000000`|
|Steel|28|Mr Color|0|0|0|![#000000](https://placehold.co/15x15/000000/000000.png) `#000000`|
|Steel|H18|Aqueous Hobby Color|0|0|0|![#000000](https://placehold.co/15x15/000000/000000.png) `#000000`|
|Steel Red|N38|Acrysion|59|48|57|![#3B3039](https://placehold.co/15x15/3B3039/3B3039.png) `#3B3039`|
|Steel Red|H38|Aqueous Hobby Color|59|48|57|![#3B3039](https://placehold.co/15x15/3B3039/3B3039.png) `#3B3039`|
|Super Chrome Silver 2|SM206|Mr Color Super Metallic 2|215|214|215|![#D7D6D7](https://placehold.co/15x15/D7D6D7/D7D6D7.png) `#D7D6D7`|
|Super Clear Gray Tone|183|Mr Color|245|247|247|![#F5F7F7](https://placehold.co/15x15/F5F7F7/F5F7F7.png) `#F5F7F7`|
|Super Clear III|GX100|Mr Color GX|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Super Fine Silver 2|SM201|Mr Color Super Metallic 2|219|218|219|![#DBDADB](https://placehold.co/15x15/DBDADB/DBDADB.png) `#DBDADB`|
|Super Gold 2|SM202|Mr Color Super Metallic 2|207|177|110|![#CFB16E](https://placehold.co/15x15/CFB16E/CFB16E.png) `#CFB16E`|
|Super Iron 2|SM203|Mr Color Super Metallic 2|196|195|195|![#C4C3C3](https://placehold.co/15x15/C4C3C3/C4C3C3.png) `#C4C3C3`|
|Super Italian Red|158|Mr Color|216|12|24|![#D80C18](https://placehold.co/15x15/D80C18/D80C18.png) `#D80C18`|
|Super Silver|159|Mr Color|220|221|221|![#DCDDDD](https://placehold.co/15x15/DCDDDD/DCDDDD.png) `#DCDDDD`|
|Super Smooth Clear|GX114|Mr Color GX|220|221|221|![#DCDDDD](https://placehold.co/15x15/DCDDDD/DCDDDD.png) `#DCDDDD`|
|Super Stainless 2|SM204|Mr Color Super Metallic 2|201|201|200|![#C9C9C8](https://placehold.co/15x15/C9C9C8/C9C9C8.png) `#C9C9C8`|
|Super Titanium 2|SM205|Mr Color Super Metallic 2|222|218|220|![#DEDADC](https://placehold.co/15x15/DEDADC/DEDADC.png) `#DEDADC`|
|Super White Iv|156|Mr Color|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Susie Blue|GX5|Mr Color GX|0|78|162|![#004EA2](https://placehold.co/15x15/004EA2/004EA2.png) `#004EA2`|
|Tan|44|Mr Color|201|169|101|![#C9A965](https://placehold.co/15x15/C9A965/C9A965.png) `#C9A965`|
|Tan|SP44|Mr Color Spray|201|169|101|![#C9A965](https://placehold.co/15x15/C9A965/C9A965.png) `#C9A965`|
|Tan|N27|Acrysion|201|169|101|![#C9A965](https://placehold.co/15x15/C9A965/C9A965.png) `#C9A965`|
|Tan|H27|Aqueous Hobby Color|201|169|101|![#C9A965](https://placehold.co/15x15/C9A965/C9A965.png) `#C9A965`|
|Teerschwarz|521|Mr Color|34|40|41|![#222829](https://placehold.co/15x15/222829/222829.png) `#222829`|
|Tire Black|N77|Acrysion|0|0|0|![#000000](https://placehold.co/15x15/000000/000000.png) `#000000`|
|Tire Black|H77|Aqueous Hobby Color|0|0|0|![#000000](https://placehold.co/15x15/000000/000000.png) `#000000`|
|Tire Black|137|Mr Color|0|0|0|![#000000](https://placehold.co/15x15/000000/000000.png) `#000000`|
|Topaz Gold|XC02|Mr Crystal Color|195|213|211|![#C3D5D3](https://placehold.co/15x15/C3D5D3/C3D5D3.png) `#C3D5D3`|
|Tourmaline Green|XC06|Mr Crystal Color|174|202|223|![#AECADF](https://placehold.co/15x15/AECADF/AECADF.png) `#AECADF`|
|Turquoise Green|XC07|Mr Crystal Color|170|196|229|![#AAC4E5](https://placehold.co/15x15/AAC4E5/AAC4E5.png) `#AAC4E5`|
|U.N.T'.s MS Gray|UG6|Mr Color Gundam Color|142|175|140|![#8EAF8C](https://placehold.co/15x15/8EAF8C/8EAF8C.png) `#8EAF8C`|
|U.N.T'.s MS Gray|SG6|Gundam Color Spray|142|175|140|![#8EAF8C](https://placehold.co/15x15/8EAF8C/8EAF8C.png) `#8EAF8C`|
|Ueno Black|GX2|Mr Color GX|0|0|0|![#000000](https://placehold.co/15x15/000000/000000.png) `#000000`|
|Violet|N49|Acrysion|115|132|193|![#7384C1](https://placehold.co/15x15/7384C1/7384C1.png) `#7384C1`|
|Violet|H49|Aqueous Hobby Color|115|132|193|![#7384C1](https://placehold.co/15x15/7384C1/7384C1.png) `#7384C1`|
|White|N1|Acrysion|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|White|SP1|Mr Color Spray|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|White|H1|Aqueous Hobby Color|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|White|1|Mr Color|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|White Fs17875|H316|Aqueous Hobby Color|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|White Fs17875|316|Mr Color|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|White Green|H31|Aqueous Hobby Color|235|245|236|![#EBF5EC](https://placehold.co/15x15/EBF5EC/EBF5EC.png) `#EBF5EC`|
|White Peach|SM211|Mr Color Lascivus|251|215|190|![#FBD7BE](https://placehold.co/15x15/FBD7BE/FBD7BE.png) `#FBD7BE`|
|White Pearl|SP151|Mr Color Spray|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|White Pearl|151|Mr Color|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|White Silver|GX213|Mr Metallic Color GX|163|160|177|![#A3A0B1](https://placehold.co/15x15/A3A0B1/A3A0B1.png) `#A3A0B1`|
|Wine Red|N43|Acrysion|176|30|49|![#B01E31](https://placehold.co/15x15/B01E31/B01E31.png) `#B01E31`|
|Wine Red|100|Mr Color|176|30|49|![#B01E31](https://placehold.co/15x15/B01E31/B01E31.png) `#B01E31`|
|Wine Red|H43|Aqueous Hobby Color|200|22|30|![#C8161E](https://placehold.co/15x15/C8161E/C8161E.png) `#C8161E`|
|Wood Brown|H37|Aqueous Hobby Color|106|74|49|![#6A4A31](https://placehold.co/15x15/6A4A31/6A4A31.png) `#6A4A31`|
|Wood Brown|43|Mr Color|106|74|49|![#6A4A31](https://placehold.co/15x15/6A4A31/6A4A31.png) `#6A4A31`|
|Wood Brown|N37|Acrysion|106|74|49|![#6A4A31](https://placehold.co/15x15/6A4A31/6A4A31.png) `#6A4A31`|
|Wood Brown|SP43|Mr Color Spray|106|74|49|![#6A4A31](https://placehold.co/15x15/6A4A31/6A4A31.png) `#6A4A31`|
|Yellow|N4|Acrysion|255|225|0|![#FFE100](https://placehold.co/15x15/FFE100/FFE100.png) `#FFE100`|
|Yellow|4|Mr Color|255|225|0|![#FFE100](https://placehold.co/15x15/FFE100/FFE100.png) `#FFE100`|
|Yellow|SP4|Mr Color Spray|255|225|0|![#FFE100](https://placehold.co/15x15/FFE100/FFE100.png) `#FFE100`|
|Yellow|H4|Aqueous Hobby Color|255|225|0|![#FFE100](https://placehold.co/15x15/FFE100/FFE100.png) `#FFE100`|
|Yellow|CR3|Primary Color Pigments|255|241|0|![#FFF100](https://placehold.co/15x15/FFF100/FFF100.png) `#FFF100`|
|Yellow Fs13538|329|Mr Color|245|162|0|![#F5A200](https://placehold.co/15x15/F5A200/F5A200.png) `#F5A200`|
|Yellow Fs13538 A|H329|Aqueous Hobby Color|246|168|0|![#F6A800](https://placehold.co/15x15/F6A800/F6A800.png) `#F6A800`|
|Yellow Fs33531|313|Mr Color|232|198|137|![#E8C689](https://placehold.co/15x15/E8C689/E8C689.png) `#E8C689`|
|Yellow Fs33531|H313|Aqueous Hobby Color|234|200|80|![#EAC850](https://placehold.co/15x15/EAC850/EAC850.png) `#EAC850`|
|Yellow Green|SP64|Mr Color Spray|0|163|59|![#00A33B](https://placehold.co/15x15/00A33B/00A33B.png) `#00A33B`|
|Yellow Green|64|Mr Color|0|163|59|![#00A33B](https://placehold.co/15x15/00A33B/00A33B.png) `#00A33B`|
|Yellow Green|N16|Acrysion|0|158|59|![#009E3B](https://placehold.co/15x15/009E3B/009E3B.png) `#009E3B`|
|Yellow Green|H16|Aqueous Hobby Color|0|158|59|![#009E3B](https://placehold.co/15x15/009E3B/009E3B.png) `#009E3B`|
|Zeon's MS Gray|UG10|Mr Color Gundam Color|221|107|105|![#DD6B69](https://placehold.co/15x15/DD6B69/DD6B69.png) `#DD6B69`|
|Zeon's MS Gray|SG10|Gundam Color Spray|221|107|105|![#DD6B69](https://placehold.co/15x15/DD6B69/DD6B69.png) `#DD6B69`|
|Zinc-chromate Type I Fs34151|351|Mr Color|120|120|69|![#787845](https://placehold.co/15x15/787845/787845.png) `#787845`|
<p align="center"><img src="../logos/logo_rnd.png" height="70" /></p>
<p align="center">Made available by <a href="https://miniaturepainterpro.app/">Miniature Painter Pro</a></p>
<p align="center">
<a href="https://play.google.com/store/apps/details?id=com.rfsp.paintmaster"> <img src="../logos/Android.png" height="30" /></a>
<a href="https://apps.apple.com/us/app/miniature-painter-pro/id1495938928"> <img src="../logos/iOS.png" height="30" /></a>
</p>
