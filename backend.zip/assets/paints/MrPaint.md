# Mr Paint
![MrPaint](../logos/MrPaint.png "MrPaint")

|Name|Code|Set|R|G|B|Hex|
|---|---|---|---|---|---|---|
|4bo - 1941 Russian Green|MRP-A034|Mr Paint - Aqua Colors|69|64|34|![#454022](https://placehold.co/15x15/454022/454022.png) `#454022`|
|4bo - 1947 Russian Green|MRP-A035|Mr Paint - Aqua Colors|107|91|58|![#6B5B3A](https://placehold.co/15x15/6B5B3A/6B5B3A.png) `#6B5B3A`|
|4bo Russian Green|MRP-026|Mr Paint|70|64|28|![#46401C](https://placehold.co/15x15/46401C/46401C.png) `#46401C`|
|6k Russian Brown|MRP-A036|Mr Paint - Aqua Colors|42|32|20|![#2A2014](https://placehold.co/15x15/2A2014/2A2014.png) `#2A2014`|
|6k Russian Brown|MRP-275|Mr Paint|44|30|17|![#2C1E11](https://placehold.co/15x15/2C1E11/2C1E11.png) `#2C1E11`|
|7k Russian Tan|MRP-A037|Mr Paint - Aqua Colors|141|120|93|![#8D785D](https://placehold.co/15x15/8D785D/8D785D.png) `#8D785D`|
|7k Russian Tan|MRP-276|Mr Paint|145|120|90|![#91785A](https://placehold.co/15x15/91785A/91785A.png) `#91785A`|
|A Ii 3 Green|MRP-023|Mr Paint|86|74|32|![#564A20](https://placehold.co/15x15/564A20/564A20.png) `#564A20`|
|A Ii G Light Blue|MRP-024|Mr Paint|102|178|174|![#66B2AE](https://placehold.co/15x15/66B2AE/66B2AE.png) `#66B2AE`|
|A Ii Kr  Red|MRP-025|Mr Paint|201|32|37|![#C92025](https://placehold.co/15x15/C92025/C92025.png) `#C92025`|
|A-14 Faded Grey|MRP-021|Mr Paint|120|130|132|![#788284](https://placehold.co/15x15/788284/788284.png) `#788284`|
|A-21 Brown|MRP-022|Mr Paint|116|107|92|![#746B5C](https://placehold.co/15x15/746B5C/746B5C.png) `#746B5C`|
|Air Superiority Blue FS35450|MRP-240|Mr Paint|118|178|189|![#76B2BD](https://placehold.co/15x15/76B2BD/76B2BD.png) `#76B2BD`|
|Aircraft Exterior Grey  FS36300|MRP-247|Mr Paint|139|148|155|![#8B949B](https://placehold.co/15x15/8B949B/8B949B.png) `#8B949B`|
|Aircraft Grey Bs693|MRP-383|Mr Paint|117|128|120|![#758078](https://placehold.co/15x15/758078/758078.png) `#758078`|
|Aircraft Grey-green Bs283|MRP-228|Mr Paint|102|118|91|![#66765B](https://placehold.co/15x15/66765B/66765B.png) `#66765B`|
|Amt-1 Light Brown|MRP-015|Mr Paint|111|100|82|![#6F6452](https://placehold.co/15x15/6F6452/6F6452.png) `#6F6452`|
|Amt-11 Blue Grey|MRP-019|Mr Paint|102|115|121|![#667379](https://placehold.co/15x15/667379/667379.png) `#667379`|
|Amt-12 Dark Grey|MRP-020|Mr Paint|70|75|79|![#464B4F](https://placehold.co/15x15/464B4F/464B4F.png) `#464B4F`|
|Amt-4 Camouflage Green|MRP-016|Mr Paint|72|66|32|![#484220](https://placehold.co/15x15/484220/484220.png) `#484220`|
|Amt-6 Black|MRP-017|Mr Paint|26|32|32|![#1A2020](https://placehold.co/15x15/1A2020/1A2020.png) `#1A2020`|
|Amt-7 Grey Blue|MRP-018|Mr Paint|95|156|161|![#5F9CA1](https://placehold.co/15x15/5F9CA1/5F9CA1.png) `#5F9CA1`|
|Anodized Aluminium|MRP-A016|Mr Paint - Aqua Colors|128|118|91|![#80765B](https://placehold.co/15x15/80765B/80765B.png) `#80765B`|
|Anodized Aluminium|MRP-081|Mr Paint|129|118|88|![#817658](https://placehold.co/15x15/817658/817658.png) `#817658`|
|Anticorrosiva|MRP-317|Mr Paint|125|143|103|![#7D8F67](https://placehold.co/15x15/7D8F67/7D8F67.png) `#7D8F67`|
|Aotake Blue|MRP-A022|Mr Paint - Aqua Colors|0|88|96|![#005860](https://placehold.co/15x15/005860/005860.png) `#005860`|
|Aotake Blue Primer|MRP-410|Mr Paint|0|85|89|![#005559](https://placehold.co/15x15/005559/005559.png) `#005559`|
|Aotake Green|MRP-A023|Mr Paint - Aqua Colors|0|97|93|![#00615D](https://placehold.co/15x15/00615D/00615D.png) `#00615D`|
|Aotake Green Primer|MRP-409|Mr Paint|0|93|86|![#005D56](https://placehold.co/15x15/005D56/005D56.png) `#005D56`|
|Army Forest Green  FS34086|MRP-434|Mr Paint|75|76|62|![#4B4C3E](https://placehold.co/15x15/4B4C3E/4B4C3E.png) `#4B4C3E`|
|Azure Blue|MRP-119|Mr Paint|104|153|193|![#6899C1](https://placehold.co/15x15/6899C1/6899C1.png) `#6899C1`|
|Azure Blue Ana 609|MRP-143|Mr Paint|99|148|189|![#6394BD](https://placehold.co/15x15/6394BD/6394BD.png) `#6394BD`|
|Azzurro|MRP-316|Mr Paint|1|84|128|![#015480](https://placehold.co/15x15/015480/015480.png) `#015480`|
|Azzurro Celeste|MRP-332|Mr Paint|104|153|193|![#6899C1](https://placehold.co/15x15/6899C1/6899C1.png) `#6899C1`|
|Azzurro Subalare|MRP-319|Mr Paint|118|148|156|![#76949C](https://placehold.co/15x15/76949C/76949C.png) `#76949C`|
|BBS Gold|MRP-C016|Mr Paint - Car|137|112|71|![#897047](https://placehold.co/15x15/897047/897047.png) `#897047`|
|BBS Silver|MRP-C017|Mr Paint - Car|118|122|123|![#767A7B](https://placehold.co/15x15/767A7B/767A7B.png) `#767A7B`|
|Basalt Grey RAL 7012|MRP-209|Mr Paint|87|92|96|![#575C60](https://placehold.co/15x15/575C60/575C60.png) `#575C60`|
|Beige RAL 1001|MRP-210|Mr Paint|210|173|121|![#D2AD79](https://placehold.co/15x15/D2AD79/D2AD79.png) `#D2AD79`|
|Bianco Avorio|MRP-307|Mr Paint|246|208|135|![#F6D087](https://placehold.co/15x15/F6D087/F6D087.png) `#F6D087`|
|Bianco Neve|MRP-308|Mr Paint|233|236|229|![#E9ECE5](https://placehold.co/15x15/E9ECE5/E9ECE5.png) `#E9ECE5`|
|Black|MRP-A001|Mr Paint - Aqua Colors|0|0|0|![#000000](https://placehold.co/15x15/000000/000000.png) `#000000`|
|Black|MRP-255|Mr Paint|33|34|38|![#212226](https://placehold.co/15x15/212226/212226.png) `#212226`|
|Black 093m|MRP-176|Mr Paint|26|31|34|![#1A1F22](https://placehold.co/15x15/1A1F22/1A1F22.png) `#1A1F22`|
|Black/Basic Black|MRP-005|Mr Paint|0|0|0|![#000000](https://placehold.co/15x15/000000/000000.png) `#000000`|
|Blaugrün|MRP-181|Mr Paint|156|181|159|![#9CB59F](https://placehold.co/15x15/9CB59F/9CB59F.png) `#9CB59F`|
|Blue  SU-33|MRP-199|Mr Paint|1|171|206|![#01ABCE](https://placehold.co/15x15/01ABCE/01ABCE.png) `#01ABCE`|
|Blue - Gray|MRP-405|Mr Paint|186|196|206|![#BAC4CE](https://placehold.co/15x15/BAC4CE/BAC4CE.png) `#BAC4CE`|
|Blue Angels Blue|MRP-188|Mr Paint|1|52|79|![#01344F](https://placehold.co/15x15/01344F/01344F.png) `#01344F`|
|Blue Clear|MRP-267|Mr Paint|21|96|179|![#1560B3](https://placehold.co/15x15/1560B3/1560B3.png) `#1560B3`|
|Blue FS35190|MRP-239|Mr Paint|72|143|163|![#488FA3](https://placehold.co/15x15/488FA3/488FA3.png) `#488FA3`|
|Blue Green FS35414|MRP-393|Mr Paint|125|164|161|![#7DA4A1](https://placehold.co/15x15/7DA4A1/7DA4A1.png) `#7DA4A1`|
|Blue Grey M-485|MRP-133|Mr Paint|85|124|131|![#557C83](https://placehold.co/15x15/557C83/557C83.png) `#557C83`|
|Blue Metallic For Subaru Brz|MRP-C025|Mr Paint - Car|0|52|92|![#00345C](https://placehold.co/15x15/00345C/00345C.png) `#00345C`|
|Blue SU-27|MRP-044|Mr Paint|0|156|197|![#009CC5](https://placehold.co/15x15/009CC5/009CC5.png) `#009CC5`|
|Blue SU-35|MRP-298|Mr Paint|116|163|181|![#74A3B5](https://placehold.co/15x15/74A3B5/74A3B5.png) `#74A3B5`|
|Boeing Grey 707 FS16515|MRP-363|Mr Paint|192|193|185|![#C0C1B9](https://placehold.co/15x15/C0C1B9/C0C1B9.png) `#C0C1B9`|
|Brass|MRP-150|Mr Paint|146|123|73|![#927B49](https://placehold.co/15x15/927B49/927B49.png) `#927B49`|
|Brass|MRP-A018|Mr Paint - Aqua Colors|142|123|80|![#8E7B50](https://placehold.co/15x15/8E7B50/8E7B50.png) `#8E7B50`|
|Bronze|MRP-A019|Mr Paint - Aqua Colors|56|34|23|![#382217](https://placehold.co/15x15/382217/382217.png) `#382217`|
|Bronze|MRP-151|Mr Paint|59|33|20|![#3B2114](https://placehold.co/15x15/3B2114/3B2114.png) `#3B2114`|
|Brown|MRP-351|Mr Paint|148|116|78|![#94744E](https://placehold.co/15x15/94744E/94744E.png) `#94744E`|
|Brown  L-29 Delfín|MRP-074|Mr Paint|112|65|49|![#704131](https://placehold.co/15x15/704131/704131.png) `#704131`|
|Brown Green Čsn 2250|MRP-010|Mr Paint|140|122|84|![#8C7A54](https://placehold.co/15x15/8C7A54/8C7A54.png) `#8C7A54`|
|Bruno|MRP-315|Mr Paint|75|53|42|![#4B352A](https://placehold.co/15x15/4B352A/4B352A.png) `#4B352A`|
|Bruno Chiaro|MRP-314|Mr Paint|120|100|89|![#786459](https://placehold.co/15x15/786459/786459.png) `#786459`|
|Bruno Mimetico|MRP-322|Mr Paint|63|53|41|![#3F3529](https://placehold.co/15x15/3F3529/3F3529.png) `#3F3529`|
|Bruno Rossiccio|MRP-313|Mr Paint|110|62|52|![#6E3E34](https://placehold.co/15x15/6E3E34/6E3E34.png) `#6E3E34`|
|Bsc No.28|MRP-334|Mr Paint|156|151|119|![#9C9777](https://placehold.co/15x15/9C9777/9C9777.png) `#9C9777`|
|Bsc No.34|MRP-335|Mr Paint|82|85|76|![#52554C](https://placehold.co/15x15/52554C/52554C.png) `#52554C`|
|Bsc No.49|MRP-336|Mr Paint|76|26|25|![#4C1A19](https://placehold.co/15x15/4C1A19/4C1A19.png) `#4C1A19`|
|Bsc No.61|MRP-337|Mr Paint|205|160|93|![#CDA05D](https://placehold.co/15x15/CDA05D/CDA05D.png) `#CDA05D`|
|Bsc No.64|MRP-338|Mr Paint|205|182|138|![#CDB68A](https://placehold.co/15x15/CDB68A/CDB68A.png) `#CDB68A`|
|Burnt Iron|MRP-147|Mr Paint|108|101|95|![#6C655F](https://placehold.co/15x15/6C655F/6C655F.png) `#6C655F`|
|Burnt Metal Blue|MRP-A024|Mr Paint - Aqua Colors|30|42|54|![#1E2A36](https://placehold.co/15x15/1E2A36/1E2A36.png) `#1E2A36`|
|Burnt Metal Blue|MRP-155|Mr Paint|26|42|55|![#1A2A37](https://placehold.co/15x15/1A2A37/1A2A37.png) `#1A2A37`|
|Burnt Metal Violet|MRP-156|Mr Paint|61|54|87|![#3D3657](https://placehold.co/15x15/3D3657/3D3657.png) `#3D3657`|
|Burnt Metal Violet|MRP-A025|Mr Paint - Aqua Colors|59|54|86|![#3B3656](https://placehold.co/15x15/3B3656/3B3656.png) `#3B3656`|
|Camouflage Beige  Bs389|MRP-377|Mr Paint|153|139|113|![#998B71](https://placehold.co/15x15/998B71/998B71.png) `#998B71`|
|Camouflage Grey  Bs626|MRP-373|Mr Paint|139|149|151|![#8B9597](https://placehold.co/15x15/8B9597/8B9597.png) `#8B9597`|
|Camouflage Grey FS36170|MRP-280|Mr Paint|104|103|101|![#686765](https://placehold.co/15x15/686765/686765.png) `#686765`|
|Cdl Bleached|MRP-256|Mr Paint|236|224|202|![#ECE0CA](https://placehold.co/15x15/ECE0CA/ECE0CA.png) `#ECE0CA`|
|Cdl Variant 1|MRP-257|Mr Paint|171|163|142|![#ABA38E](https://placehold.co/15x15/ABA38E/ABA38E.png) `#ABA38E`|
|Cdl Variant 2|MRP-258|Mr Paint|183|153|115|![#B79973](https://placehold.co/15x15/B79973/B79973.png) `#B79973`|
|Celomer 1620|MRP-357|Mr Paint|85|110|117|![#556E75](https://placehold.co/15x15/556E75/556E75.png) `#556E75`|
|Celomer 1625|MRP-356|Mr Paint|139|148|155|![#8B949B](https://placehold.co/15x15/8B949B/8B949B.png) `#8B949B`|
|Chameleon Gold-green|MRP-C027|Mr Paint - Car|31|61|51|![#1F3D33](https://placehold.co/15x15/1F3D33/1F3D33.png) `#1F3D33`|
|Chameleon Pink-bronz|MRP-C028|Mr Paint - Car|52|58|30|![#343A1E](https://placehold.co/15x15/343A1E/343A1E.png) `#343A1E`|
|Chameleon Purple-green|MRP-C029|Mr Paint - Car|31|58|49|![#1F3A31](https://placehold.co/15x15/1F3A31/1F3A31.png) `#1F3A31`|
|Cherry Red Čsn 8850|MRP-088|Mr Paint|107|2|16|![#6B0210](https://placehold.co/15x15/6B0210/6B0210.png) `#6B0210`|
|Chestnut Brown|MRP-166|Mr Paint|66|45|40|![#422D28](https://placehold.co/15x15/422D28/422D28.png) `#422D28`|
|Chipping Dark Brown Matt|MRP-A027|Mr Paint - Aqua Colors|44|40|41|![#2C2829](https://placehold.co/15x15/2C2829/2C2829.png) `#2C2829`|
|Chocolate  Čsn 2430|MRP-159|Mr Paint|85|49|35|![#553123](https://placehold.co/15x15/553123/553123.png) `#553123`|
|Chrome|MRP-031|Mr Paint|248|248|248|![#F8F8F8](https://placehold.co/15x15/F8F8F8/F8F8F8.png) `#F8F8F8`|
|Chrome|MRP-A011|Mr Paint - Aqua Colors|118|122|123|![#767A7B](https://placehold.co/15x15/767A7B/767A7B.png) `#767A7B`|
|Cocpit Light Blue Mig 29 Smt|MRP-290|Mr Paint|154|188|187|![#9ABCBB](https://placehold.co/15x15/9ABCBB/9ABCBB.png) `#9ABCBB`|
|Cocpit Light Grey Mig 29|MRP-291|Mr Paint|140|159|163|![#8C9FA3](https://placehold.co/15x15/8C9FA3/8C9FA3.png) `#8C9FA3`|
|Copper|MRP-A021|Mr Paint - Aqua Colors|103|51|30|![#67331E](https://placehold.co/15x15/67331E/67331E.png) `#67331E`|
|Copper|MRP-154|Mr Paint|109|47|26|![#6D2F1A](https://placehold.co/15x15/6D2F1A/6D2F1A.png) `#6D2F1A`|
|Cream  RAL 9001|MRP-A033|Mr Paint - Aqua Colors|230|224|212|![#E6E0D4](https://placehold.co/15x15/E6E0D4/E6E0D4.png) `#E6E0D4`|
|Dark Admiralty Grey (Bs 632 / FS 36152)|MRP-439|Mr Paint|92|100|103|![#5C6467](https://placehold.co/15x15/5C6467/5C6467.png) `#5C6467`|
|Dark Aluminium|MRP-A014|Mr Paint - Aqua Colors|20|20|20|![#141414](https://placehold.co/15x15/141414/141414.png) `#141414`|
|Dark Aluminium|MRP-146|Mr Paint|108|113|107|![#6C716B](https://placehold.co/15x15/6C716B/6C716B.png) `#6C716B`|
|Dark Blue  SU-33|MRP-200|Mr Paint|44|111|128|![#2C6F80](https://placehold.co/15x15/2C6F80/2C6F80.png) `#2C6F80`|
|Dark Blue 438|MRP-219|Mr Paint|20|49|55|![#143137](https://placehold.co/15x15/143137/143137.png) `#143137`|
|Dark Blue Green FS34058|MRP-388|Mr Paint|23|74|77|![#174A4D](https://placehold.co/15x15/174A4D/174A4D.png) `#174A4D`|
|Dark Blue SU-27|MRP-045|Mr Paint|1|94|137|![#015E89](https://placehold.co/15x15/015E89/015E89.png) `#015E89`|
|Dark Brown  Čsn 2430/Čsn 1010|MRP-161|Mr Paint|127|80|62|![#7F503E](https://placehold.co/15x15/7F503E/7F503E.png) `#7F503E`|
|Dark Camouflge Grey  Bs629|MRP-375|Mr Paint|101|111|121|![#656F79](https://placehold.co/15x15/656F79/656F79.png) `#656F79`|
|Dark Chrome Yellow Čsn 6400|MRP-028|Mr Paint|245|136|31|![#F5881F](https://placehold.co/15x15/F5881F/F5881F.png) `#F5881F`|
|Dark Earth|MRP-108|Mr Paint|113|87|64|![#715740](https://placehold.co/15x15/715740/715740.png) `#715740`|
|Dark Earth Ana 617|MRP-145|Mr Paint|115|86|52|![#735634](https://placehold.co/15x15/735634/735634.png) `#735634`|
|Dark Gray|MRP-404|Mr Paint|73|78|82|![#494E52](https://placehold.co/15x15/494E52/494E52.png) `#494E52`|
|Dark Gray FS36118|MRP-040|Mr Paint|66|82|95|![#42525F](https://placehold.co/15x15/42525F/42525F.png) `#42525F`|
|Dark Gray Radio Antenna SU-27....|MRP-047|Mr Paint|120|130|132|![#788284](https://placehold.co/15x15/788284/788284.png) `#788284`|
|Dark Green|MRP-352|Mr Paint|30|69|51|![#1E4533](https://placehold.co/15x15/1E4533/1E4533.png) `#1E4533`|
|Dark Green|MRP-110|Mr Paint|62|63|45|![#3E3F2D](https://placehold.co/15x15/3E3F2D/3E3F2D.png) `#3E3F2D`|
|Dark Green - Blue SU-34|MRP-204|Mr Paint|0|111|112|![#006F70](https://placehold.co/15x15/006F70/006F70.png) `#006F70`|
|Dark Green 326m|MRP-177|Mr Paint|57|71|56|![#394738](https://placehold.co/15x15/394738/394738.png) `#394738`|
|Dark Green Camo FS34084|MRP-433|Mr Paint|57|56|52|![#393834](https://placehold.co/15x15/393834/393834.png) `#393834`|
|Dark Green FS34096|MRP-370|Mr Paint|75|84|65|![#4B5441](https://placehold.co/15x15/4B5441/4B5441.png) `#4B5441`|
|Dark Green G4|MRP-343|Mr Paint|57|65|54|![#394136](https://placehold.co/15x15/394136/394136.png) `#394136`|
|Dark Green Grey Mig 29 Smt|MRP-288|Mr Paint|62|81|85|![#3E5155](https://placehold.co/15x15/3E5155/3E5155.png) `#3E5155`|
|Dark Green International FS34108|MRP-438|Mr Paint|53|96|77|![#35604D](https://placehold.co/15x15/35604D/35604D.png) `#35604D`|
|Dark Green Mig 29 Smt|MRP-286|Mr Paint|87|93|67|![#575D43](https://placehold.co/15x15/575D43/575D43.png) `#575D43`|
|Dark Grey 033|MRP-221|Mr Paint|130|136|132|![#828884](https://placehold.co/15x15/828884/828884.png) `#828884`|
|Dark Grey FS36076|MRP-366|Mr Paint|64|74|83|![#404A53](https://placehold.co/15x15/404A53/404A53.png) `#404A53`|
|Dark Grey Mig 29 Smt|MRP-289|Mr Paint|35|36|41|![#232429](https://placehold.co/15x15/232429/232429.png) `#232429`|
|Dark Gunship Grey FS36081|MRP-241|Mr Paint|84|90|90|![#545A5A](https://placehold.co/15x15/545A5A/545A5A.png) `#545A5A`|
|Dark Olive Green 328|MRP-218|Mr Paint|46|51|44|![#2E332C](https://placehold.co/15x15/2E332C/2E332C.png) `#2E332C`|
|Dark Olive Green PFI|MRP-340|Mr Paint|65|64|44|![#41402C](https://placehold.co/15x15/41402C/41402C.png) `#41402C`|
|Dark Orange F-16|MRP-206|Mr Paint|141|45|20|![#8D2D14](https://placehold.co/15x15/8D2D14/8D2D14.png) `#8D2D14`|
|Dark Sea Grey|MRP-113|Mr Paint|91|98|106|![#5B626A](https://placehold.co/15x15/5B626A/5B626A.png) `#5B626A`|
|Dark Slate Grey|MRP-117|Mr Paint|82|85|76|![#52554C](https://placehold.co/15x15/52554C/52554C.png) `#52554C`|
|Dark Wood|MRP-262|Mr Paint|74|45|37|![#4A2D25](https://placehold.co/15x15/4A2D25/4A2D25.png) `#4A2D25`|
|Dark Yellow  FS33448|MRP-436|Mr Paint|179|149|111|![#B3956F](https://placehold.co/15x15/B3956F/B3956F.png) `#B3956F`|
|Dark Yellow  RAL 7028|MRP-A032|Mr Paint - Aqua Colors|169|133|75|![#A9854B](https://placehold.co/15x15/A9854B/A9854B.png) `#A9854B`|
|Dark Yellow  RAL 7028 Var. 1|MRP-215|Mr Paint|146|127|110|![#927F6E](https://placehold.co/15x15/927F6E/927F6E.png) `#927F6E`|
|Dark Yellow  RAL 7028 Var. 2|MRP-216|Mr Paint|140|121|91|![#8C795B](https://placehold.co/15x15/8C795B/8C795B.png) `#8C795B`|
|Dark Yellow RAL 7028|MRP-037|Mr Paint|176|131|64|![#B08340](https://placehold.co/15x15/B08340/B08340.png) `#B08340`|
|Dawn Grey FS16492|MRP-362|Mr Paint|181|183|169|![#B5B7A9](https://placehold.co/15x15/B5B7A9/B5B7A9.png) `#B5B7A9`|
|Deep Bronze Green No. 24|MRP-341|Mr Paint|49|53|30|![#31351E](https://placehold.co/15x15/31351E/31351E.png) `#31351E`|
|Deep Buff  Bs360|MRP-378|Mr Paint|181|113|52|![#B57134](https://placehold.co/15x15/B57134/B57134.png) `#B57134`|
|Desert Pink Raf|MRP-185|Mr Paint|169|122|102|![#A97A66](https://placehold.co/15x15/A97A66/A97A66.png) `#A97A66`|
|Desert Pink Zi|MRP-339|Mr Paint|190|151|120|![#BE9778](https://placehold.co/15x15/BE9778/BE9778.png) `#BE9778`|
|Dove Grey|MRP-223|Mr Paint|154|160|160|![#9AA0A0](https://placehold.co/15x15/9AA0A0/9AA0A0.png) `#9AA0A0`|
|Duraluminium|MRP-008|Mr Paint|134|133|128|![#868580](https://placehold.co/15x15/868580/868580.png) `#868580`|
|Earth Red FS30117|MRP-387|Mr Paint|127|80|62|![#7F503E](https://placehold.co/15x15/7F503E/7F503E.png) `#7F503E`|
|Earth Yellow FS30257|MRP-368|Mr Paint|184|133|80|![#B88550](https://placehold.co/15x15/B88550/B88550.png) `#B88550`|
|Eggplant Dark Grey - Blue SU-34|MRP-205|Mr Paint|42|39|50|![#2A2732](https://placehold.co/15x15/2A2732/2A2732.png) `#2A2732`|
|Emerald Green RAL 6001|MRP-A010|Mr Paint - Aqua Colors|65|102|58|![#41663A](https://placehold.co/15x15/41663A/41663A.png) `#41663A`|
|Exhaust Metal|MRP-148|Mr Paint|52|52|50|![#343432](https://placehold.co/15x15/343432/343432.png) `#343432`|
|Exhaust Metal|MRP-A017|Mr Paint - Aqua Colors|52|52|50|![#343432](https://placehold.co/15x15/343432/343432.png) `#343432`|
|Exhaust Soot|MRP-180|Mr Paint|137|137|137|![#898989](https://placehold.co/15x15/898989/898989.png) `#898989`|
|Extra Dark Rust|MRP-361|Mr Paint|45|39|39|![#2D2727](https://placehold.co/15x15/2D2727/2D2727.png) `#2D2727`|
|Extra Dark Sea Grey|MRP-114|Mr Paint|59|77|87|![#3B4D57](https://placehold.co/15x15/3B4D57/3B4D57.png) `#3B4D57`|
|Field Green FS34095|MRP-369|Mr Paint|68|71|44|![#44472C](https://placehold.co/15x15/44472C/44472C.png) `#44472C`|
|Field Green FS34097|MRP-236|Mr Paint|75|84|65|![#4B5441](https://placehold.co/15x15/4B5441/4B5441.png) `#4B5441`|
|Fine Surface Primer-black|MRP-LPB|Mr Paint|0|0|0|![#000000](https://placehold.co/15x15/000000/000000.png) `#000000`|
|Fine Surface Primer-fleshtone|MRP-LPF|Mr Paint|194|136|86|![#C28856](https://placehold.co/15x15/C28856/C28856.png) `#C28856`|
|Fine Surface Primer-gray|MRP-LPG|Mr Paint|115|132|139|![#73848B](https://placehold.co/15x15/73848B/73848B.png) `#73848B`|
|Fine Surface Primer-olive Green|MRP-LPO|Mr Paint|77|77|49|![#4D4D31](https://placehold.co/15x15/4D4D31/4D4D31.png) `#4D4D31`|
|Fine Surface Primer-oxide Red|MRP-LPR|Mr Paint|105|37|24|![#692518](https://placehold.co/15x15/692518/692518.png) `#692518`|
|Fine Surface Primer-sand Yellow|MRP-LPY|Mr Paint|191|139|56|![#BF8B38](https://placehold.co/15x15/BF8B38/BF8B38.png) `#BF8B38`|
|Fine Surface Primer-white|MRP-LPW|Mr Paint|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Flat Base|MRP-187|Mr Paint|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Ford Gt Gulf Blue {heritage Edition}|MRP-C001|Mr Paint - Car|0|177|193|![#00B1C1](https://placehold.co/15x15/00B1C1/00B1C1.png) `#00B1C1`|
|Ford Gt Gulf Orange {heritage Edition}|MRP-C002|Mr Paint - Car|204|67|0|![#CC4300](https://placehold.co/15x15/CC4300/CC4300.png) `#CC4300`|
|Ford Gt Liquid Blue|MRP-C003|Mr Paint - Car|0|56|86|![#003856](https://placehold.co/15x15/003856/003856.png) `#003856`|
|Ford Gt Liquid Gray|MRP-C005|Mr Paint - Car|49|54|58|![#31363A](https://placehold.co/15x15/31363A/31363A.png) `#31363A`|
|Ford Gt Liquid Red|MRP-C004|Mr Paint - Car|74|0|3|![#4A0003](https://placehold.co/15x15/4A0003/4A0003.png) `#4A0003`|
|Ford Gt Med. Royal Blue|MRP-C006|Mr Paint - Car|5|17|31|![#05111F](https://placehold.co/15x15/05111F/05111F.png) `#05111F`|
|Giallo Cromo|MRP-310|Mr Paint|241|170|0|![#F1AA00](https://placehold.co/15x15/F1AA00/F1AA00.png) `#F1AA00`|
|Giallo Cromo|MRP-309|Mr Paint|230|145|0|![#E69100](https://placehold.co/15x15/E69100/E69100.png) `#E69100`|
|Giallo Mimetico|MRP-323|Mr Paint|216|132|34|![#D88422](https://placehold.co/15x15/D88422/D88422.png) `#D88422`|
|Giallo Mimetico|MRP-324|Mr Paint|244|183|103|![#F4B767](https://placehold.co/15x15/F4B767/F4B767.png) `#F4B767`|
|Giallo Mimetico|MRP-325|Mr Paint|238|157|22|![#EE9D16](https://placehold.co/15x15/EE9D16/EE9D16.png) `#EE9D16`|
|Gold|MRP-153|Mr Paint|133|109|37|![#856D25](https://placehold.co/15x15/856D25/856D25.png) `#856D25`|
|Gold|MRP-A020|Mr Paint - Aqua Colors|129|110|51|![#816E33](https://placehold.co/15x15/816E33/816E33.png) `#816E33`|
|Grabber Blue - Ford Mustang|MRP-C009|Mr Paint - Car|0|124|175|![#007CAF](https://placehold.co/15x15/007CAF/007CAF.png) `#007CAF`|
|Grabber Lime - Ford Mustang|MRP-C008|Mr Paint - Car|147|168|47|![#93A82F](https://placehold.co/15x15/93A82F/93A82F.png) `#93A82F`|
|Graphite Metallic|MRP-272|Mr Paint|57|57|55|![#393937](https://placehold.co/15x15/393937/393937.png) `#393937`|
|Gray|MRP-403|Mr Paint|120|127|135|![#787F87](https://placehold.co/15x15/787F87/787F87.png) `#787F87`|
|Gray Blue|MRP-398|Mr Paint|123|148|152|![#7B9498](https://placehold.co/15x15/7B9498/7B9498.png) `#7B9498`|
|Gray Carbon Brake|MRP-C012|Mr Paint - Car|57|57|55|![#393937](https://placehold.co/15x15/393937/393937.png) `#393937`|
|Gray FS36270|MRP-039|Mr Paint|123|129|129|![#7B8181](https://placehold.co/15x15/7B8181/7B8181.png) `#7B8181`|
|Gray RAL 7000|MRP-A003|Mr Paint - Aqua Colors|138|146|157|![#8A929D](https://placehold.co/15x15/8A929D/8A929D.png) `#8A929D`|
|Green|MRP-400|Mr Paint|100|95|75|![#645F4B](https://placehold.co/15x15/645F4B/645F4B.png) `#645F4B`|
|Green  FS34230|MRP-437|Mr Paint|35|135|62|![#23873E](https://placehold.co/15x15/23873E/23873E.png) `#23873E`|
|Green  FS34258|MRP-248|Mr Paint|126|126|88|![#7E7E58](https://placehold.co/15x15/7E7E58/7E7E58.png) `#7E7E58`|
|Green Brown RAL 8000|MRP-213|Mr Paint|141|100|44|![#8D642C](https://placehold.co/15x15/8D642C/8D642C.png) `#8D642C`|
|Green Clear|MRP-268|Mr Paint|0|163|129|![#00A381](https://placehold.co/15x15/00A381/00A381.png) `#00A381`|
|Green FS34138|MRP-391|Mr Paint|84|128|77|![#54804D](https://placehold.co/15x15/54804D/54804D.png) `#54804D`|
|Green FS34159|MRP-390|Mr Paint|105|119|104|![#697768](https://placehold.co/15x15/697768/697768.png) `#697768`|
|Green FS34227|MRP-227|Mr Paint|111|132|99|![#6F8463](https://placehold.co/15x15/6F8463/6F8463.png) `#6F8463`|
|Green For Wheels|MRP-032|Mr Paint|50|81|21|![#325115](https://placehold.co/15x15/325115/325115.png) `#325115`|
|Green For Wheels|MRP-A046|Mr Paint - Aqua Colors|56|80|30|![#38501E](https://placehold.co/15x15/38501E/38501E.png) `#38501E`|
|Green Syrian AFVs|MRP-292|Mr Paint|40|64|50|![#284032](https://placehold.co/15x15/284032/284032.png) `#284032`|
|Grey|MRP-354|Mr Paint|154|160|160|![#9AA0A0](https://placehold.co/15x15/9AA0A0/9AA0A0.png) `#9AA0A0`|
|Grey 032|MRP-220|Mr Paint|191|194|187|![#BFC2BB](https://placehold.co/15x15/BFC2BB/BFC2BB.png) `#BFC2BB`|
|Grey Blue|MRP-168|Mr Paint|124|158|144|![#7C9E90](https://placehold.co/15x15/7C9E90/7C9E90.png) `#7C9E90`|
|Grey Blue RAL 5008|MRP-281|Mr Paint|35|53|65|![#233541](https://placehold.co/15x15/233541/233541.png) `#233541`|
|Grey Green|MRP-165|Mr Paint|89|88|57|![#595839](https://placehold.co/15x15/595839/595839.png) `#595839`|
|Grigio Azzurro|MRP-302|Mr Paint|146|177|161|![#92B1A1](https://placehold.co/15x15/92B1A1/92B1A1.png) `#92B1A1`|
|Grigio Azzurro|MRP-301|Mr Paint|151|162|158|![#97A29E](https://placehold.co/15x15/97A29E/97A29E.png) `#97A29E`|
|Grigio Azzurro|MRP-304|Mr Paint|64|73|80|![#404950](https://placehold.co/15x15/404950/404950.png) `#404950`|
|Grünblau|MRP-182|Mr Paint|201|197|152|![#C9C598](https://placehold.co/15x15/C9C598/C9C598.png) `#C9C598`|
|Gun Metal|MRP-149|Mr Paint|20|20|20|![#141414](https://placehold.co/15x15/141414/141414.png) `#141414`|
|Gunship Green FS34092|MRP-235|Mr Paint|58|85|78|![#3A554E](https://placehold.co/15x15/3A554E/3A554E.png) `#3A554E`|
|Gunship Grey FS363118|MRP-A087|Mr Paint - Aqua Colors|70|82|94|![#46525E](https://placehold.co/15x15/46525E/46525E.png) `#46525E`|
|Have Glass|MRP-278|Mr Paint|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Haze Grey FS36270|MRP-A085|Mr Paint - Aqua Colors|123|129|129|![#7B8181](https://placehold.co/15x15/7B8181/7B8181.png) `#7B8181`|
|Highland Green - Ford Mustang Bullitt|MRP-C007|Mr Paint - Car|7|23|22|![#071716](https://placehold.co/15x15/071716/071716.png) `#071716`|
|Hinomaru Aka Iro (National Insignia Red)|MRP-411|Mr Paint|160|0|0|![#A00000](https://placehold.co/15x15/A00000/A00000.png) `#A00000`|
|Hyundai I20 Wrc|MRP-C018|Mr Paint - Car|116|165|197|![#74A5C5](https://placehold.co/15x15/74A5C5/74A5C5.png) `#74A5C5`|
|IDF AFV Sand Gray|MRP-106|Mr Paint|120|103|87|![#786757](https://placehold.co/15x15/786757/786757.png) `#786757`|
|IJAAF  1 Hairyokushoku (Bluish Gray Version)|MRP-416|Mr Paint|164|176|176|![#A4B0B0](https://placehold.co/15x15/A4B0B0/A4B0B0.png) `#A4B0B0`|
|IJAAF  1 Hairyokushoku (Greenish Gray Version)|MRP-415|Mr Paint|140|151|137|![#8C9789](https://placehold.co/15x15/8C9789/8C9789.png) `#8C9789`|
|IJAAF  14 Ki Iro (Marking Yellow)|MRP-419|Mr Paint|238|128|15|![#EE800F](https://placehold.co/15x15/EE800F/EE800F.png) `#EE800F`|
|IJAAF  21 Midori Iro (Camouflage Green)|MRP-420|Mr Paint|49|74|52|![#314A34](https://placehold.co/15x15/314A34/314A34.png) `#314A34`|
|IJAAF  27 Ao Midori Iro (Blue Green, "Jungle Green")|MRP-421|Mr Paint|34|53|34|![#223522](https://placehold.co/15x15/223522/223522.png) `#223522`|
|IJAAF  3 Hai Ran Shoku (Cockpit Blue-gey)|MRP-417|Mr Paint|32|54|65|![#203641](https://placehold.co/15x15/203641/203641.png) `#203641`|
|IJAAF  30 Karekusa Iro (Parched Grass)|MRP-422|Mr Paint|164|126|90|![#A47E5A](https://placehold.co/15x15/A47E5A/A47E5A.png) `#A47E5A`|
|IJAAF  31 Cha Kasshoku (Tea Color)|MRP-423|Mr Paint|76|52|42|![#4C342A](https://placehold.co/15x15/4C342A/4C342A.png) `#4C342A`|
|IJAAF  7 Ohryoku Nana Go Shoku (Yellow Green  7)|MRP-418|Mr Paint|84|75|32|![#544B20](https://placehold.co/15x15/544B20/544B20.png) `#544B20`|
|IJNAF D1 Nohryokukokushoku (Deep Black Green)|MRP-424|Mr Paint|6|32|23|![#062017](https://placehold.co/15x15/062017/062017.png) `#062017`|
|IJNAF D2 Ryokukokushoku (Black Green)|MRP-425|Mr Paint|22|50|38|![#163226](https://placehold.co/15x15/163226/163226.png) `#163226`|
|IJNAF H2 Camouflage Brown|MRP-426|Mr Paint|117|67|40|![#754328](https://placehold.co/15x15/754328/754328.png) `#754328`|
|IJNAF J3 Hai Iro (Ash Gray)|MRP-427|Mr Paint|156|157|149|![#9C9D95](https://placehold.co/15x15/9C9D95/9C9D95.png) `#9C9D95`|
|IJNAF J3 Sp Olive Gray (Mitsubishi Special Paint)|MRP-428|Mr Paint|144|128|103|![#908067](https://placehold.co/15x15/908067/908067.png) `#908067`|
|IJNAF J3 Sp Olive Gray (Nakajima Version)|MRP-429|Mr Paint|151|122|88|![#977A58](https://placehold.co/15x15/977A58/977A58.png) `#977A58`|
|IJNAF M0/M1 Official Cockpit Color (Gray Green)|MRP-430|Mr Paint|122|134|110|![#7A866E](https://placehold.co/15x15/7A866E/7A866E.png) `#7A866E`|
|IJNAF N0 Propeller Color|MRP-431|Mr Paint|57|27|25|![#391B19](https://placehold.co/15x15/391B19/391B19.png) `#391B19`|
|IJNAF Q1 Cowling Color|MRP-432|Mr Paint|15|20|26|![#0F141A](https://placehold.co/15x15/0F141A/0F141A.png) `#0F141A`|
|Insignia Blue|MRP-406|Mr Paint|2|123|166|![#027BA6](https://placehold.co/15x15/027BA6/027BA6.png) `#027BA6`|
|Insignia Blue FS15044 - Ana 502|MRP-300|Mr Paint|2|34|49|![#022231](https://placehold.co/15x15/022231/022231.png) `#022231`|
|Insignia Red FS11136 - Ana 509|MRP-299|Mr Paint|162|0|23|![#A20017](https://placehold.co/15x15/A20017/A20017.png) `#A20017`|
|Insignia Red Us Navy Training And Arctic Camo|MRP-002|Mr Paint|210|9|1|![#D20901](https://placehold.co/15x15/D20901/D20901.png) `#D20901`|
|Insignia White Ana 601|MRP-135|Mr Paint|224|223|205|![#E0DFCD](https://placehold.co/15x15/E0DFCD/E0DFCD.png) `#E0DFCD`|
|Insignia Yellow|MRP-407|Mr Paint|240|153|11|![#F0990B](https://placehold.co/15x15/F0990B/F0990B.png) `#F0990B`|
|Interior Bronze - Green|MRP-132|Mr Paint|0|100|94|![#00645E](https://placehold.co/15x15/00645E/00645E.png) `#00645E`|
|Interior Bronze - Green|MRP-A079|Mr Paint - Aqua Colors|37|98|93|![#25625D](https://placehold.co/15x15/25625D/25625D.png) `#25625D`|
|Interior Dark Dull Green|MRP-229|Mr Paint|45|96|79|![#2D604F](https://placehold.co/15x15/2D604F/2D604F.png) `#2D604F`|
|Interior Dark Dull Green|MRP-A080|Mr Paint - Aqua Colors|58|94|80|![#3A5E50](https://placehold.co/15x15/3A5E50/3A5E50.png) `#3A5E50`|
|Interior Green Ana 611|MRP-131|Mr Paint|104|102|54|![#686636](https://placehold.co/15x15/686636/686636.png) `#686636`|
|Interior Green Ana 611|MRP-A078|Mr Paint - Aqua Colors|104|102|61|![#68663D](https://placehold.co/15x15/68663D/68663D.png) `#68663D`|
|Interior Grey Green|MRP-A077|Mr Paint - Aqua Colors|104|116|92|![#68745C](https://placehold.co/15x15/68745C/68745C.png) `#68745C`|
|Interior Grey Green|MRP-111|Mr Paint|101|115|89|![#657359](https://placehold.co/15x15/657359/657359.png) `#657359`|
|Interior U.S.modern  FS36231|MRP-100|Mr Paint|121|126|130|![#797E82](https://placehold.co/15x15/797E82/797E82.png) `#797E82`|
|Interior Yellow - Green|MRP-170|Mr Paint|164|134|0|![#A48600](https://placehold.co/15x15/A48600/A48600.png) `#A48600`|
|Intermediate Blue Ana 608/FS35164|MRP-136|Mr Paint|71|104|113|![#476871](https://placehold.co/15x15/476871/476871.png) `#476871`|
|Intermediate Blue FS35164|MRP-A089|Mr Paint - Aqua Colors|79|103|113|![#4F6771](https://placehold.co/15x15/4F6771/4F6771.png) `#4F6771`|
|International Blue FS35109|MRP-238|Mr Paint|37|102|120|![#256678](https://placehold.co/15x15/256678/256678.png) `#256678`|
|International Orange Bs 592|MRP-232|Mr Paint|210|43|1|![#D22B01](https://placehold.co/15x15/D22B01/D22B01.png) `#D22B01`|
|Interni Subalare|MRP-318|Mr Paint|163|194|179|![#A3C2B3](https://placehold.co/15x15/A3C2B3/A3C2B3.png) `#A3C2B3`|
|J.a.s.d.f. Blue|MRP-295|Mr Paint|50|124|151|![#327C97](https://placehold.co/15x15/327C97/327C97.png) `#327C97`|
|Jaegermeister Orange|MRP-C023|Mr Paint - Car|254|108|22|![#FE6C16](https://placehold.co/15x15/FE6C16/FE6C16.png) `#FE6C16`|
|Jet Black Ana 622|MRP-137|Mr Paint|26|31|34|![#1A1F22](https://placehold.co/15x15/1A1F22/1A1F22.png) `#1A1F22`|
|Kawanishi Cockpit Color|MRP-412|Mr Paint|108|120|96|![#6C7860](https://placehold.co/15x15/6C7860/6C7860.png) `#6C7860`|
|Khaki  L-29 Delfín|MRP-075|Mr Paint|75|57|11|![#4B390B](https://placehold.co/15x15/4B390B/4B390B.png) `#4B390B`|
|Khaki Green No.3|MRP-333|Mr Paint|84|64|37|![#544025](https://placehold.co/15x15/544025/544025.png) `#544025`|
|Khaki Grey RAL 7008|MRP-211|Mr Paint|121|92|50|![#795C32](https://placehold.co/15x15/795C32/795C32.png) `#795C32`|
|Khaki Čsn 5450|MRP-013|Mr Paint|76|70|58|![#4C463A](https://placehold.co/15x15/4C463A/4C463A.png) `#4C463A`|
|Khaki Čsn 5450|MRP-A040|Mr Paint - Aqua Colors|74|70|58|![#4A463A](https://placehold.co/15x15/4A463A/4A463A.png) `#4A463A`|
|Lemon Yellow FS13655|MRP-386|Mr Paint|237|159|1|![#ED9F01](https://placehold.co/15x15/ED9F01/ED9F01.png) `#ED9F01`|
|Lemon-gray|MRP-090|Mr Paint|221|210|104|![#DDD268](https://placehold.co/15x15/DDD268/DDD268.png) `#DDD268`|
|Light Admiralty Grey  Bs697|MRP-379|Mr Paint|152|183|177|![#98B7B1](https://placehold.co/15x15/98B7B1/98B7B1.png) `#98B7B1`|
|Light Aircraft Grey  Bs627|MRP-374|Mr Paint|167|168|160|![#A7A8A0](https://placehold.co/15x15/A7A8A0/A7A8A0.png) `#A7A8A0`|
|Light Arctic Grey  FS36628|MRP-246|Mr Paint|194|194|182|![#C2C2B6](https://placehold.co/15x15/C2C2B6/C2C2B6.png) `#C2C2B6`|
|Light Blue|MRP-353|Mr Paint|132|183|168|![#84B7A8](https://placehold.co/15x15/84B7A8/84B7A8.png) `#84B7A8`|
|Light Blue  SU-27/33|MRP-196|Mr Paint|118|178|189|![#76B2BD](https://placehold.co/15x15/76B2BD/76B2BD.png) `#76B2BD`|
|Light Blue FS 35622|MRP-225|Mr Paint|189|203|186|![#BDCBBA](https://placehold.co/15x15/BDCBBA/BDCBBA.png) `#BDCBBA`|
|Light Blue Grey  SU-27/33|MRP-197|Mr Paint|166|210|211|![#A6D2D3](https://placehold.co/15x15/A6D2D3/A6D2D3.png) `#A6D2D3`|
|Light Blue SU-27|MRP-043|Mr Paint|147|204|213|![#93CCD5](https://placehold.co/15x15/93CCD5/93CCD5.png) `#93CCD5`|
|Light Blue SU-34|MRP-202|Mr Paint|48|195|205|![#30C3CD](https://placehold.co/15x15/30C3CD/30C3CD.png) `#30C3CD`|
|Light Blue SU-35|MRP-297|Mr Paint|146|198|212|![#92C6D4](https://placehold.co/15x15/92C6D4/92C6D4.png) `#92C6D4`|
|Light Brown  Čsn 2430/Čsn 1010|MRP-162|Mr Paint|156|130|117|![#9C8275](https://placehold.co/15x15/9C8275/9C8275.png) `#9C8275`|
|Light Earth|MRP-167|Mr Paint|153|121|100|![#997964](https://placehold.co/15x15/997964/997964.png) `#997964`|
|Light Earth|MRP-107|Mr Paint|170|122|76|![#AA7A4C](https://placehold.co/15x15/AA7A4C/AA7A4C.png) `#AA7A4C`|
|Light Gray|MRP-091|Mr Paint|149|155|153|![#959B99](https://placehold.co/15x15/959B99/959B99.png) `#959B99`|
|Light Gray|MRP-402|Mr Paint|188|198|207|![#BCC6CF](https://placehold.co/15x15/BCC6CF/BCC6CF.png) `#BCC6CF`|
|Light Gray Blue|MRP-049|Mr Paint|124|145|130|![#7C9182](https://placehold.co/15x15/7C9182/7C9182.png) `#7C9182`|
|Light Gray Blue  L-29 Delfín|MRP-073|Mr Paint|171|212|206|![#ABD4CE](https://placehold.co/15x15/ABD4CE/ABD4CE.png) `#ABD4CE`|
|Light Gray FS36375|MRP-038|Mr Paint|140|150|159|![#8C969F](https://placehold.co/15x15/8C969F/8C969F.png) `#8C969F`|
|Light Gray Green|MRP-399|Mr Paint|152|140|102|![#988C66](https://placehold.co/15x15/988C66/988C66.png) `#988C66`|
|Light Gray SU-27|MRP-046|Mr Paint|163|169|169|![#A3A9A9](https://placehold.co/15x15/A3A9A9/A3A9A9.png) `#A3A9A9`|
|Light Gray SU-33|MRP-201|Mr Paint|175|192|186|![#AFC0BA](https://placehold.co/15x15/AFC0BA/AFC0BA.png) `#AFC0BA`|
|Light Green|MRP-109|Mr Paint|95|93|68|![#5F5D44](https://placehold.co/15x15/5F5D44/5F5D44.png) `#5F5D44`|
|Light Green - Blue SU-34|MRP-203|Mr Paint|1|150|154|![#01969A](https://placehold.co/15x15/01969A/01969A.png) `#01969A`|
|Light Green G5|MRP-344|Mr Paint|65|66|35|![#414223](https://placehold.co/15x15/414223/414223.png) `#414223`|
|Light Green Gray|MRP-092|Mr Paint|107|140|119|![#6B8C77](https://placehold.co/15x15/6B8C77/6B8C77.png) `#6B8C77`|
|Light Green Grey Mig 29 Smt|MRP-287|Mr Paint|146|157|149|![#929D95](https://placehold.co/15x15/929D95/929D95.png) `#929D95`|
|Light Green Mig 29 Smt|MRP-285|Mr Paint|132|150|134|![#849686](https://placehold.co/15x15/849686/849686.png) `#849686`|
|Light Grey|MRP-186|Mr Paint|192|193|187|![#C0C1BB](https://placehold.co/15x15/C0C1BB/C0C1BB.png) `#C0C1BB`|
|Light Grey  FS36293|MRP-279|Mr Paint|134|138|137|![#868A89](https://placehold.co/15x15/868A89/868A89.png) `#868A89`|
|Light Grey  FS36373|MRP-372|Mr Paint|153|158|162|![#999EA2](https://placehold.co/15x15/999EA2/999EA2.png) `#999EA2`|
|Light Grey  SU-27/33|MRP-198|Mr Paint|178|183|177|![#B2B7B1](https://placehold.co/15x15/B2B7B1/B2B7B1.png) `#B2B7B1`|
|Light Grey FS36495|MRP-364|Mr Paint|196|200|185|![#C4C8B9](https://placehold.co/15x15/C4C8B9/C4C8B9.png) `#C4C8B9`|
|Light Grey M-495|MRP-134|Mr Paint|178|183|177|![#B2B7B1](https://placehold.co/15x15/B2B7B1/B2B7B1.png) `#B2B7B1`|
|Light Grey Mig 29 Smt|MRP-284|Mr Paint|183|189|189|![#B7BDBD](https://placehold.co/15x15/B7BDBD/B7BDBD.png) `#B7BDBD`|
|Light Grey SU-35|MRP-296|Mr Paint|158|188|196|![#9EBCC4](https://placehold.co/15x15/9EBCC4/9EBCC4.png) `#9EBCC4`|
|Light Gull Grey FS36440|MRP-A084|Mr Paint - Aqua Colors|164|162|150|![#A4A296](https://placehold.co/15x15/A4A296/A4A296.png) `#A4A296`|
|Light Khaki Avia B534|MRP-169|Mr Paint|70|63|34|![#463F22](https://placehold.co/15x15/463F22/463F22.png) `#463F22`|
|Light Mud|MRP-350|Mr Paint|146|135|117|![#928775](https://placehold.co/15x15/928775/928775.png) `#928775`|
|Light Orange F-16|MRP-207|Mr Paint|193|93|18|![#C15D12](https://placehold.co/15x15/C15D12/C15D12.png) `#C15D12`|
|Light Pastel Grey Čsn 1010|MRP-027|Mr Paint|146|163|155|![#92A39B](https://placehold.co/15x15/92A39B/92A39B.png) `#92A39B`|
|Light Rust|MRP-358|Mr Paint|214|129|0|![#D68100](https://placehold.co/15x15/D68100/D68100.png) `#D68100`|
|Light Sea Grey  FS36307|MRP-245|Mr Paint|155|157|144|![#9B9D90](https://placehold.co/15x15/9B9D90/9B9D90.png) `#9B9D90`|
|Light Sky Blue FS35526|MRP-397|Mr Paint|163|187|189|![#A3BBBD](https://placehold.co/15x15/A3BBBD/A3BBBD.png) `#A3BBBD`|
|Light Slate Grey|MRP-116|Mr Paint|90|102|92|![#5A665C](https://placehold.co/15x15/5A665C/5A665C.png) `#5A665C`|
|Luminous Orange RAL 2005|MRP-194|Mr Paint|254|48|0|![#FE3000](https://placehold.co/15x15/FE3000/FE3000.png) `#FE3000`|
|Luminous Red RAL 3024|MRP-193|Mr Paint|254|0|0|![#FE0000](https://placehold.co/15x15/FE0000/FE0000.png) `#FE0000`|
|Luminous Yellow RAL 1026|MRP-192|Mr Paint|254|254|0|![#FEFE00](https://placehold.co/15x15/FEFE00/FEFE00.png) `#FEFE00`|
|Marking Blue|MRP-124|Mr Paint|34|64|88|![#224058](https://placehold.co/15x15/224058/224058.png) `#224058`|
|Marking Blue|MRP-408|Mr Paint|0|80|136|![#005088](https://placehold.co/15x15/005088/005088.png) `#005088`|
|Marking Blue - Czech &amp; Slovak Insignia|MRP-007|Mr Paint|2|75|128|![#024B80](https://placehold.co/15x15/024B80/024B80.png) `#024B80`|
|Marking Red|MRP-123|Mr Paint|146|42|15|![#922A0F](https://placehold.co/15x15/922A0F/922A0F.png) `#922A0F`|
|Marking Red - Czech &amp; Slovak Insignia|MRP-006|Mr Paint|182|11|3|![#B60B03](https://placehold.co/15x15/B60B03/B60B03.png) `#B60B03`|
|Marking Yellow|MRP-122|Mr Paint|237|146|39|![#ED9227](https://placehold.co/15x15/ED9227/ED9227.png) `#ED9227`|
|Medium Green 42|MRP-140|Mr Paint|58|85|78|![#3A554E](https://placehold.co/15x15/3A554E/3A554E.png) `#3A554E`|
|Medium Grey FS36375|MRP-A086|Mr Paint - Aqua Colors|141|150|157|![#8D969D](https://placehold.co/15x15/8D969D/8D969D.png) `#8D969D`|
|Medium Rust|MRP-359|Mr Paint|194|85|0|![#C25500](https://placehold.co/15x15/C25500/C25500.png) `#C25500`|
|Medium Sea Grey|MRP-112|Mr Paint|123|134|140|![#7B868C](https://placehold.co/15x15/7B868C/7B868C.png) `#7B868C`|
|Mercedes 300sl Restomod Green Metallic|MRP-C030|Mr Paint - Car|17|44|39|![#112C27](https://placehold.co/15x15/112C27/112C27.png) `#112C27`|
|Mid Green 322m|MRP-178|Mr Paint|90|99|52|![#5A6334](https://placehold.co/15x15/5A6334/5A6334.png) `#5A6334`|
|Middle Stone|MRP-121|Mr Paint|178|129|60|![#B2813C](https://placehold.co/15x15/B2813C/B2813C.png) `#B2813C`|
|Mitsubishi Cockpit Color (Aged)|MRP-413|Mr Paint|100|101|61|![#64653D](https://placehold.co/15x15/64653D/64653D.png) `#64653D`|
|Modern Italian Sky Gray  FS36280|MRP-095|Mr Paint|132|138|134|![#848A86](https://placehold.co/15x15/848A86/848A86.png) `#848A86`|
|Morning Blue|MRP-158|Mr Paint|8|39|70|![#082746](https://placehold.co/15x15/082746/082746.png) `#082746`|
|Nakajima Cockpit Color (Aged)|MRP-414|Mr Paint|167|150|106|![#A7966A](https://placehold.co/15x15/A7966A/A7966A.png) `#A7966A`|
|Nato Black|MRP-077|Mr Paint|48|53|57|![#303539](https://placehold.co/15x15/303539/303539.png) `#303539`|
|Nato Brown|MRP-079|Mr Paint|77|60|53|![#4D3C35](https://placehold.co/15x15/4D3C35/4D3C35.png) `#4D3C35`|
|Nato Gray FS26329|MRP-096|Mr Paint|137|158|151|![#899E97](https://placehold.co/15x15/899E97/899E97.png) `#899E97`|
|Nato Green|MRP-078|Mr Paint|45|47|23|![#2D2F17](https://placehold.co/15x15/2D2F17/2D2F17.png) `#2D2F17`|
|Nato Green  Bs285|MRP-381|Mr Paint|65|64|44|![#41402C](https://placehold.co/15x15/41402C/41402C.png) `#41402C`|
|Need For Green - Ford Mustang|MRP-C011|Mr Paint - Car|0|115|22|![#007316](https://placehold.co/15x15/007316/007316.png) `#007316`|
|Neutral Grey 43|MRP-141|Mr Paint|111|120|127|![#6F787F](https://placehold.co/15x15/6F787F/6F787F.png) `#6F787F`|
|Nobels Dark Tarmac No.4|MRP-342|Mr Paint|67|74|82|![#434A52](https://placehold.co/15x15/434A52/434A52.png) `#434A52`|
|Nocciola|MRP-305|Mr Paint|129|103|86|![#816756](https://placehold.co/15x15/816756/816756.png) `#816756`|
|Ocean Grey|MRP-115|Mr Paint|80|90|99|![#505A63](https://placehold.co/15x15/505A63/505A63.png) `#505A63`|
|Ocean Grey FS36173|MRP-365|Mr Paint|102|113|119|![#667177](https://placehold.co/15x15/667177/667177.png) `#667177`|
|Ochre Wood|MRP-260|Mr Paint|170|122|76|![#AA7A4C](https://placehold.co/15x15/AA7A4C/AA7A4C.png) `#AA7A4C`|
|Olive Brown RAL 8008|MRP-282|Mr Paint|115|68|12|![#73440C](https://placehold.co/15x15/73440C/73440C.png) `#73440C`|
|Olive Drab 41|MRP-139|Mr Paint|77|79|65|![#4D4F41](https://placehold.co/15x15/4D4F41/4D4F41.png) `#4D4F41`|
|Olive Drab Ana 613|MRP-138|Mr Paint|100|93|67|![#645D43](https://placehold.co/15x15/645D43/645D43.png) `#645D43`|
|Olive Drab FS34087|MRP-234|Mr Paint|48|46|21|![#302E15](https://placehold.co/15x15/302E15/302E15.png) `#302E15`|
|Olive Green|MRP-164|Mr Paint|58|59|43|![#3A3B2B](https://placehold.co/15x15/3A3B2B/3A3B2B.png) `#3A3B2B`|
|Olive Green  Čsn 5220|MRP-160|Mr Paint|74|86|50|![#4A5632](https://placehold.co/15x15/4A5632/4A5632.png) `#4A5632`|
|Olive Green 325|MRP-217|Mr Paint|60|58|45|![#3C3A2D](https://placehold.co/15x15/3C3A2D/3C3A2D.png) `#3C3A2D`|
|Olive Green Bs220|MRP-376|Mr Paint|68|70|23|![#444617](https://placehold.co/15x15/444617/444617.png) `#444617`|
|Olive Green RAL 6003|MRP-035|Mr Paint|72|77|47|![#484D2F](https://placehold.co/15x15/484D2F/484D2F.png) `#484D2F`|
|Olive Green RAL 6003|MRP-A030|Mr Paint - Aqua Colors|74|77|50|![#4A4D32](https://placehold.co/15x15/4A4D32/4A4D32.png) `#4A4D32`|
|Orange Clear|MRP-265|Mr Paint|243|118|52|![#F37634](https://placehold.co/15x15/F37634/F37634.png) `#F37634`|
|Orange Ladders For Russian Aircraft|MRP-089|Mr Paint|225|110|30|![#E16E1E](https://placehold.co/15x15/E16E1E/E16E1E.png) `#E16E1E`|
|Orange Metallic For Toyota Gt86|MRP-C024|Mr Paint - Car|145|35|2|![#912302](https://placehold.co/15x15/912302/912302.png) `#912302`|
|Orange RAL 2017|MRP-A005|Mr Paint - Aqua Colors|226|125|57|![#E27D39](https://placehold.co/15x15/E27D39/E27D39.png) `#E27D39`|
|Orange Yellow 47|MRP-142|Mr Paint|236|143|39|![#EC8F27](https://placehold.co/15x15/EC8F27/EC8F27.png) `#EC8F27`|
|Oxford Blue|MRP-183|Mr Paint|1|40|71|![#012847](https://placehold.co/15x15/012847/012847.png) `#012847`|
|P.r.u. Blue|MRP-120|Mr Paint|64|102|115|![#406673](https://placehold.co/15x15/406673/406673.png) `#406673`|
|P.r.u. Pink|MRP-190|Mr Paint|221|191|183|![#DDBFB7](https://placehold.co/15x15/DDBFB7/DDBFB7.png) `#DDBFB7`|
|Pale Burnt Metal|MRP-152|Mr Paint|132|121|103|![#847967](https://placehold.co/15x15/847967/847967.png) `#847967`|
|Pale Green FS34424|MRP-371|Mr Paint|181|183|159|![#B5B79F](https://placehold.co/15x15/B5B79F/B5B79F.png) `#B5B79F`|
|Pale Roundel Blue Bs 172|MRP-230|Mr Paint|124|171|199|![#7CABC7](https://placehold.co/15x15/7CABC7/7CABC7.png) `#7CABC7`|
|Pale Roundel Red Bs 454|MRP-231|Mr Paint|202|133|138|![#CA858A](https://placehold.co/15x15/CA858A/CA858A.png) `#CA858A`|
|Pale Wood|MRP-259|Mr Paint|190|154|118|![#BE9A76](https://placehold.co/15x15/BE9A76/BE9A76.png) `#BE9A76`|
|Panzer Grey|MRP-222|Mr Paint|117|123|123|![#757B7B](https://placehold.co/15x15/757B7B/757B7B.png) `#757B7B`|
|Pc-10 Early|MRP-252|Mr Paint|48|46|21|![#302E15](https://placehold.co/15x15/302E15/302E15.png) `#302E15`|
|Pc-10 Late|MRP-253|Mr Paint|53|45|26|![#352D1A](https://placehold.co/15x15/352D1A/352D1A.png) `#352D1A`|
|Pc-12|MRP-254|Mr Paint|80|52|41|![#503429](https://placehold.co/15x15/503429/503429.png) `#503429`|
|Pc-8|MRP-251|Mr Paint|123|96|53|![#7B6035](https://placehold.co/15x15/7B6035/7B6035.png) `#7B6035`|
|Pearl Gray FS26493|MRP-392|Mr Paint|178|183|177|![#B2B7B1](https://placehold.co/15x15/B2B7B1/B2B7B1.png) `#B2B7B1`|
|Porsche Acid Green|MRP-C032|Mr Paint - Car|189|197|0|![#BDC500](https://placehold.co/15x15/BDC500/BDC500.png) `#BDC500`|
|Porsche Gulf Blue|MRP-C013|Mr Paint - Car|82|169|186|![#52A9BA](https://placehold.co/15x15/52A9BA/52A9BA.png) `#52A9BA`|
|Porsche Gulf Orange|MRP-C014|Mr Paint - Car|235|66|0|![#EB4200](https://placehold.co/15x15/EB4200/EB4200.png) `#EB4200`|
|Porsche Lava Orange|MRP-C038|Mr Paint - Car|181|51|27|![#B5331B](https://placehold.co/15x15/B5331B/B5331B.png) `#B5331B`|
|Porsche Light Green|MRP-C037|Mr Paint - Car|172|166|30|![#ACA61E](https://placehold.co/15x15/ACA61E/ACA61E.png) `#ACA61E`|
|Porsche Lizard Green|MRP-C035|Mr Paint - Car|101|155|43|![#659B2B](https://placehold.co/15x15/659B2B/659B2B.png) `#659B2B`|
|Porsche Miami Blue|MRP-C015|Mr Paint - Car|0|129|145|![#008191](https://placehold.co/15x15/008191/008191.png) `#008191`|
|Porsche Mint Green|MRP-C036|Mr Paint - Car|88|176|152|![#58B098](https://placehold.co/15x15/58B098/58B098.png) `#58B098`|
|Porsche Olive Green|MRP-C031|Mr Paint - Car|84|89|48|![#545930](https://placehold.co/15x15/545930/545930.png) `#545930`|
|Porsche Shark Blue|MRP-C039|Mr Paint - Car|20|95|150|![#145F96](https://placehold.co/15x15/145F96/145F96.png) `#145F96`|
|Porsche Signal Green|MRP-C033|Mr Paint - Car|0|133|62|![#00853E](https://placehold.co/15x15/00853E/00853E.png) `#00853E`|
|Porsche Speedway Green|MRP-C034|Mr Paint - Car|28|128|42|![#1C802A](https://placehold.co/15x15/1C802A/1C802A.png) `#1C802A`|
|Porsche Sternrubin Neo|MRP-C040|Mr Paint - Car|107|38|67|![#6B2643](https://placehold.co/15x15/6B2643/6B2643.png) `#6B2643`|
|Porsche Ultra Violet|MRP-C041|Mr Paint - Car|42|39|70|![#2A2746](https://placehold.co/15x15/2A2746/2A2746.png) `#2A2746`|
|Primer Red RAL 8012|MRP-A028|Mr Paint - Aqua Colors|98|40|28|![#62281C](https://placehold.co/15x15/62281C/62281C.png) `#62281C`|
|Primer Red RAL 8012|MRP-033|Mr Paint|105|35|23|![#692317](https://placehold.co/15x15/692317/692317.png) `#692317`|
|RLM 02 Grau|MRP-050|Mr Paint|120|114|92|![#78725C](https://placehold.co/15x15/78725C/78725C.png) `#78725C`|
|RLM 02 Grau|MRP-A049|Mr Paint - Aqua Colors|120|115|96|![#787360](https://placehold.co/15x15/787360/787360.png) `#787360`|
|RLM 04|MRP-A050|Mr Paint - Aqua Colors|246|155|2|![#F69B02](https://placehold.co/15x15/F69B02/F69B02.png) `#F69B02`|
|RLM 04 Gelb|MRP-051|Mr Paint|236|143|39|![#EC8F27](https://placehold.co/15x15/EC8F27/EC8F27.png) `#EC8F27`|
|RLM 23|MRP-A051|Mr Paint - Aqua Colors|186|37|31|![#BA251F](https://placehold.co/15x15/BA251F/BA251F.png) `#BA251F`|
|RLM 23 Rot|MRP-052|Mr Paint|205|0|15|![#CD000F](https://placehold.co/15x15/CD000F/CD000F.png) `#CD000F`|
|RLM 24|MRP-A052|Mr Paint - Aqua Colors|4|74|125|![#044A7D](https://placehold.co/15x15/044A7D/044A7D.png) `#044A7D`|
|RLM 24 Dunkelblau|MRP-053|Mr Paint|0|76|128|![#004C80](https://placehold.co/15x15/004C80/004C80.png) `#004C80`|
|RLM 25|MRP-A053|Mr Paint - Aqua Colors|63|111|89|![#3F6F59](https://placehold.co/15x15/3F6F59/3F6F59.png) `#3F6F59`|
|RLM 25 Hellgrun|MRP-054|Mr Paint|44|112|87|![#2C7057](https://placehold.co/15x15/2C7057/2C7057.png) `#2C7057`|
|RLM 61|MRP-A054|Mr Paint - Aqua Colors|62|57|54|![#3E3936](https://placehold.co/15x15/3E3936/3E3936.png) `#3E3936`|
|RLM 61 Dunkelbraun|MRP-055|Mr Paint|62|57|53|![#3E3935](https://placehold.co/15x15/3E3935/3E3935.png) `#3E3935`|
|RLM 62|MRP-A055|Mr Paint - Aqua Colors|89|89|61|![#59593D](https://placehold.co/15x15/59593D/59593D.png) `#59593D`|
|RLM 62 Grun|MRP-056|Mr Paint|89|88|57|![#595839](https://placehold.co/15x15/595839/595839.png) `#595839`|
|RLM 63|MRP-A056|Mr Paint - Aqua Colors|110|108|95|![#6E6C5F](https://placehold.co/15x15/6E6C5F/6E6C5F.png) `#6E6C5F`|
|RLM 63 Hellgrau|MRP-057|Mr Paint|110|108|95|![#6E6C5F](https://placehold.co/15x15/6E6C5F/6E6C5F.png) `#6E6C5F`|
|RLM 65|MRP-A057|Mr Paint - Aqua Colors|133|160|153|![#85A099](https://placehold.co/15x15/85A099/85A099.png) `#85A099`|
|RLM 65 Hellblau|MRP-058|Mr Paint|126|161|154|![#7EA19A](https://placehold.co/15x15/7EA19A/7EA19A.png) `#7EA19A`|
|RLM 66 Schwarzgrau|MRP-059|Mr Paint|51|56|60|![#33383C](https://placehold.co/15x15/33383C/33383C.png) `#33383C`|
|RLM 66 Schwarzgrau|MRP-A058|Mr Paint - Aqua Colors|51|56|59|![#33383B](https://placehold.co/15x15/33383B/33383B.png) `#33383B`|
|RLM 70|MRP-A059|Mr Paint - Aqua Colors|51|57|55|![#333937](https://placehold.co/15x15/333937/333937.png) `#333937`|
|RLM 70 Schwarzgrun|MRP-060|Mr Paint|51|57|55|![#333937](https://placehold.co/15x15/333937/333937.png) `#333937`|
|RLM 71|MRP-A060|Mr Paint - Aqua Colors|62|60|47|![#3E3C2F](https://placehold.co/15x15/3E3C2F/3E3C2F.png) `#3E3C2F`|
|RLM 71 Dunkelgrun|MRP-061|Mr Paint|61|59|44|![#3D3B2C](https://placehold.co/15x15/3D3B2C/3D3B2C.png) `#3D3B2C`|
|RLM 72|MRP-A061|Mr Paint - Aqua Colors|62|63|58|![#3E3F3A](https://placehold.co/15x15/3E3F3A/3E3F3A.png) `#3E3F3A`|
|RLM 72 Grun|MRP-062|Mr Paint|62|63|57|![#3E3F39](https://placehold.co/15x15/3E3F39/3E3F39.png) `#3E3F39`|
|RLM 73|MRP-A062|Mr Paint - Aqua Colors|59|66|59|![#3B423B](https://placehold.co/15x15/3B423B/3B423B.png) `#3B423B`|
|RLM 73 Grun|MRP-063|Mr Paint|56|66|58|![#38423A](https://placehold.co/15x15/38423A/38423A.png) `#38423A`|
|RLM 74|MRP-A063|Mr Paint - Aqua Colors|66|72|68|![#424844](https://placehold.co/15x15/424844/424844.png) `#424844`|
|RLM 74 Graugrun|MRP-064|Mr Paint|66|72|68|![#424844](https://placehold.co/15x15/424844/424844.png) `#424844`|
|RLM 75|MRP-A064|Mr Paint - Aqua Colors|94|95|97|![#5E5F61](https://placehold.co/15x15/5E5F61/5E5F61.png) `#5E5F61`|
|RLM 75 Grauviolett|MRP-065|Mr Paint|94|95|97|![#5E5F61](https://placehold.co/15x15/5E5F61/5E5F61.png) `#5E5F61`|
|RLM 76|MRP-A065|Mr Paint - Aqua Colors|162|175|165|![#A2AFA5](https://placehold.co/15x15/A2AFA5/A2AFA5.png) `#A2AFA5`|
|RLM 76 Lichtblau|MRP-066|Mr Paint|159|175|164|![#9FAFA4](https://placehold.co/15x15/9FAFA4/9FAFA4.png) `#9FAFA4`|
|RLM 76 Variant|MRP-A067|Mr Paint - Aqua Colors|202|197|159|![#CAC59F](https://placehold.co/15x15/CAC59F/CAC59F.png) `#CAC59F`|
|RLM 76 Variant|MRP-A066|Mr Paint - Aqua Colors|162|181|162|![#A2B5A2](https://placehold.co/15x15/A2B5A2/A2B5A2.png) `#A2B5A2`|
|RLM 77|MRP-A068|Mr Paint - Aqua Colors|185|191|191|![#B9BFBF](https://placehold.co/15x15/B9BFBF/B9BFBF.png) `#B9BFBF`|
|RLM 78|MRP-A069|Mr Paint - Aqua Colors|120|171|190|![#78ABBE](https://placehold.co/15x15/78ABBE/78ABBE.png) `#78ABBE`|
|RLM 78 Hellblau|MRP-067|Mr Paint|105|173|192|![#69ADC0](https://placehold.co/15x15/69ADC0/69ADC0.png) `#69ADC0`|
|RLM 79 Sandgelb I.|MRP-068|Mr Paint|188|119|62|![#BC773E](https://placehold.co/15x15/BC773E/BC773E.png) `#BC773E`|
|RLM 79 Variant 1|MRP-A070|Mr Paint - Aqua Colors|178|122|73|![#B27A49](https://placehold.co/15x15/B27A49/B27A49.png) `#B27A49`|
|RLM 79 Variant 2|MRP-A071|Mr Paint - Aqua Colors|137|92|51|![#895C33](https://placehold.co/15x15/895C33/895C33.png) `#895C33`|
|RLM 80|MRP-A072|Mr Paint - Aqua Colors|54|63|44|![#363F2C](https://placehold.co/15x15/363F2C/363F2C.png) `#363F2C`|
|RLM 80 Olivgrun|MRP-069|Mr Paint|50|62|40|![#323E28](https://placehold.co/15x15/323E28/323E28.png) `#323E28`|
|RLM 81 Braunviolet|MRP-070|Mr Paint|68|63|44|![#443F2C](https://placehold.co/15x15/443F2C/443F2C.png) `#443F2C`|
|RLM 81 Variant 2|MRP-A074|Mr Paint - Aqua Colors|74|65|60|![#4A413C](https://placehold.co/15x15/4A413C/4A413C.png) `#4A413C`|
|RLM 82|MRP-A075|Mr Paint - Aqua Colors|78|83|60|![#4E533C](https://placehold.co/15x15/4E533C/4E533C.png) `#4E533C`|
|RLM 82 Hellgrun|MRP-071|Mr Paint|76|82|56|![#4C5238](https://placehold.co/15x15/4C5238/4C5238.png) `#4C5238`|
|RLM 83 Dunkelgrun|MRP-072|Mr Paint|78|70|57|![#4E4639](https://placehold.co/15x15/4E4639/4E4639.png) `#4E4639`|
|Race Red - Ford Mustang|MRP-C010|Mr Paint - Car|180|0|1|![#B40001](https://placehold.co/15x15/B40001/B40001.png) `#B40001`|
|Radome Tan FS33613|MRP-394|Mr Paint|238|194|155|![#EEC29B](https://placehold.co/15x15/EEC29B/EEC29B.png) `#EEC29B`|
|Raf Blue-grey  Bs633|MRP-380|Mr Paint|43|56|65|![#2B3841](https://placehold.co/15x15/2B3841/2B3841.png) `#2B3841`|
|Red Brown  RAL 8017|MRP-A031|Mr Paint - Aqua Colors|62|38|28|![#3E261C](https://placehold.co/15x15/3E261C/3E261C.png) `#3E261C`|
|Red Brown RAL 8017|MRP-036|Mr Paint|65|37|26|![#41251A](https://placehold.co/15x15/41251A/41251A.png) `#41251A`|
|Red Chassis Covers SU-27, SU-35, SU-37|MRP-042|Mr Paint|165|26|23|![#A51A17](https://placehold.co/15x15/A51A17/A51A17.png) `#A51A17`|
|Red Clear|MRP-266|Mr Paint|221|48|50|![#DD3032](https://placehold.co/15x15/DD3032/DD3032.png) `#DD3032`|
|Red Engine Covers For Aircraft|MRP-041|Mr Paint|192|0|0|![#C00000](https://placehold.co/15x15/C00000/C00000.png) `#C00000`|
|Red Engine Covers For Aircraft|MRP-A047|Mr Paint - Aqua Colors|174|22|8|![#AE1608](https://placehold.co/15x15/AE1608/AE1608.png) `#AE1608`|
|Red Rust|MRP-360|Mr Paint|193|55|9|![#C13709](https://placehold.co/15x15/C13709/C13709.png) `#C13709`|
|Red Wood|MRP-261|Mr Paint|116|49|30|![#74311E](https://placehold.co/15x15/74311E/74311E.png) `#74311E`|
|Red-brown Clear|MRP-269|Mr Paint|170|96|87|![#AA6057](https://placehold.co/15x15/AA6057/AA6057.png) `#AA6057`|
|Reed Green RAL 6013|MRP-012|Mr Paint|119|112|83|![#777053](https://placehold.co/15x15/777053/777053.png) `#777053`|
|Reseda Green RAL 6011|MRP-011|Mr Paint|102|124|85|![#667C55](https://placehold.co/15x15/667C55/667C55.png) `#667C55`|
|Richthofens Red|MRP-250|Mr Paint|172|0|22|![#AC0016](https://placehold.co/15x15/AC0016/AC0016.png) `#AC0016`|
|Rosso|MRP-311|Mr Paint|168|33|37|![#A82125](https://placehold.co/15x15/A82125/A82125.png) `#A82125`|
|Rosso Corsa Ferrari No.300|MRP-C026|Mr Paint - Car|147|0|16|![#930010](https://placehold.co/15x15/930010/930010.png) `#930010`|
|Rosso Mimetico|MRP-321|Mr Paint|154|105|72|![#9A6948](https://placehold.co/15x15/9A6948/9A6948.png) `#9A6948`|
|Russia Cockpit Blue|MRP-277|Mr Paint|78|163|183|![#4EA3B7](https://placehold.co/15x15/4EA3B7/4EA3B7.png) `#4EA3B7`|
|Russia Cockpit Blue|MRP-A043|Mr Paint - Aqua Colors|100|161|180|![#64A1B4](https://placehold.co/15x15/64A1B4/64A1B4.png) `#64A1B4`|
|Russia Cockpit Light Blue|MRP-A045|Mr Paint - Aqua Colors|161|187|186|![#A1BBBA](https://placehold.co/15x15/A1BBBA/A1BBBA.png) `#A1BBBA`|
|Russia Cockpit Light Grey|MRP-A044|Mr Paint - Aqua Colors|144|159|162|![#909FA2](https://placehold.co/15x15/909FA2/909FA2.png) `#909FA2`|
|Russia Turquoise Cockpit|MRP-A041|Mr Paint - Aqua Colors|0|148|122|![#00947A](https://placehold.co/15x15/00947A/00947A.png) `#00947A`|
|Russia Turquoise Cockpit|MRP-001|Mr Paint|0|151|120|![#009778](https://placehold.co/15x15/009778/009778.png) `#009778`|
|Russian Cockpit Sealant|MRP-A048|Mr Paint - Aqua Colors|206|163|156|![#CEA39C](https://placehold.co/15x15/CEA39C/CEA39C.png) `#CEA39C`|
|Russian Cockpit Sealant|MRP-355|Mr Paint|214|161|153|![#D6A199](https://placehold.co/15x15/D6A199/D6A199.png) `#D6A199`|
|Russian Protective Green  Nc-1200|MRP-274|Mr Paint|66|80|67|![#425043](https://placehold.co/15x15/425043/425043.png) `#425043`|
|Russian Protective Green Nc-1200|MRP-A039|Mr Paint - Aqua Colors|67|79|67|![#434F43](https://placehold.co/15x15/434F43/434F43.png) `#434F43`|
|SCC No.14|MRP-348|Mr Paint|47|54|62|![#2F363E](https://placehold.co/15x15/2F363E/2F363E.png) `#2F363E`|
|SCC No.15|MRP-349|Mr Paint|83|80|63|![#53503F](https://placehold.co/15x15/53503F/53503F.png) `#53503F`|
|SCC No.1a|MRP-345|Mr Paint|54|41|32|![#362920](https://placehold.co/15x15/362920/362920.png) `#362920`|
|SCC No.2|MRP-346|Mr Paint|104|82|59|![#68523B](https://placehold.co/15x15/68523B/68523B.png) `#68523B`|
|SCC No.7|MRP-347|Mr Paint|72|71|51|![#484733](https://placehold.co/15x15/484733/484733.png) `#484733`|
|Sabbia|MRP-306|Mr Paint|193|163|111|![#C1A36F](https://placehold.co/15x15/C1A36F/C1A36F.png) `#C1A36F`|
|Sac Bomber Green  FS34127|MRP-249|Mr Paint|87|81|33|![#575121](https://placehold.co/15x15/575121/575121.png) `#575121`|
|Salmon - Pink Primer|MRP-130|Mr Paint|215|115|92|![#D7735C](https://placehold.co/15x15/D7735C/D7735C.png) `#D7735C`|
|Salmon - Pink Primer|MRP-A082|Mr Paint - Aqua Colors|202|120|99|![#CA7863](https://placehold.co/15x15/CA7863/CA7863.png) `#CA7863`|
|Sand - Tan FS33711|MRP-396|Mr Paint|223|188|148|![#DFBC94](https://placehold.co/15x15/DFBC94/DFBC94.png) `#DFBC94`|
|Sand Ana 616|MRP-144|Mr Paint|168|135|116|![#A88774](https://placehold.co/15x15/A88774/A88774.png) `#A88774`|
|Sand Brown FS30277|MRP-395|Mr Paint|160|140|115|![#A08C73](https://placehold.co/15x15/A08C73/A08C73.png) `#A08C73`|
|Sand Camouflage  FS33303|MRP-435|Mr Paint|151|135|109|![#97876D](https://placehold.co/15x15/97876D/97876D.png) `#97876D`|
|Sand FS 33531|MRP-226|Mr Paint|200|175|145|![#C8AF91](https://placehold.co/15x15/C8AF91/C8AF91.png) `#C8AF91`|
|Sand Grey RAL 7027|MRP-212|Mr Paint|151|120|92|![#97785C](https://placehold.co/15x15/97785C/97785C.png) `#97785C`|
|Sand Yellow  L-29 Delfín|MRP-076|Mr Paint|198|156|118|![#C69C76](https://placehold.co/15x15/C69C76/C69C76.png) `#C69C76`|
|Sand Yellow Syrian AFVs|MRP-294|Mr Paint|164|133|102|![#A48566](https://placehold.co/15x15/A48566/A48566.png) `#A48566`|
|Saudi Color FS30475|MRP-367|Mr Paint|190|154|118|![#BE9A76](https://placehold.co/15x15/BE9A76/BE9A76.png) `#BE9A76`|
|Sea Blue Ana 623|MRP-014|Mr Paint|7|35|46|![#07232E](https://placehold.co/15x15/07232E/07232E.png) `#07232E`|
|Sea Blue FS15042|MRP-A088|Mr Paint - Aqua Colors|16|34|44|![#10222C](https://placehold.co/15x15/10222C/10222C.png) `#10222C`|
|Sea Blue FS35042|MRP-237|Mr Paint|22|40|50|![#162832](https://placehold.co/15x15/162832/162832.png) `#162832`|
|Sea Camouflage  FS30219|MRP-103|Mr Paint|153|121|100|![#997964](https://placehold.co/15x15/997964/997964.png) `#997964`|
|Sea Camouflage  FS34079|MRP-101|Mr Paint|66|63|46|![#423F2E](https://placehold.co/15x15/423F2E/423F2E.png) `#423F2E`|
|Sea Camouflage  FS34102|MRP-102|Mr Paint|75|84|65|![#4B5441](https://placehold.co/15x15/4B5441/4B5441.png) `#4B5441`|
|Sea Camouflage  FS36622|MRP-104|Mr Paint|203|201|188|![#CBC9BC](https://placehold.co/15x15/CBC9BC/CBC9BC.png) `#CBC9BC`|
|Signal Blue RAL 5005|MRP-A009|Mr Paint - Aqua Colors|25|64|131|![#194083](https://placehold.co/15x15/194083/194083.png) `#194083`|
|Signal Brown RAL 8002|MRP-A006|Mr Paint - Aqua Colors|111|78|63|![#6F4E3F](https://placehold.co/15x15/6F4E3F/6F4E3F.png) `#6F4E3F`|
|Signal Brown RAL 8002|MRP-029|Mr Paint|111|62|55|![#6F3E37](https://placehold.co/15x15/6F3E37/6F3E37.png) `#6F3E37`|
|Signal Red|MRP-184|Mr Paint|188|0|0|![#BC0000](https://placehold.co/15x15/BC0000/BC0000.png) `#BC0000`|
|Signal Viollet RAL 4008|MRP-A008|Mr Paint - Aqua Colors|126|78|130|![#7E4E82](https://placehold.co/15x15/7E4E82/7E4E82.png) `#7E4E82`|
|Silk Grey RAL 7044|MRP-283|Mr Paint|183|177|165|![#B7B1A5](https://placehold.co/15x15/B7B1A5/B7B1A5.png) `#B7B1A5`|
|Silver|MRP-A012|Mr Paint - Aqua Colors|120|124|125|![#787C7D](https://placehold.co/15x15/787C7D/787C7D.png) `#787C7D`|
|Silver Metallic|MRP-128|Mr Paint|121|127|127|![#797F7F](https://placehold.co/15x15/797F7F/797F7F.png) `#797F7F`|
|Sky|MRP-118|Mr Paint|164|166|142|![#A4A68E](https://placehold.co/15x15/A4A68E/A4A68E.png) `#A4A68E`|
|Sky Grey FS36473|MRP-242|Mr Paint|159|180|175|![#9FB4AF](https://placehold.co/15x15/9FB4AF/9FB4AF.png) `#9FB4AF`|
|Smoke Clear|MRP-271|Mr Paint|98|104|104|![#626868](https://placehold.co/15x15/626868/626868.png) `#626868`|
|Soviet Protective Green  KHV-518|MRP-273|Mr Paint|70|80|27|![#46501B](https://placehold.co/15x15/46501B/46501B.png) `#46501B`|
|Soviet Protective Green KHV-518|MRP-A038|Mr Paint - Aqua Colors|71|80|35|![#475023](https://placehold.co/15x15/475023/475023.png) `#475023`|
|Special Brown FS30140|MRP-233|Mr Paint|122|82|57|![#7A5239](https://placehold.co/15x15/7A5239/7A5239.png) `#7A5239`|
|Spruce Green  Bs284|MRP-382|Mr Paint|95|94|74|![#5F5E4A](https://placehold.co/15x15/5F5E4A/5F5E4A.png) `#5F5E4A`|
|Steel|MRP-030|Mr Paint|89|90|84|![#595A54](https://placehold.co/15x15/595A54/595A54.png) `#595A54`|
|Steel|MRP-A013|Mr Paint - Aqua Colors|90|91|86|![#5A5B56](https://placehold.co/15x15/5A5B56/5A5B56.png) `#5A5B56`|
|Sukhoi Cockpit|MRP-195|Mr Paint|110|161|164|![#6EA1A4](https://placehold.co/15x15/6EA1A4/6EA1A4.png) `#6EA1A4`|
|Sukhoi Cockpit|MRP-A042|Mr Paint - Aqua Colors|122|162|164|![#7AA2A4](https://placehold.co/15x15/7AA2A4/7AA2A4.png) `#7AA2A4`|
|Sulfur Yellow RAL 1016|MRP-163|Mr Paint|240|213|0|![#F0D500](https://placehold.co/15x15/F0D500/F0D500.png) `#F0D500`|
|Sunset Violet|MRP-157|Mr Paint|54|30|52|![#361E34](https://placehold.co/15x15/361E34/361E34.png) `#361E34`|
|Super Clear Gloss|MRP-048|Mr Paint|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Super Clear Matt|MRP-127|Mr Paint|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Super Clear Semigloss|MRP-125|Mr Paint|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Super Clear Semimatt|MRP-126|Mr Paint|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Super Gloss Black|MRP-172|Mr Paint|0|0|0|![#000000](https://placehold.co/15x15/000000/000000.png) `#000000`|
|Super Matt Black|MRP-171|Mr Paint|0|0|0|![#000000](https://placehold.co/15x15/000000/000000.png) `#000000`|
|Super Silver Metallic|MRP-003|Mr Paint|116|122|122|![#747A7A](https://placehold.co/15x15/747A7A/747A7A.png) `#747A7A`|
|Tan 507m|MRP-179|Mr Paint|128|96|73|![#806049](https://placehold.co/15x15/806049/806049.png) `#806049`|
|Tan FS20400|MRP-244|Mr Paint|215|157|109|![#D79D6D](https://placehold.co/15x15/D79D6D/D79D6D.png) `#D79D6D`|
|Tan Green FS34201|MRP-389|Mr Paint|138|119|87|![#8A7757](https://placehold.co/15x15/8A7757/8A7757.png) `#8A7757`|
|Tank Grey RAL 7021|MRP-A029|Mr Paint - Aqua Colors|41|44|49|![#292C31](https://placehold.co/15x15/292C31/292C31.png) `#292C31`|
|Tank Grey RAL 7021|MRP-034|Mr Paint|40|43|50|![#282B32](https://placehold.co/15x15/282B32/282B32.png) `#282B32`|
|Terra Dombra|MRP-320|Mr Paint|153|135|87|![#998757](https://placehold.co/15x15/998757/998757.png) `#998757`|
|Titanium|MRP-082|Mr Paint|103|105|100|![#676964](https://placehold.co/15x15/676964/676964.png) `#676964`|
|Toyota Gr Supra Deep Blue Metallic|MRP-C021|Mr Paint - Car|5|18|35|![#051223](https://placehold.co/15x15/051223/051223.png) `#051223`|
|Toyota Gr Supra Lightning Yellow|MRP-C020|Mr Paint - Car|234|132|8|![#EA8408](https://placehold.co/15x15/EA8408/EA8408.png) `#EA8408`|
|Toyota Gr Supra Matte Storm Gray|MRP-C022|Mr Paint - Car|59|69|71|![#3B4547](https://placehold.co/15x15/3B4547/3B4547.png) `#3B4547`|
|Toyota Gr Supra Prominence Red|MRP-C019|Mr Paint - Car|138|0|2|![#8A0002](https://placehold.co/15x15/8A0002/8A0002.png) `#8A0002`|
|Traffic Grey|MRP-189|Mr Paint|165|181|178|![#A5B5B2](https://placehold.co/15x15/A5B5B2/A5B5B2.png) `#A5B5B2`|
|Traffic Red RAL 3020|MRP-A007|Mr Paint - Aqua Colors|168|44|32|![#A82C20](https://placehold.co/15x15/A82C20/A82C20.png) `#A82C20`|
|Traffic Yellow RAL 1023|MRP-A004|Mr Paint - Aqua Colors|230|186|63|![#E6BA3F](https://placehold.co/15x15/E6BA3F/E6BA3F.png) `#E6BA3F`|
|True Blue  FS15102|MRP-384|Mr Paint|0|100|142|![#00648E](https://placehold.co/15x15/00648E/00648E.png) `#00648E`|
|Tyre Rubber Matt|MRP-A026|Mr Paint - Aqua Colors|41|44|49|![#292C31](https://placehold.co/15x15/292C31/292C31.png) `#292C31`|
|Tyre-rubber Matt|MRP-173|Mr Paint|40|43|50|![#282B32](https://placehold.co/15x15/282B32/282B32.png) `#282B32`|
|U.S. Dark Ghost Gray FS36320|MRP-097|Mr Paint|132|145|151|![#849197](https://placehold.co/15x15/849197/849197.png) `#849197`|
|U.S. Dark Mod. Gray FS36176|MRP-093|Mr Paint|102|119|129|![#667781](https://placehold.co/15x15/667781/667781.png) `#667781`|
|U.S. Medium Mod. Gray FS36251|MRP-094|Mr Paint|124|128|127|![#7C807F](https://placehold.co/15x15/7C807F/7C807F.png) `#7C807F`|
|U.S. Navy Light Gull Grey FS36440|MRP-098|Mr Paint|164|162|149|![#A4A295](https://placehold.co/15x15/A4A295/A4A295.png) `#A4A295`|
|U.S. Navy White  FS17875|MRP-099|Mr Paint|226|220|196|![#E2DCC4](https://placehold.co/15x15/E2DCC4/E2DCC4.png) `#E2DCC4`|
|U.S.navy Modern FS35237|MRP-105|Mr Paint|117|135|139|![#75878B](https://placehold.co/15x15/75878B/75878B.png) `#75878B`|
|Us Desert Sand FS30279|MRP-243|Mr Paint|173|139|114|![#AD8B72](https://placehold.co/15x15/AD8B72/AD8B72.png) `#AD8B72`|
|Us Helo Drab FS 34031|MRP-174|Mr Paint|60|56|45|![#3C382D](https://placehold.co/15x15/3C382D/3C382D.png) `#3C382D`|
|Us Modern AFVs|MRP-080|Mr Paint|188|158|124|![#BC9E7C](https://placehold.co/15x15/BC9E7C/BC9E7C.png) `#BC9E7C`|
|Us Non Chromate Epoxy Primer|MRP-191|Mr Paint|97|209|173|![#61D1AD](https://placehold.co/15x15/61D1AD/61D1AD.png) `#61D1AD`|
|Verde|MRP-312|Mr Paint|0|93|66|![#005D42](https://placehold.co/15x15/005D42/005D42.png) `#005D42`|
|Verde Azzurro Chiaro|MRP-331|Mr Paint|72|124|102|![#487C66](https://placehold.co/15x15/487C66/487C66.png) `#487C66`|
|Verde Azzurro Scuro|MRP-330|Mr Paint|45|86|92|![#2D565C](https://placehold.co/15x15/2D565C/2D565C.png) `#2D565C`|
|Verde Mimetico|MRP-326|Mr Paint|114|136|115|![#728873](https://placehold.co/15x15/728873/728873.png) `#728873`|
|Verde Mimetico|MRP-327|Mr Paint|98|110|74|![#626E4A](https://placehold.co/15x15/626E4A/626E4A.png) `#626E4A`|
|Verde Mimetico Chiaro|MRP-329|Mr Paint|90|99|52|![#5A6334](https://placehold.co/15x15/5A6334/5A6334.png) `#5A6334`|
|Verde Mimetico Scuro|MRP-328|Mr Paint|78|84|56|![#4E5438](https://placehold.co/15x15/4E5438/4E5438.png) `#4E5438`|
|Verde Oliva Scuro|MRP-303|Mr Paint|49|55|51|![#313733](https://placehold.co/15x15/313733/313733.png) `#313733`|
|Violet Clear|MRP-270|Mr Paint|102|50|177|![#6632B1](https://placehold.co/15x15/6632B1/6632B1.png) `#6632B1`|
|White|MRP-401|Mr Paint|226|224|211|![#E2E0D3](https://placehold.co/15x15/E2E0D3/E2E0D3.png) `#E2E0D3`|
|White|MRP-A002|Mr Paint - Aqua Colors|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|White Aluminium|MRP-A015|Mr Paint - Aqua Colors|103|105|100|![#676964](https://placehold.co/15x15/676964/676964.png) `#676964`|
|White Aluminium|MRP-009|Mr Paint|118|124|124|![#767C7C](https://placehold.co/15x15/767C7C/767C7C.png) `#767C7C`|
|White FS17875|MRP-A083|Mr Paint - Aqua Colors|226|221|201|![#E2DDC9](https://placehold.co/15x15/E2DDC9/E2DDC9.png) `#E2DDC9`|
|White/Basic White|MRP-004|Mr Paint|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Willow Green FS14187|MRP-385|Mr Paint|70|113|33|![#467121](https://placehold.co/15x15/467121/467121.png) `#467121`|
|Yellow|MRP-224|Mr Paint|237|160|42|![#EDA02A](https://placehold.co/15x15/EDA02A/EDA02A.png) `#EDA02A`|
|Yellow Brown RAL 8020|MRP-214|Mr Paint|193|144|104|![#C19068](https://placehold.co/15x15/C19068/C19068.png) `#C19068`|
|Yellow Brown Syrian AFVs|MRP-293|Mr Paint|166|118|69|![#A67645](https://placehold.co/15x15/A67645/A67645.png) `#A67645`|
|Yellow Clear|MRP-264|Mr Paint|235|169|47|![#EBA92F](https://placehold.co/15x15/EBA92F/EBA92F.png) `#EBA92F`|
|Yellow Olive RAL 6014|MRP-208|Mr Paint|63|53|28|![#3F351C](https://placehold.co/15x15/3F351C/3F351C.png) `#3F351C`|
|Yellow-green Clear|MRP-263|Mr Paint|212|195|63|![#D4C33F](https://placehold.co/15x15/D4C33F/D4C33F.png) `#D4C33F`|
|Zinc-chromate Primer|MRP-129|Mr Paint|201|161|65|![#C9A141](https://placehold.co/15x15/C9A141/C9A141.png) `#C9A141`|
|Zinc-chromate Primer|MRP-A081|Mr Paint - Aqua Colors|196|164|81|![#C4A451](https://placehold.co/15x15/C4A451/C4A451.png) `#C4A451`|
<p align="center"><img src="../logos/logo_rnd.png" height="70" /></p>
<p align="center">Made available by <a href="https://miniaturepainterpro.app/">Miniature Painter Pro</a></p>
<p align="center">
<a href="https://play.google.com/store/apps/details?id=com.rfsp.paintmaster"> <img src="../logos/Android.png" height="30" /></a>
<a href="https://apps.apple.com/us/app/miniature-painter-pro/id1495938928"> <img src="../logos/iOS.png" height="30" /></a>
</p>
