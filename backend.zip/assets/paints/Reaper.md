# Reaper
![Reaper](../logos/Reaper.png "Reaper")

|Name|Code|Set|R|G|B|Hex|
|---|---|---|---|---|---|---|
|Adamantine|89556|Master Series Paints Pathfinder|144|134|125|![#90867D](https://placehold.co/15x15/90867D/90867D.png) `#90867D`|
|Adamantium Black|9124|Master Series Paints Core Colors|15|15|15|![#0F0F0F](https://placehold.co/15x15/0F0F0F/0F0F0F.png) `#0F0F0F`|
|Adonese Green|9297|Master Series Paints Core Colors|31|76|17|![#1F4C11](https://placehold.co/15x15/1F4C11/1F4C11.png) `#1F4C11`|
|Aged Bone|9059|Master Series Paints Core Colors|225|215|188|![#E1D7BC](https://placehold.co/15x15/E1D7BC/E1D7BC.png) `#E1D7BC`|
|Aged Pewter|9196|Master Series Paints Core Colors|87|80|54|![#575036](https://placehold.co/15x15/575036/575036.png) `#575036`|
|Aircraft Grey|9290|Master Series Paints Core Colors|179|179|179|![#B3B3B3](https://placehold.co/15x15/B3B3B3/B3B3B3.png) `#B3B3B3`|
|Akata Blue|89523|Master Series Paints Pathfinder|165|197|210|![#A5C5D2](https://placehold.co/15x15/A5C5D2/A5C5D2.png) `#A5C5D2`|
|Alchemical Green|89516|Master Series Paints Pathfinder|145|201|100|![#91C964](https://placehold.co/15x15/91C964/91C964.png) `#91C964`|
|Alien Flesh|9293|Master Series Paints Core Colors|160|134|109|![#A0866D](https://placehold.co/15x15/A0866D/A0866D.png) `#A0866D`|
|Alien Goo|9294|Master Series Paints Core Colors|182|255|0|![#B6FF00](https://placehold.co/15x15/B6FF00/B6FF00.png) `#B6FF00`|
|Amber Gold|9032|Master Series Paints Core Colors|206|163|94|![#CEA35E](https://placehold.co/15x15/CEA35E/CEA35E.png) `#CEA35E`|
|Amethyst Purple|9024|Master Series Paints Core Colors|158|125|170|![#9E7DAA](https://placehold.co/15x15/9E7DAA/9E7DAA.png) `#9E7DAA`|
|Ancient Bronze|9049|Master Series Paints Core Colors|174|128|92|![#AE805C](https://placehold.co/15x15/AE805C/AE805C.png) `#AE805C`|
|Ancient Oak|9412|Master Series Paints Bones|0|33|6|![#002106](https://placehold.co/15x15/002106/002106.png) `#002106`|
|Ancient Wood|9315|Master Series Paints Core Colors|191|180|188|![#BFB4BC](https://placehold.co/15x15/BFB4BC/BFB4BC.png) `#BFB4BC`|
|Andoran Blue|89527|Master Series Paints Pathfinder|1|113|187|![#0171BB](https://placehold.co/15x15/0171BB/0171BB.png) `#0171BB`|
|Anti-Shine Additive|9215|Master Series Paints Core Colors|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Antique Gold|9050|Master Series Paints Core Colors|208|177|97|![#D0B161](https://placehold.co/15x15/D0B161/D0B161.png) `#D0B161`|
|Arclord Purple|89534|Master Series Paints Pathfinder|172|67|152|![#AC4398](https://placehold.co/15x15/AC4398/AC4398.png) `#AC4398`|
|Ashen Blue|9057|Master Series Paints Core Colors|85|126|144|![#557E90](https://placehold.co/15x15/557E90/557E90.png) `#557E90`|
|Asmodeus Red|89507|Master Series Paints Pathfinder|157|28|48|![#9D1C30](https://placehold.co/15x15/9D1C30/9D1C30.png) `#9D1C30`|
|Auburn Shadow|9241|Master Series Paints Core Colors|129|48|31|![#81301F](https://placehold.co/15x15/81301F/81301F.png) `#81301F`|
|Azlanti Violet|89533|Master Series Paints Pathfinder|71|46|140|![#472E8C](https://placehold.co/15x15/472E8C/472E8C.png) `#472E8C`|
|Barbarian Flesh|9442|Master Series Paints Bones|169|106|65|![#A96A41](https://placehold.co/15x15/A96A41/A96A41.png) `#A96A41`|
|Basic Dirt|9245|Master Series Paints Core Colors|88|68|43|![#58442B](https://placehold.co/15x15/58442B/58442B.png) `#58442B`|
|Bathalian Chitin|9292|Master Series Paints Core Colors|231|189|89|![#E7BD59](https://placehold.co/15x15/E7BD59/E7BD59.png) `#E7BD59`|
|Besmara Black|89546|Master Series Paints Pathfinder|38|39|41|![#262729](https://placehold.co/15x15/262729/262729.png) `#262729`|
|Black Green|9236|Master Series Paints Core Colors|1|31|7|![#011F07](https://placehold.co/15x15/011F07/011F07.png) `#011F07`|
|Black Ink|9208|Master Series Paints Core Colors|0|17|33|![#001121](https://placehold.co/15x15/001121/001121.png) `#001121`|
|Black Wash|9255|Master Series Paints Core Colors Wash|56|60|63|![#383C3F](https://placehold.co/15x15/383C3F/383C3F.png) `#383C3F`|
|Blackened Brown|9137|Master Series Paints Core Colors|93|5|1|![#5D0501](https://placehold.co/15x15/5D0501/5D0501.png) `#5D0501`|
|Blackened Steel|9205|Master Series Paints Core Colors|43|37|37|![#2B2525](https://placehold.co/15x15/2B2525/2B2525.png) `#2B2525`|
|Blade Steel|9452|Master Series Paints Bones|144|136|134|![#908886](https://placehold.co/15x15/908886/908886.png) `#908886`|
|Bleached Linen|9436|Master Series Paints Bones|241|232|217|![#F1E8D9](https://placehold.co/15x15/F1E8D9/F1E8D9.png) `#F1E8D9`|
|Blonde Hair|9257|Master Series Paints Core Colors|215|141|46|![#D78D2E](https://placehold.co/15x15/D78D2E/D78D2E.png) `#D78D2E`|
|Blonde Highlight|9258|Master Series Paints Core Colors|242|194|96|![#F2C260](https://placehold.co/15x15/F2C260/F2C260.png) `#F2C260`|
|Blonde Shadow|9256|Master Series Paints Core Colors|167|65|0|![#A74100](https://placehold.co/15x15/A74100/A74100.png) `#A74100`|
|Blood Red|9003|Master Series Paints Core Colors|173|23|50|![#AD1732](https://placehold.co/15x15/AD1732/AD1732.png) `#AD1732`|
|Bloodless Skin|9150|Master Series Paints Core Colors|210|207|154|![#D2CF9A](https://placehold.co/15x15/D2CF9A/D2CF9A.png) `#D2CF9A`|
|Bloodstain Red|9133|Master Series Paints Core Colors|104|0|1|![#680001](https://placehold.co/15x15/680001/680001.png) `#680001`|
|Blue Flame|9480|Master Series Paints Bones|212|238|251|![#D4EEFB](https://placehold.co/15x15/D4EEFB/D4EEFB.png) `#D4EEFB`|
|Blue Liner|9066|Master Series Paints Core Colors|1|20|34|![#011422](https://placehold.co/15x15/011422/011422.png) `#011422`|
|Blush Pink|9262|Master Series Paints Core Colors|253|66|173|![#FD42AD](https://placehold.co/15x15/FD42AD/FD42AD.png) `#FD42AD`|
|Boggard Green|89515|Master Series Paints Pathfinder|167|187|176|![#A7BBB0](https://placehold.co/15x15/A7BBB0/A7BBB0.png) `#A7BBB0`|
|Bone Shadow|9058|Master Series Paints Core Colors|214|198|175|![#D6C6AF](https://placehold.co/15x15/D6C6AF/D6C6AF.png) `#D6C6AF`|
|Braaaains Pink|9281|Master Series Paints Core Colors|200|129|163|![#C881A3](https://placehold.co/15x15/C881A3/C881A3.png) `#C881A3`|
|Breonne Blue|9055|Master Series Paints Core Colors|1|39|60|![#01273C](https://placehold.co/15x15/01273C/01273C.png) `#01273C`|
|Brevoy Copper|89553|Master Series Paints Pathfinder|167|129|93|![#A7815D](https://placehold.co/15x15/A7815D/A7815D.png) `#A7815D`|
|Bright Bronze|89555|Master Series Paints Pathfinder|208|145|112|![#D09170](https://placehold.co/15x15/D09170/D09170.png) `#D09170`|
|Bright Skin|9233|Master Series Paints Core Colors|236|171|89|![#ECAB59](https://placehold.co/15x15/ECAB59/ECAB59.png) `#ECAB59`|
|Bright Skin Highlight|9234|Master Series Paints Core Colors|241|212|95|![#F1D45F](https://placehold.co/15x15/F1D45F/F1D45F.png) `#F1D45F`|
|Bright Skin Shadow|9232|Master Series Paints Core Colors|222|136|113|![#DE8871](https://placehold.co/15x15/DE8871/DE8871.png) `#DE8871`|
|Bright Turquoise|9471|Master Series Paints Bones|0|91|92|![#005B5C](https://placehold.co/15x15/005B5C/005B5C.png) `#005B5C`|
|Brilliant Blue|9116|Master Series Paints Core Colors|2|87|142|![#02578E](https://placehold.co/15x15/02578E/02578E.png) `#02578E`|
|Brilliant Green|9227|Master Series Paints Core Colors|1|100|45|![#01642D](https://placehold.co/15x15/01642D/01642D.png) `#01642D`|
|Brilliant Red|9468|Master Series Paints Bones|236|32|43|![#EC202B](https://placehold.co/15x15/EC202B/EC202B.png) `#EC202B`|
|Bronzed Skin|9260|Master Series Paints Core Colors|208|94|23|![#D05E17](https://placehold.co/15x15/D05E17/D05E17.png) `#D05E17`|
|Bronzed Skin Highlight|9261|Master Series Paints Core Colors|229|162|58|![#E5A23A](https://placehold.co/15x15/E5A23A/E5A23A.png) `#E5A23A`|
|Bronzed Skin Shadow|9259|Master Series Paints Core Colors|166|50|1|![#A63201](https://placehold.co/15x15/A63201/A63201.png) `#A63201`|
|Brown Ink|9209|Master Series Paints Core Colors|97|44|0|![#612C00](https://placehold.co/15x15/612C00/612C00.png) `#612C00`|
|Brown Liner|9064|Master Series Paints Core Colors|36|23|17|![#241711](https://placehold.co/15x15/241711/241711.png) `#241711`|
|Brown Sand|9246|Master Series Paints Core Colors|138|105|60|![#8A693C](https://placehold.co/15x15/8A693C/8A693C.png) `#8A693C`|
|Brown Wash|9254|Master Series Paints Core Colors Wash|116|72|59|![#74483B](https://placehold.co/15x15/74483B/74483B.png) `#74483B`|
|Brush-On Black Primer|9214|Master Series Paints Core Colors Primer|0|0|0|![#000000](https://placehold.co/15x15/000000/000000.png) `#000000`|
|Brush-On Grey Primer|9299|Master Series Paints Core Colors Primer|188|204|204|![#BCCCCC](https://placehold.co/15x15/BCCCCC/BCCCCC.png) `#BCCCCC`|
|Brush-on Sealer|9107|Master Series Paints Core Colors|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Brush-on White Primer|9108|Master Series Paints Core Colors Primer|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Buckskin Pale|9075|Master Series Paints Core Colors|220|184|90|![#DCB85A](https://placehold.co/15x15/DCB85A/DCB85A.png) `#DCB85A`|
|Bugbear Fur|9490|Master Series Paints Bones|216|160|83|![#D8A053](https://placehold.co/15x15/D8A053/D8A053.png) `#D8A053`|
|Burgundy Wine|9025|Master Series Paints Core Colors|70|32|53|![#462035](https://placehold.co/15x15/462035/462035.png) `#462035`|
|Burnt Orange|9111|Master Series Paints Core Colors|225|135|73|![#E18749](https://placehold.co/15x15/E18749/E18749.png) `#E18749`|
|Cailean Wine|89506|Master Series Paints Pathfinder|161|49|89|![#A13159](https://placehold.co/15x15/A13159/A13159.png) `#A13159`|
|Cairn Stone|89512|Master Series Paints Pathfinder|209|195|146|![#D1C392](https://placehold.co/15x15/D1C392/D1C392.png) `#D1C392`|
|Calistria Yellow|89513|Master Series Paints Pathfinder|248|212|74|![#F8D44A](https://placehold.co/15x15/F8D44A/F8D44A.png) `#F8D44A`|
|Camouflage Green|9177|Master Series Paints Core Colors|140|141|39|![#8C8D27](https://placehold.co/15x15/8C8D27/8C8D27.png) `#8C8D27`|
|Canary Yellow|9409|Master Series Paints Bones|248|224|2|![#F8E002](https://placehold.co/15x15/F8E002/F8E002.png) `#F8E002`|
|Candlelight Yellow|9408|Master Series Paints Bones|255|203|5|![#FFCB05](https://placehold.co/15x15/FFCB05/FFCB05.png) `#FFCB05`|
|Carbon Grey|9318|Master Series Paints Core Colors|65|65|65|![#414141](https://placehold.co/15x15/414141/414141.png) `#414141`|
|Carnage Red|9135|Master Series Paints Core Colors|177|15|30|![#B10F1E](https://placehold.co/15x15/B10F1E/B10F1E.png) `#B10F1E`|
|Carrottop Red|9242|Master Series Paints Core Colors|193|73|23|![#C14917](https://placehold.co/15x15/C14917/C14917.png) `#C14917`|
|Cats-Eye Green|9414|Master Series Paints Bones|90|149|65|![#5A9541](https://placehold.co/15x15/5A9541/5A9541.png) `#5A9541`|
|Caucasian Flesh|9474|Master Series Paints Bones|230|177|123|![#E6B17B](https://placehold.co/15x15/E6B17B/E6B17B.png) `#E6B17B`|
|Cavalier Orange|89509|Master Series Paints Pathfinder|242|104|42|![#F2682A](https://placehold.co/15x15/F2682A/F2682A.png) `#F2682A`|
|Charred Brown|9426|Master Series Paints Bones|38|22|9|![#261609](https://placehold.co/15x15/261609/261609.png) `#261609`|
|Chestnut Brown|9071|Master Series Paints Core Colors|127|67|59|![#7F433B](https://placehold.co/15x15/7F433B/7F433B.png) `#7F433B`|
|Chestnut Gold|9073|Master Series Paints Core Colors|152|106|57|![#986A39](https://placehold.co/15x15/986A39/986A39.png) `#986A39`|
|Christmas Wreath|9658|Master Series Paints Core Colors|41|116|59|![#29743B](https://placehold.co/15x15/29743B/29743B.png) `#29743B`|
|Cinnamon Red|9404|Master Series Paints Bones|159|39|14|![#9F270E](https://placehold.co/15x15/9F270E/9F270E.png) `#9F270E`|
|Clear Blue|9097|Master Series Paints Core Colors|51|68|150|![#334496](https://placehold.co/15x15/334496/334496.png) `#334496`|
|Clear Green|9096|Master Series Paints Core Colors|4|159|58|![#049F3A](https://placehold.co/15x15/049F3A/049F3A.png) `#049F3A`|
|Clear Magenta|9098|Master Series Paints Core Colors|226|1|123|![#E2017B](https://placehold.co/15x15/E2017B/E2017B.png) `#E2017B`|
|Clear Purple|9099|Master Series Paints Core Colors|95|13|123|![#5F0D7B](https://placehold.co/15x15/5F0D7B/5F0D7B.png) `#5F0D7B`|
|Clear Red|9094|Master Series Paints Core Colors|224|0|36|![#E00024](https://placehold.co/15x15/E00024/E00024.png) `#E00024`|
|Clear Yellow|9095|Master Series Paints Core Colors|249|244|4|![#F9F404](https://placehold.co/15x15/F9F404/F9F404.png) `#F9F404`|
|Clockwork Brass|89554|Master Series Paints Pathfinder|184|164|113|![#B8A471](https://placehold.co/15x15/B8A471/B8A471.png) `#B8A471`|
|Clotted Red|9134|Master Series Paints Core Colors|137|1|1|![#890101](https://placehold.co/15x15/890101/890101.png) `#890101`|
|Cloudy Grey|9089|Master Series Paints Core Colors|112|112|112|![#707070](https://placehold.co/15x15/707070/707070.png) `#707070`|
|Coal Black|9693|Master Series Paints Core Colors|32|40|53|![#202835](https://placehold.co/15x15/202835/202835.png) `#202835`|
|Cold Iron|89549|Master Series Paints Pathfinder|130|120|119|![#827877](https://placehold.co/15x15/827877/827877.png) `#827877`|
|Copper Verdigris|9304|Master Series Paints Core Colors|107|196|174|![#6BC4AE](https://placehold.co/15x15/6BC4AE/6BC4AE.png) `#6BC4AE`|
|Coppery Orange|9102|Master Series Paints Core Colors|211|160|131|![#D3A083](https://placehold.co/15x15/D3A083/D3A083.png) `#D3A083`|
|Creamy Ivory|9144|Master Series Paints Core Colors|233|216|164|![#E9D8A4](https://placehold.co/15x15/E9D8A4/E9D8A4.png) `#E9D8A4`|
|Crimson Red|9467|Master Series Paints Bones|113|19|19|![#711313](https://placehold.co/15x15/711313/711313.png) `#711313`|
|Crusader Silver|89550|Master Series Paints Pathfinder|159|159|159|![#9F9F9F](https://placehold.co/15x15/9F9F9F/9F9F9F.png) `#9F9F9F`|
|Cursed Gold|9464|Master Series Paints Bones|177|107|35|![#B16B23](https://placehold.co/15x15/B16B23/B16B23.png) `#B16B23`|
|Cyan Blue|9117|Master Series Paints Core Colors|2|136|209|![#0288D1](https://placehold.co/15x15/0288D1/0288D1.png) `#0288D1`|
|Dark Elf Highlight|9165|Master Series Paints Core Colors|134|127|135|![#867F87](https://placehold.co/15x15/867F87/867F87.png) `#867F87`|
|Dark Elf Shadow|9163|Master Series Paints Core Colors|70|52|64|![#463440](https://placehold.co/15x15/463440/463440.png) `#463440`|
|Dark Elf Skin|9164|Master Series Paints Core Colors|99|86|95|![#63565F](https://placehold.co/15x15/63565F/63565F.png) `#63565F`|
|Dark Highlights|9042|Master Series Paints Core Colors|66|43|25|![#422B19](https://placehold.co/15x15/422B19/422B19.png) `#422B19`|
|Dark Shadow|9040|Master Series Paints Core Colors|34|13|12|![#220D0C](https://placehold.co/15x15/220D0C/220D0C.png) `#220D0C`|
|Dark Skin|9041|Master Series Paints Core Colors|65|36|30|![#41241E](https://placehold.co/15x15/41241E/41241E.png) `#41241E`|
|Deep Ocean|9076|Master Series Paints Core Colors|28|57|71|![#1C3947](https://placehold.co/15x15/1C3947/1C3947.png) `#1C3947`|
|Deep Red|9002|Master Series Paints Core Colors|159|55|62|![#9F373E](https://placehold.co/15x15/9F373E/9F373E.png) `#9F373E`|
|Deep Twilight|9265|Master Series Paints Core Colors|8|12|39|![#080C27](https://placehold.co/15x15/080C27/080C27.png) `#080C27`|
|Denim Blue|9285|Master Series Paints Core Colors|0|28|91|![#001C5B](https://placehold.co/15x15/001C5B/001C5B.png) `#001C5B`|
|Desert Sand|9432|Master Series Paints Bones|197|180|154|![#C5B49A](https://placehold.co/15x15/C5B49A/C5B49A.png) `#C5B49A`|
|Desert Stone|9431|Master Series Paints Bones|155|126|82|![#9B7E52](https://placehold.co/15x15/9B7E52/9B7E52.png) `#9B7E52`|
|Desna Blue|89530|Master Series Paints Pathfinder|77|96|172|![#4D60AC](https://placehold.co/15x15/4D60AC/4D60AC.png) `#4D60AC`|
|Dirty Bone|9271|Master Series Paints Core Colors|157|161|77|![#9DA14D](https://placehold.co/15x15/9DA14D/9DA14D.png) `#9DA14D`|
|Dragon Black|9437|Master Series Paints Bones|6|0|0|![#060000](https://placehold.co/15x15/060000/060000.png) `#060000`|
|Dragon Blue|9472|Master Series Paints Bones|8|108|183|![#086CB7](https://placehold.co/15x15/086CB7/086CB7.png) `#086CB7`|
|Dragon Bronze|9449|Master Series Paints Bones|159|141|91|![#9F8D5B](https://placehold.co/15x15/9F8D5B/9F8D5B.png) `#9F8D5B`|
|Dragon Copper|9448|Master Series Paints Bones|185|127|103|![#B97F67](https://placehold.co/15x15/B97F67/B97F67.png) `#B97F67`|
|Dragon Gold|9450|Master Series Paints Bones|197|148|72|![#C59448](https://placehold.co/15x15/C59448/C59448.png) `#C59448`|
|Dragon Green|9410|Master Series Paints Bones|2|59|27|![#023B1B](https://placehold.co/15x15/023B1B/023B1B.png) `#023B1B`|
|Dragon Red|9401|Master Series Paints Bones|81|9|21|![#510915](https://placehold.co/15x15/510915/510915.png) `#510915`|
|Dragon White|9439|Master Series Paints Bones|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Driftwood Brown|9162|Master Series Paints Core Colors|164|126|77|![#A47E4D](https://placehold.co/15x15/A47E4D/A47E4D.png) `#A47E4D`|
|Drow Silver|9495|Master Series Paints Bones|152|132|160|![#9884A0](https://placehold.co/15x15/9884A0/9884A0.png) `#9884A0`|
|Drying Retarder|9216|Master Series Paints Core Colors|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Dungeon Grey|9466|Master Series Paints Bones|83|70|64|![#534640](https://placehold.co/15x15/534640/534640.png) `#534640`|
|Dungeon Slime|9415|Master Series Paints Bones|186|216|116|![#BAD874](https://placehold.co/15x15/BAD874/BAD874.png) `#BAD874`|
|Dusky Skin|9251|Master Series Paints Core Colors|118|97|94|![#76615E](https://placehold.co/15x15/76615E/76615E.png) `#76615E`|
|Dusky Skin Highlight|9252|Master Series Paints Core Colors|168|148|150|![#A89496](https://placehold.co/15x15/A89496/A89496.png) `#A89496`|
|Dusky Skin Shadow|9250|Master Series Paints Core Colors|70|54|57|![#463639](https://placehold.co/15x15/463639/463639.png) `#463639`|
|Dwarven Gold|9451|Master Series Paints Bones|169|102|23|![#A96617](https://placehold.co/15x15/A96617/A96617.png) `#A96617`|
|Earth Brown|9029|Master Series Paints Core Colors|120|83|54|![#785336](https://placehold.co/15x15/785336/785336.png) `#785336`|
|Ebony Flesh|9440|Master Series Paints Bones|19|12|4|![#130C04](https://placehold.co/15x15/130C04/130C04.png) `#130C04`|
|Eldritch Purple|9463|Master Series Paints Bones|146|39|143|![#92278F](https://placehold.co/15x15/92278F/92278F.png) `#92278F`|
|Elven Green|9488|Master Series Paints Bones|38|64|51|![#264033](https://placehold.co/15x15/264033/264033.png) `#264033`|
|Emerald Green|9103|Master Series Paints Core Colors|133|185|196|![#85B9C4](https://placehold.co/15x15/85B9C4/85B9C4.png) `#85B9C4`|
|Explosion Orange|9219|Master Series Paints Core Colors|222|124|27|![#DE7C1B](https://placehold.co/15x15/DE7C1B/DE7C1B.png) `#DE7C1B`|
|Ezren Blue|89528|Master Series Paints Pathfinder|1|113|187|![#0171BB](https://placehold.co/15x15/0171BB/0171BB.png) `#0171BB`|
|Faded Khaki|9129|Master Series Paints Core Colors|187|145|35|![#BB9123](https://placehold.co/15x15/BB9123/BB9123.png) `#BB9123`|
|Fair Highlights|9048|Master Series Paints Core Colors|244|230|204|![#F4E6CC](https://placehold.co/15x15/F4E6CC/F4E6CC.png) `#F4E6CC`|
|Fair Shadow|9046|Master Series Paints Core Colors|231|190|146|![#E7BE92](https://placehold.co/15x15/E7BE92/E7BE92.png) `#E7BE92`|
|Fair Skin|9047|Master Series Paints Core Colors|241|210|179|![#F1D2B3](https://placehold.co/15x15/F1D2B3/F1D2B3.png) `#F1D2B3`|
|Filigree Silver|9453|Master Series Paints Bones|178|173|170|![#B2ADAA](https://placehold.co/15x15/B2ADAA/B2ADAA.png) `#B2ADAA`|
|Fire Orange|9006|Master Series Paints Core Colors|234|113|44|![#EA712C](https://placehold.co/15x15/EA712C/EA712C.png) `#EA712C`|
|Fire Red|9004|Master Series Paints Core Colors|192|8|60|![#C0083C](https://placehold.co/15x15/C0083C/C0083C.png) `#C0083C`|
|Fireball Orange|9469|Master Series Paints Bones|239|111|36|![#EF6F24](https://placehold.co/15x15/EF6F24/EF6F24.png) `#EF6F24`|
|Flesh Wash|9253|Master Series Paints Core Colors Wash|164|75|69|![#A44B45](https://placehold.co/15x15/A44B45/A44B45.png) `#A44B45`|
|Flow Improver|9106|Master Series Paints Core Colors|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Foggy Grey|9316|Master Series Paints Core Colors|210|211|213|![#D2D3D5](https://placehold.co/15x15/D2D3D5/D2D3D5.png) `#D2D3D5`|
|Forest Green|9013|Master Series Paints Core Colors|0|69|40|![#004528](https://placehold.co/15x15/004528/004528.png) `#004528`|
|Fresh Blood|9279|Master Series Paints Core Colors|190|0|0|![#BE0000](https://placehold.co/15x15/BE0000/BE0000.png) `#BE0000`|
|Frost Blue|9421|Master Series Paints Bones|140|194|218|![#8CC2DA](https://placehold.co/15x15/8CC2DA/8CC2DA.png) `#8CC2DA`|
|Frosty Blue|9692|Master Series Paints Core Colors|110|208|247|![#6ED0F7](https://placehold.co/15x15/6ED0F7/6ED0F7.png) `#6ED0F7`|
|Gargoyle Grey|9493|Master Series Paints Bones|158|176|186|![#9EB0BA](https://placehold.co/15x15/9EB0BA/9EB0BA.png) `#9EB0BA`|
|Gem Purple|9473|Master Series Paints Bones|71|40|110|![#47286E](https://placehold.co/15x15/47286E/47286E.png) `#47286E`|
|Ghost White|9063|Master Series Paints Core Colors|234|245|251|![#EAF5FB](https://placehold.co/15x15/EAF5FB/EAF5FB.png) `#EAF5FB`|
|Ghoul Skin|9148|Master Series Paints Core Colors|144|148|115|![#909473](https://placehold.co/15x15/909473/909473.png) `#909473`|
|Ghoul Violet|89532|Master Series Paints Pathfinder|102|96|170|![#6660AA](https://placehold.co/15x15/6660AA/6660AA.png) `#6660AA`|
|Ginger Cookie|9659|Master Series Paints Core Colors|198|155|110|![#C69B6E](https://placehold.co/15x15/C69B6E/C69B6E.png) `#C69B6E`|
|Glacial Mist|9323|Master Series Paints Core Colors|97|128|149|![#618095](https://placehold.co/15x15/618095/618095.png) `#618095`|
|Glacier Blue|9420|Master Series Paints Bones|84|155|185|![#549BB9](https://placehold.co/15x15/549BB9/549BB9.png) `#549BB9`|
|Gloss Sealer|9298|Master Series Paints Core Colors|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Gnoll Pelt|9460|Master Series Paints Bones|151|140|60|![#978C3C](https://placehold.co/15x15/978C3C/978C3C.png) `#978C3C`|
|Gnome Flesh|9494|Master Series Paints Bones|215|148|131|![#D79483](https://placehold.co/15x15/D79483/D79483.png) `#D79483`|
|Goblin Green|89519|Master Series Paints Pathfinder|121|156|72|![#799C48](https://placehold.co/15x15/799C48/799C48.png) `#799C48`|
|Goblin Skin|9457|Master Series Paints Bones|176|88|42|![#B0582A](https://placehold.co/15x15/B0582A/B0582A.png) `#B0582A`|
|Golden Blonde|9033|Master Series Paints Core Colors|242|226|148|![#F2E294](https://placehold.co/15x15/F2E294/F2E294.png) `#F2E294`|
|Golden Glow|9671|Master Series Paints Core Colors|255|214|100|![#FFD664](https://placehold.co/15x15/FFD664/FFD664.png) `#FFD664`|
|Golden Highlight|9093|Master Series Paints Core Colors|242|206|154|![#F2CE9A](https://placehold.co/15x15/F2CE9A/F2CE9A.png) `#F2CE9A`|
|Golden Shadow|9091|Master Series Paints Core Colors|189|149|100|![#BD9564](https://placehold.co/15x15/BD9564/BD9564.png) `#BD9564`|
|Golden Skin|9092|Master Series Paints Core Colors|210|173|129|![#D2AD81](https://placehold.co/15x15/D2AD81/D2AD81.png) `#D2AD81`|
|Golden Yellow|9470|Master Series Paints Bones|247|183|23|![#F7B717](https://placehold.co/15x15/F7B717/F7B717.png) `#F7B717`|
|Gory Red|9278|Master Series Paints Core Colors|121|2|6|![#790206](https://placehold.co/15x15/790206/790206.png) `#790206`|
|Gozreh Gray|89545|Master Series Paints Pathfinder|120|120|122|![#78787A](https://placehold.co/15x15/78787A/78787A.png) `#78787A`|
|Grass Green|9014|Master Series Paints Core Colors|6|122|85|![#067A55](https://placehold.co/15x15/067A55/067A55.png) `#067A55`|
|Graveyard Bone|9272|Master Series Paints Core Colors|197|196|131|![#C5C483](https://placehold.co/15x15/C5C483/C5C483.png) `#C5C483`|
|Green Liner|9308|Master Series Paints Core Colors|21|42|23|![#152A17](https://placehold.co/15x15/152A17/152A17.png) `#152A17`|
|Green Ochre|9128|Master Series Paints Core Colors|155|116|25|![#9B7419](https://placehold.co/15x15/9B7419/9B7419.png) `#9B7419`|
|Grey Liner|9065|Master Series Paints Core Colors|54|54|54|![#363636](https://placehold.co/15x15/363636/363636.png) `#363636`|
|Grindylow Blue|89522|Master Series Paints Pathfinder|0|180|169|![#00B4A9](https://placehold.co/15x15/00B4A9/00B4A9.png) `#00B4A9`|
|Gug Umber|89543|Master Series Paints Pathfinder|97|82|79|![#61524F](https://placehold.co/15x15/61524F/61524F.png) `#61524F`|
|Gunmetal Blue|9126|Master Series Paints Core Colors|19|55|79|![#13374F](https://placehold.co/15x15/13374F/13374F.png) `#13374F`|
|Harvest Brown|9200|Master Series Paints Core Colors|142|62|1|![#8E3E01](https://placehold.co/15x15/8E3E01/8E3E01.png) `#8E3E01`|
|Hearth Fire|9690|Master Series Paints Core Colors|247|148|29|![#F7941D](https://placehold.co/15x15/F7941D/F7941D.png) `#F7941D`|
|Heartwood Brown|9314|Master Series Paints Core Colors|197|136|53|![#C58835](https://placehold.co/15x15/C58835/C58835.png) `#C58835`|
|Heather Blue|9231|Master Series Paints Core Colors|83|123|149|![#537B95](https://placehold.co/15x15/537B95/537B95.png) `#537B95`|
|Heraldic Red|9402|Master Series Paints Bones|151|22|26|![#97161A](https://placehold.co/15x15/97161A/97161A.png) `#97161A`|
|Highland Moss|9083|Master Series Paints Core Colors|61|80|74|![#3D504A](https://placehold.co/15x15/3D504A/3D504A.png) `#3D504A`|
|Highlight Orange|9243|Master Series Paints Core Colors|226|120|18|![#E27812](https://placehold.co/15x15/E27812/E27812.png) `#E27812`|
|Hobgoblin Blue|89529|Master Series Paints Pathfinder|107|162|183|![#6BA2B7](https://placehold.co/15x15/6BA2B7/6BA2B7.png) `#6BA2B7`|
|Hodag Green|89520|Master Series Paints Pathfinder|110|112|47|![#6E702F](https://placehold.co/15x15/6E702F/6E702F.png) `#6E702F`|
|Holly Berry|9687|Master Series Paints Core Colors|238|68|35|![#EE4423](https://placehold.co/15x15/EE4423/EE4423.png) `#EE4423`|
|Honed Steel|9053|Master Series Paints Core Colors|176|176|176|![#B0B0B0](https://placehold.co/15x15/B0B0B0/B0B0B0.png) `#B0B0B0`|
|IMEF Olive|9291|Master Series Paints Core Colors|60|92|9|![#3C5C09](https://placehold.co/15x15/3C5C09/3C5C09.png) `#3C5C09`|
|Ice Devil Blue|89524|Master Series Paints Pathfinder|140|211|217|![#8CD3D9](https://placehold.co/15x15/8CD3D9/8CD3D9.png) `#8CD3D9`|
|Icy Violet|9425|Master Series Paints Bones|127|119|168|![#7F77A8](https://placehold.co/15x15/7F77A8/7F77A8.png) `#7F77A8`|
|Imperial Purple|9023|Master Series Paints Core Colors|99|72|113|![#634871](https://placehold.co/15x15/634871/634871.png) `#634871`|
|Intense Brown|9138|Master Series Paints Core Colors|141|49|2|![#8D3102](https://placehold.co/15x15/8D3102/8D3102.png) `#8D3102`|
|Irrisen Blue|89525|Master Series Paints Pathfinder|204|232|243|![#CCE8F3](https://placehold.co/15x15/CCE8F3/CCE8F3.png) `#CCE8F3`|
|Jade Green|9015|Master Series Paints Core Colors|5|173|98|![#05AD62](https://placehold.co/15x15/05AD62/05AD62.png) `#05AD62`|
|Jungle Mist|9322|Master Series Paints Core Colors|151|175|143|![#97AF8F](https://placehold.co/15x15/97AF8F/97AF8F.png) `#97AF8F`|
|Jungle Moss|9082|Master Series Paints Core Colors|39|55|45|![#27372D](https://placehold.co/15x15/27372D/27372D.png) `#27372D`|
|Keleshite Gold|89551|Master Series Paints Pathfinder|189|158|68|![#BD9E44](https://placehold.co/15x15/BD9E44/BD9E44.png) `#BD9E44`|
|Kellid Tan|89539|Master Series Paints Pathfinder|208|167|135|![#D0A787](https://placehold.co/15x15/D0A787/D0A787.png) `#D0A787`|
|Khaki Highlight|9123|Master Series Paints Core Colors|219|213|189|![#DBD5BD](https://placehold.co/15x15/DBD5BD/DBD5BD.png) `#DBD5BD`|
|Khaki Shadow|9121|Master Series Paints Core Colors|180|160|123|![#B4A07B](https://placehold.co/15x15/B4A07B/B4A07B.png) `#B4A07B`|
|Kobold Scale|9458|Master Series Paints Bones|129|43|26|![#812B1A](https://placehold.co/15x15/812B1A/812B1A.png) `#812B1A`|
|Kraken Purple|89531|Master Series Paints Pathfinder|184|180|217|![#B8B4D9](https://placehold.co/15x15/B8B4D9/B8B4D9.png) `#B8B4D9`|
|Kyonin Beige|89541|Master Series Paints Pathfinder|243|218|178|![#F3DAB2](https://placehold.co/15x15/F3DAB2/F3DAB2.png) `#F3DAB2`|
|LED Blue|9288|Master Series Paints Core Colors|118|217|160|![#76D9A0](https://placehold.co/15x15/76D9A0/76D9A0.png) `#76D9A0`|
|Lantern Yellow|9407|Master Series Paints Bones|248|165|23|![#F8A517](https://placehold.co/15x15/F8A517/F8A517.png) `#F8A517`|
|Lava Orange|9218|Master Series Paints Core Colors|222|86|34|![#DE5622](https://placehold.co/15x15/DE5622/DE5622.png) `#DE5622`|
|Leaf Green|9011|Master Series Paints Core Colors|22|137|68|![#168944](https://placehold.co/15x15/168944/168944.png) `#168944`|
|Leather Brown|9030|Master Series Paints Core Colors|165|117|77|![#A5754D](https://placehold.co/15x15/A5754D/A5754D.png) `#A5754D`|
|Leather White|9062|Master Series Paints Core Colors|233|225|212|![#E9E1D4](https://placehold.co/15x15/E9E1D4/E9E1D4.png) `#E9E1D4`|
|Lemon Yellow|9009|Master Series Paints Core Colors|248|237|31|![#F8ED1F](https://placehold.co/15x15/F8ED1F/F8ED1F.png) `#F8ED1F`|
|Light Blue|9264|Master Series Paints Core Colors|114|218|229|![#72DAE5](https://placehold.co/15x15/72DAE5/72DAE5.png) `#72DAE5`|
|Linen White|9061|Master Series Paints Core Colors|254|252|239|![#FEFCEF](https://placehold.co/15x15/FEFCEF/FEFCEF.png) `#FEFCEF`|
|Lini Green|89517|Master Series Paints Pathfinder|64|175|73|![#40AF49](https://placehold.co/15x15/40AF49/40AF49.png) `#40AF49`|
|Lone Star Leather|9284|Master Series Paints Core Colors|87|94|0|![#575E00](https://placehold.co/15x15/575E00/575E00.png) `#575E00`|
|Maggot White|9282|Master Series Paints Core Colors|221|255|222|![#DDFFDE](https://placehold.co/15x15/DDFFDE/DDFFDE.png) `#DDFFDE`|
|Magma Red|9217|Master Series Paints Core Colors|219|58|40|![#DB3A28](https://placehold.co/15x15/DB3A28/DB3A28.png) `#DB3A28`|
|Mahogany Brown|9070|Master Series Paints Core Colors|36|18|16|![#241210](https://placehold.co/15x15/241210/241210.png) `#241210`|
|Maiden Flesh|9475|Master Series Paints Bones|241|223|199|![#F1DFC7](https://placehold.co/15x15/F1DFC7/F1DFC7.png) `#F1DFC7`|
|Malvernian Purple|9296|Master Series Paints Core Colors|55|38|106|![#37266A](https://placehold.co/15x15/37266A/37266A.png) `#37266A`|
|Mana Waste Gray|89544|Master Series Paints Pathfinder|194|179|182|![#C2B3B6](https://placehold.co/15x15/C2B3B6/C2B3B6.png) `#C2B3B6`|
|Marid Blue|89526|Master Series Paints Pathfinder|1|168|223|![#01A8DF](https://placehold.co/15x15/01A8DF/01A8DF.png) `#01A8DF`|
|Marigold Yellow|9007|Master Series Paints Core Colors|238|146|43|![#EE922B](https://placehold.co/15x15/EE922B/EE922B.png) `#EE922B`|
|Marine Teal|9077|Master Series Paints Core Colors|2|94|109|![#025E6D](https://placehold.co/15x15/025E6D/025E6D.png) `#025E6D`|
|Meadow Green|9485|Master Series Paints Bones|107|147|59|![#6B933B](https://placehold.co/15x15/6B933B/6B933B.png) `#6B933B`|
|Medusa Green|89521|Master Series Paints Pathfinder|161|152|87|![#A19857](https://placehold.co/15x15/A19857/A19857.png) `#A19857`|
|Merisiel Red|89505|Master Series Paints Pathfinder|195|32|51|![#C32033](https://placehold.co/15x15/C32033/C32033.png) `#C32033`|
|Midnight Blue|9019|Master Series Paints Core Colors|11|20|29|![#0B141D](https://placehold.co/15x15/0B141D/0B141D.png) `#0B141D`|
|Milani Rose|89502|Master Series Paints Pathfinder|248|185|212|![#F8B9D4](https://placehold.co/15x15/F8B9D4/F8B9D4.png) `#F8B9D4`|
|Military Blue|9269|Master Series Paints Core Colors|19|81|76|![#13514C](https://placehold.co/15x15/13514C/13514C.png) `#13514C`|
|Military Green|9176|Master Series Paints Core Colors|68|80|32|![#445020](https://placehold.co/15x15/445020/445020.png) `#445020`|
|Minotaur Hide|9491|Master Series Paints Bones|119|69|60|![#77453C](https://placehold.co/15x15/77453C/77453C.png) `#77453C`|
|Mint Green|9263|Master Series Paints Core Colors|129|254|128|![#81FE80](https://placehold.co/15x15/81FE80/81FE80.png) `#81FE80`|
|Misty Grey|9090|Master Series Paints Core Colors|204|204|204|![#CCCCCC](https://placehold.co/15x15/CCCCCC/CCCCCC.png) `#CCCCCC`|
|Moldy Skin|9149|Master Series Paints Core Colors|183|184|127|![#B7B87F](https://placehold.co/15x15/B7B87F/B7B87F.png) `#B7B87F`|
|Monarch Purple|9239|Master Series Paints Core Colors|77|0|54|![#4D0036](https://placehold.co/15x15/4D0036/4D0036.png) `#4D0036`|
|Monster Maw|9403|Master Series Paints Bones|233|130|134|![#E98286](https://placehold.co/15x15/E98286/E98286.png) `#E98286`|
|Moonstone Blue|9317|Master Series Paints Core Colors|184|213|219|![#B8D5DB](https://placehold.co/15x15/B8D5DB/B8D5DB.png) `#B8D5DB`|
|Morning-After Blues|9683|Master Series Paints Bones|0|115|159|![#00739F](https://placehold.co/15x15/00739F/00739F.png) `#00739F`|
|Moth Green|9248|Master Series Paints Core Colors|107|191|41|![#6BBF29](https://placehold.co/15x15/6BBF29/6BBF29.png) `#6BBF29`|
|Mountain Stone|9433|Master Series Paints Bones|75|67|56|![#4B4338](https://placehold.co/15x15/4B4338/4B4338.png) `#4B4338`|
|Muddy Brown|9028|Master Series Paints Core Colors|67|46|27|![#432E1B](https://placehold.co/15x15/432E1B/432E1B.png) `#432E1B`|
|Muddy Olive|9034|Master Series Paints Core Colors|64|112|54|![#407036](https://placehold.co/15x15/407036/407036.png) `#407036`|
|Muddy Soil|9244|Master Series Paints Core Colors|27|22|3|![#1B1603](https://placehold.co/15x15/1B1603/1B1603.png) `#1B1603`|
|Mwangi Brown|89538|Master Series Paints Pathfinder|102|59|43|![#663B2B](https://placehold.co/15x15/663B2B/663B2B.png) `#663B2B`|
|NMM Gold Base|9302|Master Series Paints Core Colors|213|151|40|![#D59728](https://placehold.co/15x15/D59728/D59728.png) `#D59728`|
|NMM Gold Highlight|9303|Master Series Paints Core Colors|253|220|67|![#FDDC43](https://placehold.co/15x15/FDDC43/FDDC43.png) `#FDDC43`|
|NMM Gold Shadow|9301|Master Series Paints Core Colors|140|102|39|![#8C6627](https://placehold.co/15x15/8C6627/8C6627.png) `#8C6627`|
|Naga Green|9413|Master Series Paints Bones|67|136|55|![#438837](https://placehold.co/15x15/438837/438837.png) `#438837`|
|Neon Yellow|9287|Master Series Paints Core Colors|203|255|23|![#CBFF17](https://placehold.co/15x15/CBFF17/CBFF17.png) `#CBFF17`|
|New Copper|9306|Master Series Paints Core Colors|247|150|107|![#F7966B](https://placehold.co/15x15/F7966B/F7966B.png) `#F7966B`|
|New Gold|9051|Master Series Paints Core Colors|232|197|67|![#E8C543](https://placehold.co/15x15/E8C543/E8C543.png) `#E8C543`|
|Nightmare Black|9280|Master Series Paints Core Colors|8|15|31|![#080F1F](https://placehold.co/15x15/080F1F/080F1F.png) `#080F1F`|
|Nightshade Purple|9022|Master Series Paints Core Colors|38|25|45|![#26192D](https://placehold.co/15x15/26192D/26192D.png) `#26192D`|
|Nightsky Indigo|9422|Master Series Paints Bones|61|56|96|![#3D3860](https://placehold.co/15x15/3D3860/3D3860.png) `#3D3860`|
|Noir Black|9289|Master Series Paints Core Colors|21|21|21|![#151515](https://placehold.co/15x15/151515/151515.png) `#151515`|
|Numeria Rust|89510|Master Series Paints Pathfinder|193|80|38|![#C15026](https://placehold.co/15x15/C15026/C15026.png) `#C15026`|
|Nut Brown|9427|Master Series Paints Bones|73|45|31|![#492D1F](https://placehold.co/15x15/492D1F/492D1F.png) `#492D1F`|
|Oceanic Blue|9418|Master Series Paints Bones|0|84|144|![#005490](https://placehold.co/15x15/005490/005490.png) `#005490`|
|Ogre Skin|9459|Master Series Paints Bones|242|175|42|![#F2AF2A](https://placehold.co/15x15/F2AF2A/F2AF2A.png) `#F2AF2A`|
|Oiled Leather|9110|Master Series Paints Core Colors|150|83|54|![#965336](https://placehold.co/15x15/965336/965336.png) `#965336`|
|Old Bronze|9197|Master Series Paints Core Colors|51|41|16|![#332910](https://placehold.co/15x15/332910/332910.png) `#332910`|
|Old West Rose|9283|Master Series Paints Core Colors|156|31|61|![#9C1F3D](https://placehold.co/15x15/9C1F3D/9C1F3D.png) `#9C1F3D`|
|Olive Drab|9158|Master Series Paints Core Colors|92|86|2|![#5C5602](https://placehold.co/15x15/5C5602/5C5602.png) `#5C5602`|
|Olive Green|9035|Master Series Paints Core Colors|114|150|86|![#729656](https://placehold.co/15x15/729656/729656.png) `#729656`|
|Olive Shadow|9157|Master Series Paints Core Colors|74|57|1|![#4A3901](https://placehold.co/15x15/4A3901/4A3901.png) `#4A3901`|
|Olive Skin|9221|Master Series Paints Core Colors|169|127|29|![#A97F1D](https://placehold.co/15x15/A97F1D/A97F1D.png) `#A97F1D`|
|Olive Skin Highlight|9222|Master Series Paints Core Colors|190|165|81|![#BEA551](https://placehold.co/15x15/BEA551/BEA551.png) `#BEA551`|
|Olive Skin Shadow|9220|Master Series Paints Core Colors|116|82|19|![#745213](https://placehold.co/15x15/745213/745213.png) `#745213`|
|Orange Brown|9201|Master Series Paints Core Colors|200|91|22|![#C85B16](https://placehold.co/15x15/C85B16/C85B16.png) `#C85B16`|
|Orc Skin|9456|Master Series Paints Bones|137|135|112|![#898770](https://placehold.co/15x15/898770/898770.png) `#898770`|
|Osirian Sand|89511|Master Series Paints Pathfinder|244|228|177|![#F4E4B1](https://placehold.co/15x15/F4E4B1/F4E4B1.png) `#F4E4B1`|
|Pale Flesh|9446|Master Series Paints Bones|254|210|185|![#FED2B9](https://placehold.co/15x15/FED2B9/FED2B9.png) `#FED2B9`|
|Pale Green|9012|Master Series Paints Core Colors|53|180|75|![#35B44B](https://placehold.co/15x15/35B44B/35B44B.png) `#35B44B`|
|Pale Lichen|9084|Master Series Paints Core Colors|125|151|140|![#7D978C](https://placehold.co/15x15/7D978C/7D978C.png) `#7D978C`|
|Pale Olive|9036|Master Series Paints Core Colors|165|181|142|![#A5B58E](https://placehold.co/15x15/A5B58E/A5B58E.png) `#A5B58E`|
|Pale Saffron|9484|Master Series Paints Bones|254|221|44|![#FEDD2C](https://placehold.co/15x15/FEDD2C/FEDD2C.png) `#FEDD2C`|
|Pale Violet Red|9027|Master Series Paints Core Colors|146|51|91|![#92335B](https://placehold.co/15x15/92335B/92335B.png) `#92335B`|
|Palomino Gold|9074|Master Series Paints Core Colors|187|150|46|![#BB962E](https://placehold.co/15x15/BB962E/BB962E.png) `#BB962E`|
|Peacock Green|9226|Master Series Paints Core Colors|30|46|43|![#1E2E2B](https://placehold.co/15x15/1E2E2B/1E2E2B.png) `#1E2E2B`|
|Pearl White|9100|Master Series Paints Core Colors|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Peppermint White|9688|Master Series Paints Core Colors|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Phantom Glow|9319|Master Series Paints Core Colors|1|173|135|![#01AD87](https://placehold.co/15x15/01AD87/01AD87.png) `#01AD87`|
|Pharasma Purple|89535|Master Series Paints Pathfinder|144|65|154|![#90419A](https://placehold.co/15x15/90419A/90419A.png) `#90419A`|
|Phoenix Red|9005|Master Series Paints Core Colors|210|56|48|![#D23830](https://placehold.co/15x15/D23830/D23830.png) `#D23830`|
|Pine Green|9010|Master Series Paints Core Colors|0|89|41|![#005929](https://placehold.co/15x15/005929/005929.png) `#005929`|
|Polished Bone|9060|Master Series Paints Core Colors|236|225|205|![#ECE1CD](https://placehold.co/15x15/ECE1CD/ECE1CD.png) `#ECE1CD`|
|Polished Leather|9430|Master Series Paints Bones|155|99|38|![#9B6326](https://placehold.co/15x15/9B6326/9B6326.png) `#9B6326`|
|Polished Silver|9054|Master Series Paints Core Colors|228|228|228|![#E4E4E4](https://placehold.co/15x15/E4E4E4/E4E4E4.png) `#E4E4E4`|
|Prom Night Pink|9681|Master Series Paints Core Colors|195|22|78|![#C3164E](https://placehold.co/15x15/C3164E/C3164E.png) `#C3164E`|
|Punk Rock Pink|9286|Master Series Paints Core Colors|200|14|115|![#C80E73](https://placehold.co/15x15/C80E73/C80E73.png) `#C80E73`|
|Pure Black|9037|Master Series Paints Core Colors|0|0|0|![#000000](https://placehold.co/15x15/000000/000000.png) `#000000`|
|Pure White|9039|Master Series Paints Core Colors|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Rach Red|9295|Master Series Paints Core Colors|189|0|4|![#BD0004](https://placehold.co/15x15/BD0004/BD0004.png) `#BD0004`|
|Rainy Grey|9038|Master Series Paints Core Colors|149|149|149|![#959595](https://placehold.co/15x15/959595/959595.png) `#959595`|
|Red Brick|9001|Master Series Paints Core Colors|80|19|37|![#501325](https://placehold.co/15x15/501325/501325.png) `#501325`|
|Red Ink|9210|Master Series Paints Core Colors|120|0|1|![#780001](https://placehold.co/15x15/780001/780001.png) `#780001`|
|Red Liner|9307|Master Series Paints Core Colors|66|18|16|![#421210](https://placehold.co/15x15/421210/421210.png) `#421210`|
|Red Neon Glow|9321|Master Series Paints Core Colors|242|103|74|![#F2674A](https://placehold.co/15x15/F2674A/F2674A.png) `#F2674A`|
|Red Shadow|9235|Master Series Paints Core Colors|86|0|29|![#56001D](https://placehold.co/15x15/56001D/56001D.png) `#56001D`|
|Redstone|9224|Master Series Paints Core Colors|126|57|42|![#7E392A](https://placehold.co/15x15/7E392A/7E392A.png) `#7E392A`|
|Redstone Highlight|9225|Master Series Paints Core Colors|168|88|55|![#A85837](https://placehold.co/15x15/A85837/A85837.png) `#A85837`|
|Redstone Shadow|9223|Master Series Paints Core Colors|58|31|36|![#3A1F24](https://placehold.co/15x15/3A1F24/3A1F24.png) `#3A1F24`|
|Regal Purple|9238|Master Series Paints Core Colors|46|0|29|![#2E001D](https://placehold.co/15x15/2E001D/2E001D.png) `#2E001D`|
|Reliquary Gold|9496|Master Series Paints Bones|168|158|87|![#A89E57](https://placehold.co/15x15/A89E57/A89E57.png) `#A89E57`|
|Rich Leather|9429|Master Series Paints Bones|122|89|46|![#7A592E](https://placehold.co/15x15/7A592E/7A592E.png) `#7A592E`|
|Ritterlich Blue|9115|Master Series Paints Core Colors|0|55|96|![#003760](https://placehold.co/15x15/003760/003760.png) `#003760`|
|Rose Gold|9608|Master Series Paints Core Colors|175|134|132|![#AF8684](https://placehold.co/15x15/AF8684/AF8684.png) `#AF8684`|
|Rosy Highlight|9069|Master Series Paints Core Colors|232|187|164|![#E8BBA4](https://placehold.co/15x15/E8BBA4/E8BBA4.png) `#E8BBA4`|
|Rosy Shadow|9067|Master Series Paints Core Colors|207|150|133|![#CF9685](https://placehold.co/15x15/CF9685/CF9685.png) `#CF9685`|
|Rosy Skin|9068|Master Series Paints Core Colors|236|174|159|![#ECAE9F](https://placehold.co/15x15/ECAE9F/ECAE9F.png) `#ECAE9F`|
|Rotting Wood|9313|Master Series Paints Core Colors|85|73|33|![#554921](https://placehold.co/15x15/554921/554921.png) `#554921`|
|Royal Purple|9240|Master Series Paints Core Colors|132|0|83|![#840053](https://placehold.co/15x15/840053/840053.png) `#840053`|
|Ruby Red|9101|Master Series Paints Core Colors|237|176|145|![#EDB091](https://placehold.co/15x15/EDB091/EDB091.png) `#EDB091`|
|Ruddy Flesh|9441|Master Series Paints Bones|123|79|42|![#7B4F2A](https://placehold.co/15x15/7B4F2A/7B4F2A.png) `#7B4F2A`|
|Ruddy Leather|9109|Master Series Paints Core Colors|106|52|42|![#6A342A](https://placehold.co/15x15/6A342A/6A342A.png) `#6A342A`|
|Runic Glow|9320|Master Series Paints Core Colors|231|89|161|![#E759A1](https://placehold.co/15x15/E759A1/E759A1.png) `#E759A1`|
|Runic Purple|9424|Master Series Paints Bones|111|51|102|![#6F3366](https://placehold.co/15x15/6F3366/6F3366.png) `#6F3366`|
|Russet Brown|9199|Master Series Paints Core Colors|83|16|0|![#531000](https://placehold.co/15x15/531000/531000.png) `#531000`|
|Rust Brown|9072|Master Series Paints Core Colors|178|74|65|![#B24A41](https://placehold.co/15x15/B24A41/B24A41.png) `#B24A41`|
|Saddle Brown|9428|Master Series Paints Bones|88|57|36|![#583924](https://placehold.co/15x15/583924/583924.png) `#583924`|
|Saffron Sunset|9247|Master Series Paints Core Colors|238|165|1|![#EEA501](https://placehold.co/15x15/EEA501/EEA501.png) `#EEA501`|
|Sandy Brown|9249|Master Series Paints Core Colors|184|133|50|![#B88532](https://placehold.co/15x15/B88532/B88532.png) `#B88532`|
|Sapphire Blue|9016|Master Series Paints Core Colors|41|69|143|![#29458F](https://placehold.co/15x15/29458F/29458F.png) `#29458F`|
|Sarenrae Yellow|89514|Master Series Paints Pathfinder|254|189|63|![#FEBD3F](https://placehold.co/15x15/FEBD3F/FEBD3F.png) `#FEBD3F`|
|Scholar Flesh|9444|Master Series Paints Bones|228|184|149|![#E4B895](https://placehold.co/15x15/E4B895/E4B895.png) `#E4B895`|
|Scorched Metal|9125|Master Series Paints Core Colors|151|95|70|![#975F46](https://placehold.co/15x15/975F46/975F46.png) `#975F46`|
|Seoni Scarlet|89504|Master Series Paints Pathfinder|239|55|67|![#EF3743](https://placehold.co/15x15/EF3743/EF3743.png) `#EF3743`|
|Sepia Liner|9309|Master Series Paints Core Colors|79|50|18|![#4F3212](https://placehold.co/15x15/4F3212/4F3212.png) `#4F3212`|
|Sepia Wash|9310|Master Series Paints Core Colors Wash|47|31|18|![#2F1F12](https://placehold.co/15x15/2F1F12/2F1F12.png) `#2F1F12`|
|Seugathi Purple|89536|Master Series Paints Pathfinder|135|50|118|![#873276](https://placehold.co/15x15/873276/873276.png) `#873276`|
|Shadow Green|9270|Master Series Paints Core Colors|41|97|10|![#29610A](https://placehold.co/15x15/29610A/29610A.png) `#29610A`|
|Shadowed Steel|9052|Master Series Paints Core Colors|122|122|122|![#7A7A7A](https://placehold.co/15x15/7A7A7A/7A7A7A.png) `#7A7A7A`|
|Shadowed Stone|9085|Master Series Paints Core Colors|100|97|92|![#64615C](https://placehold.co/15x15/64615C/64615C.png) `#64615C`|
|Shelyn Blush|89501|Master Series Paints Pathfinder|247|176|170|![#F7B0AA](https://placehold.co/15x15/F7B0AA/F7B0AA.png) `#F7B0AA`|
|Shield Brown|9161|Master Series Paints Core Colors|125|83|41|![#7D5329](https://placehold.co/15x15/7D5329/7D5329.png) `#7D5329`|
|Shining Mithril|9454|Master Series Paints Bones|200|196|195|![#C8C4C3](https://placehold.co/15x15/C8C4C3/C8C4C3.png) `#C8C4C3`|
|Shoanti Sienna|89542|Master Series Paints Pathfinder|186|105|84|![#BA6954](https://placehold.co/15x15/BA6954/BA6954.png) `#BA6954`|
|Sinspawn Pink|89503|Master Series Paints Pathfinder|229|187|191|![#E5BBBF](https://placehold.co/15x15/E5BBBF/E5BBBF.png) `#E5BBBF`|
|Siren's Song|9489|Master Series Paints Bones|65|181|172|![#41B5AC](https://placehold.co/15x15/41B5AC/41B5AC.png) `#41B5AC`|
|Skeleton Bone|9435|Master Series Paints Bones|216|209|191|![#D8D1BF](https://placehold.co/15x15/D8D1BF/D8D1BF.png) `#D8D1BF`|
|Skeleton Key|9465|Master Series Paints Bones|83|90|83|![#535A53](https://placehold.co/15x15/535A53/535A53.png) `#535A53`|
|Skeleton White|89548|Master Series Paints Pathfinder|242|242|232|![#F2F2E8](https://placehold.co/15x15/F2F2E8/F2F2E8.png) `#F2F2E8`|
|Sky Blue|9018|Master Series Paints Core Colors|75|163|213|![#4BA3D5](https://placehold.co/15x15/4BA3D5/4BA3D5.png) `#4BA3D5`|
|Snow Shadow|9021|Master Series Paints Core Colors|127|147|172|![#7F93AC](https://placehold.co/15x15/7F93AC/7F93AC.png) `#7F93AC`|
|Soft Blue|9230|Master Series Paints Core Colors|18|69|96|![#124560](https://placehold.co/15x15/124560/124560.png) `#124560`|
|Solid Black|9479|Master Series Paints Bones|0|0|0|![#000000](https://placehold.co/15x15/000000/000000.png) `#000000`|
|Solid White|9478|Master Series Paints Bones|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Sophie Champagne|9609|Master Series Paints Core Colors|235|213|163|![#EBD5A3](https://placehold.co/15x15/EBD5A3/EBD5A3.png) `#EBD5A3`|
|Sorcerous Mist|9324|Master Series Paints Core Colors|185|141|164|![#B98DA4](https://placehold.co/15x15/B98DA4/B98DA4.png) `#B98DA4`|
|Sparkling Amethyst|9105|Master Series Paints Core Colors|178|175|202|![#B2AFCA](https://placehold.co/15x15/B2AFCA/B2AFCA.png) `#B2AFCA`|
|Sparkling Blue|9104|Master Series Paints Core Colors|168|185|201|![#A8B9C9](https://placehold.co/15x15/A8B9C9/A8B9C9.png) `#A8B9C9`|
|Sparkling Snow|9689|Master Series Paints Core Colors|195|208|214|![#C3D0D6](https://placehold.co/15x15/C3D0D6/C3D0D6.png) `#C3D0D6`|
|Spattered Crimson|9277|Master Series Paints Core Colors|94|0|16|![#5E0010](https://placehold.co/15x15/5E0010/5E0010.png) `#5E0010`|
|Spectral Glow|9416|Master Series Paints Bones|88|185|174|![#58B9AE](https://placehold.co/15x15/58B9AE/58B9AE.png) `#58B9AE`|
|Splintered Bone|9273|Master Series Paints Core Colors|218|217|169|![#DAD9A9](https://placehold.co/15x15/DAD9A9/DAD9A9.png) `#DAD9A9`|
|Stained Ivory|9142|Master Series Paints Core Colors|199|163|105|![#C7A369](https://placehold.co/15x15/C7A369/C7A369.png) `#C7A369`|
|Stark Naked|9682|Master Series Paints Bones|253|199|139|![#FDC78B](https://placehold.co/15x15/FDC78B/FDC78B.png) `#FDC78B`|
|Steel Wash|9312|Master Series Paints Core Colors Wash|33|34|36|![#212224](https://placehold.co/15x15/212224/212224.png) `#212224`|
|Stone Grey|9086|Master Series Paints Core Colors|124|119|113|![#7C7771](https://placehold.co/15x15/7C7771/7C7771.png) `#7C7771`|
|Stone Wash|9311|Master Series Paints Core Colors Wash|40|36|33|![#282421](https://placehold.co/15x15/282421/282421.png) `#282421`|
|Stormy Grey|9088|Master Series Paints Core Colors|70|70|70|![#464646](https://placehold.co/15x15/464646/464646.png) `#464646`|
|Styx Purple|9423|Master Series Paints Bones|32|4|52|![#200434](https://placehold.co/15x15/200434/200434.png) `#200434`|
|Succubus Kiss|9462|Master Series Paints Bones|122|0|37|![#7A0025](https://placehold.co/15x15/7A0025/7A0025.png) `#7A0025`|
|Sun Yellow|9008|Master Series Paints Core Colors|247|192|39|![#F7C027](https://placehold.co/15x15/F7C027/F7C027.png) `#F7C027`|
|Sunrise Orange|9406|Master Series Paints Bones|243|112|34|![#F37022](https://placehold.co/15x15/F37022/F37022.png) `#F37022`|
|Sunset Purple|9267|Master Series Paints Core Colors|89|97|178|![#5961B2](https://placehold.co/15x15/5961B2/5961B2.png) `#5961B2`|
|Suntan Flesh|9482|Master Series Paints Bones|178|109|42|![#B26D2A](https://placehold.co/15x15/B26D2A/B26D2A.png) `#B26D2A`|
|Surf Aqua|9078|Master Series Paints Core Colors|100|179|186|![#64B3BA](https://placehold.co/15x15/64B3BA/64B3BA.png) `#64B3BA`|
|Swamp Green|9175|Master Series Paints Core Colors|42|36|0|![#2A2400](https://placehold.co/15x15/2A2400/2A2400.png) `#2A2400`|
|Taldan Pink|89540|Master Series Paints Pathfinder|226|183|166|![#E2B7A6](https://placehold.co/15x15/E2B7A6/E2B7A6.png) `#E2B7A6`|
|Tanned Highlight|9045|Master Series Paints Core Colors|210|166|129|![#D2A681](https://placehold.co/15x15/D2A681/D2A681.png) `#D2A681`|
|Tanned Leather|9031|Master Series Paints Core Colors|183|131|73|![#B78349](https://placehold.co/15x15/B78349/B78349.png) `#B78349`|
|Tanned Shadow|9043|Master Series Paints Core Colors|163|117|94|![#A3755E](https://placehold.co/15x15/A3755E/A3755E.png) `#A3755E`|
|Tanned Skin|9044|Master Series Paints Core Colors|188|141|111|![#BC8D6F](https://placehold.co/15x15/BC8D6F/BC8D6F.png) `#BC8D6F`|
|Tarnished Brass|9198|Master Series Paints Core Colors|81|59|1|![#513B01](https://placehold.co/15x15/513B01/513B01.png) `#513B01`|
|Tarnished Copper|9305|Master Series Paints Core Colors|150|56|31|![#96381F](https://placehold.co/15x15/96381F/96381F.png) `#96381F`|
|Tarnished Steel|9206|Master Series Paints Core Colors|139|138|136|![#8B8A88](https://placehold.co/15x15/8B8A88/8B8A88.png) `#8B8A88`|
|Tawny Flesh|9444b|Master Series Paints Bones|228|184|149|![#E4B895](https://placehold.co/15x15/E4B895/E4B895.png) `#E4B895`|
|Tempest Grey|9438|Master Series Paints Bones|71|72|77|![#47484D](https://placehold.co/15x15/47484D/47484D.png) `#47484D`|
|Templar Blue|9056|Master Series Paints Core Colors|49|70|89|![#314659](https://placehold.co/15x15/314659/314659.png) `#314659`|
|Tendril Pink|9486|Master Series Paints Bones|244|152|193|![#F498C1](https://placehold.co/15x15/F498C1/F498C1.png) `#F498C1`|
|Terran Khaki|9122|Master Series Paints Core Colors|199|186|154|![#C7BA9A](https://placehold.co/15x15/C7BA9A/C7BA9A.png) `#C7BA9A`|
|Thuvian Sun Orchid|89537|Master Series Paints Pathfinder|226|30|142|![#E21E8E](https://placehold.co/15x15/E21E8E/E21E8E.png) `#E21E8E`|
|Tian Xia Jade|89518|Master Series Paints Pathfinder|0|149|94|![#00955E](https://placehold.co/15x15/00955E/00955E.png) `#00955E`|
|Troll Hide|9455|Master Series Paints Bones|85|82|5|![#555205](https://placehold.co/15x15/555205/555205.png) `#555205`|
|Tropical Blue|9419|Master Series Paints Bones|2|117|162|![#0275A2](https://placehold.co/15x15/0275A2/0275A2.png) `#0275A2`|
|True Blue|9017|Master Series Paints Core Colors|0|124|186|![#007CBA](https://placehold.co/15x15/007CBA/007CBA.png) `#007CBA`|
|True Silver|9207|Master Series Paints Core Colors|178|177|175|![#B2B1AF](https://placehold.co/15x15/B2B1AF/B2B1AF.png) `#B2B1AF`|
|Turf Green|9481|Master Series Paints Bones|40|129|63|![#28813F](https://placehold.co/15x15/28813F/28813F.png) `#28813F`|
|Turkey Brown|9691|Master Series Paints Core Colors|118|76|36|![#764C24](https://placehold.co/15x15/764C24/764C24.png) `#764C24`|
|Twilight Blue|9020|Master Series Paints Core Colors|56|73|99|![#384963](https://placehold.co/15x15/384963/384963.png) `#384963`|
|Twilight Purple|9483|Master Series Paints Bones|33|49|101|![#213165](https://placehold.co/15x15/213165/213165.png) `#213165`|
|Ultramarine Blue|9188|Master Series Paints Core Colors|1|77|126|![#014D7E](https://placehold.co/15x15/014D7E/014D7E.png) `#014D7E`|
|Ultramarine Highlight|9189|Master Series Paints Core Colors|1|117|190|![#0175BE](https://placehold.co/15x15/0175BE/0175BE.png) `#0175BE`|
|Ultramarine Shadow|9187|Master Series Paints Core Colors|0|34|61|![#00223D](https://placehold.co/15x15/00223D/00223D.png) `#00223D`|
|Undead Flesh|9447|Master Series Paints Bones|223|221|209|![#DFDDD1](https://placehold.co/15x15/DFDDD1/DFDDD1.png) `#DFDDD1`|
|Unicorn White|89547|Master Series Paints Pathfinder|242|242|232|![#F2F2E8](https://placehold.co/15x15/F2F2E8/F2F2E8.png) `#F2F2E8`|
|Uniform Brown|9127|Master Series Paints Core Colors|106|79|0|![#6A4F00](https://placehold.co/15x15/6A4F00/6A4F00.png) `#6A4F00`|
|Urgathoa Red|89508|Master Series Paints Pathfinder|111|42|61|![#6F2A3D](https://placehold.co/15x15/6F2A3D/6F2A3D.png) `#6F2A3D`|
|Valeros Gold|89552|Master Series Paints Pathfinder|164|131|78|![#A4834E](https://placehold.co/15x15/A4834E/A4834E.png) `#A4834E`|
|Vampiric Highlight|9276|Master Series Paints Core Colors|233|226|200|![#E9E2C8](https://placehold.co/15x15/E9E2C8/E9E2C8.png) `#E9E2C8`|
|Vampiric Mist|9461|Master Series Paints Bones|234|234|236|![#EAEAEC](https://placehold.co/15x15/EAEAEC/EAEAEC.png) `#EAEAEC`|
|Vampiric Shadow|9274|Master Series Paints Core Colors|161|160|139|![#A1A08B](https://placehold.co/15x15/A1A08B/A1A08B.png) `#A1A08B`|
|Vampiric Skin|9275|Master Series Paints Core Colors|208|196|172|![#D0C4AC](https://placehold.co/15x15/D0C4AC/D0C4AC.png) `#D0C4AC`|
|Violet Light|9266|Master Series Paints Core Colors|22|40|116|![#162874](https://placehold.co/15x15/162874/162874.png) `#162874`|
|Violet Red|9026|Master Series Paints Core Colors|97|30|71|![#611E47](https://placehold.co/15x15/611E47/611E47.png) `#611E47`|
|Violet Shadow|9237|Master Series Paints Core Colors|68|0|57|![#440039](https://placehold.co/15x15/440039/440039.png) `#440039`|
|Viper Green|9228|Master Series Paints Core Colors|0|143|55|![#008F37](https://placehold.co/15x15/008F37/008F37.png) `#008F37`|
|Void Blue|9417|Master Series Paints Bones|2|27|84|![#021B54](https://placehold.co/15x15/021B54/021B54.png) `#021B54`|
|Volcanic Orange|9405|Master Series Paints Bones|226|73|32|![#E24920](https://placehold.co/15x15/E24920/E24920.png) `#E24920`|
|Volcano Brown|9268|Master Series Paints Core Colors|72|36|40|![#482428](https://placehold.co/15x15/482428/482428.png) `#482428`|
|Walnut Brown|9136|Master Series Paints Core Colors|70|0|0|![#460000](https://placehold.co/15x15/460000/460000.png) `#460000`|
|Warrior Flesh|9443|Master Series Paints Bones|171|117|79|![#AB754F](https://placehold.co/15x15/AB754F/AB754F.png) `#AB754F`|
|Wash Medium|9300|Master Series Paints Core Colors|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Weathered Stone|9087|Master Series Paints Core Colors|148|143|140|![#948F8C](https://placehold.co/15x15/948F8C/948F8C.png) `#948F8C`|
|Wilderness Green|9411|Master Series Paints Bones|23|55|8|![#173708](https://placehold.co/15x15/173708/173708.png) `#173708`|
|Witchcraft Purple|9477|Master Series Paints Bones|139|77|124|![#8B4D7C](https://placehold.co/15x15/8B4D7C/8B4D7C.png) `#8B4D7C`|
|Wolf Grey|9434|Master Series Paints Bones|124|116|105|![#7C7469](https://placehold.co/15x15/7C7469/7C7469.png) `#7C7469`|
|Woodland Brown|9476|Master Series Paints Bones|161|112|54|![#A17036](https://placehold.co/15x15/A17036/A17036.png) `#A17036`|
|Woodstain Brown|9160|Master Series Paints Core Colors|87|63|39|![#573F27](https://placehold.co/15x15/573F27/573F27.png) `#573F27`|
|Worn Navy|9229|Master Series Paints Core Colors|18|19|21|![#121315](https://placehold.co/15x15/121315/121315.png) `#121315`|
|Worn Olive|9159|Master Series Paints Core Colors|131|116|23|![#837417](https://placehold.co/15x15/837417/837417.png) `#837417`|
|Wyvern Leather|9492|Master Series Paints Bones|110|53|46|![#6E352E](https://placehold.co/15x15/6E352E/6E352E.png) `#6E352E`|
|Yellow Mold|9487|Master Series Paints Bones|252|248|200|![#FCF8C8](https://placehold.co/15x15/FCF8C8/FCF8C8.png) `#FCF8C8`|
|Yellowed Ivory|9143|Master Series Paints Core Colors|211|189|132|![#D3BD84](https://placehold.co/15x15/D3BD84/D3BD84.png) `#D3BD84`|
|Youthful Flesh|9445|Master Series Paints Bones|252|189|136|![#FCBD88](https://placehold.co/15x15/FCBD88/FCBD88.png) `#FCBD88`|
<p align="center"><img src="../logos/logo_rnd.png" height="70" /></p>
<p align="center">Made available by <a href="https://miniaturepainterpro.app/">Miniature Painter Pro</a></p>
<p align="center">
<a href="https://play.google.com/store/apps/details?id=com.rfsp.paintmaster"> <img src="../logos/Android.png" height="30" /></a>
<a href="https://apps.apple.com/us/app/miniature-painter-pro/id1495938928"> <img src="../logos/iOS.png" height="30" /></a>
</p>
