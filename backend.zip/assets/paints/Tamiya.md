# Tamiya
![Tamiya](../logos/Tamiya.png "Tamiya")

|Name|Code|Set|R|G|B|Hex|
|---|---|---|---|---|---|---|
|Acrylic thinner|X-20A|Acrylics Mini Gloss|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Bare-metal silver|AS-12|Aircraft Spray|194|200|202|![#C2C8CA](https://placehold.co/15x15/C2C8CA/C2C8CA.png) `#C2C8CA`|
|Base white|TS-101|Tamiya Spray|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Black|LP-1|Lacquer Paint|4|0|0|![#040000](https://placehold.co/15x15/040000/040000.png) `#040000`|
|Black|X-1|Acrylics Mini Gloss|0|0|0|![#000000](https://placehold.co/15x15/000000/000000.png) `#000000`|
|Black|TS-14|Tamiya Spray|51|51|51|![#333333](https://placehold.co/15x15/333333/333333.png) `#333333`|
|Black green|XF-27|Acrylics Mini Flat|0|38|15|![#00260F](https://placehold.co/15x15/00260F/00260F.png) `#00260F`|
|Blue|TS-15|Tamiya Spray|9|52|123|![#09347B](https://placehold.co/15x15/09347B/09347B.png) `#09347B`|
|Blue|X-4|Acrylics Mini Gloss|9|52|123|![#09347B](https://placehold.co/15x15/09347B/09347B.png) `#09347B`|
|Blue violet|TS-57|Tamiya Spray|81|114|179|![#5172B3](https://placehold.co/15x15/5172B3/5172B3.png) `#5172B3`|
|Bright mica red|TS-85|Tamiya Spray|229|0|18|![#E50012](https://placehold.co/15x15/E50012/E50012.png) `#E50012`|
|Bright orange|TS-31|Tamiya Spray|254|27|14|![#FE1B0E](https://placehold.co/15x15/FE1B0E/FE1B0E.png) `#FE1B0E`|
|Bright red|TS-49|Tamiya Spray|255|0|0|![#FF0000](https://placehold.co/15x15/FF0000/FF0000.png) `#FF0000`|
|Bright red|LP-50|Lacquer Paint|229|0|20|![#E50014](https://placehold.co/15x15/E50014/E50014.png) `#E50014`|
|Brilliant blue|TS-44|Tamiya Spray|8|96|168|![#0860A8](https://placehold.co/15x15/0860A8/0860A8.png) `#0860A8`|
|Brilliant orange|TS-56|Tamiya Spray|255|127|0|![#FF7F00](https://placehold.co/15x15/FF7F00/FF7F00.png) `#FF7F00`|
|British green|TS-9|Tamiya Spray|0|43|17|![#002B11](https://placehold.co/15x15/002B11/002B11.png) `#002B11`|
|Bronze|X-33|Acrylics Mini Gloss|103|38|34|![#672622](https://placehold.co/15x15/672622/672622.png) `#672622`|
|Brown|X-9|Acrylics Mini Gloss|77|34|7|![#4D2207](https://placehold.co/15x15/4D2207/4D2207.png) `#4D2207`|
|Brown (JGSDF)|LP-25|Lacquer Paint|113|90|61|![#715A3D](https://placehold.co/15x15/715A3D/715A3D.png) `#715A3D`|
|Brown (JGSDF)|XF-72|Acrylics Mini Flat|115|76|12|![#734C0C](https://placehold.co/15x15/734C0C/734C0C.png) `#734C0C`|
|Brown (JGSDF)|TS-90|Tamiya Spray|130|102|54|![#826636](https://placehold.co/15x15/826636/826636.png) `#826636`|
|Buff|LP-75|Lacquer Paint|204|167|123|![#CCA77B](https://placehold.co/15x15/CCA77B/CCA77B.png) `#CCA77B`|
|Buff|XF-57|Acrylics Mini Flat|184|179|106|![#B8B36A](https://placehold.co/15x15/B8B36A/B8B36A.png) `#B8B36A`|
|Camel yellow|TS-34|Tamiya Spray|255|179|0|![#FFB300](https://placehold.co/15x15/FFB300/FFB300.png) `#FFB300`|
|Candy lime green|TS-52|Tamiya Spray|77|172|38|![#4DAC26](https://placehold.co/15x15/4DAC26/4DAC26.png) `#4DAC26`|
|Champagne gold|LP-71|Lacquer Paint|210|199|154|![#D2C79A](https://placehold.co/15x15/D2C79A/D2C79A.png) `#D2C79A`|
|Champagne gold|TS-75|Tamiya Spray|195|184|126|![#C3B87E](https://placehold.co/15x15/C3B87E/C3B87E.png) `#C3B87E`|
|Chrome silver|X-11|Acrylics Mini Gloss|194|200|202|![#C2C8CA](https://placehold.co/15x15/C2C8CA/C2C8CA.png) `#C2C8CA`|
|Chrome yellow|TS-47|Tamiya Spray|255|204|0|![#FFCC00](https://placehold.co/15x15/FFCC00/FFCC00.png) `#FFCC00`|
|Clear|TS-13|Tamiya Spray|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Clear|LP-9|Lacquer Paint|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Clear|X-22|Acrylics Mini Gloss|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Clear blue|X-23|Acrylics Mini Gloss|52|179|209|![#34B3D1](https://placehold.co/15x15/34B3D1/34B3D1.png) `#34B3D1`|
|Clear blue|LP-68|Lacquer Paint|0|166|234|![#00A6EA](https://placehold.co/15x15/00A6EA/00A6EA.png) `#00A6EA`|
|Clear blue|TS-72|Tamiya Spray|52|176|185|![#34B0B9](https://placehold.co/15x15/34B0B9/34B0B9.png) `#34B0B9`|
|Clear green|X-25|Acrylics Mini Gloss|26|150|65|![#1A9641](https://placehold.co/15x15/1A9641/1A9641.png) `#1A9641`|
|Clear orange|X-26|Acrylics Mini Gloss|254|140|20|![#FE8C14](https://placehold.co/15x15/FE8C14/FE8C14.png) `#FE8C14`|
|Clear orange|TS-73|Tamiya Spray|255|115|0|![#FF7300](https://placehold.co/15x15/FF7300/FF7300.png) `#FF7300`|
|Clear orange|LP-53|Lacquer Paint|240|137|0|![#F08900](https://placehold.co/15x15/F08900/F08900.png) `#F08900`|
|Clear red|LP-52|Lacquer Paint|229|0|127|![#E5007F](https://placehold.co/15x15/E5007F/E5007F.png) `#E5007F`|
|Clear red|X-27|Acrylics Mini Gloss|250|0|38|![#FA0026](https://placehold.co/15x15/FA0026/FA0026.png) `#FA0026`|
|Clear red|TS-74|Tamiya Spray|240|2|127|![#F0027F](https://placehold.co/15x15/F0027F/F0027F.png) `#F0027F`|
|Clear yellow|LP-69|Lacquer Paint|255|229|0|![#FFE500](https://placehold.co/15x15/FFE500/FFE500.png) `#FFE500`|
|Clear yellow|X-24|Acrylics Mini Gloss|255|230|0|![#FFE600](https://placehold.co/15x15/FFE600/FFE600.png) `#FFE600`|
|Cockpit green (IJN)|XF-71|Acrylics Mini Flat|116|146|93|![#74925D](https://placehold.co/15x15/74925D/74925D.png) `#74925D`|
|Copper|XF-6|Acrylics Mini Flat|204|92|3|![#CC5C03](https://placehold.co/15x15/CC5C03/CC5C03.png) `#CC5C03`|
|Coral blue|TS-41|Tamiya Spray|78|184|163|![#4EB8A3](https://placehold.co/15x15/4EB8A3/4EB8A3.png) `#4EB8A3`|
|Dark blue|TS-55|Tamiya Spray|2|20|46|![#02142E](https://placehold.co/15x15/02142E/02142E.png) `#02142E`|
|Dark copper|XF-28|Acrylics Mini Flat|153|95|59|![#995F3B](https://placehold.co/15x15/995F3B/995F3B.png) `#995F3B`|
|Dark earth|AS-22|Aircraft Spray|103|75|43|![#674B2B](https://placehold.co/15x15/674B2B/674B2B.png) `#674B2B`|
|Dark ghost gray|LP-36|Lacquer Paint|128|161|176|![#80A1B0](https://placehold.co/15x15/80A1B0/80A1B0.png) `#80A1B0`|
|Dark ghost grey|AS-25|Aircraft Spray|108|137|142|![#6C898E](https://placehold.co/15x15/6C898E/6C898E.png) `#6C898E`|
|Dark green|TS-2|Tamiya Spray|26|45|15|![#1A2D0F](https://placehold.co/15x15/1A2D0F/1A2D0F.png) `#1A2D0F`|
|Dark green|XF-61|Acrylics Mini Flat|26|45|15|![#1A2D0F](https://placehold.co/15x15/1A2D0F/1A2D0F.png) `#1A2D0F`|
|Dark green|AS-1|Aircraft Spray|17|57|21|![#113915](https://placehold.co/15x15/113915/113915.png) `#113915`|
|Dark green|AS-9|Aircraft Spray|46|72|20|![#2E4814](https://placehold.co/15x15/2E4814/2E4814.png) `#2E4814`|
|Dark green (IJA)|AS-17|Aircraft Spray|24|67|22|![#184316](https://placehold.co/15x15/184316/184316.png) `#184316`|
|Dark green (JGSDF)|TS-91|Tamiya Spray|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Dark green (JGSDF)|XF-73|Acrylics Mini Flat|26|67|22|![#1A4316](https://placehold.co/15x15/1A4316/1A4316.png) `#1A4316`|
|Dark green (JGSDF).jpeg|LP-26|Lacquer Paint|61|89|63|![#3D593F](https://placehold.co/15x15/3D593F/3D593F.png) `#3D593F`|
|Dark green (Luftwaffe)|AS-24|Aircraft Spray|24|40|13|![#18280D](https://placehold.co/15x15/18280D/18280D.png) `#18280D`|
|Dark green 2|LP-56|Lacquer Paint|91|131|97|![#5B8361](https://placehold.co/15x15/5B8361/5B8361.png) `#5B8361`|
|Dark green 2|XF-70|Acrylics Mini Flat|0|37|15|![#00250F](https://placehold.co/15x15/00250F/00250F.png) `#00250F`|
|Dark green 2|XF-89|Acrylics Mini Flat|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Dark green 2|AS-30|Aircraft Spray|53|85|51|![#355533](https://placehold.co/15x15/355533/355533.png) `#355533`|
|Dark green 2 (IJN)|AS-21|Aircraft Spray|0|44|18|![#002C12](https://placehold.co/15x15/002C12/002C12.png) `#002C12`|
|Dark green 2 (IJN)|LP-31|Lacquer Paint|0|66|52|![#004234](https://placehold.co/15x15/004234/004234.png) `#004234`|
|Dark green 2 (RAF)|XF-81|Acrylics Mini Flat|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Dark grey|XF-24|Acrylics Mini Flat|62|68|72|![#3E4448](https://placehold.co/15x15/3E4448/3E4448.png) `#3E4448`|
|Dark iron|XF-84|Acrylics Mini Flat|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Dark iron|LP-54|Lacquer Paint|83|67|52|![#534334](https://placehold.co/15x15/534334/534334.png) `#534334`|
|Dark mica blue|TS-64|Tamiya Spray|10|20|35|![#0A1423](https://placehold.co/15x15/0A1423/0A1423.png) `#0A1423`|
|Dark sea grey|XF-54|Acrylics Mini Flat|92|93|97|![#5C5D61](https://placehold.co/15x15/5C5D61/5C5D61.png) `#5C5D61`|
|Dark yellow|XF-60|Acrylics Mini Flat|199|177|64|![#C7B140](https://placehold.co/15x15/C7B140/C7B140.png) `#C7B140`|
|Dark yellow|TS-3|Tamiya Spray|203|175|91|![#CBAF5B](https://placehold.co/15x15/CBAF5B/CBAF5B.png) `#CBAF5B`|
|Dark yellow 2|XF-88|Acrylics Mini Flat|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Dark yellow 2|LP-55|Lacquer Paint|201|180|75|![#C9B44B](https://placehold.co/15x15/C9B44B/C9B44B.png) `#C9B44B`|
|Deck tan|XF-55|Acrylics Mini Flat|183|177|135|![#B7B187](https://placehold.co/15x15/B7B187/B7B187.png) `#B7B187`|
|Deep green|XF-26|Acrylics Mini Flat|46|31|9|![#2E1F09](https://placehold.co/15x15/2E1F09/2E1F09.png) `#2E1F09`|
|Deep metallic blue|TS-53|Tamiya Spray|17|33|53|![#112135](https://placehold.co/15x15/112135/112135.png) `#112135`|
|Desert yellow|XF-59|Acrylics Mini Flat|216|156|66|![#D89C42](https://placehold.co/15x15/D89C42/D89C42.png) `#D89C42`|
|Dull red|TS-33|Tamiya Spray|102|0|0|![#660000](https://placehold.co/15x15/660000/660000.png) `#660000`|
|Dull red.jpeg|LP-18|Lacquer Paint|123|69|56|![#7B4538](https://placehold.co/15x15/7B4538/7B4538.png) `#7B4538`|
|Field blue|XF-50|Acrylics Mini Flat|54|65|70|![#364146](https://placehold.co/15x15/364146/364146.png) `#364146`|
|Field grey|XF-65|Acrylics Mini Flat|103|134|107|![#67866B](https://placehold.co/15x15/67866B/67866B.png) `#67866B`|
|Field grey|TS-78|Tamiya Spray|79|108|86|![#4F6C56](https://placehold.co/15x15/4F6C56/4F6C56.png) `#4F6C56`|
|Flat aluminum|LP-38|Lacquer Paint|220|222|221|![#DCDEDD](https://placehold.co/15x15/DCDEDD/DCDEDD.png) `#DCDEDD`|
|Flat aluminum|XF-16|Acrylics Mini Flat|204|204|204|![#CCCCCC](https://placehold.co/15x15/CCCCCC/CCCCCC.png) `#CCCCCC`|
|Flat base|LP-22|Lacquer Paint|255|255|254|![#FFFFFE](https://placehold.co/15x15/FFFFFE/FFFFFE.png) `#FFFFFE`|
|Flat base|X-21|Acrylics Mini Gloss|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Flat black|LP-3|Lacquer Paint|4|0|0|![#040000](https://placehold.co/15x15/040000/040000.png) `#040000`|
|Flat black|XF-1|Acrylics Mini Flat|51|51|51|![#333333](https://placehold.co/15x15/333333/333333.png) `#333333`|
|Flat blue|LP-78|Lacquer Paint|0|106|148|![#006A94](https://placehold.co/15x15/006A94/006A94.png) `#006A94`|
|Flat blue|XF-8|Acrylics Mini Flat|40|76|123|![#284C7B](https://placehold.co/15x15/284C7B/284C7B.png) `#284C7B`|
|Flat brown|XF-10|Acrylics Mini Flat|62|42|9|![#3E2A09](https://placehold.co/15x15/3E2A09/3E2A09.png) `#3E2A09`|
|Flat clear|LP-23|Lacquer Paint|157|179|191|![#9DB3BF](https://placehold.co/15x15/9DB3BF/9DB3BF.png) `#9DB3BF`|
|Flat clear|XF-86|Acrylics Mini Flat|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Flat clear|TS-80|Tamiya Spray|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Flat earth|LP-74|Lacquer Paint|153|71|47|![#99472F](https://placehold.co/15x15/99472F/99472F.png) `#99472F`|
|Flat earth|XF-52|Acrylics Mini Flat|115|72|52|![#734834](https://placehold.co/15x15/734834/734834.png) `#734834`|
|Flat flesh|TS-77|Tamiya Spray|253|192|134|![#FDC086](https://placehold.co/15x15/FDC086/FDC086.png) `#FDC086`|
|Flat flesh|XF-15|Acrylics Mini Flat|253|205|161|![#FDCDA1](https://placehold.co/15x15/FDCDA1/FDCDA1.png) `#FDCDA1`|
|Flat flesh|LP-66|Lacquer Paint|250|204|142|![#FACC8E](https://placehold.co/15x15/FACC8E/FACC8E.png) `#FACC8E`|
|Flat green|XF-5|Acrylics Mini Flat|36|67|19|![#244313](https://placehold.co/15x15/244313/244313.png) `#244313`|
|Flat red|LP-79|Lacquer Paint|230|0|28|![#E6001C](https://placehold.co/15x15/E6001C/E6001C.png) `#E6001C`|
|Flat red|XF-7|Acrylics Mini Flat|255|0|0|![#FF0000](https://placehold.co/15x15/FF0000/FF0000.png) `#FF0000`|
|Flat white|LP-4|Lacquer Paint|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Flat white|XF-2|Acrylics Mini Flat|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Flat yellow|XF-3|Acrylics Mini Flat|255|204|0|![#FFCC00](https://placehold.co/15x15/FFCC00/FFCC00.png) `#FFCC00`|
|Flat yellow|LP-80|Lacquer Paint|254|225|1|![#FEE101](https://placehold.co/15x15/FEE101/FEE101.png) `#FEE101`|
|Fluorescent orange|TS-96|Tamiya Spray|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Fluorescent red|TS-36|Tamiya Spray|252|0|25|![#FC0019](https://placehold.co/15x15/FC0019/FC0019.png) `#FC0019`|
|French blue|TS-10|Tamiya Spray|54|144|192|![#3690C0](https://placehold.co/15x15/3690C0/3690C0.png) `#3690C0`|
|German gray|LP-27|Lacquer Paint|65|88|98|![#415862](https://placehold.co/15x15/415862/415862.png) `#415862`|
|German grey|TS-4|Tamiya Spray|62|71|74|![#3E474A](https://placehold.co/15x15/3E474A/3E474A.png) `#3E474A`|
|German grey|XF-63|Acrylics Mini Flat|62|71|74|![#3E474A](https://placehold.co/15x15/3E474A/3E474A.png) `#3E474A`|
|Gloss aluminum|TS-17|Tamiya Spray|194|200|202|![#C2C8CA](https://placehold.co/15x15/C2C8CA/C2C8CA.png) `#C2C8CA`|
|Gloss aluminum|LP-70|Lacquer Paint|220|222|221|![#DCDEDD](https://placehold.co/15x15/DCDEDD/DCDEDD.png) `#DCDEDD`|
|Gold|TS-21|Tamiya Spray|204|162|8|![#CCA208](https://placehold.co/15x15/CCA208/CCA208.png) `#CCA208`|
|Gold leaf|X-12|Acrylics Mini Gloss|204|162|8|![#CCA208](https://placehold.co/15x15/CCA208/CCA208.png) `#CCA208`|
|Gray green|AS-3|Aircraft Spray|37|58|46|![#253A2E](https://placehold.co/15x15/253A2E/253A2E.png) `#253A2E`|
|Gray green (IJN)|LP-33|Lacquer Paint|185|196|166|![#B9C4A6](https://placehold.co/15x15/B9C4A6/B9C4A6.png) `#B9C4A6`|
|Gray green (IJN)|XF-76|Acrylics Mini Flat|184|195|167|![#B8C3A7](https://placehold.co/15x15/B8C3A7/B8C3A7.png) `#B8C3A7`|
|Gray green (IJN)|AS-29|Aircraft Spray|184|195|167|![#B8C3A7](https://placehold.co/15x15/B8C3A7/B8C3A7.png) `#B8C3A7`|
|Gray violet|AS-4|Aircraft Spray|64|83|103|![#405367](https://placehold.co/15x15/405367/405367.png) `#405367`|
|Green|X-5|Acrylics Mini Gloss|0|68|27|![#00441B](https://placehold.co/15x15/00441B/00441B.png) `#00441B`|
|Green|AS-13|Aircraft Spray|22|49|38|![#163126](https://placehold.co/15x15/163126/163126.png) `#163126`|
|Gun metal|LP-19|Lacquer Paint|77|78|77|![#4D4E4D](https://placehold.co/15x15/4D4E4D/4D4E4D.png) `#4D4E4D`|
|Gun metal|X-10|Acrylics Mini Gloss|80|85|87|![#505557](https://placehold.co/15x15/505557/505557.png) `#505557`|
|Gun metal|TS-38|Tamiya Spray|80|85|87|![#505557](https://placehold.co/15x15/505557/505557.png) `#505557`|
|Gunship gray 2|AS-27|Aircraft Spray|61|78|89|![#3D4E59](https://placehold.co/15x15/3D4E59/3D4E59.png) `#3D4E59`|
|Gunship grey|TS-48|Tamiya Spray|70|74|75|![#464A4B](https://placehold.co/15x15/464A4B/464A4B.png) `#464A4B`|
|Haze grey|TS-32|Tamiya Spray|123|142|146|![#7B8E92](https://placehold.co/15x15/7B8E92/7B8E92.png) `#7B8E92`|
|Hull red|XF-9|Acrylics Mini Flat|62|14|2|![#3E0E02](https://placehold.co/15x15/3E0E02/3E0E02.png) `#3E0E02`|
|IJN gray (Kure Arsenal)|TS-66|Tamiya Spray|130|141|147|![#828D93](https://placehold.co/15x15/828D93/828D93.png) `#828D93`|
|IJN gray (Kure Arsenal)|XF-75|Acrylics Mini Flat|130|141|147|![#828D93](https://placehold.co/15x15/828D93/828D93.png) `#828D93`|
|IJN gray (Maizuru Arsenal)|TS-99|Tamiya Spray|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|IJN gray (Maizuru Arsenal)|XF-87|Acrylics Mini Flat|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|IJN gray (Sasebo Arsenal)|XF-77|Acrylics Mini Flat|104|109|113|![#686D71](https://placehold.co/15x15/686D71/686D71.png) `#686D71`|
|IJN gray (Yokosuka Arsenal)|XF-91|Acrylics Mini Flat|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|IJN gray<br>(Kure Arsenal)|LP-12|Lacquer Paint|113|123|133|![#717B85](https://placehold.co/15x15/717B85/717B85.png) `#717B85`|
|IJN gray<br>(Maizuru Arsenal)|LP-14|Lacquer Paint|125|128|135|![#7D8087](https://placehold.co/15x15/7D8087/7D8087.png) `#7D8087`|
|IJN gray<br>(Sasebo Arsenal)|LP-13|Lacquer Paint|83|87|96|![#535760](https://placehold.co/15x15/535760/535760.png) `#535760`|
|IJN gray<br>(Yokosuka Arsenal)|LP-15|Lacquer Paint|100|107|117|![#646B75](https://placehold.co/15x15/646B75/646B75.png) `#646B75`|
|IJN graySasebo Arsenal|TS-67|Tamiya Spray|104|109|113|![#686D71](https://placehold.co/15x15/686D71/686D71.png) `#686D71`|
|Insignia white|LP-35|Lacquer Paint|221|220|215|![#DDDCD7](https://placehold.co/15x15/DDDCD7/DDDCD7.png) `#DDDCD7`|
|Insignia white|AS-20|Aircraft Spray|242|242|229|![#F2F2E5](https://placehold.co/15x15/F2F2E5/F2F2E5.png) `#F2F2E5`|
|Intermediate blue|AS-19|Aircraft Spray|91|142|152|![#5B8E98](https://placehold.co/15x15/5B8E98/5B8E98.png) `#5B8E98`|
|Italian red|LP-21|Lacquer Paint|198|56|52|![#C63834](https://placehold.co/15x15/C63834/C63834.png) `#C63834`|
|Italian red|TS-8|Tamiya Spray|255|0|0|![#FF0000](https://placehold.co/15x15/FF0000/FF0000.png) `#FF0000`|
|J.A. green|XF-13|Acrylics Mini Flat|51|74|31|![#334A1F](https://placehold.co/15x15/334A1F/334A1F.png) `#334A1F`|
|J.A. grey|XF-14|Acrylics Mini Flat|179|202|142|![#B3CA8E](https://placehold.co/15x15/B3CA8E/B3CA8E.png) `#B3CA8E`|
|J.N. green|XF-11|Acrylics Mini Flat|38|51|11|![#26330B](https://placehold.co/15x15/26330B/26330B.png) `#26330B`|
|J.N. grey|XF-12|Acrylics Mini Flat|179|203|174|![#B3CBAE](https://placehold.co/15x15/B3CBAE/B3CBAE.png) `#B3CBAE`|
|Khaki|LP-73|Lacquer Paint|154|143|51|![#9A8F33](https://placehold.co/15x15/9A8F33/9A8F33.png) `#9A8F33`|
|Khaki|XF-49|Acrylics Mini Flat|126|120|63|![#7E783F](https://placehold.co/15x15/7E783F/7E783F.png) `#7E783F`|
|Khaki drab|XF-51|Acrylics Mini Flat|41|51|14|![#29330E](https://placehold.co/15x15/29330E/29330E.png) `#29330E`|
|Lacquer thinner|LP-10|Lacquer Paint|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Lavender|TS-37|Tamiya Spray|106|41|144|![#6A2990](https://placehold.co/15x15/6A2990/6A2990.png) `#6A2990`|
|Lemon yellow|X-8|Acrylics Mini Gloss|255|230|0|![#FFE600](https://placehold.co/15x15/FFE600/FFE600.png) `#FFE600`|
|Light blue|TS-23|Tamiya Spray|40|174|207|![#28AECF](https://placehold.co/15x15/28AECF/28AECF.png) `#28AECF`|
|Light blue|AS-5|Aircraft Spray|153|194|181|![#99C2B5](https://placehold.co/15x15/99C2B5/99C2B5.png) `#99C2B5`|
|Light blue|XF-23|Acrylics Mini Flat|143|181|173|![#8FB5AD](https://placehold.co/15x15/8FB5AD/8FB5AD.png) `#8FB5AD`|
|Light brown (DAK 1941)|LP-77|Lacquer Paint|229|179|110|![#E5B36E](https://placehold.co/15x15/E5B36E/E5B36E.png) `#E5B36E`|
|Light ghost gray|LP-37|Lacquer Paint|152|180|192|![#98B4C0](https://placehold.co/15x15/98B4C0/98B4C0.png) `#98B4C0`|
|Light ghost grey|AS-26|Aircraft Spray|133|160|163|![#85A0A3](https://placehold.co/15x15/85A0A3/85A0A3.png) `#85A0A3`|
|Light gray|AS-2|Aircraft Spray|163|170|150|![#A3AA96](https://placehold.co/15x15/A3AA96/A3AA96.png) `#A3AA96`|
|Light gray|LP-34|Lacquer Paint|208|204|192|![#D0CCC0](https://placehold.co/15x15/D0CCC0/D0CCC0.png) `#D0CCC0`|
|Light gray|AS-16|Aircraft Spray|204|212|188|![#CCD4BC](https://placehold.co/15x15/CCD4BC/CCD4BC.png) `#CCD4BC`|
|Light gray (IJA)|AS-18|Aircraft Spray|161|183|167|![#A1B7A7](https://placehold.co/15x15/A1B7A7/A1B7A7.png) `#A1B7A7`|
|Light gray (IJN)|LP-32|Lacquer Paint|201|209|194|![#C9D1C2](https://placehold.co/15x15/C9D1C2/C9D1C2.png) `#C9D1C2`|
|Light green|X-15|Acrylics Mini Gloss|102|184|33|![#66B821](https://placehold.co/15x15/66B821/66B821.png) `#66B821`|
|Light green|TS-22|Tamiya Spray|127|195|28|![#7FC31C](https://placehold.co/15x15/7FC31C/7FC31C.png) `#7FC31C`|
|Light green (Luftwaffe)|AS-23|Aircraft Spray|51|112|31|![#33701F](https://placehold.co/15x15/33701F/33701F.png) `#33701F`|
|Light grey|XF-66|Acrylics Mini Flat|102|118|121|![#667679](https://placehold.co/15x15/667679/667679.png) `#667679`|
|Light gun metal|LP-20|Lacquer Paint|119|119|118|![#777776](https://placehold.co/15x15/777776/777776.png) `#777776`|
|Light gun metal|TS-42|Tamiya Spray|115|122|124|![#737A7C](https://placehold.co/15x15/737A7C/737A7C.png) `#737A7C`|
|Light metallic blue|TS-54|Tamiya Spray|16|102|122|![#10667A](https://placehold.co/15x15/10667A/10667A.png) `#10667A`|
|Light sand|LP-30|Lacquer Paint|209|171|124|![#D1AB7C](https://placehold.co/15x15/D1AB7C/D1AB7C.png) `#D1AB7C`|
|Light sand|TS-46|Tamiya Spray|203|164|88|![#CBA458](https://placehold.co/15x15/CBA458/CBA458.png) `#CBA458`|
|Light sea grey|XF-25|Acrylics Mini Flat|122|139|169|![#7A8BA9](https://placehold.co/15x15/7A8BA9/7A8BA9.png) `#7A8BA9`|
|Linoleum deck brown|TS-69|Tamiya Spray|92|33|5|![#5C2105](https://placehold.co/15x15/5C2105/5C2105.png) `#5C2105`|
|Linoleum deck brown|XF-79|Acrylics Mini Flat|120|70|41|![#784629](https://placehold.co/15x15/784629/784629.png) `#784629`|
|Linoleum deck brown.jpeg|LP-17|Lacquer Paint|86|74|58|![#564A3A](https://placehold.co/15x15/564A3A/564A3A.png) `#564A3A`|
|Maroon|TS-11|Tamiya Spray|77|18|2|![#4D1202](https://placehold.co/15x15/4D1202/4D1202.png) `#4D1202`|
|Matt black|TS-6|Tamiya Spray|51|51|51|![#333333](https://placehold.co/15x15/333333/333333.png) `#333333`|
|Matt white|TS-27|Tamiya Spray|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Medium blue|XF-18|Acrylics Mini Flat|72|91|95|![#485B5F](https://placehold.co/15x15/485B5F/485B5F.png) `#485B5F`|
|Medium gray|AS-28|Aircraft Spray|114|125|125|![#727D7D](https://placehold.co/15x15/727D7D/727D7D.png) `#727D7D`|
|Medium grey|XF-20|Acrylics Mini Flat|163|170|150|![#A3AA96](https://placehold.co/15x15/A3AA96/A3AA96.png) `#A3AA96`|
|Medium sea gray|AS-11|Aircraft Spray|143|157|135|![#8F9D87](https://placehold.co/15x15/8F9D87/8F9D87.png) `#8F9D87`|
|Medium sea gray 2|AS-32|Aircraft Spray|170|190|185|![#AABEB9](https://placehold.co/15x15/AABEB9/AABEB9.png) `#AABEB9`|
|Medium sea gray 2 (RAF)|XF-83|Acrylics Mini Flat|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Metallic black|TS-40|Tamiya Spray|57|61|62|![#393D3E](https://placehold.co/15x15/393D3E/393D3E.png) `#393D3E`|
|Metallic black|LP-40|Lacquer Paint|63|59|58|![#3F3B3A](https://placehold.co/15x15/3F3B3A/3F3B3A.png) `#3F3B3A`|
|Metallic blue|X-13|Acrylics Mini Gloss|30|116|151|![#1E7497](https://placehold.co/15x15/1E7497/1E7497.png) `#1E7497`|
|Metallic blue|TS-19|Tamiya Spray|10|80|161|![#0A50A1](https://placehold.co/15x15/0A50A1/0A50A1.png) `#0A50A1`|
|Metallic brown|X-34|Acrylics Mini Gloss|153|63|6|![#993F06](https://placehold.co/15x15/993F06/993F06.png) `#993F06`|
|Metallic gold|TS-84|Tamiya Spray|221|210|157|![#DDD29D](https://placehold.co/15x15/DDD29D/DDD29D.png) `#DDD29D`|
|Metallic gray|TS-94|Tamiya Spray|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Metallic gray|LP-61|Lacquer Paint|114|112|113|![#727071](https://placehold.co/15x15/727071/727071.png) `#727071`|
|Metallic green|TS-20|Tamiya Spray|39|158|79|![#279E4F](https://placehold.co/15x15/279E4F/279E4F.png) `#279E4F`|
|Metallic grey|XF-56|Acrylics Mini Flat|92|98|100|![#5C6264](https://placehold.co/15x15/5C6264/5C6264.png) `#5C6264`|
|Metallic orange|TS-92|Tamiya Spray|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Metallic orange|LP-44|Lacquer Paint|239|120|0|![#EF7800](https://placehold.co/15x15/EF7800/EF7800.png) `#EF7800`|
|Metallic red|TS-18|Tamiya Spray|227|0|23|![#E30017](https://placehold.co/15x15/E30017/E30017.png) `#E30017`|
|Metallic silver|TS-83|Tamiya Spray|217|218|222|![#D9DADE](https://placehold.co/15x15/D9DADE/D9DADE.png) `#D9DADE`|
|Mica blue|LP-41|Lacquer Paint|1|57|142|![#01398E](https://placehold.co/15x15/01398E/01398E.png) `#01398E`|
|Mica blue|TS-50|Tamiya Spray|11|58|139|![#0B3A8B](https://placehold.co/15x15/0B3A8B/0B3A8B.png) `#0B3A8B`|
|Mica red|LP-42|Lacquer Paint|200|23|29|![#C8171D](https://placehold.co/15x15/C8171D/C8171D.png) `#C8171D`|
|Mica red|TS-39|Tamiya Spray|230|0|0|![#E60000](https://placehold.co/15x15/E60000/E60000.png) `#E60000`|
|Mica silver|LP-72|Lacquer Paint|212|217|220|![#D4D9DC](https://placehold.co/15x15/D4D9DC/D4D9DC.png) `#D4D9DC`|
|Mica silver|TS-76|Tamiya Spray|204|204|204|![#CCCCCC](https://placehold.co/15x15/CCCCCC/CCCCCC.png) `#CCCCCC`|
|Mixing blue|LP-81|Lacquer Paint|32|42|103|![#202A67](https://placehold.co/15x15/202A67/202A67.png) `#202A67`|
|Mixing red|LP-82|Lacquer Paint|200|17|61|![#C8113D](https://placehold.co/15x15/C8113D/C8113D.png) `#C8113D`|
|Mixing yellow|LP-83|Lacquer Paint|254|215|0|![#FED700](https://placehold.co/15x15/FED700/FED700.png) `#FED700`|
|NATO black|LP-60|Lacquer Paint|0|0|0|![#000000](https://placehold.co/15x15/000000/000000.png) `#000000`|
|NATO black|TS-63|Tamiya Spray|34|36|36|![#222424](https://placehold.co/15x15/222424/222424.png) `#222424`|
|NATO black|XF-69|Acrylics Mini Flat|34|36|36|![#222424](https://placehold.co/15x15/222424/222424.png) `#222424`|
|NATO brown|LP-59|Lacquer Paint|106|74|49|![#6A4A31](https://placehold.co/15x15/6A4A31/6A4A31.png) `#6A4A31`|
|NATO brown|XF-68|Acrylics Mini Flat|115|48|7|![#733007](https://placehold.co/15x15/733007/733007.png) `#733007`|
|NATO brown|TS-62|Tamiya Spray|115|48|7|![#733007](https://placehold.co/15x15/733007/733007.png) `#733007`|
|NATO green|LP-58|Lacquer Paint|41|84|56|![#295438](https://placehold.co/15x15/295438/295438.png) `#295438`|
|NATO green|XF-67|Acrylics Mini Flat|51|96|26|![#33601A](https://placehold.co/15x15/33601A/33601A.png) `#33601A`|
|NATO green|TS-61|Tamiya Spray|51|96|26|![#33601A](https://placehold.co/15x15/33601A/33601A.png) `#33601A`|
|Navy blue|AS-8|Aircraft Spray|40|66|94|![#28425E](https://placehold.co/15x15/28425E/28425E.png) `#28425E`|
|Neutral gray|AS-7|Aircraft Spray|126|135|137|![#7E8789](https://placehold.co/15x15/7E8789/7E8789.png) `#7E8789`|
|Neutral grey|XF-53|Acrylics Mini Flat|108|120|123|![#6C787B](https://placehold.co/15x15/6C787B/6C787B.png) `#6C787B`|
|Ocean gray|AS-10|Aircraft Spray|82|90|95|![#525A5F](https://placehold.co/15x15/525A5F/525A5F.png) `#525A5F`|
|Ocean gray 2|AS-31|Aircraft Spray|108|140|153|![#6C8C99](https://placehold.co/15x15/6C8C99/6C8C99.png) `#6C8C99`|
|Ocean gray 2 (RAF)|XF-82|Acrylics Mini Flat|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Olive drab|XF-62|Acrylics Mini Flat|64|75|19|![#404B13](https://placehold.co/15x15/404B13/404B13.png) `#404B13`|
|Olive drab|LP-28|Lacquer Paint|77|86|65|![#4D5641](https://placehold.co/15x15/4D5641/4D5641.png) `#4D5641`|
|Olive drab|TS-5|Tamiya Spray|64|75|19|![#404B13](https://placehold.co/15x15/404B13/404B13.png) `#404B13`|
|Olive drab|AS-6|Aircraft Spray|64|75|19|![#404B13](https://placehold.co/15x15/404B13/404B13.png) `#404B13`|
|Olive drab (JGSDF)|LP-64|Lacquer Paint|41|84|56|![#295438](https://placehold.co/15x15/295438/295438.png) `#295438`|
|Olive drab (JGSDF)|XF-74|Acrylics Mini Flat|51|64|18|![#334012](https://placehold.co/15x15/334012/334012.png) `#334012`|
|Olive drab (JGSDF)|TS-70|Tamiya Spray|46|65|18|![#2E4112](https://placehold.co/15x15/2E4112/2E4112.png) `#2E4112`|
|Olive drab 2|TS-28|Tamiya Spray|77|86|19|![#4D5613](https://placehold.co/15x15/4D5613/4D5613.png) `#4D5613`|
|Olive drab 2|LP-29|Lacquer Paint|71|87|62|![#47573E](https://placehold.co/15x15/47573E/47573E.png) `#47573E`|
|Olive green|XF-58|Acrylics Mini Flat|26|59|20|![#1A3B14](https://placehold.co/15x15/1A3B14/1A3B14.png) `#1A3B14`|
|Olive green|AS-14|Aircraft Spray|51|80|22|![#335016](https://placehold.co/15x15/335016/335016.png) `#335016`|
|Orange|X-6|Acrylics Mini Gloss|255|127|0|![#FF7F00](https://placehold.co/15x15/FF7F00/FF7F00.png) `#FF7F00`|
|Orange|TS-12|Tamiya Spray|255|89|0|![#FF5900](https://placehold.co/15x15/FF5900/FF5900.png) `#FF5900`|
|Park green|X-28|Acrylics Mini Gloss|51|164|77|![#33A44D](https://placehold.co/15x15/33A44D/33A44D.png) `#33A44D`|
|Park green|TS-35|Tamiya Spray|51|162|61|![#33A23D](https://placehold.co/15x15/33A23D/33A23D.png) `#33A23D`|
|Pearl blue|LP-47|Lacquer Paint|1|59|143|![#013B8F](https://placehold.co/15x15/013B8F/013B8F.png) `#013B8F`|
|Pearl blue|TS-89|Tamiya Spray|12|62|128|![#0C3E80](https://placehold.co/15x15/0C3E80/0C3E80.png) `#0C3E80`|
|Pearl clear|LP-49|Lacquer Paint|247|249|248|![#F7F9F8](https://placehold.co/15x15/F7F9F8/F7F9F8.png) `#F7F9F8`|
|Pearl clear|TS-65|Tamiya Spray|230|230|207|![#E6E6CF](https://placehold.co/15x15/E6E6CF/E6E6CF.png) `#E6E6CF`|
|Pearl green|TS-60|Tamiya Spray|153|202|144|![#99CA90](https://placehold.co/15x15/99CA90/99CA90.png) `#99CA90`|
|Pearl light blue|TS-58|Tamiya Spray|115|150|186|![#7396BA](https://placehold.co/15x15/7396BA/7396BA.png) `#7396BA`|
|Pearl light red|TS-59|Tamiya Spray|204|134|163|![#CC86A3](https://placehold.co/15x15/CC86A3/CC86A3.png) `#CC86A3`|
|Pearl white|LP-43|Lacquer Paint|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Pearl white|TS-45|Tamiya Spray|242|242|229|![#F2F2E5](https://placehold.co/15x15/F2F2E5/F2F2E5.png) `#F2F2E5`|
|Pearl yellow|TS-97|Tamiya Spray|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Pink|TS-25|Tamiya Spray|250|154|184|![#FA9AB8](https://placehold.co/15x15/FA9AB8/FA9AB8.png) `#FA9AB8`|
|Pink|X-17|Acrylics Mini Gloss|248|129|172|![#F881AC](https://placehold.co/15x15/F881AC/F881AC.png) `#F881AC`|
|Pure blue|LP-6|Lacquer Paint|0|91|172|![#005BAC](https://placehold.co/15x15/005BAC/005BAC.png) `#005BAC`|
|Pure blue|TS-93|Tamiya Spray|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Pure metallic red|TS-95|Tamiya Spray|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Pure metallic red|LP-46|Lacquer Paint|223|0|18|![#DF0012](https://placehold.co/15x15/DF0012/DF0012.png) `#DF0012`|
|Pure orange|LP-51|Lacquer Paint|241|141|1|![#F18D01](https://placehold.co/15x15/F18D01/F18D01.png) `#F18D01`|
|Pure orange|TS-98|Tamiya Spray|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Pure red|LP-7|Lacquer Paint|231|0|18|![#E70012](https://placehold.co/15x15/E70012/E70012.png) `#E70012`|
|Pure red|TS-86|Tamiya Spray|229|0|18|![#E50012](https://placehold.co/15x15/E50012/E50012.png) `#E50012`|
|Pure white|TS-26|Tamiya Spray|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Pure yellow|LP-8|Lacquer Paint|255|240|1|![#FFF001](https://placehold.co/15x15/FFF001/FFF001.png) `#FFF001`|
|Purple|X-16|Acrylics Mini Gloss|71|75|160|![#474BA0](https://placehold.co/15x15/474BA0/474BA0.png) `#474BA0`|
|Purple|TS-24|Tamiya Spray|71|75|160|![#474BA0](https://placehold.co/15x15/474BA0/474BA0.png) `#474BA0`|
|RLM grey|XF-22|Acrylics Mini Flat|123|141|125|![#7B8D7D](https://placehold.co/15x15/7B8D7D/7B8D7D.png) `#7B8D7D`|
|Racing blue|LP-45|Lacquer Paint|1|59|143|![#013B8F](https://placehold.co/15x15/013B8F/013B8F.png) `#013B8F`|
|Racing blue|TS-51|Tamiya Spray|14|30|125|![#0E1E7D](https://placehold.co/15x15/0E1E7D/0E1E7D.png) `#0E1E7D`|
|Racing green|TS-43|Tamiya Spray|24|67|22|![#184316](https://placehold.co/15x15/184316/184316.png) `#184316`|
|Racing white|TS-7|Tamiya Spray|230|230|230|![#E6E6E6](https://placehold.co/15x15/E6E6E6/E6E6E6.png) `#E6E6E6`|
|Racing white|LP-39|Lacquer Paint|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Red|X-7|Acrylics Mini Gloss|255|0|0|![#FF0000](https://placehold.co/15x15/FF0000/FF0000.png) `#FF0000`|
|Red brown|TS-1|Tamiya Spray|102|55|10|![#66370A](https://placehold.co/15x15/66370A/66370A.png) `#66370A`|
|Red brown|XF-64|Acrylics Mini Flat|102|55|10|![#66370A](https://placehold.co/15x15/66370A/66370A.png) `#66370A`|
|Red brown 2|LP-57|Lacquer Paint|79|55|51|![#4F3733](https://placehold.co/15x15/4F3733/4F3733.png) `#4F3733`|
|Red brown 2|XF-90|Acrylics Mini Flat|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Royal blue|X-3|Acrylics Mini Gloss|29|45|83|![#1D2D53](https://placehold.co/15x15/1D2D53/1D2D53.png) `#1D2D53`|
|Royal light gray|TS-81|Tamiya Spray|193|202|200|![#C1CAC8](https://placehold.co/15x15/C1CAC8/C1CAC8.png) `#C1CAC8`|
|Royal light gray|XF-80|Acrylics Mini Flat|193|202|200|![#C1CAC8](https://placehold.co/15x15/C1CAC8/C1CAC8.png) `#C1CAC8`|
|Rubber black|XF-85|Acrylics Mini Flat|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Rubber black|LP-65|Lacquer Paint|0|0|0|![#000000](https://placehold.co/15x15/000000/000000.png) `#000000`|
|Rubber black|TS-82|Tamiya Spray|68|70|72|![#444648](https://placehold.co/15x15/444648/444648.png) `#444648`|
|Sea blue|XF-17|Acrylics Mini Flat|46|59|67|![#2E3B43](https://placehold.co/15x15/2E3B43/2E3B43.png) `#2E3B43`|
|Semi gloss black|TS-29|Tamiya Spray|51|51|51|![#333333](https://placehold.co/15x15/333333/333333.png) `#333333`|
|Semi gloss black|LP-5|Lacquer Paint|4|0|0|![#040000](https://placehold.co/15x15/040000/040000.png) `#040000`|
|Semi gloss black|X-18|Acrylics Mini Gloss|51|51|51|![#333333](https://placehold.co/15x15/333333/333333.png) `#333333`|
|Semi gloss clear|TS-79|Tamiya Spray|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Semi gloss clear|LP-24|Lacquer Paint|255|255|254|![#FFFFFE](https://placehold.co/15x15/FFFFFE/FFFFFE.png) `#FFFFFE`|
|Semi-gloss bright gun metal|TS-100|Tamiya Spray|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Semi-gloss clear|X-35|Acrylics Mini Gloss|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Silver|LP-11|Lacquer Paint|223|223|223|![#DFDFDF](https://placehold.co/15x15/DFDFDF/DFDFDF.png) `#DFDFDF`|
|Silver leaf|TS-30|Tamiya Spray|204|204|204|![#CCCCCC](https://placehold.co/15x15/CCCCCC/CCCCCC.png) `#CCCCCC`|
|Sky|XF-21|Acrylics Mini Flat|184|190|119|![#B8BE77](https://placehold.co/15x15/B8BE77/B8BE77.png) `#B8BE77`|
|Sky blue|X-14|Acrylics Mini Gloss|29|153|196|![#1D99C4](https://placehold.co/15x15/1D99C4/1D99C4.png) `#1D99C4`|
|Sky grey|XF-19|Acrylics Mini Flat|173|183|192|![#ADB7C0](https://placehold.co/15x15/ADB7C0/ADB7C0.png) `#ADB7C0`|
|Smoke|LP-67|Lacquer Paint|199|201|200|![#C7C9C8](https://placehold.co/15x15/C7C9C8/C7C9C8.png) `#C7C9C8`|
|Smoke|X-19|Acrylics Mini Gloss|143|145|140|![#8F918C](https://placehold.co/15x15/8F918C/8F918C.png) `#8F918C`|
|Smoke|TS-71|Tamiya Spray|179|170|174|![#B3AAAE](https://placehold.co/15x15/B3AAAE/B3AAAE.png) `#B3AAAE`|
|Sparkling silver|LP-48|Lacquer Paint|222|224|223|![#DEE0DF](https://placehold.co/15x15/DEE0DF/DEE0DF.png) `#DEE0DF`|
|Tan|AS-15|Aircraft Spray|166|131|84|![#A68354](https://placehold.co/15x15/A68354/A68354.png) `#A68354`|
|Titanium gold|X-31|Acrylics Mini Gloss|203|187|114|![#CBBB72](https://placehold.co/15x15/CBBB72/CBBB72.png) `#CBBB72`|
|Titanium gold|TS-87|Tamiya Spray|199|186|130|![#C7BA82](https://placehold.co/15x15/C7BA82/C7BA82.png) `#C7BA82`|
|Titanium gold|LP-62|Lacquer Paint|218|201|147|![#DAC993](https://placehold.co/15x15/DAC993/DAC993.png) `#DAC993`|
|Titanium silver|TS-88|Tamiya Spray|198|205|194|![#C6CDC2](https://placehold.co/15x15/C6CDC2/C6CDC2.png) `#C6CDC2`|
|Titanium silver|LP-63|Lacquer Paint|219|220|206|![#DBDCCE](https://placehold.co/15x15/DBDCCE/DBDCCE.png) `#DBDCCE`|
|Titanium silver|X-32|Acrylics Mini Gloss|204|204|184|![#CCCCB8](https://placehold.co/15x15/CCCCB8/CCCCB8.png) `#CCCCB8`|
|White|LP-2|Lacquer Paint|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|White|X-2|Acrylics Mini Gloss|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Wooden deck tan|LP-16|Lacquer Paint|172|161|132|![#ACA184](https://placehold.co/15x15/ACA184/ACA184.png) `#ACA184`|
|Wooden deck tan|XF-78|Acrylics Mini Flat|211|182|133|![#D3B685](https://placehold.co/15x15/D3B685/D3B685.png) `#D3B685`|
|Wooden deck tan|TS-68|Tamiya Spray|203|164|108|![#CBA46C](https://placehold.co/15x15/CBA46C/CBA46C.png) `#CBA46C`|
|Yellow|TS-16|Tamiya Spray|255|230|0|![#FFE600](https://placehold.co/15x15/FFE600/FFE600.png) `#FFE600`|
|Yellow green|XF-4|Acrylics Mini Flat|179|198|15|![#B3C60F](https://placehold.co/15x15/B3C60F/B3C60F.png) `#B3C60F`|
|Yellow-brown (DAK 1941)|LP-76|Lacquer Paint|177|129|80|![#B18150](https://placehold.co/15x15/B18150/B18150.png) `#B18150`|
<p align="center"><img src="../logos/logo_rnd.png" height="70" /></p>
<p align="center">Made available by <a href="https://miniaturepainterpro.app/">Miniature Painter Pro</a></p>
<p align="center">
<a href="https://play.google.com/store/apps/details?id=com.rfsp.paintmaster"> <img src="../logos/Android.png" height="30" /></a>
<a href="https://apps.apple.com/us/app/miniature-painter-pro/id1495938928"> <img src="../logos/iOS.png" height="30" /></a>
</p>
