import reflex as rx
import os
from ..state import BaseState
from ..services.supabase import supabase_admin

ADMIN_EMAIL = os.environ.get("ADMIN_EMAIL")

class AdminState(BaseState):
    tokens: list[dict] = []
    
    async def check_access(self):
        """Run on page mount to ensure admin access."""
        # await self.check_auth() # Ensure user is loaded
        
        # Simple security check
        # NOTE: self.user is populated by BaseState logic (needs to be robust in prod)
        if not self.user or self.user.get("email") != ADMIN_EMAIL:
             return rx.redirect("/")
        
        await self.fetch_tokens()

    async def fetch_tokens(self):
        if not supabase_admin:
            return
        
        # Retrieve tokens (newest first)
        res = supabase_admin.table("access_tokens").select("*").order("created_at", desc=True).execute()
        self.tokens = res.data

    async def generate_token(self):
        if not supabase_admin:
            return

        # Insert new active token
        # Defaults in DB will handle UUID and status='active'
        res = supabase_admin.table("access_tokens").insert({}).execute()
        if res.data:
            self.tokens.insert(0, res.data[0]) 

def admin_page():
    return rx.vstack(
        rx.heading("Admin Dashboard", size="8"),
        rx.text(f"Logged in as: {ADMIN_EMAIL}", color="gray"),
        rx.divider(),
        
        rx.hstack(
            rx.button("Generate New Token", on_click=AdminState.generate_token, color_scheme="blue"),
            rx.button("Refresh List", on_click=AdminState.fetch_tokens, variant="outline"),
            spacing="4"
        ),
        
        rx.table.root(
            rx.table.header(
                rx.table.row(
                    rx.table.column_header_cell("Token UUID"),
                    rx.table.column_header_cell("Status"),
                    rx.table.column_header_cell("Used By"),
                    rx.table.column_header_cell("Created At"),
                )
            ),
            rx.table.body(
                rx.foreach(
                    AdminState.tokens,
                    lambda token: rx.table.row(
                        rx.table.cell(token["token_code"]),
                        rx.table.cell(
                            rx.badge(token["status"], color_scheme=rx.cond(token["status"] == "active", "green", "gray"))
                        ),
                        rx.table.cell(token["used_by_email"]),
                        rx.table.cell(token["created_at"]),
                    )
                )
            ),
            width="100%"
        ),
        
        spacing="6",
        padding="2em",
        on_mount=AdminState.check_access,
        width="100%",
        max_width="1200px"
    )
