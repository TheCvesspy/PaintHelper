import reflex as rx
import os
from ..services.supabase import supabase

class BaseState(rx.State):
    user: dict = {}
    
    async def check_auth(self):
        """Check if user is authenticated via Supabase."""
        # In a real app, we might check an access token stored in local storage
        # and validate it with Supabase.
        # For this MVP, we will assume the session is handled via 'on_load' checks 
        # or we will implement a simple session restoration if possible.
        session = supabase.auth.get_session()
        if session:
            self.user = session.user.__dict__ # specific to supabase return type
        else:
            self.user = {}

    @rx.var
    def is_authenticated(self) -> bool:
        return bool(self.user)
        
    def logout(self):
        supabase.auth.sign_out()
        self.user = {}
        return rx.redirect("/")
