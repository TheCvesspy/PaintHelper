import reflex as rx


def painting_guides_tab():
    """Painting guides list and management view"""
    # Import dependencies locally to avoid circular imports  
    from ...pages.dashboard import DashboardState, render_create_guide_modal, render_guide_detail_modal, render_cancel_confirmation_modal
    state_class = DashboardState
    """Painting guides list and management view"""
    return rx.vstack(
        render_create_guide_modal(),
        render_guide_detail_modal(),
        render_cancel_confirmation_modal(),
        rx.hstack(
            rx.heading("Painting Guides", size="5"),
            rx.spacer(),
            rx.button("New Guide", on_click=state_class.toggle_guide_modal)
        ),
        
        rx.grid(
            rx.foreach(
                state_class.painting_guides,
                lambda guide: rx.card(
                    rx.vstack(
                        rx.hstack(
                            rx.vstack(
                                rx.text(guide.name, weight="bold", size="3"),
                                rx.text(f"{guide.guide_details.length()} Sections", size="1", color="violet"),
                                align_items="start",
                                spacing="1"
                            ),
                            rx.spacer(),
                            rx.hstack(
                                rx.button(
                                    rx.icon("pencil", size=16),
                                    on_click=lambda: state_class.open_guide_for_edit(guide),
                                    variant="ghost",
                                    size="1",
                                    color_scheme="violet"
                                ),
                                rx.button(
                                    rx.icon("eye", size=16),
                                    on_click=lambda: state_class.open_guide_detail(guide),
                                    variant="ghost",
                                    size="1"
                                ),
                                rx.button(
                                    rx.icon("trash-2", size=16),
                                    on_click=lambda: state_class.delete_guide(guide.id),
                                    variant="ghost",
                                    size="1",
                                    color_scheme="red"
                                ),
                                spacing="1"
                            ),
                            width="100%",
                            align_items="center"
                        ),
                        width="100%",
                        spacing="2"
                    ),
                    width="100%",
                    cursor="default",
                    _hover={"boxShadow": "md"}
                )
            ),
            columns="3",
            spacing="4",
            width="100%"
        ),
        
        width="100%",
        spacing="4",
        align_items="start"
    )
