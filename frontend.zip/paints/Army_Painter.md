# Army Painter
![Army_Painter](../logos/Army_Painter.png "Army_Painter")

|Name|Code|Set|R|G|B|Hex|
|---|---|---|---|---|---|---|
|Abomination Gore|WP1401|Warpaints|163|47|38|![#A32F26](https://placehold.co/15x15/A32F26/A32F26.png) `#A32F26`|
|Absolution Green|null|Speedpaint Set|34|49|31|![#22311F](https://placehold.co/15x15/22311F/22311F.png) `#22311F`|
|Absolution Green|null|Speedpaint Set 2.0|33|74|40|![#214A28](https://placehold.co/15x15/214A28/214A28.png) `#214A28`|
|Abyssal Black|null|D&D Nolzur's Marvelous Pigments|33|32|29|![#21201D](https://placehold.co/15x15/21201D/21201D.png) `#21201D`|
|Abyssal Blue|null|Warpaints Fanatic|0|80|108|![#00506C](https://placehold.co/15x15/00506C/00506C.png) `#00506C`|
|Aegis Aqua|null|Warpaints Fanatic|50|179|213|![#32B3D5](https://placehold.co/15x15/32B3D5/32B3D5.png) `#32B3D5`|
|Aegis Suit Satin Varnish|CP3027|Warpaints Primer|244|247|247|![#F4F7F7](https://placehold.co/15x15/F4F7F7/F4F7F7.png) `#F4F7F7`|
|Afterglow|null|Warpaints Fanatic|228|234|141|![#E4EA8D](https://placehold.co/15x15/E4EA8D/E4EA8D.png) `#E4EA8D`|
|Agate Skin|null|Warpaints Fanatic|215|135|123|![#D7877B](https://placehold.co/15x15/D7877B/D7877B.png) `#D7877B`|
|Aged Hide|null|Speedpaint Set 2.0|213|108|79|![#D56C4F](https://placehold.co/15x15/D56C4F/D56C4F.png) `#D56C4F`|
|Algae Green|null|Speedpaint Set 2.0|156|170|83|![#9CAA53](https://placehold.co/15x15/9CAA53/9CAA53.png) `#9CAA53`|
|Alien Purple|null|Warpaints Fanatic|97|84|163|![#6154A3](https://placehold.co/15x15/6154A3/6154A3.png) `#6154A3`|
|Alien Purple|CP3019|Warpaints Primer|73|43|121|![#492B79](https://placehold.co/15x15/492B79/492B79.png) `#492B79`|
|Alien Purple|null|Warpaints Air|61|37|96|![#3D2560](https://placehold.co/15x15/3D2560/3D2560.png) `#3D2560`|
|Alien Purple|WP1128|Warpaints|70|45|89|![#462D59](https://placehold.co/15x15/462D59/462D59.png) `#462D59`|
|Alpha Blue|null|Warpaints Fanatic|102|125|192|![#667DC0](https://placehold.co/15x15/667DC0/667DC0.png) `#667DC0`|
|Amber Skin|null|Warpaints Fanatic|196|160|131|![#C4A083](https://placehold.co/15x15/C4A083/C4A083.png) `#C4A083`|
|Amber Skin|null|Skin Tones Paint Set|172|131|93|![#AC835D](https://placehold.co/15x15/AC835D/AC835D.png) `#AC835D`|
|Amulet Aqua|null|Warpaints Fanatic|104|197|182|![#68C5B6](https://placehold.co/15x15/68C5B6/68C5B6.png) `#68C5B6`|
|Ancient Honey|null|Speedpaint Set 2.0|235|189|33|![#EBBD21](https://placehold.co/15x15/EBBD21/EBBD21.png) `#EBBD21`|
|Ancient Mummy|null|D&D Underdark Set|253|234|169|![#FDEAA9](https://placehold.co/15x15/FDEAA9/FDEAA9.png) `#FDEAA9`|
|Ancient Stone|null|Warpaints Fanatic|208|195|163|![#D0C3A3](https://placehold.co/15x15/D0C3A3/D0C3A3.png) `#D0C3A3`|
|Angel Green|null|Warpaints Air|32|50|29|![#20321D](https://placehold.co/15x15/20321D/20321D.png) `#20321D`|
|Angel Green|WP1112|Warpaints|15|53|21|![#0F3515](https://placehold.co/15x15/0F3515/0F3515.png) `#0F3515`|
|Angel Green|CP3020|Warpaints Primer|39|59|47|![#273B2F](https://placehold.co/15x15/273B2F/273B2F.png) `#273B2F`|
|Angel Green|null|Warpaints Fanatic|23|62|49|![#173E31](https://placehold.co/15x15/173E31/173E31.png) `#173E31`|
|Angelic Red|null|Warpaints Fanatic|212|44|57|![#D42C39](https://placehold.co/15x15/D42C39/D42C39.png) `#D42C39`|
|Angelic Yellow|null|D&D Nolzur's Marvelous Pigments|249|223|28|![#F9DF1C](https://placehold.co/15x15/F9DF1C/F9DF1C.png) `#F9DF1C`|
|Anti-Shine Matt Varnish|CP3003|Warpaints Primer|240|240|240|![#F0F0F0](https://placehold.co/15x15/F0F0F0/F0F0F0.png) `#F0F0F0`|
|Anti-Shine Matt Varnish|WP1103|Warpaints Wash|240|240|240|![#F0F0F0](https://placehold.co/15x15/F0F0F0/F0F0F0.png) `#F0F0F0`|
|Aqua Alchemy|null|Warpaints Fanatic|36|187|166|![#24BBA6](https://placehold.co/15x15/24BBA6/24BBA6.png) `#24BBA6`|
|Aquamarine|null|Warpaints Fanatic|86|196|205|![#56C4CD](https://placehold.co/15x15/56C4CD/56C4CD.png) `#56C4CD`|
|Archangel Red|null|Warpaints Air|197|40|34|![#C52822](https://placehold.co/15x15/C52822/C52822.png) `#C52822`|
|Arctic Gem|null|Warpaints Fanatic|25|149|212|![#1995D4](https://placehold.co/15x15/1995D4/1995D4.png) `#1995D4`|
|Arid Earth|WP1402|Warpaints|253|237|199|![#FDEDC7](https://placehold.co/15x15/FDEDC7/FDEDC7.png) `#FDEDC7`|
|Army Green|null|Warpaints Fanatic|93|117|84|![#5D7554](https://placehold.co/15x15/5D7554/5D7554.png) `#5D7554`|
|Army Green|null|Warpaints Air|83|102|56|![#536638](https://placehold.co/15x15/536638/536638.png) `#536638`|
|Army Green|CP3005|Warpaints Primer|102|105|58|![#66693A](https://placehold.co/15x15/66693A/66693A.png) `#66693A`|
|Army Green|WP1110|Warpaints|116|114|96|![#747260](https://placehold.co/15x15/747260/747260.png) `#747260`|
|Ash Grey|WP1117|Warpaints|149|149|159|![#95959F](https://placehold.co/15x15/95959F/95959F.png) `#95959F`|
|Ash Grey|null|Warpaints Fanatic|132|135|143|![#84878F](https://placehold.co/15x15/84878F/84878F.png) `#84878F`|
|Ashen Stone|null|Speedpaint Set 2.0|179|185|185|![#B3B9B9](https://placehold.co/15x15/B3B9B9/B3B9B9.png) `#B3B9B9`|
|Augur Blue|null|Warpaints Fanatic|172|188|226|![#ACBCE2](https://placehold.co/15x15/ACBCE2/ACBCE2.png) `#ACBCE2`|
|Autumn Sage|null|Warpaints Fanatic|117|173|152|![#75AD98](https://placehold.co/15x15/75AD98/75AD98.png) `#75AD98`|
|Aztec Gold|null|Speedpaint Set 2.0|98|115|47|![#62732F](https://placehold.co/15x15/62732F/62732F.png) `#62732F`|
|Azure Magic|null|Metallic Colours Paint Set|0|93|120|![#005D78](https://placehold.co/15x15/005D78/005D78.png) `#005D78`|
|Azure Magic|null|Warpaints Air|21|63|81|![#153F51](https://placehold.co/15x15/153F51/153F51.png) `#153F51`|
|Babe Blonde|WP1403|Warpaints|251|220|4|![#FBDC04](https://placehold.co/15x15/FBDC04/FBDC04.png) `#FBDC04`|
|Banshee Brown|WP1404|Warpaints|191|165|155|![#BFA59B](https://placehold.co/15x15/BFA59B/BFA59B.png) `#BFA59B`|
|Barbarian Flesh|null|Warpaints Air|210|141|87|![#D28D57](https://placehold.co/15x15/D28D57/D28D57.png) `#D28D57`|
|Barbarian Flesh|null|Warpaints Fanatic|246|155|127|![#F69B7F](https://placehold.co/15x15/F69B7F/F69B7F.png) `#F69B7F`|
|Barbarian Flesh|WP1126|Warpaints|227|140|127|![#E38C7F](https://placehold.co/15x15/E38C7F/E38C7F.png) `#E38C7F`|
|Barbarian Flesh|CP3007|Warpaints Primer|229|155|102|![#E59B66](https://placehold.co/15x15/E59B66/E59B66.png) `#E59B66`|
|Baron Blue|null|Warpaints Fanatic|124|149|204|![#7C95CC](https://placehold.co/15x15/7C95CC/7C95CC.png) `#7C95CC`|
|Barren Dune|null|Warpaints Fanatic|222|187|114|![#DEBB72](https://placehold.co/15x15/DEBB72/DEBB72.png) `#DEBB72`|
|Barren Yellow|null|Warpaints Air|132|91|37|![#845B25](https://placehold.co/15x15/845B25/845B25.png) `#845B25`|
|Basilisk Brown|WP1405|Warpaints|207|129|0|![#CF8100](https://placehold.co/15x15/CF8100/CF8100.png) `#CF8100`|
|Basilisk Red|null|Warpaints Fanatic|108|37|57|![#6C2539](https://placehold.co/15x15/6C2539/6C2539.png) `#6C2539`|
|Battleship Grey|null|Speedpaint Set 2.0|183|198|201|![#B7C6C9](https://placehold.co/15x15/B7C6C9/B7C6C9.png) `#B7C6C9`|
|Beholder Purple|null|D&D Nolzur's Marvelous Pigments|168|147|179|![#A893B3](https://placehold.co/15x15/A893B3/A893B3.png) `#A893B3`|
|Beowulf Blue|null|Speedpaint Set 2.0|12|63|128|![#0C3F80](https://placehold.co/15x15/0C3F80/0C3F80.png) `#0C3F80`|
|Bleached Bone|null|Warpaints Air|223|217|183|![#DFD9B7](https://placehold.co/15x15/DFD9B7/DFD9B7.png) `#DFD9B7`|
|Bleached Skull|null|D&D Undead Set|245|244|240|![#F5F4F0](https://placehold.co/15x15/F5F4F0/F5F4F0.png) `#F5F4F0`|
|Blinding Light|null|Speedpaint Set 2.0|245|244|239|![#F5F4EF](https://placehold.co/15x15/F5F4EF/F5F4EF.png) `#F5F4EF`|
|Blood Chalice|null|Warpaints Fanatic|219|75|80|![#DB4B50](https://placehold.co/15x15/DB4B50/DB4B50.png) `#DB4B50`|
|Blood Red|null|Speedpaint Set 2.0|219|48|22|![#DB3016](https://placehold.co/15x15/DB3016/DB3016.png) `#DB3016`|
|Blood Red|null|Speedpaint Set|168|20|31|![#A8141F](https://placehold.co/15x15/A8141F/A8141F.png) `#A8141F`|
|Blue Flux|null|Warpaints Air|0|139|189|![#008BBD](https://placehold.co/15x15/008BBD/008BBD.png) `#008BBD`|
|Blue Tone|null|Quickshade Washes Set|13|37|64|![#0D2540](https://placehold.co/15x15/0D2540/0D2540.png) `#0D2540`|
|Blue Tone|WP1139|Warpaints Tone|17|42|71|![#112A47](https://placehold.co/15x15/112A47/112A47.png) `#112A47`|
|Blue Tone|null|Warpaints Fanatic Wash|19|43|71|![#132B47](https://placehold.co/15x15/132B47/132B47.png) `#132B47`|
|Bogey Green|null|Warpaints Air|161|189|103|![#A1BD67](https://placehold.co/15x15/A1BD67/A1BD67.png) `#A1BD67`|
|Boney Spikes|null|Warpaints Fanatic|230|212|193|![#E6D4C1](https://placehold.co/15x15/E6D4C1/E6D4C1.png) `#E6D4C1`|
|Bony Matter|null|Speedpaint Set 2.0|182|148|113|![#B69471](https://placehold.co/15x15/B69471/B69471.png) `#B69471`|
|Bootstrap Brown|null|Warpaints Fanatic|93|77|77|![#5D4D4D](https://placehold.co/15x15/5D4D4D/5D4D4D.png) `#5D4D4D`|
|Brainmatter Beige|null|Warpaints Fanatic|222|219|211|![#DEDBD3](https://placehold.co/15x15/DEDBD3/DEDBD3.png) `#DEDBD3`|
|Brainmatter Beige|WP1405|Warpaints|241|242|226|![#F1F2E2](https://placehold.co/15x15/F1F2E2/F1F2E2.png) `#F1F2E2`|
|Brazen Copper|null|Speedpaint Set 2.0|106|61|55|![#6A3D37](https://placehold.co/15x15/6A3D37/6A3D37.png) `#6A3D37`|
|Brethil Flesh|null|Warpaints Air|196|145|90|![#C4915A](https://placehold.co/15x15/C4915A/C4915A.png) `#C4915A`|
|Brigade Grey|null|Warpaints Fanatic|208|208|210|![#D0D0D2](https://placehold.co/15x15/D0D0D2/D0D0D2.png) `#D0D0D2`|
|Brigadine Brown|null|Warpaints Fanatic|68|58|64|![#443A40](https://placehold.co/15x15/443A40/443A40.png) `#443A40`|
|Bright Gold|null|Warpaints Air|180|128|36|![#B48024](https://placehold.co/15x15/B48024/B48024.png) `#B48024`|
|Bright Gold|null|Warpaints Fanatic|152|123|26|![#987B1A](https://placehold.co/15x15/987B1A/987B1A.png) `#987B1A`|
|Bright Gold|WP1144|Warpaints|187|135|2|![#BB8702](https://placehold.co/15x15/BB8702/BB8702.png) `#BB8702`|
|Bright Red|null|Speedpaint Set 2.0|225|90|61|![#E15A3D](https://placehold.co/15x15/E15A3D/E15A3D.png) `#E15A3D`|
|Bright Sapphire|null|Warpaints Fanatic|132|206|240|![#84CEF0](https://placehold.co/15x15/84CEF0/84CEF0.png) `#84CEF0`|
|Broadsword Silver|null|Speedpaint Set 2.0|89|88|84|![#595854](https://placehold.co/15x15/595854/595854.png) `#595854`|
|Broodmother Purple|null|Warpaints Air|38|35|59|![#26233B](https://placehold.co/15x15/26233B/26233B.png) `#26233B`|
|Brown Wash|null|D&D Nolzur's Marvelous Pigments Wash|53|42|22|![#352A16](https://placehold.co/15x15/352A16/352A16.png) `#352A16`|
|Brownish Decay|null|Speedpaint Set 2.0|123|108|51|![#7B6C33](https://placehold.co/15x15/7B6C33/7B6C33.png) `#7B6C33`|
|Brush-On Primer|null|Warpaints Fanatic Wash|114|116|117|![#727475](https://placehold.co/15x15/727475/727475.png) `#727475`|
|Brush-On Primer|WP1472|Warpaints Primer|160|163|162|![#A0A3A2](https://placehold.co/15x15/A0A3A2/A0A3A2.png) `#A0A3A2`|
|Buffed Hide|null|Warpaints Fanatic|179|117|106|![#B3756A](https://placehold.co/15x15/B3756A/B3756A.png) `#B3756A`|
|Bugbear Brown|null|D&D Nolzur's Marvelous Pigments|123|86|30|![#7B561E](https://placehold.co/15x15/7B561E/7B561E.png) `#7B561E`|
|Bullwhack Brown|null|Warpaints Air|138|98|67|![#8A6243](https://placehold.co/15x15/8A6243/8A6243.png) `#8A6243`|
|Burning Ore|null|Warpaints Fanatic|242|101|62|![#F2653E](https://placehold.co/15x15/F2653E/F2653E.png) `#F2653E`|
|Burnished Red|null|Speedpaint Set 2.0|99|59|51|![#633B33](https://placehold.co/15x15/633B33/633B33.png) `#633B33`|
|Burnt Moss|null|Speedpaint Set 2.0|77|90|80|![#4D5A50](https://placehold.co/15x15/4D5A50/4D5A50.png) `#4D5A50`|
|Burnt Turf|null|Warpaints Fanatic|190|152|89|![#BE9859](https://placehold.co/15x15/BE9859/BE9859.png) `#BE9859`|
|Cadre Grey|null|Warpaints Air|142|153|153|![#8E9999](https://placehold.co/15x15/8E9999/8E9999.png) `#8E9999`|
|Cambion Crimson|null|D&D Nolzur's Marvelous Pigments|156|26|29|![#9C1A1D](https://placehold.co/15x15/9C1A1D/9C1A1D.png) `#9C1A1D`|
|Camo Cloak|null|Speedpaint Set 2.0|90|113|59|![#5A713B](https://placehold.co/15x15/5A713B/5A713B.png) `#5A713B`|
|Camo Cloak|null|Speedpaint Set|83|102|57|![#536639](https://placehold.co/15x15/536639/536639.png) `#536639`|
|Camouflage Green|null|Warpaints Fanatic|110|131|88|![#6E8358](https://placehold.co/15x15/6E8358/6E8358.png) `#6E8358`|
|Canopy Green|null|Warpaints Air|171|190|85|![#ABBE55](https://placehold.co/15x15/ABBE55/ABBE55.png) `#ABBE55`|
|Caribbean Ocean|null|Speedpaint Set 2.0|9|166|181|![#09A6B5](https://placehold.co/15x15/09A6B5/09A6B5.png) `#09A6B5`|
|Carmine Dragon|null|Speedpaint Set 2.0|220|48|88|![#DC3058](https://placehold.co/15x15/DC3058/DC3058.png) `#DC3058`|
|Carnelian Skin|null|Warpaints Fanatic|93|62|70|![#5D3E46](https://placehold.co/15x15/5D3E46/5D3E46.png) `#5D3E46`|
|Castle Grey|WP1407|Warpaints|141|136|127|![#8D887F](https://placehold.co/15x15/8D887F/8D887F.png) `#8D887F`|
|Centaur Skin|WP1408|Warpaints|227|177|165|![#E3B1A5](https://placehold.co/15x15/E3B1A5/E3B1A5.png) `#E3B1A5`|
|Chaotic Red|null|Warpaints Air|88|32|19|![#582013](https://placehold.co/15x15/582013/582013.png) `#582013`|
|Chaotic Red|CP3026|Warpaints Primer|108|42|49|![#6C2A31](https://placehold.co/15x15/6C2A31/6C2A31.png) `#6C2A31`|
|Chaotic Red|WP1142|Warpaints|111|29|6|![#6F1D06](https://placehold.co/15x15/6F1D06/6F1D06.png) `#6F1D06`|
|Charming Chartreuse|null|Speedpaint Set 2.0|201|207|71|![#C9CF47](https://placehold.co/15x15/C9CF47/C9CF47.png) `#C9CF47`|
|Charred Bone|null|Warpaints Air|140|119|87|![#8C7757](https://placehold.co/15x15/8C7757/8C7757.png) `#8C7757`|
|Chimera Red|null|Warpaints Air|98|23|35|![#621723](https://placehold.co/15x15/621723/621723.png) `#621723`|
|Cloudburst Blue|null|Speedpaint Set 2.0|60|66|88|![#3C4258](https://placehold.co/15x15/3C4258/3C4258.png) `#3C4258`|
|Cloudburst Blue|null|Speedpaint Set|54|70|83|![#364653](https://placehold.co/15x15/364653/364653.png) `#364653`|
|Cobalt Metal|null|Warpaints Fanatic|46|66|73|![#2E4249](https://placehold.co/15x15/2E4249/2E4249.png) `#2E4249`|
|Cold Flesh|null|D&D Undead Set|231|240|249|![#E7F0F9](https://placehold.co/15x15/E7F0F9/E7F0F9.png) `#E7F0F9`|
|Combat Fatigues|WP1409|Warpaints|134|142|89|![#868E59](https://placehold.co/15x15/868E59/868E59.png) `#868E59`|
|Command Khaki|null|Warpaints Fanatic|180|148|136|![#B49488](https://placehold.co/15x15/B49488/B49488.png) `#B49488`|
|Commando Green|WP1410|Warpaints|132|127|55|![#847F37](https://placehold.co/15x15/847F37/847F37.png) `#847F37`|
|Company Grey|null|Warpaints Fanatic|188|190|194|![#BCBEC2](https://placehold.co/15x15/BCBEC2/BCBEC2.png) `#BCBEC2`|
|Consul Blue|null|Warpaints Air|82|104|153|![#526899](https://placehold.co/15x15/526899/526899.png) `#526899`|
|Corpse Pale|WP1411|Warpaints|239|208|175|![#EFD0AF](https://placehold.co/15x15/EFD0AF/EFD0AF.png) `#EFD0AF`|
|Cosmic Dust|null|Warpaints Air|238|228|125|![#EEE47D](https://placehold.co/15x15/EEE47D/EEE47D.png) `#EEE47D`|
|Coven Purple|null|Warpaints Air|123|90|133|![#7B5A85](https://placehold.co/15x15/7B5A85/7B5A85.png) `#7B5A85`|
|Crow Hue|null|Warpaints Air|66|75|71|![#424B47](https://placehold.co/15x15/424B47/424B47.png) `#424B47`|
|Crusader Skin|null|Speedpaint Set 2.0|235|154|91|![#EB9A5B](https://placehold.co/15x15/EB9A5B/EB9A5B.png) `#EB9A5B`|
|Crusader Skin|null|Speedpaint Set|210|141|87|![#D28D57](https://placehold.co/15x15/D28D57/D28D57.png) `#D28D57`|
|Crusted Sore|WP1412|Warpaints|132|48|70|![#843046](https://placehold.co/15x15/843046/843046.png) `#843046`|
|Crypt Wraith|WP1413|Warpaints|93|95|77|![#5D5F4D](https://placehold.co/15x15/5D5F4D/5D5F4D.png) `#5D5F4D`|
|Crystal Blue|CP3017|Warpaints Primer|37|128|186|![#2580BA](https://placehold.co/15x15/2580BA/2580BA.png) `#2580BA`|
|Crystal Blue|null|Warpaints Fanatic|2|115|188|![#0273BC](https://placehold.co/15x15/0273BC/0273BC.png) `#0273BC`|
|Crystal Blue|null|Warpaints Air|16|109|172|![#106DAC](https://placehold.co/15x15/106DAC/106DAC.png) `#106DAC`|
|Crystal Blue|WP1114|Warpaints|37|121|187|![#2579BB](https://placehold.co/15x15/2579BB/2579BB.png) `#2579BB`|
|Cultist Purple|null|Warpaints Fanatic|105|98|171|![#6962AB](https://placehold.co/15x15/6962AB/6962AB.png) `#6962AB`|
|Cultist Robe|WP1414|Warpaints|120|113|100|![#787164](https://placehold.co/15x15/787164/787164.png) `#787164`|
|Cursed Blade|null|D&D Undead Set|123|72|42|![#7B482A](https://placehold.co/15x15/7B482A/7B482A.png) `#7B482A`|
|Cypress Brown|null|Warpaints Air|84|69|55|![#544537](https://placehold.co/15x15/544537/544537.png) `#544537`|
|Daemonic Yellow|WP1107|Warpaints|248|191|62|![#F8BF3E](https://placehold.co/15x15/F8BF3E/F8BF3E.png) `#F8BF3E`|
|Daemonic Yellow|null|Warpaints Fanatic|254|206|42|![#FECE2A](https://placehold.co/15x15/FECE2A/FECE2A.png) `#FECE2A`|
|Daemonic Yellow|CP3015|Warpaints Primer|247|210|1|![#F7D201](https://placehold.co/15x15/F7D201/F7D201.png) `#F7D201`|
|Daemonic Yellow|null|Warpaints Air|241|209|47|![#F1D12F](https://placehold.co/15x15/F1D12F/F1D12F.png) `#F1D12F`|
|Dark Blue Tone|null|Warpaints Fanatic Wash|23|32|46|![#17202E](https://placehold.co/15x15/17202E/17202E.png) `#17202E`|
|Dark Emerald|null|Warpaints Fanatic|59|74|37|![#3B4A25](https://placehold.co/15x15/3B4A25/3B4A25.png) `#3B4A25`|
|Dark Red Tone|null|Warpaints Fanatic Wash|46|19|26|![#2E131A](https://placehold.co/15x15/2E131A/2E131A.png) `#2E131A`|
|Dark Rust|null|Warpaints Fanatic Wash|41|15|18|![#290F12](https://placehold.co/15x15/290F12/290F12.png) `#290F12`|
|Dark Skin Shade|null|Warpaints Fanatic Wash|68|54|56|![#443638](https://placehold.co/15x15/443638/443638.png) `#443638`|
|Dark Skin Wash|null|Skin Tones Paint Set - Washes|51|33|35|![#332123](https://placehold.co/15x15/332123/332123.png) `#332123`|
|Dark Sky|null|Warpaints Air|53|70|83|![#354653](https://placehold.co/15x15/354653/354653.png) `#354653`|
|Dark Sky|WP1415|Warpaints|49|79|94|![#314F5E](https://placehold.co/15x15/314F5E/314F5E.png) `#314F5E`|
|Dark Stone|WP1425|Warpaints|73|56|60|![#49383C](https://placehold.co/15x15/49383C/49383C.png) `#49383C`|
|Dark Tone|null|Quickshade Washes Set|12|6|14|![#0C060E](https://placehold.co/15x15/0C060E/0C060E.png) `#0C060E`|
|Dark Tone|null|Warpaints Fanatic Wash|31|31|31|![#1F1F1F](https://placehold.co/15x15/1F1F1F/1F1F1F.png) `#1F1F1F`|
|Dark Tone|WP1136|Warpaints Tone|5|5|5|![#050505](https://placehold.co/15x15/050505/050505.png) `#050505`|
|Dark Wood|null|Speedpaint Set 2.0|72|45|26|![#482D1A](https://placehold.co/15x15/482D1A/482D1A.png) `#482D1A`|
|Dark Wood|null|Speedpaint Set|58|36|21|![#3A2415](https://placehold.co/15x15/3A2415/3A2415.png) `#3A2415`|
|Data System Glow|null|Warpaints Fanatic Wash|135|200|102|![#87C866](https://placehold.co/15x15/87C866/87C866.png) `#87C866`|
|Death Metal|null|Warpaints Fanatic|43|43|43|![#2B2B2B](https://placehold.co/15x15/2B2B2B/2B2B2B.png) `#2B2B2B`|
|Deep Azure|null|Warpaints Fanatic|0|107|121|![#006B79](https://placehold.co/15x15/006B79/006B79.png) `#006B79`|
|Deep Blue|WP1116|Warpaints|14|78|118|![#0E4E76](https://placehold.co/15x15/0E4E76/0E4E76.png) `#0E4E76`|
|Deep Grey|null|Warpaints Fanatic|75|81|100|![#4B5164](https://placehold.co/15x15/4B5164/4B5164.png) `#4B5164`|
|Deep Ocean Blue|null|Warpaints Fanatic|27|48|68|![#1B3044](https://placehold.co/15x15/1B3044/1B3044.png) `#1B3044`|
|Demigod Flames|null|Warpaints Fanatic|209|123|65|![#D17B41](https://placehold.co/15x15/D17B41/D17B41.png) `#D17B41`|
|Desert Yellow|null|Warpaints Fanatic|133|109|69|![#856D45](https://placehold.co/15x15/856D45/856D45.png) `#856D45`|
|Desert Yellow|WP1121|Warpaints|215|149|90|![#D7955A](https://placehold.co/15x15/D7955A/D7955A.png) `#D7955A`|
|Desert Yellow|CP3011|Warpaints Primer|193|140|23|![#C18C17](https://placehold.co/15x15/C18C17/C18C17.png) `#C18C17`|
|Desert Yellow|null|Warpaints Air|185|144|41|![#B99029](https://placehold.co/15x15/B99029/B99029.png) `#B99029`|
|Desolate Brown|null|Speedpaint Set 2.0|122|112|59|![#7A703B](https://placehold.co/15x15/7A703B/7A703B.png) `#7A703B`|
|Diabolic Plum|null|Warpaints Fanatic|86|45|116|![#562D74](https://placehold.co/15x15/562D74/562D74.png) `#562D74`|
|Dirt Spatter|WP1416|Warpaints|96|57|32|![#603920](https://placehold.co/15x15/603920/603920.png) `#603920`|
|Disgusting Slime|null|Warpaints Fanatic Wash|165|195|69|![#A5C345](https://placehold.co/15x15/A5C345/A5C345.png) `#A5C345`|
|Disgusting Slime|WP1477|Warpaints|203|181|3|![#CBB503](https://placehold.co/15x15/CBB503/CBB503.png) `#CBB503`|
|Diviner Light|null|Warpaints Fanatic|213|159|197|![#D59FC5](https://placehold.co/15x15/D59FC5/D59FC5.png) `#D59FC5`|
|Doomfire Drab|null|Warpaints Fanatic|249|217|230|![#F9D9E6](https://placehold.co/15x15/F9D9E6/F9D9E6.png) `#F9D9E6`|
|Dorado Skin|null|Skin Tones Paint Set|169|119|97|![#A97761](https://placehold.co/15x15/A97761/A97761.png) `#A97761`|
|Dorado Skin|null|Warpaints Fanatic|238|199|158|![#EEC79E](https://placehold.co/15x15/EEC79E/EEC79E.png) `#EEC79E`|
|Drab Green|null|Warpaints Air|127|129|92|![#7F815C](https://placehold.co/15x15/7F815C/7F815C.png) `#7F815C`|
|Dragon Red|CP3018|Warpaints Primer|149|37|38|![#952526](https://placehold.co/15x15/952526/952526.png) `#952526`|
|Dragon Red|null|Warpaints Air|124|25|27|![#7C191B](https://placehold.co/15x15/7C191B/7C191B.png) `#7C191B`|
|Dragon Red|null|Warpaints Fanatic|191|40|59|![#BF283B](https://placehold.co/15x15/BF283B/BF283B.png) `#BF283B`|
|Dragon Red|WP1105|Warpaints|185|17|48|![#B91130](https://placehold.co/15x15/B91130/B91130.png) `#B91130`|
|Dragonfire Red|null|D&D Nolzur's Marvelous Pigments|207|37|41|![#CF2529](https://placehold.co/15x15/CF2529/CF2529.png) `#CF2529`|
|Drake Tooth|WP1417|Warpaints|213|210|189|![#D5D2BD](https://placehold.co/15x15/D5D2BD/D5D2BD.png) `#D5D2BD`|
|Drakolich Scales|null|D&D Undead Set|109|127|163|![#6D7FA3](https://placehold.co/15x15/6D7FA3/6D7FA3.png) `#6D7FA3`|
|Dry Blood|null|Warpaints Fanatic Wash|36|0|14|![#24000E](https://placehold.co/15x15/24000E/24000E.png) `#24000E`|
|Dry Rust|WP1479|Warpaints|231|79|53|![#E74F35](https://placehold.co/15x15/E74F35/E74F35.png) `#E74F35`|
|Dryad Brown|null|Warpaints Fanatic|97|54|48|![#613630](https://placehold.co/15x15/613630/613630.png) `#613630`|
|Duergar Metal|null|D&D Underdark Set|88|33|33|![#582121](https://placehold.co/15x15/582121/582121.png) `#582121`|
|Dungeon Grey|WP1418|Warpaints|103|107|112|![#676B70](https://placehold.co/15x15/676B70/676B70.png) `#676B70`|
|Dungeon Stone|null|D&D Nolzur's Marvelous Pigments|102|109|116|![#666D74](https://placehold.co/15x15/666D74/666D74.png) `#666D74`|
|Dusk Red|null|Speedpaint Set 2.0|96|62|61|![#603E3D](https://placehold.co/15x15/603E3D/603E3D.png) `#603E3D`|
|Dusty Skull|null|Warpaints Fanatic|139|124|104|![#8B7C68](https://placehold.co/15x15/8B7C68/8B7C68.png) `#8B7C68`|
|Dwarven Bronze|null|D&D Nolzur's Marvelous Pigments|205|96|31|![#CD601F](https://placehold.co/15x15/CD601F/CD601F.png) `#CD601F`|
|Elder Flower|null|Warpaints Fanatic|168|87|123|![#A8577B](https://placehold.co/15x15/A8577B/A8577B.png) `#A8577B`|
|Electric Blue|WP1113|Warpaints|82|136|184|![#5288B8](https://placehold.co/15x15/5288B8/5288B8.png) `#5288B8`|
|Electric Lime|null|Warpaints Fanatic|189|213|50|![#BDD532](https://placehold.co/15x15/BDD532/BDD532.png) `#BDD532`|
|Elemental Bolt|WP1419|Warpaints|21|142|118|![#158E76](https://placehold.co/15x15/158E76/158E76.png) `#158E76`|
|Elemental Bolt|null|Warpaints Air|0|129|108|![#00816C](https://placehold.co/15x15/00816C/00816C.png) `#00816C`|
|Elf Green|WP1420|Warpaints|75|82|18|![#4B5212](https://placehold.co/15x15/4B5212/4B5212.png) `#4B5212`|
|Elven Armor|null|Warpaints Air|27|48|97|![#1B3061](https://placehold.co/15x15/1B3061/1B3061.png) `#1B3061`|
|Elven Armour|null|Metallic Colours Paint Set|0|61|129|![#003D81](https://placehold.co/15x15/003D81/003D81.png) `#003D81`|
|Elven Flesh|null|Warpaints Air|230|173|134|![#E6AD86](https://placehold.co/15x15/E6AD86/E6AD86.png) `#E6AD86`|
|Elven Flesh|WP1421|Warpaints|249|190|148|![#F9BE94](https://placehold.co/15x15/F9BE94/F9BE94.png) `#F9BE94`|
|Emerald Forest|null|Warpaints Fanatic|91|187|77|![#5BBB4D](https://placehold.co/15x15/5BBB4D/5BBB4D.png) `#5BBB4D`|
|Encarmine Red|null|Warpaints Air|114|24|36|![#721824](https://placehold.co/15x15/721824/721824.png) `#721824`|
|Enchanted Pink|null|Warpaints Fanatic|182|108|174|![#B66CAE](https://placehold.co/15x15/B66CAE/B66CAE.png) `#B66CAE`|
|Enchanted Steel|null|Speedpaint Set 2.0|79|89|91|![#4F595B](https://placehold.co/15x15/4F595B/4F595B.png) `#4F595B`|
|Eternal Blue|null|D&D Nolzur's Marvelous Pigments|90|127|147|![#5A7F93](https://placehold.co/15x15/5A7F93/5A7F93.png) `#5A7F93`|
|Eternal Hunt|null|Warpaints Fanatic|39|154|76|![#279A4C](https://placehold.co/15x15/279A4C/279A4C.png) `#279A4C`|
|Ethereal Specter|null|D&D Undead Set|193|175|187|![#C1AFBB](https://placehold.co/15x15/C1AFBB/C1AFBB.png) `#C1AFBB`|
|Evergreen Fog|null|Warpaints Fanatic|57|99|96|![#396360](https://placehold.co/15x15/396360/396360.png) `#396360`|
|Evil Chrome|null|Metallic Colours Paint Set|164|96|73|![#A46049](https://placehold.co/15x15/A46049/A46049.png) `#A46049`|
|Evil Chrome|null|Warpaints Fanatic|91|59|47|![#5B3B2F](https://placehold.co/15x15/5B3B2F/5B3B2F.png) `#5B3B2F`|
|Evil Chrome|null|Warpaints Air|100|65|51|![#644133](https://placehold.co/15x15/644133/644133.png) `#644133`|
|Exile Green|null|Warpaints Air|76|104|91|![#4C685B](https://placehold.co/15x15/4C685B/4C685B.png) `#4C685B`|
|Faerzress Purple|null|D&D Underdark Set|135|20|110|![#87146E](https://placehold.co/15x15/87146E/87146E.png) `#87146E`|
|Fair Skin|null|D&D Nolzur's Marvelous Pigments|234|205|173|![#EACDAD](https://placehold.co/15x15/EACDAD/EACDAD.png) `#EACDAD`|
|Fairy Dust|null|Warpaints Air|140|140|140|![#8C8C8C](https://placehold.co/15x15/8C8C8C/8C8C8C.png) `#8C8C8C`|
|Fairy Dust|null|Metallic Colours Paint Set|169|60|39|![#A93C27](https://placehold.co/15x15/A93C27/A93C27.png) `#A93C27`|
|Fairy Pink|null|Warpaints Air|129|55|95|![#81375F](https://placehold.co/15x15/81375F/81375F.png) `#81375F`|
|Familiar Pink|null|Speedpaint Set 2.0|214|47|127|![#D62F7F](https://placehold.co/15x15/D62F7F/D62F7F.png) `#D62F7F`|
|Feral Green|null|Warpaints Air|93|135|88|![#5D8758](https://placehold.co/15x15/5D8758/5D8758.png) `#5D8758`|
|Ferocious Green|null|Warpaints Fanatic|117|195|119|![#75C377](https://placehold.co/15x15/75C377/75C377.png) `#75C377`|
|Fey Pink|null|Warpaints Air|195|132|166|![#C384A6](https://placehold.co/15x15/C384A6/C384A6.png) `#C384A6`|
|Feywild Emerald|null|D&D Nolzur's Marvelous Pigments|0|110|64|![#006E40](https://placehold.co/15x15/006E40/006E40.png) `#006E40`|
|Feywild Glow|null|Warpaints Air|242|204|158|![#F2CC9E](https://placehold.co/15x15/F2CC9E/F2CC9E.png) `#F2CC9E`|
|Field Grey|WP1481|Warpaints|125|128|123|![#7D807B](https://placehold.co/15x15/7D807B/7D807B.png) `#7D807B`|
|Fiendish Yellow|null|Warpaints Fanatic|236|154|68|![#EC9A44](https://placehold.co/15x15/EC9A44/EC9A44.png) `#EC9A44`|
|Figgy Pink|null|Warpaints Fanatic|227|175|201|![#E3AFC9](https://placehold.co/15x15/E3AFC9/E3AFC9.png) `#E3AFC9`|
|Filthy Cape|WP1424|Warpaints|125|120|90|![#7D785A](https://placehold.co/15x15/7D785A/7D785A.png) `#7D785A`|
|Fire Drake|null|Speedpaint Set 2.0|210|145|107|![#D2916B](https://placehold.co/15x15/D2916B/D2916B.png) `#D2916B`|
|Fire Giant Orange|null|Speedpaint Set|190|63|32|![#BE3F20](https://placehold.co/15x15/BE3F20/BE3F20.png) `#BE3F20`|
|Fire Giant Orange|null|Speedpaint Set 2.0|231|121|36|![#E77924](https://placehold.co/15x15/E77924/E77924.png) `#E77924`|
|Fire Lizard|WP1426|Warpaints|240|112|0|![#F07000](https://placehold.co/15x15/F07000/F07000.png) `#F07000`|
|Firenewt Orange|null|D&D Nolzur's Marvelous Pigments|246|170|13|![#F6AA0D](https://placehold.co/15x15/F6AA0D/F6AA0D.png) `#F6AA0D`|
|Flesh Wash|WP1143|Warpaints Tone|74|27|14|![#4A1B0E](https://placehold.co/15x15/4A1B0E/4A1B0E.png) `#4A1B0E`|
|Flesh Wash|null|Quickshade Washes Set|68|21|23|![#441517](https://placehold.co/15x15/441517/441517.png) `#441517`|
|Flesh Wash|null|D&D Nolzur's Marvelous Pigments Wash|75|27|14|![#4B1B0E](https://placehold.co/15x15/4B1B0E/4B1B0E.png) `#4B1B0E`|
|Flickering Flame|null|Warpaints Fanatic|245|139|61|![#F58B3D](https://placehold.co/15x15/F58B3D/F58B3D.png) `#F58B3D`|
|Flumph Pink|null|D&D Nolzur's Marvelous Pigments|230|157|99|![#E69D63](https://placehold.co/15x15/E69D63/E69D63.png) `#E69D63`|
|Fog Grey|WP1427|Warpaints|122|151|177|![#7A97B1](https://placehold.co/15x15/7A97B1/7A97B1.png) `#7A97B1`|
|Forbidden Fruit|null|Warpaints Fanatic|205|136|169|![#CD88A9](https://placehold.co/15x15/CD88A9/CD88A9.png) `#CD88A9`|
|Forest Faun|null|Warpaints Fanatic|161|199|175|![#A1C7AF](https://placehold.co/15x15/A1C7AF/A1C7AF.png) `#A1C7AF`|
|Forest Sprite|null|Speedpaint Set 2.0|111|160|69|![#6FA045](https://placehold.co/15x15/6FA045/6FA045.png) `#6FA045`|
|Fresh Rust|null|Warpaints Fanatic Wash|194|84|40|![#C25428](https://placehold.co/15x15/C25428/C25428.png) `#C25428`|
|Frost Blue|null|D&D Nolzur's Marvelous Pigments|0|128|191|![#0080BF](https://placehold.co/15x15/0080BF/0080BF.png) `#0080BF`|
|Frost Blue|null|Warpaints Fanatic|154|190|222|![#9ABEDE](https://placehold.co/15x15/9ABEDE/9ABEDE.png) `#9ABEDE`|
|Fur Brown|null|Warpaints Air|132|53|29|![#84351D](https://placehold.co/15x15/84351D/84351D.png) `#84351D`|
|Fur Brown|null|Warpaints Fanatic|119|69|68|![#774544](https://placehold.co/15x15/774544/774544.png) `#774544`|
|Fur Brown|CP3016|Warpaints Primer|153|56|34|![#993822](https://placehold.co/15x15/993822/993822.png) `#993822`|
|Fur Brown|WP1122|Warpaints|161|58|15|![#A13A0F](https://placehold.co/15x15/A13A0F/A13A0F.png) `#A13A0F`|
|Gargoyle Grey|null|Warpaints Fanatic|168|162|146|![#A8A292](https://placehold.co/15x15/A8A292/A8A292.png) `#A8A292`|
|Garment Pigment Toner|null|Skin Tones Paint Set|117|35|48|![#752330](https://placehold.co/15x15/752330/752330.png) `#752330`|
|Gauss Green|null|Warpaints Air|99|163|60|![#63A33C](https://placehold.co/15x15/63A33C/63A33C.png) `#63A33C`|
|Gelatinous Blue|null|D&D Nolzur's Marvelous Pigments|199|207|227|![#C7CFE3](https://placehold.co/15x15/C7CFE3/C7CFE3.png) `#C7CFE3`|
|Gemstone|null|Metallic Colours Paint Set|174|28|40|![#AE1C28](https://placehold.co/15x15/AE1C28/AE1C28.png) `#AE1C28`|
|Gemstone|null|Warpaints Air|105|25|31|![#69191F](https://placehold.co/15x15/69191F/69191F.png) `#69191F`|
|Gemstone Red|null|Warpaints Fanatic|130|29|35|![#821D23](https://placehold.co/15x15/821D23/821D23.png) `#821D23`|
|Ghillie Dew|null|Speedpaint Set 2.0|144|172|35|![#90AC23](https://placehold.co/15x15/90AC23/90AC23.png) `#90AC23`|
|Ghostly Blue|null|D&D Nolzur's Marvelous Pigments|58|157|213|![#3A9DD5](https://placehold.co/15x15/3A9DD5/3A9DD5.png) `#3A9DD5`|
|Ghostly Vapours|null|D&D Undead Set|165|197|192|![#A5C5C0](https://placehold.co/15x15/A5C5C0/A5C5C0.png) `#A5C5C0`|
|Ghoul Green|null|Speedpaint Set 2.0|68|169|99|![#44A963](https://placehold.co/15x15/44A963/44A963.png) `#44A963`|
|Ghoul Grey|null|D&D Undead Set|185|190|196|![#B9BEC4](https://placehold.co/15x15/B9BEC4/B9BEC4.png) `#B9BEC4`|
|Glistening Blood|WP1476|Warpaints|179|8|45|![#B3082D](https://placehold.co/15x15/B3082D/B3082D.png) `#B3082D`|
|Glistening Blood|null|D&D Nolzur's Marvelous Pigments Wash|187|41|41|![#BB2929](https://placehold.co/15x15/BB2929/BB2929.png) `#BB2929`|
|Glitter Green|null|Metallic Colours Paint Set|0|123|58|![#007B3A](https://placehold.co/15x15/007B3A/007B3A.png) `#007B3A`|
|Glitter Green|null|Warpaints Air|46|90|47|![#2E5A2F](https://placehold.co/15x15/2E5A2F/2E5A2F.png) `#2E5A2F`|
|Glittering Green|null|Warpaints Fanatic|46|121|74|![#2E794A](https://placehold.co/15x15/2E794A/2E794A.png) `#2E794A`|
|Glittering Loot|null|Speedpaint Set 2.0|131|102|8|![#836608](https://placehold.co/15x15/836608/836608.png) `#836608`|
|Gloss Varnish|WP1473|Warpaints|247|247|247|![#F7F7F7](https://placehold.co/15x15/F7F7F7/F7F7F7.png) `#F7F7F7`|
|Glowing Inferno|null|Warpaints Fanatic|247|157|66|![#F79D42](https://placehold.co/15x15/F79D42/F79D42.png) `#F79D42`|
|Gnome Cheeks|null|Warpaints Air|151|131|118|![#978376](https://placehold.co/15x15/978376/978376.png) `#978376`|
|Goblin Green|null|Warpaints Air|82|133|54|![#528536](https://placehold.co/15x15/528536/528536.png) `#528536`|
|Goblin Green|CP3024|Warpaints Primer|30|132|48|![#1E8430](https://placehold.co/15x15/1E8430/1E8430.png) `#1E8430`|
|Goblin Green|WP1109|Warpaints|51|142|70|![#338E46](https://placehold.co/15x15/338E46/338E46.png) `#338E46`|
|Goblin Skin|WP1720|D&D Nolzur's Marvelous Pigments|224|178|106|![#E0B26A](https://placehold.co/15x15/E0B26A/E0B26A.png) `#E0B26A`|
|Goddess Glow|null|Speedpaint Set 2.0|154|87|81|![#9A5751](https://placehold.co/15x15/9A5751/9A5751.png) `#9A5751`|
|Golden Armour|null|Speedpaint Set 2.0|113|72|8|![#714808](https://placehold.co/15x15/714808/714808.png) `#714808`|
|Gorgon Hide|WP1428|Warpaints|207|215|231|![#CFD7E7](https://placehold.co/15x15/CFD7E7/CFD7E7.png) `#CFD7E7`|
|Gothic Blue|null|Warpaints Fanatic|46|62|121|![#2E3E79](https://placehold.co/15x15/2E3E79/2E3E79.png) `#2E3E79`|
|Gravelord Grey|null|Speedpaint Set 2.0|68|71|76|![#44474C](https://placehold.co/15x15/44474C/44474C.png) `#44474C`|
|Gravelord Grey|null|Speedpaint Set|41|41|43|![#29292B](https://placehold.co/15x15/29292B/29292B.png) `#29292B`|
|Great Hall Grey|null|Warpaints Fanatic|187|180|166|![#BBB4A6](https://placehold.co/15x15/BBB4A6/BBB4A6.png) `#BBB4A6`|
|Greedy Gold|WP1132|Warpaints|204|125|0|![#CC7D00](https://placehold.co/15x15/CC7D00/CC7D00.png) `#CC7D00`|
|Greedy Gold|null|Warpaints Fanatic|116|82|24|![#745218](https://placehold.co/15x15/745218/745218.png) `#745218`|
|Greedy Gold|null|Warpaints Air|163|88|25|![#A35819](https://placehold.co/15x15/A35819/A35819.png) `#A35819`|
|Green Flame|null|D&D Nolzur's Marvelous Pigments|129|172|54|![#81AC36](https://placehold.co/15x15/81AC36/81AC36.png) `#81AC36`|
|Green Tone|null|Quickshade Washes Set|15|43|24|![#0F2B18](https://placehold.co/15x15/0F2B18/0F2B18.png) `#0F2B18`|
|Green Tone|null|Warpaints Fanatic Wash|31|54|37|![#1F3625](https://placehold.co/15x15/1F3625/1F3625.png) `#1F3625`|
|Green Tone|WP1137|Warpaints Tone|22|47|18|![#162F12](https://placehold.co/15x15/162F12/162F12.png) `#162F12`|
|Greenskin|CP3014|Warpaints Primer|27|97|58|![#1B613A](https://placehold.co/15x15/1B613A/1B613A.png) `#1B613A`|
|Greenskin|null|Warpaints Fanatic|31|120|67|![#1F7843](https://placehold.co/15x15/1F7843/1F7843.png) `#1F7843`|
|Greenskin|WP1111|Warpaints|4|102|43|![#04662B](https://placehold.co/15x15/04662B/04662B.png) `#04662B`|
|Greenskin|null|Warpaints Air|44|92|47|![#2C5C2F](https://placehold.co/15x15/2C5C2F/2C5C2F.png) `#2C5C2F`|
|Gremlin Green|null|Warpaints Air|74|90|43|![#4A5A2B](https://placehold.co/15x15/4A5A2B/4A5A2B.png) `#4A5A2B`|
|Grey Castle|null|Warpaints Fanatic|146|146|134|![#929286](https://placehold.co/15x15/929286/929286.png) `#929286`|
|Grey Primer|null|D&D Nolzur's Marvelous Pigments Primer|145|146|150|![#919296](https://placehold.co/15x15/919296/919296.png) `#919296`|
|Griffon Blue|WP1429|Warpaints|32|71|122|![#20477A](https://placehold.co/15x15/20477A/20477A.png) `#20477A`|
|Grim Black|null|Speedpaint Set 2.0|22|21|17|![#161511](https://placehold.co/15x15/161511/161511.png) `#161511`|
|Grim Black|null|Speedpaint Set|25|25|21|![#191915](https://placehold.co/15x15/191915/191915.png) `#191915`|
|Grimoire Purple|WP1444|Warpaints|114|72|96|![#724860](https://placehold.co/15x15/724860/724860.png) `#724860`|
|Grotesque Green|null|Warpaints Fanatic|179|194|157|![#B3C29D](https://placehold.co/15x15/B3C29D/B3C29D.png) `#B3C29D`|
|Grung Green|WP1731|D&D Nolzur's Marvelous Pigments|157|194|158|![#9DC29E](https://placehold.co/15x15/9DC29E/9DC29E.png) `#9DC29E`|
|Guardian Green|null|Warpaints Fanatic|34|98|72|![#226248](https://placehold.co/15x15/226248/226248.png) `#226248`|
|Gun Metal|null|Warpaints Air|95|93|92|![#5F5D5C](https://placehold.co/15x15/5F5D5C/5F5D5C.png) `#5F5D5C`|
|Gun Metal|null|Warpaints Fanatic|79|80|83|![#4F5053](https://placehold.co/15x15/4F5053/4F5053.png) `#4F5053`|
|Gun Metal|CP3025|Warpaints Primer|133|129|128|![#858180](https://placehold.co/15x15/858180/858180.png) `#858180`|
|Gun Metal|WP1131|Warpaints|126|124|123|![#7E7C7B](https://placehold.co/15x15/7E7C7B/7E7C7B.png) `#7E7C7B`|
|Gunner Camo|null|Speedpaint Set 2.0|50|81|65|![#325141](https://placehold.co/15x15/325141/325141.png) `#325141`|
|Hardened Carapace|WP1430|Warpaints|68|69|59|![#44453B](https://placehold.co/15x15/44453B/44453B.png) `#44453B`|
|Hardened Leather|null|Speedpaint Set 2.0|140|80|30|![#8C501E](https://placehold.co/15x15/8C501E/8C501E.png) `#8C501E`|
|Hardened Leather|null|Speedpaint Set|104|70|31|![#68461F](https://placehold.co/15x15/68461F/68461F.png) `#68461F`|
|Hazardous Smog|null|Warpaints Air|96|171|151|![#60AB97](https://placehold.co/15x15/60AB97/60AB97.png) `#60AB97`|
|Hemp Rope|WP1431|Warpaints|151|124|58|![#977C3A](https://placehold.co/15x15/977C3A/977C3A.png) `#977C3A`|
|Hexed Violet|null|Warpaints Fanatic|141|129|190|![#8D81BE](https://placehold.co/15x15/8D81BE/8D81BE.png) `#8D81BE`|
|Highlord Blue|null|Speedpaint Set 2.0|27|86|130|![#1B5682](https://placehold.co/15x15/1B5682/1B5682.png) `#1B5682`|
|Highlord Blue|null|Speedpaint Set|42|73|116|![#2A4974](https://placehold.co/15x15/2A4974/2A4974.png) `#2A4974`|
|Hive Dweller Purple|null|Speedpaint Set 2.0|87|54|107|![#57366B](https://placehold.co/15x15/57366B/57366B.png) `#57366B`|
|Hive Dweller Purple|null|Speedpaint Set|62|37|97|![#3E2561](https://placehold.co/15x15/3E2561/3E2561.png) `#3E2561`|
|Hoard Bronze|null|Speedpaint Set 2.0|134|114|64|![#867240](https://placehold.co/15x15/867240/867240.png) `#867240`|
|Hobgoblin Hue|null|Warpaints Air|243|219|192|![#F3DBC0](https://placehold.co/15x15/F3DBC0/F3DBC0.png) `#F3DBC0`|
|Holy White|null|Speedpaint Set|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Holy White|null|Speedpaint Set 2.0|226|225|220|![#E2E1DC](https://placehold.co/15x15/E2E1DC/E2E1DC.png) `#E2E1DC`|
|Hoplite Gold|null|Speedpaint Set 2.0|144|115|23|![#907317](https://placehold.co/15x15/907317/907317.png) `#907317`|
|Hot Pink|null|Warpaints Air|203|68|133|![#CB4485](https://placehold.co/15x15/CB4485/CB4485.png) `#CB4485`|
|Howling Sand|null|Speedpaint Set 2.0|206|207|176|![#CECFB0](https://placehold.co/15x15/CECFB0/CECFB0.png) `#CECFB0`|
|Husk Brown|null|Warpaints Air|86|47|34|![#562F22](https://placehold.co/15x15/562F22/562F22.png) `#562F22`|
|Hydra Turqoise|WP1141|Warpaints|30|147|156|![#1E939C](https://placehold.co/15x15/1E939C/1E939C.png) `#1E939C`|
|Hydra Turquoise|null|Warpaints Air|39|117|129|![#277581](https://placehold.co/15x15/277581/277581.png) `#277581`|
|Hydra Turquoise|null|Warpaints Fanatic|20|147|152|![#149398](https://placehold.co/15x15/149398/149398.png) `#149398`|
|Ice Storm|WP1432|Warpaints|59|160|203|![#3BA0CB](https://placehold.co/15x15/3BA0CB/3BA0CB.png) `#3BA0CB`|
|Ice Yellow|null|Warpaints Fanatic|255|237|173|![#FFEDAD](https://placehold.co/15x15/FFEDAD/FFEDAD.png) `#FFEDAD`|
|Imp Yellow|null|Warpaints Air|227|190|106|![#E3BE6A](https://placehold.co/15x15/E3BE6A/E3BE6A.png) `#E3BE6A`|
|Imperial Navy|null|Warpaints Fanatic|6|53|101|![#063565](https://placehold.co/15x15/063565/063565.png) `#063565`|
|Impish Rouge|null|Warpaints Fanatic|217|87|160|![#D957A0](https://placehold.co/15x15/D957A0/D957A0.png) `#D957A0`|
|Incursion Orange|null|Warpaints Air|215|117|42|![#D7752A](https://placehold.co/15x15/D7752A/D7752A.png) `#D7752A`|
|Inner Light|null|Warpaints Fanatic|253|203|95|![#FDCB5F](https://placehold.co/15x15/FDCB5F/FDCB5F.png) `#FDCB5F`|
|Ionic Blue|null|Warpaints Air|57|146|197|![#3992C5](https://placehold.co/15x15/3992C5/3992C5.png) `#3992C5`|
|Iron Wolf|null|Warpaints Air|53|75|87|![#354B57](https://placehold.co/15x15/354B57/354B57.png) `#354B57`|
|Jasper Skin|null|Skin Tones Paint Set|131|70|65|![#834641](https://placehold.co/15x15/834641/834641.png) `#834641`|
|Jasper Skin|null|Warpaints Fanatic|186|115|114|![#BA7372](https://placehold.co/15x15/BA7372/BA7372.png) `#BA7372`|
|Jungle Green|null|Warpaints Air|119|159|55|![#779F37](https://placehold.co/15x15/779F37/779F37.png) `#779F37`|
|Jungle Green|WP1433|Warpaints|142|169|1|![#8EA901](https://placehold.co/15x15/8EA901/8EA901.png) `#8EA901`|
|Ki-Rin Gold|null|D&D Nolzur's Marvelous Pigments|175|129|2|![#AF8102](https://placehold.co/15x15/AF8102/AF8102.png) `#AF8102`|
|Kobold Red|null|D&D Nolzur's Marvelous Pigments|109|31|12|![#6D1F0C](https://placehold.co/15x15/6D1F0C/6D1F0C.png) `#6D1F0C`|
|Kobold Skin|null|Warpaints Air|199|156|121|![#C79C79](https://placehold.co/15x15/C79C79/C79C79.png) `#C79C79`|
|Kobold Skin|WP1434|Warpaints|216|157|143|![#D89D8F](https://placehold.co/15x15/D89D8F/D89D8F.png) `#D89D8F`|
|Kraken Blue|null|D&D Nolzur's Marvelous Pigments|5|94|143|![#055E8F](https://placehold.co/15x15/055E8F/055E8F.png) `#055E8F`|
|Kraken Lavender|null|Warpaints Fanatic|213|202|229|![#D5CAE5](https://placehold.co/15x15/D5CAE5/D5CAE5.png) `#D5CAE5`|
|Kraken Skin|WP1435|Warpaints|113|191|135|![#71BF87](https://placehold.co/15x15/71BF87/71BF87.png) `#71BF87`|
|Lava Orange|null|Warpaints Fanatic|245|121|44|![#F5792C](https://placehold.co/15x15/F5792C/F5792C.png) `#F5792C`|
|Lava Orange|WP1106|Warpaints|226|70|6|![#E24606](https://placehold.co/15x15/E24606/E24606.png) `#E24606`|
|Lava Orange|null|Warpaints Air|191|61|32|![#BF3D20](https://placehold.co/15x15/BF3D20/BF3D20.png) `#BF3D20`|
|Lawfull White|null|D&D Nolzur's Marvelous Pigments|254|255|255|![#FEFFFF](https://placehold.co/15x15/FEFFFF/FEFFFF.png) `#FEFFFF`|
|Leafy Green|null|Warpaints Fanatic|118|192|69|![#76C045](https://placehold.co/15x15/76C045/76C045.png) `#76C045`|
|Leather Brown|null|Warpaints Fanatic|124|91|84|![#7C5B54](https://placehold.co/15x15/7C5B54/7C5B54.png) `#7C5B54`|
|Leather Brown|WP1123|Warpaints|124|79|16|![#7C4F10](https://placehold.co/15x15/7C4F10/7C4F10.png) `#7C4F10`|
|Leather Brown|CP3004|Warpaints Primer|113|62|41|![#713E29](https://placehold.co/15x15/713E29/713E29.png) `#713E29`|
|Leather Brown|null|Warpaints Air|103|71|30|![#67471E](https://placehold.co/15x15/67471E/67471E.png) `#67471E`|
|Legendary Red|null|Warpaints Fanatic|239|75|62|![#EF4B3E](https://placehold.co/15x15/EF4B3E/EF4B3E.png) `#EF4B3E`|
|Lens Flare Glow|null|Warpaints Fanatic Wash|255|244|100|![#FFF464](https://placehold.co/15x15/FFF464/FFF464.png) `#FFF464`|
|Leopard Stone Skin|null|Warpaints Fanatic|231|180|177|![#E7B4B1](https://placehold.co/15x15/E7B4B1/E7B4B1.png) `#E7B4B1`|
|Leviathan Light|null|Warpaints Air|181|210|186|![#B5D2BA](https://placehold.co/15x15/B5D2BA/B5D2BA.png) `#B5D2BA`|
|Lich Blue|null|D&D Underdark Set|9|64|115|![#094073](https://placehold.co/15x15/094073/094073.png) `#094073`|
|Lich Skin|null|D&D Nolzur's Marvelous Pigments|131|130|123|![#83827B](https://placehold.co/15x15/83827B/83827B.png) `#83827B`|
|Light Tone|null|Quickshade Washes Set|171|59|44|![#AB3B2C](https://placehold.co/15x15/AB3B2C/AB3B2C.png) `#AB3B2C`|
|Light Tone|null|Warpaints Fanatic Wash|127|82|22|![#7F5216](https://placehold.co/15x15/7F5216/7F5216.png) `#7F5216`|
|Light Tone|WP1470|Warpaints Tone|176|56|18|![#B03812](https://placehold.co/15x15/B03812/B03812.png) `#B03812`|
|Lizardfolk Cyan|null|Speedpaint Set 2.0|57|152|156|![#39989C](https://placehold.co/15x15/39989C/39989C.png) `#39989C`|
|Magecast Magenta|null|Warpaints Fanatic|112|64|153|![#704099](https://placehold.co/15x15/704099/704099.png) `#704099`|
|Magenta Tone|null|Warpaints Fanatic Wash|89|1|53|![#590135](https://placehold.co/15x15/590135/590135.png) `#590135`|
|Maggot Skin|null|Speedpaint Set 2.0|203|200|97|![#CBC861](https://placehold.co/15x15/CBC861/CBC861.png) `#CBC861`|
|Magic Blue|null|Speedpaint Set|17|109|172|![#116DAC](https://placehold.co/15x15/116DAC/116DAC.png) `#116DAC`|
|Magic Blue|null|Speedpaint Set 2.0|11|121|174|![#0B79AE](https://placehold.co/15x15/0B79AE/0B79AE.png) `#0B79AE`|
|Magnolia Brown|null|Warpaints Air|44|44|36|![#2C2C24](https://placehold.co/15x15/2C2C24/2C2C24.png) `#2C2C24`|
|Maize Yellow|null|Speedpaint Set 2.0|246|211|31|![#F6D31F](https://placehold.co/15x15/F6D31F/F6D31F.png) `#F6D31F`|
|Majestic Fortress|null|Warpaints Air|0|104|86|![#006856](https://placehold.co/15x15/006856/006856.png) `#006856`|
|Malignant Green|null|Speedpaint Set 2.0|190|203|61|![#BECB3D](https://placehold.co/15x15/BECB3D/BECB3D.png) `#BECB3D`|
|Malignent Green|null|Speedpaint Set|178|184|134|![#B2B886](https://placehold.co/15x15/B2B886/B2B886.png) `#B2B886`|
|Marine Mist|null|Warpaints Fanatic|148|214|215|![#94D6D7](https://placehold.co/15x15/94D6D7/94D6D7.png) `#94D6D7`|
|Mars Red|WP1436|Warpaints|211|56|48|![#D33830](https://placehold.co/15x15/D33830/D33830.png) `#D33830`|
|Matt Black|WP1101|Warpaints|0|0|0|![#000000](https://placehold.co/15x15/000000/000000.png) `#000000`|
|Matt Black|CP3001|Warpaints Primer|0|0|0|![#000000](https://placehold.co/15x15/000000/000000.png) `#000000`|
|Matt Black|null|Warpaints Fanatic|0|0|0|![#000000](https://placehold.co/15x15/000000/000000.png) `#000000`|
|Matt Black|null|Warpaints Air|24|25|21|![#181915](https://placehold.co/15x15/181915/181915.png) `#181915`|
|Matt White|null|Warpaints Air|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Matt White|null|Warpaints Fanatic|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Matt White|WP1102|Warpaints|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Matt White|CP3002|Warpaints Primer|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Medieval Forest|null|Warpaints Fanatic|67|124|109|![#437C6D](https://placehold.co/15x15/437C6D/437C6D.png) `#437C6D`|
|Merfolk Turquoise|null|D&D Nolzur's Marvelous Pigments|1|144|150|![#019096](https://placehold.co/15x15/019096/019096.png) `#019096`|
|Meteor Rock|null|Warpaints Air|215|175|43|![#D7AF2B](https://placehold.co/15x15/D7AF2B/D7AF2B.png) `#D7AF2B`|
|Mid Brown|WP1469|Warpaints|146|90|17|![#925A11](https://placehold.co/15x15/925A11/925A11.png) `#925A11`|
|Mid Brown|null|Quickshade Washes Set|147|78|43|![#934E2B](https://placehold.co/15x15/934E2B/934E2B.png) `#934E2B`|
|Military Shade|null|Warpaints Fanatic Wash|35|39|14|![#23270E](https://placehold.co/15x15/23270E/23270E.png) `#23270E`|
|Military Shader|WP1471|Warpaints Tone|76|99|28|![#4C631C](https://placehold.co/15x15/4C631C/4C631C.png) `#4C631C`|
|Military Shader|null|Quickshade Washes Set|67|88|43|![#43582B](https://placehold.co/15x15/43582B/43582B.png) `#43582B`|
|Militia Green|null|Warpaints Air|39|49|36|![#273124](https://placehold.co/15x15/273124/273124.png) `#273124`|
|Minotaur Hide|null|D&D Nolzur's Marvelous Pigments|163|69|33|![#A34521](https://placehold.co/15x15/A34521/A34521.png) `#A34521`|
|Mithral Silver|null|D&D Nolzur's Marvelous Pigments|128|129|130|![#808182](https://placehold.co/15x15/808182/808182.png) `#808182`|
|Mithril|null|Warpaints Fanatic|158|159|163|![#9E9FA3](https://placehold.co/15x15/9E9FA3/9E9FA3.png) `#9E9FA3`|
|Mocca Skin|null|Skin Tones Paint Set|64|40|40|![#402828](https://placehold.co/15x15/402828/402828.png) `#402828`|
|Mocca Skin|null|Warpaints Fanatic|129|101|90|![#81655A](https://placehold.co/15x15/81655A/81655A.png) `#81655A`|
|Moldy Wine|null|Warpaints Fanatic|125|52|81|![#7D3451](https://placehold.co/15x15/7D3451/7D3451.png) `#7D3451`|
|Molten Lava|null|Warpaints Fanatic|240|90|62|![#F05A3E](https://placehold.co/15x15/F05A3E/F05A3E.png) `#F05A3E`|
|Molten Orange|null|Warpaints Air|125|50|34|![#7D3222](https://placehold.co/15x15/7D3222/7D3222.png) `#7D3222`|
|Monster Brown|WP1120|Warpaints|157|106|95|![#9D6A5F](https://placehold.co/15x15/9D6A5F/9D6A5F.png) `#9D6A5F`|
|Moody Mauve|null|Speedpaint Set 2.0|161|79|125|![#A14F7D](https://placehold.co/15x15/A14F7D/A14F7D.png) `#A14F7D`|
|Moon Dust|null|Warpaints Air|228|203|99|![#E4CB63](https://placehold.co/15x15/E4CB63/E4CB63.png) `#E4CB63`|
|Moon Dust|WP1438|Warpaints|240|212|95|![#F0D45F](https://placehold.co/15x15/F0D45F/F0D45F.png) `#F0D45F`|
|Moonlake Coral|null|Speedpaint Set 2.0|165|57|109|![#A5396D](https://placehold.co/15x15/A5396D/A5396D.png) `#A5396D`|
|Moonstone Skin|null|Warpaints Fanatic|197|123|116|![#C57B74](https://placehold.co/15x15/C57B74/C57B74.png) `#C57B74`|
|Mossy Green|null|Warpaints Fanatic|177|220|192|![#B1DCC0](https://placehold.co/15x15/B1DCC0/B1DCC0.png) `#B1DCC0`|
|Mouldy Clothes|WP1439|Warpaints|58|117|41|![#3A7529](https://placehold.co/15x15/3A7529/3A7529.png) `#3A7529`|
|Mouldy Wash|null|D&D Undead Set|65|99|12|![#41630C](https://placehold.co/15x15/41630C/41630C.png) `#41630C`|
|Mulled Berry|null|Warpaints Fanatic|98|51|72|![#623348](https://placehold.co/15x15/623348/623348.png) `#623348`|
|Mummified Grime|null|Speedpaint Set 2.0|102|103|72|![#666748](https://placehold.co/15x15/666748/666748.png) `#666748`|
|Mummy Robes|WP1440|Warpaints|239|222|214|![#EFDED6](https://placehold.co/15x15/EFDED6/EFDED6.png) `#EFDED6`|
|Murder Scene|null|Speedpaint Set 2.0|110|42|57|![#6E2A39](https://placehold.co/15x15/6E2A39/6E2A39.png) `#6E2A39`|
|Mutant Hue|WP1441|Warpaints|172|138|141|![#AC8A8D](https://placehold.co/15x15/AC8A8D/AC8A8D.png) `#AC8A8D`|
|Mythical Orange|WP1442|Warpaints|226|46|13|![#E22E0D](https://placehold.co/15x15/E22E0D/E22E0D.png) `#E22E0D`|
|Necromancer Cloak|WP1443|Warpaints|65|60|71|![#413C47](https://placehold.co/15x15/413C47/413C47.png) `#413C47`|
|Necrotic Flesh|null|Warpaints Air|177|184|134|![#B1B886](https://placehold.co/15x15/B1B886/B1B886.png) `#B1B886`|
|Necrotic Flesh|WP1108|Warpaints|182|167|137|![#B6A789](https://placehold.co/15x15/B6A789/B6A789.png) `#B6A789`|
|Necrotic Flesh|CP3013|Warpaints Primer|188|190|140|![#BCBE8C](https://placehold.co/15x15/BCBE8C/BCBE8C.png) `#BCBE8C`|
|Necrotic Flesh|null|Warpaints Fanatic|154|169|132|![#9AA984](https://placehold.co/15x15/9AA984/9AA984.png) `#9AA984`|
|Neon Yellow|null|Warpaints Air|254|222|64|![#FEDE40](https://placehold.co/15x15/FEDE40/FEDE40.png) `#FEDE40`|
|Neptune Glow|null|Warpaints Fanatic|117|206|212|![#75CED4](https://placehold.co/15x15/75CED4/75CED4.png) `#75CED4`|
|Night Scales|null|Warpaints Air|35|32|35|![#232023](https://placehold.co/15x15/232023/232023.png) `#232023`|
|Night Scales|null|Metallic Colours Paint Set|49|44|47|![#312C2F](https://placehold.co/15x15/312C2F/312C2F.png) `#312C2F`|
|Night Sky|null|Warpaints Fanatic|48|67|88|![#304358](https://placehold.co/15x15/304358/304358.png) `#304358`|
|Noble Skin|null|Speedpaint Set 2.0|79|73|61|![#4F493D](https://placehold.co/15x15/4F493D/4F493D.png) `#4F493D`|
|Nomad Flesh|null|Warpaints Air|179|97|75|![#B3614B](https://placehold.co/15x15/B3614B/B3614B.png) `#B3614B`|
|Nuclear Sunrise|null|Speedpaint Set 2.0|229|111|37|![#E56F25](https://placehold.co/15x15/E56F25/E56F25.png) `#E56F25`|
|Oak Brown|null|Warpaints Air|58|36|21|![#3A2415](https://placehold.co/15x15/3A2415/3A2415.png) `#3A2415`|
|Oak Brown|null|Warpaints Fanatic|57|38|42|![#39262A](https://placehold.co/15x15/39262A/39262A.png) `#39262A`|
|Oak Brown|WP1124|Warpaints|72|36|10|![#48240A](https://placehold.co/15x15/48240A/48240A.png) `#48240A`|
|Obsidian Pigment Toner|null|Skin Tones Paint Set|31|34|36|![#1F2224](https://placehold.co/15x15/1F2224/1F2224.png) `#1F2224`|
|Obsidian Skin|null|Warpaints Fanatic|74|64|70|![#4A4046](https://placehold.co/15x15/4A4046/4A4046.png) `#4A4046`|
|Occultist Cloak|null|Speedpaint Set 2.0|48|50|62|![#30323E](https://placehold.co/15x15/30323E/30323E.png) `#30323E`|
|Ocean Depths|null|Warpaints Air|5|76|91|![#054C5B](https://placehold.co/15x15/054C5B/054C5B.png) `#054C5B`|
|Ochre Clay|null|Speedpaint Set 2.0|184|169|54|![#B8A936](https://placehold.co/15x15/B8A936/B8A936.png) `#B8A936`|
|Oil Stains|null|Warpaints Fanatic Wash|29|37|43|![#1D252B](https://placehold.co/15x15/1D252B/1D252B.png) `#1D252B`|
|Olive Drab|null|Warpaints Fanatic|122|144|95|![#7A905F](https://placehold.co/15x15/7A905F/7A905F.png) `#7A905F`|
|Omega Blue|null|Warpaints Air|31|56|99|![#1F3863](https://placehold.co/15x15/1F3863/1F3863.png) `#1F3863`|
|Onyx Skin|null|Skin Tones Paint Set|54|50|49|![#363231](https://placehold.co/15x15/363231/363231.png) `#363231`|
|Onyx Skin|null|Warpaints Fanatic|102|74|77|![#664A4D](https://placehold.co/15x15/664A4D/664A4D.png) `#664A4D`|
|Oozing Purple|WP1445|Warpaints|178|157|183|![#B29DB7](https://placehold.co/15x15/B29DB7/B29DB7.png) `#B29DB7`|
|Oozing Vomit|null|Warpaints Fanatic Wash|123|92|29|![#7B5C1D](https://placehold.co/15x15/7B5C1D/7B5C1D.png) `#7B5C1D`|
|Opal Skin|null|Skin Tones Paint Set|214|195|193|![#D6C3C1](https://placehold.co/15x15/D6C3C1/D6C3C1.png) `#D6C3C1`|
|Opal Skin|null|Warpaints Fanatic|255|210|200|![#FFD2C8](https://placehold.co/15x15/FFD2C8/FFD2C8.png) `#FFD2C8`|
|Orange Magma|null|Warpaints Air|197|40|34|![#C52822](https://placehold.co/15x15/C52822/C52822.png) `#C52822`|
|Orange Tone|null|Warpaints Fanatic Wash|100|48|15|![#64300F](https://placehold.co/15x15/64300F/64300F.png) `#64300F`|
|Orc Blood|WP1422|Warpaints|144|75|122|![#904B7A](https://placehold.co/15x15/904B7A/904B7A.png) `#904B7A`|
|Orc Skin|null|Speedpaint Set|45|91|47|![#2D5B2F](https://placehold.co/15x15/2D5B2F/2D5B2F.png) `#2D5B2F`|
|Orc Skin|null|Speedpaint Set 2.0|37|131|53|![#258335](https://placehold.co/15x15/258335/258335.png) `#258335`|
|Orc Skin|null|D&D Nolzur's Marvelous Pigments|159|163|163|![#9FA3A3](https://placehold.co/15x15/9FA3A3/9FA3A3.png) `#9FA3A3`|
|Otyugh Brown|null|D&D Nolzur's Marvelous Pigments|222|181|125|![#DEB57D](https://placehold.co/15x15/DEB57D/DEB57D.png) `#DEB57D`|
|Owlbear Brown|null|D&D Nolzur's Marvelous Pigments|95|61|39|![#5F3D27](https://placehold.co/15x15/5F3D27/5F3D27.png) `#5F3D27`|
|Pale Sand|null|Warpaints Fanatic|239|234|211|![#EFEAD3](https://placehold.co/15x15/EFEAD3/EFEAD3.png) `#EFEAD3`|
|Pallid Bone|null|Speedpaint Set 2.0|225|204|149|![#E1CC95](https://placehold.co/15x15/E1CC95/E1CC95.png) `#E1CC95`|
|Pallid Bone|null|Speedpaint Set|203|194|149|![#CBC295](https://placehold.co/15x15/CBC295/CBC295.png) `#CBC295`|
|Paratrooper Tan|null|Warpaints Fanatic|154|119|108|![#9A776C](https://placehold.co/15x15/9A776C/9A776C.png) `#9A776C`|
|Pastel Indigo|null|Speedpaint Set 2.0|159|188|218|![#9FBCDA](https://placehold.co/15x15/9FBCDA/9FBCDA.png) `#9FBCDA`|
|Pastel Lavender|null|Speedpaint Set 2.0|213|191|212|![#D5BFD4](https://placehold.co/15x15/D5BFD4/D5BFD4.png) `#D5BFD4`|
|Pastel Salmon|null|Speedpaint Set 2.0|243|196|152|![#F3C498](https://placehold.co/15x15/F3C498/F3C498.png) `#F3C498`|
|Pastel Seafoam|null|Speedpaint Set 2.0|184|215|200|![#B8D7C8](https://placehold.co/15x15/B8D7C8/B8D7C8.png) `#B8D7C8`|
|Pastel Yellow|null|Speedpaint Set 2.0|246|225|120|![#F6E178](https://placehold.co/15x15/F6E178/F6E178.png) `#F6E178`|
|Patagon Pine|null|Warpaints Fanatic|99|145|127|![#63917F](https://placehold.co/15x15/63917F/63917F.png) `#63917F`|
|Peachy Flesh|null|Speedpaint Set 2.0|237|166|104|![#EDA668](https://placehold.co/15x15/EDA668/EDA668.png) `#EDA668`|
|Pearl Pigment Toner|null|Skin Tones Paint Set|235|228|225|![#EBE4E1](https://placehold.co/15x15/EBE4E1/EBE4E1.png) `#EBE4E1`|
|Pearl Skin|null|Warpaints Fanatic|255|227|216|![#FFE3D8](https://placehold.co/15x15/FFE3D8/FFE3D8.png) `#FFE3D8`|
|Periwinkle Purple|null|Speedpaint Set 2.0|88|83|150|![#585396](https://placehold.co/15x15/585396/585396.png) `#585396`|
|Pestilent Flesh|null|Warpaints Air|112|115|59|![#70733B](https://placehold.co/15x15/70733B/70733B.png) `#70733B`|
|Phalanx Blue|null|Warpaints Fanatic|4|139|174|![#048BAE](https://placehold.co/15x15/048BAE/048BAE.png) `#048BAE`|
|Phantasmal Blue|null|Warpaints Air|92|173|179|![#5CADB3](https://placehold.co/15x15/5CADB3/5CADB3.png) `#5CADB3`|
|Pharaoh Guard|null|Warpaints Fanatic|12|124|97|![#0C7C61](https://placehold.co/15x15/0C7C61/0C7C61.png) `#0C7C61`|
|Phoenix Flames|WP1446|Warpaints|247|161|3|![#F7A103](https://placehold.co/15x15/F7A103/F7A103.png) `#F7A103`|
|Pink Potion|null|Warpaints Fanatic|244|185|212|![#F4B9D4](https://placehold.co/15x15/F4B9D4/F4B9D4.png) `#F4B9D4`|
|Pixie Pink|WP1447|Warpaints|214|123|131|![#D67B83](https://placehold.co/15x15/D67B83/D67B83.png) `#D67B83`|
|Pixie Pink|null|Warpaints Air|185|79|140|![#B94F8C](https://placehold.co/15x15/B94F8C/B94F8C.png) `#B94F8C`|
|Pixie Pink|null|Warpaints Fanatic|217|111|174|![#D96FAE](https://placehold.co/15x15/D96FAE/D96FAE.png) `#D96FAE`|
|Pixiedust Pink|null|D&D Nolzur's Marvelous Pigments|210|127|132|![#D27F84](https://placehold.co/15x15/D27F84/D27F84.png) `#D27F84`|
|Plasma Coil Glow|null|Warpaints Fanatic Wash|94|205|244|![#5ECDF4](https://placehold.co/15x15/5ECDF4/5ECDF4.png) `#5ECDF4`|
|Plasmatic Bolt|null|Speedpaint Set|0|129|108|![#00816C](https://placehold.co/15x15/00816C/00816C.png) `#00816C`|
|Plasmatic Bolt|null|Speedpaint Set 2.0|10|155|140|![#0A9B8C](https://placehold.co/15x15/0A9B8C/0A9B8C.png) `#0A9B8C`|
|Plate Mail Metal|null|Warpaints Air|106|107|104|![#6A6B68](https://placehold.co/15x15/6A6B68/6A6B68.png) `#6A6B68`|
|Plate Mail Metal|CP3008|Warpaints Primer|133|133|132|![#858584](https://placehold.co/15x15/858584/858584.png) `#858584`|
|Plate Mail Metal|WP1130|Warpaints|148|148|148|![#949494](https://placehold.co/15x15/949494/949494.png) `#949494`|
|Plate Mail Metal|null|Warpaints Fanatic|104|106|110|![#686A6E](https://placehold.co/15x15/686A6E/686A6E.png) `#686A6E`|
|Poisonous Cloud|WP1448|Warpaints|207|218|47|![#CFDA2F](https://placehold.co/15x15/CFDA2F/CFDA2F.png) `#CFDA2F`|
|Polished Silver|null|Speedpaint Set 2.0|136|135|130|![#888782](https://placehold.co/15x15/888782/888782.png) `#888782`|
|Poppy Red|null|Speedpaint Set 2.0|200|69|59|![#C8453B](https://placehold.co/15x15/C8453B/C8453B.png) `#C8453B`|
|Potion Green|null|Warpaints Air|97|138|114|![#618A72](https://placehold.co/15x15/618A72/618A72.png) `#618A72`|
|Power Node Glow|null|Warpaints Fanatic Wash|242|134|181|![#F286B5](https://placehold.co/15x15/F286B5/F286B5.png) `#F286B5`|
|Prairie Ochre|null|Warpaints Fanatic|105|98|66|![#696242](https://placehold.co/15x15/696242/696242.png) `#696242`|
|Princess Pink|null|Speedpaint Set 2.0|226|159|176|![#E29FB0](https://placehold.co/15x15/E29FB0/E29FB0.png) `#E29FB0`|
|Psychic Shock|null|Warpaints Air|93|164|144|![#5DA490](https://placehold.co/15x15/5DA490/5DA490.png) `#5DA490`|
|Pure Red|WP1104|Warpaints|202|25|19|![#CA1913](https://placehold.co/15x15/CA1913/CA1913.png) `#CA1913`|
|Pure Red|null|Warpaints Air|168|20|31|![#A8141F](https://placehold.co/15x15/A8141F/A8141F.png) `#A8141F`|
|Pure Red|CP3006|Warpaints Primer|195|35|30|![#C3231E](https://placehold.co/15x15/C3231E/C3231E.png) `#C3231E`|
|Pure Red|null|Warpaints Fanatic|205|21|28|![#CD151C](https://placehold.co/15x15/CD151C/CD151C.png) `#CD151C`|
|Purple Alchemy|null|Speedpaint Set 2.0|174|63|106|![#AE3F6A](https://placehold.co/15x15/AE3F6A/AE3F6A.png) `#AE3F6A`|
|Purple Alchemy|null|Speedpaint Set|141|51|92|![#8D335C](https://placehold.co/15x15/8D335C/8D335C.png) `#8D335C`|
|Purple Swarm|null|Speedpaint Set 2.0|101|52|131|![#653483](https://placehold.co/15x15/653483/653483.png) `#653483`|
|Purple Tone|null|Warpaints Fanatic Wash|36|28|49|![#241C31](https://placehold.co/15x15/241C31/241C31.png) `#241C31`|
|Purple Tone|WP1140|Warpaints Tone|42|28|77|![#2A1C4D](https://placehold.co/15x15/2A1C4D/2A1C4D.png) `#2A1C4D`|
|Purple Tone|null|Quickshade Washes Set|42|25|74|![#2A194A](https://placehold.co/15x15/2A194A/2A194A.png) `#2A194A`|
|Purple Worm|WP1712|D&D Nolzur's Marvelous Pigments|130|109|141|![#826D8D](https://placehold.co/15x15/826D8D/826D8D.png) `#826D8D`|
|Putrid Slime|null|D&D Underdark Set|196|177|7|![#C4B107](https://placehold.co/15x15/C4B107/C4B107.png) `#C4B107`|
|Quartz Skin|null|Warpaints Fanatic|240|208|180|![#F0D0B4](https://placehold.co/15x15/F0D0B4/F0D0B4.png) `#F0D0B4`|
|Quickshade Wash Mixing Medium|WP1474|Warpaints Wash|238|239|239|![#EEEFEF](https://placehold.co/15x15/EEEFEF/EEEFEF.png) `#EEEFEF`|
|Radiation Glow|null|Warpaints Fanatic Wash|251|179|117|![#FBB375](https://placehold.co/15x15/FBB375/FBB375.png) `#FBB375`|
|Raging Rose|null|Warpaints Fanatic|233|102|99|![#E96663](https://placehold.co/15x15/E96663/E96663.png) `#E96663`|
|Raging Rouge|null|Warpaints Fanatic|246|143|130|![#F68F82](https://placehold.co/15x15/F68F82/F68F82.png) `#F68F82`|
|Raging Sea|null|Speedpaint Set 2.0|27|149|164|![#1B95A4](https://placehold.co/15x15/1B95A4/1B95A4.png) `#1B95A4`|
|Rainforest|null|Warpaints Fanatic|139|198|62|![#8BC63E](https://placehold.co/15x15/8BC63E/8BC63E.png) `#8BC63E`|
|Raven Black|null|Warpaints Air|43|48|48|![#2B3030](https://placehold.co/15x15/2B3030/2B3030.png) `#2B3030`|
|Rawhide Brown|null|Warpaints Air|79|56|38|![#4F3826](https://placehold.co/15x15/4F3826/4F3826.png) `#4F3826`|
|Rebel Red|null|Warpaints Air|116|20|52|![#741434](https://placehold.co/15x15/741434/741434.png) `#741434`|
|Red Copper|null|Warpaints Fanatic|77|44|48|![#4D2C30](https://placehold.co/15x15/4D2C30/4D2C30.png) `#4D2C30`|
|Red Tone|WP1138|Warpaints Tone|80|33|20|![#502114](https://placehold.co/15x15/502114/502114.png) `#502114`|
|Red Tone|null|Warpaints Fanatic Wash|83|31|40|![#531F28](https://placehold.co/15x15/531F28/531F28.png) `#531F28`|
|Red Tone|null|Quickshade Washes Set|66|21|22|![#421516](https://placehold.co/15x15/421516/421516.png) `#421516`|
|Regal Blue|null|Warpaints Fanatic|0|79|136|![#004F88](https://placehold.co/15x15/004F88/004F88.png) `#004F88`|
|Regiment Grey|null|Warpaints Air|66|75|74|![#424B4A](https://placehold.co/15x15/424B4A/424B4A.png) `#424B4A`|
|Resplendent Red|null|Warpaints Fanatic|150|39|47|![#96272F](https://placehold.co/15x15/96272F/96272F.png) `#96272F`|
|Rigid Leather|null|D&D Underdark Set|82|28|2|![#521C02](https://placehold.co/15x15/521C02/521C02.png) `#521C02`|
|Rigor Mortis|null|Speedpaint Set 2.0|173|173|111|![#ADAD6F](https://placehold.co/15x15/ADAD6F/ADAD6F.png) `#ADAD6F`|
|Rosy Skin|null|D&D Nolzur's Marvelous Pigments|247|191|150|![#F7BF96](https://placehold.co/15x15/F7BF96/F7BF96.png) `#F7BF96`|
|Rough Iron|null|Warpaints Air|32|19|14|![#20130E](https://placehold.co/15x15/20130E/20130E.png) `#20130E`|
|Rough Iron|null|Warpaints Fanatic|53|45|37|![#352D25](https://placehold.co/15x15/352D25/352D25.png) `#352D25`|
|Rough Iron|WP1468|Warpaints|34|19|15|![#22130F](https://placehold.co/15x15/22130F/22130F.png) `#22130F`|
|Royal Blue|null|Warpaints Fanatic|1|98|175|![#0162AF](https://placehold.co/15x15/0162AF/0162AF.png) `#0162AF`|
|Royal Cloak|WP1449|Warpaints|28|144|149|![#1C9095](https://placehold.co/15x15/1C9095/1C9095.png) `#1C9095`|
|Royal Purple|null|Metallic Colours Paint Set|112|27|85|![#701B55](https://placehold.co/15x15/701B55/701B55.png) `#701B55`|
|Royal Purple|null|Warpaints Air|67|23|59|![#43173B](https://placehold.co/15x15/43173B/43173B.png) `#43173B`|
|Royal Robes|null|Speedpaint Set 2.0|83|99|161|![#5363A1](https://placehold.co/15x15/5363A1/5363A1.png) `#5363A1`|
|Ruby Skin|null|Skin Tones Paint Set|229|171|171|![#E5ABAB](https://placehold.co/15x15/E5ABAB/E5ABAB.png) `#E5ABAB`|
|Ruby Skin|null|Warpaints Fanatic|251|185|157|![#FBB99D](https://placehold.co/15x15/FBB99D/FBB99D.png) `#FBB99D`|
|Ruddy Fur|null|Speedpaint Set 2.0|157|73|37|![#9D4925](https://placehold.co/15x15/9D4925/9D4925.png) `#9D4925`|
|Ruddy Skin|null|D&D Nolzur's Marvelous Pigments|187|121|98|![#BB7962](https://placehold.co/15x15/BB7962/BB7962.png) `#BB7962`|
|Ruddy Umber|null|Warpaints Fanatic|152|89|81|![#985951](https://placehold.co/15x15/985951/985951.png) `#985951`|
|Ruinous Spell|null|Warpaints Air|55|82|66|![#375242](https://placehold.co/15x15/375242/375242.png) `#375242`|
|Runic Cobalt|null|Warpaints Fanatic|116|150|180|![#7496B4](https://placehold.co/15x15/7496B4/7496B4.png) `#7496B4`|
|Runic Grey|null|Speedpaint Set 2.0|85|121|137|![#557989](https://placehold.co/15x15/557989/557989.png) `#557989`|
|Runic Grey|null|Speedpaint Set|86|110|126|![#566E7E](https://placehold.co/15x15/566E7E/566E7E.png) `#566E7E`|
|Rust Monster|null|D&D Nolzur's Marvelous Pigments|229|88|30|![#E5581E](https://placehold.co/15x15/E5581E/E5581E.png) `#E5581E`|
|Rust Tone|null|Warpaints Fanatic Wash|69|42|17|![#452A11](https://placehold.co/15x15/452A11/452A11.png) `#452A11`|
|Sacred Scarlet|null|Warpaints Fanatic|241|99|76|![#F1634C](https://placehold.co/15x15/F1634C/F1634C.png) `#F1634C`|
|Safety Orange|null|Warpaints Air|222|143|88|![#DE8F58](https://placehold.co/15x15/DE8F58/DE8F58.png) `#DE8F58`|
|Sand Golem|null|Speedpaint Set 2.0|203|148|19|![#CB9413](https://placehold.co/15x15/CB9413/CB9413.png) `#CB9413`|
|Sand Golem|null|Speedpaint Set|186|144|41|![#BA9029](https://placehold.co/15x15/BA9029/BA9029.png) `#BA9029`|
|Sapphire Gem|null|Warpaints Air|28|71|126|![#1C477E](https://placehold.co/15x15/1C477E/1C477E.png) `#1C477E`|
|Satchel Brown|null|Speedpaint Set 2.0|88|61|50|![#583D32](https://placehold.co/15x15/583D32/583D32.png) `#583D32`|
|Savage Green|null|Warpaints Air|22|79|44|![#164F2C](https://placehold.co/15x15/164F2C/164F2C.png) `#164F2C`|
|Scaly Hide|WP1450|Warpaints|147|159|140|![#939F8C](https://placehold.co/15x15/939F8C/939F8C.png) `#939F8C`|
|Scar Tissue|WP1480|Warpaints|207|140|115|![#CF8C73](https://placehold.co/15x15/CF8C73/CF8C73.png) `#CF8C73`|
|Scarab Green|null|Warpaints Fanatic|25|60|68|![#193C44](https://placehold.co/15x15/193C44/193C44.png) `#193C44`|
|Sepia Tone|null|Warpaints Fanatic Wash|115|64|20|![#734014](https://placehold.co/15x15/734014/734014.png) `#734014`|
|Shadow Wash|null|D&D Nolzur's Marvelous Pigments Wash|0|1|3|![#000103](https://placehold.co/15x15/000103/000103.png) `#000103`|
|Shamrock Green|null|Speedpaint Set 2.0|96|171|44|![#60AB2C](https://placehold.co/15x15/60AB2C/60AB2C.png) `#60AB2C`|
|Shark White|null|Warpaints Air|149|159|156|![#959F9C](https://placehold.co/15x15/959F9C/959F9C.png) `#959F9C`|
|Shieldwall Blue|null|Warpaints Fanatic|8|161|204|![#08A1CC](https://placehold.co/15x15/08A1CC/08A1CC.png) `#08A1CC`|
|Shining Silver|null|Warpaints Fanatic|134|136|140|![#86888C](https://placehold.co/15x15/86888C/86888C.png) `#86888C`|
|Shining Silver|null|Warpaints Air|169|169|167|![#A9A9A7](https://placehold.co/15x15/A9A9A7/A9A9A7.png) `#A9A9A7`|
|Shining Silver|WP1129|Warpaints|177|177|175|![#B1B1AF](https://placehold.co/15x15/B1B1AF/B1B1AF.png) `#B1B1AF`|
|Silver Dragon|null|D&D Nolzur's Marvelous Pigments|178|178|179|![#B2B2B3](https://placehold.co/15x15/B2B2B3/B2B2B3.png) `#B2B2B3`|
|Skeleton Bone|null|D&D Nolzur's Marvelous Pigments|102|109|116|![#666D74](https://placehold.co/15x15/666D74/666D74.png) `#666D74`|
|Skeleton Bone|null|Warpaints Air|203|194|148|![#CBC294](https://placehold.co/15x15/CBC294/CBC294.png) `#CBC294`|
|Skeleton Bone|null|Warpaints Fanatic|194|178|147|![#C2B293](https://placehold.co/15x15/C2B293/C2B293.png) `#C2B293`|
|Skeleton Bone|WP1125|Warpaints|194|174|157|![#C2AE9D](https://placehold.co/15x15/C2AE9D/C2AE9D.png) `#C2AE9D`|
|Skeleton Bone|CP3012|Warpaints Primer|208|197|154|![#D0C59A](https://placehold.co/15x15/D0C59A/D0C59A.png) `#D0C59A`|
|Slaughter Red|null|Speedpaint Set|123|25|27|![#7B191B](https://placehold.co/15x15/7B191B/7B191B.png) `#7B191B`|
|Slaughter Red|null|Speedpaint Set 2.0|153|25|38|![#991926](https://placehold.co/15x15/991926/991926.png) `#991926`|
|Snake Scales|WP1453|Warpaints|142|174|17|![#8EAE11](https://placehold.co/15x15/8EAE11/8EAE11.png) `#8EAE11`|
|Soft Skin Wash|null|Skin Tones Paint Set - Washes|107|65|43|![#6B412B](https://placehold.co/15x15/6B412B/6B412B.png) `#6B412B`|
|Soft Tone|null|Quickshade Washes Set|73|37|30|![#49251E](https://placehold.co/15x15/49251E/49251E.png) `#49251E`|
|Soft Tone|WP1134|Warpaints Tone|83|40|20|![#532814](https://placehold.co/15x15/532814/532814.png) `#532814`|
|Soft Tone|null|Warpaints Fanatic Wash|86|61|42|![#563D2A](https://placehold.co/15x15/563D2A/563D2A.png) `#563D2A`|
|Space Dust|null|Warpaints Fanatic|255|227|136|![#FFE388](https://placehold.co/15x15/FFE388/FFE388.png) `#FFE388`|
|Spaceship Exterior|WP1454|Warpaints|214|214|214|![#D6D6D6](https://placehold.co/15x15/D6D6D6/D6D6D6.png) `#D6D6D6`|
|Speedpaint Medium|null|Speedpaint Set|239|239|239|![#EFEFEF](https://placehold.co/15x15/EFEFEF/EFEFEF.png) `#EFEFEF`|
|Speedpaint Medium|null|Speedpaint Set 2.0|243|240|235|![#F3F0EB](https://placehold.co/15x15/F3F0EB/F3F0EB.png) `#F3F0EB`|
|Spellbound Fuchsia|null|Warpaints Fanatic|173|77|160|![#AD4DA0](https://placehold.co/15x15/AD4DA0/AD4DA0.png) `#AD4DA0`|
|Stirge Tan|null|D&D Underdark Set|196|122|123|![#C47A7B](https://placehold.co/15x15/C47A7B/C47A7B.png) `#C47A7B`|
|Stone Golem|WP1455|Warpaints|195|197|190|![#C3C5BE](https://placehold.co/15x15/C3C5BE/C3C5BE.png) `#C3C5BE`|
|Storm Wolf|null|Warpaints Air|157|174|210|![#9DAED2](https://placehold.co/15x15/9DAED2/9DAED2.png) `#9DAED2`|
|Stratos Blue|null|Warpaints Fanatic|51|101|143|![#33658F](https://placehold.co/15x15/33658F/33658F.png) `#33658F`|
|Strong Skin Shade|null|Warpaints Fanatic Wash|68|40|36|![#442824](https://placehold.co/15x15/442824/442824.png) `#442824`|
|Strong Skin Wash|null|Skin Tones Paint Set - Washes|56|42|34|![#382A22](https://placehold.co/15x15/382A22/382A22.png) `#382A22`|
|Strong Tone|null|Warpaints Fanatic Wash|33|25|19|![#211913](https://placehold.co/15x15/211913/211913.png) `#211913`|
|Strong Tone|WP1135|Warpaints Tone|58|42|17|![#3A2A11](https://placehold.co/15x15/3A2A11/3A2A11.png) `#3A2A11`|
|Strong Tone|null|Quickshade Washes Set|59|40|38|![#3B2826](https://placehold.co/15x15/3B2826/3B2826.png) `#3B2826`|
|Succubus Red|null|D&D Underdark Set|170|38|47|![#AA262F](https://placehold.co/15x15/AA262F/AA262F.png) `#AA262F`|
|Sulfide Ochre|WP1456|Warpaints|199|134|0|![#C78600](https://placehold.co/15x15/C78600/C78600.png) `#C78600`|
|Tainted Gold|null|Warpaints Air|70|66|44|![#46422C](https://placehold.co/15x15/46422C/46422C.png) `#46422C`|
|Tainted Gold|null|Metallic Colours Paint Set|104|97|57|![#686139](https://placehold.co/15x15/686139/686139.png) `#686139`|
|Tainted Gold|null|Warpaints Fanatic|87|82|53|![#575235](https://placehold.co/15x15/575235/575235.png) `#575235`|
|Talisman Purple|null|Warpaints Air|206|133|156|![#CE859C](https://placehold.co/15x15/CE859C/CE859C.png) `#CE859C`|
|Talisman Teal|null|Warpaints Fanatic|31|174|145|![#1FAE91](https://placehold.co/15x15/1FAE91/1FAE91.png) `#1FAE91`|
|Talos Bronze|null|Speedpaint Set 2.0|107|59|39|![#6B3B27](https://placehold.co/15x15/6B3B27/6B3B27.png) `#6B3B27`|
|Tanned Flesh|WP1127|Warpaints|187|111|81|![#BB6F51](https://placehold.co/15x15/BB6F51/BB6F51.png) `#BB6F51`|
|Temple Gate Teal|null|Warpaints Fanatic|4|97|84|![#046154](https://placehold.co/15x15/046154/046154.png) `#046154`|
|Terrestial Titan|null|Warpaints Fanatic|48|49|73|![#303149](https://placehold.co/15x15/303149/303149.png) `#303149`|
|Thunder Storm|null|Warpaints Air|30|41|49|![#1E2931](https://placehold.co/15x15/1E2931/1E2931.png) `#1E2931`|
|Thunderbird Blue|null|Speedpaint Set 2.0|102|183|151|![#66B797](https://placehold.co/15x15/66B797/66B797.png) `#66B797`|
|Thunderous Blue|null|Warpaints Fanatic|52|87|123|![#34577B](https://placehold.co/15x15/34577B/34577B.png) `#34577B`|
|Tidal Blue|null|Warpaints Fanatic|2|107|147|![#026B93](https://placehold.co/15x15/026B93/026B93.png) `#026B93`|
|Tidal Wave|null|Speedpaint Set 2.0|18|120|182|![#1278B6](https://placehold.co/15x15/1278B6/1278B6.png) `#1278B6`|
|Tiger's Eye Skin|null|Skin Tones Paint Set|127|72|65|![#7F4841](https://placehold.co/15x15/7F4841/7F4841.png) `#7F4841`|
|Tiger’s Eye Skin|null|Warpaints Fanatic|144|77|82|![#904D52](https://placehold.co/15x15/904D52/904D52.png) `#904D52`|
|Tomb King Tan|null|Warpaints Fanatic|162|146|120|![#A29278](https://placehold.co/15x15/A29278/A29278.png) `#A29278`|
|Topaz Skin|null|Warpaints Fanatic|178|90|83|![#B25A53](https://placehold.co/15x15/B25A53/B25A53.png) `#B25A53`|
|Topaz Skin|null|Skin Tones Paint Set|191|132|119|![#BF8477](https://placehold.co/15x15/BF8477/BF8477.png) `#BF8477`|
|Tourmaline Skin|null|Warpaints Fanatic|227|152|139|![#E3988B](https://placehold.co/15x15/E3988B/E3988B.png) `#E3988B`|
|Toxic Boils|WP1457|Warpaints|166|110|125|![#A66E7D](https://placehold.co/15x15/A66E7D/A66E7D.png) `#A66E7D`|
|Toxic Mist|null|Warpaints Air|99|176|181|![#63B0B5](https://placehold.co/15x15/63B0B5/63B0B5.png) `#63B0B5`|
|Toxic Mist|WP1437|Warpaints|64|186|192|![#40BAC0](https://placehold.co/15x15/40BAC0/40BAC0.png) `#40BAC0`|
|Traitor Red|null|Warpaints Air|52|37|31|![#34251F](https://placehold.co/15x15/34251F/34251F.png) `#34251F`|
|Treant Green|null|D&D Nolzur's Marvelous Pigments|64|155|75|![#409B4B](https://placehold.co/15x15/409B4B/409B4B.png) `#409B4B`|
|Tree Ancient|null|Warpaints Fanatic|81|52|48|![#513430](https://placehold.co/15x15/513430/513430.png) `#513430`|
|Triumphant Navy|null|Warpaints Fanatic|26|44|83|![#1A2C53](https://placehold.co/15x15/1A2C53/1A2C53.png) `#1A2C53`|
|Troglodyte Blue|WP1458|Warpaints|37|136|185|![#2588B9](https://placehold.co/15x15/2588B9/2588B9.png) `#2588B9`|
|Troll Claws|WP1459|Warpaints|203|136|62|![#CB883E](https://placehold.co/15x15/CB883E/CB883E.png) `#CB883E`|
|Troll Skin|null|D&D Nolzur's Marvelous Pigments|6|56|31|![#06381F](https://placehold.co/15x15/06381F/06381F.png) `#06381F`|
|True Blood|null|Warpaints Fanatic Wash|141|4|34|![#8D0422](https://placehold.co/15x15/8D0422/8D0422.png) `#8D0422`|
|True Brass|null|Warpaints Fanatic|99|93|88|![#635D58](https://placehold.co/15x15/635D58/635D58.png) `#635D58`|
|True Copper|WP1467|Warpaints|224|125|45|![#E07D2D](https://placehold.co/15x15/E07D2D/E07D2D.png) `#E07D2D`|
|True Copper|null|Warpaints Fanatic|107|71|49|![#6B4731](https://placehold.co/15x15/6B4731/6B4731.png) `#6B4731`|
|True Copper|null|Warpaints Air|189|82|37|![#BD5225](https://placehold.co/15x15/BD5225/BD5225.png) `#BD5225`|
|Tundra Taupe|null|Warpaints Fanatic|75|77|62|![#4B4D3E](https://placehold.co/15x15/4B4D3E/4B4D3E.png) `#4B4D3E`|
|Turquoise Siren|null|Warpaints Fanatic|41|179|185|![#29B3B9](https://placehold.co/15x15/29B3B9/29B3B9.png) `#29B3B9`|
|Twilight Sky|null|Warpaints Air|27|69|95|![#1B455F](https://placehold.co/15x15/1B455F/1B455F.png) `#1B455F`|
|Tyrian Navy|null|Speedpaint Set 2.0|42|65|79|![#2A414F](https://placehold.co/15x15/2A414F/2A414F.png) `#2A414F`|
|Ultramarine Blue|CP3022|Warpaints Primer|21|66|117|![#154275](https://placehold.co/15x15/154275/154275.png) `#154275`|
|Ultramarine Blue|null|Warpaints Air|42|74|116|![#2A4A74](https://placehold.co/15x15/2A4A74/2A4A74.png) `#2A4A74`|
|Ultramarine Blue|null|Warpaints Fanatic|40|77|142|![#284D8E](https://placehold.co/15x15/284D8E/284D8E.png) `#284D8E`|
|Ultramarine Blue|WP1115|Warpaints|59|87|165|![#3B57A5](https://placehold.co/15x15/3B57A5/3B57A5.png) `#3B57A5`|
|Underdark Grey|null|D&D Underdark Set|127|115|114|![#7F7372](https://placehold.co/15x15/7F7372/7F7372.png) `#7F7372`|
|Underdark Indigo|null|D&D Nolzur's Marvelous Pigments|32|82|134|![#205286](https://placehold.co/15x15/205286/205286.png) `#205286`|
|Undergrowth Green|null|Warpaints Air|80|125|53|![#507D35](https://placehold.co/15x15/507D35/507D35.png) `#507D35`|
|Unforgiven Green|null|Warpaints Air|36|41|35|![#242923](https://placehold.co/15x15/242923/242923.png) `#242923`|
|Uniform Grey|WP1118P|Warpaints Primer|84|93|98|![#545D62](https://placehold.co/15x15/545D62/545D62.png) `#545D62`|
|Uniform Grey|null|Warpaints Air|85|92|97|![#555C61](https://placehold.co/15x15/555C61/555C61.png) `#555C61`|
|Uniform Grey|null|Warpaints Fanatic|107|112|124|![#6B707C](https://placehold.co/15x15/6B707C/6B707C.png) `#6B707C`|
|Uniform Grey|WP1118|Warpaints|112|115|127|![#70737F](https://placehold.co/15x15/70737F/70737F.png) `#70737F`|
|Urban Buff|null|Warpaints Fanatic|219|185|171|![#DBB9AB](https://placehold.co/15x15/DBB9AB/DBB9AB.png) `#DBB9AB`|
|Vampire Garments|null|D&D Undead Set|161|47|36|![#A12F24](https://placehold.co/15x15/A12F24/A12F24.png) `#A12F24`|
|Vampire Red|WP1460|Warpaints|152|23|42|![#98172A](https://placehold.co/15x15/98172A/98172A.png) `#98172A`|
|Venom Wyrm|WP1461|Warpaints|106|101|62|![#6A653E](https://placehold.co/15x15/6A653E/6A653E.png) `#6A653E`|
|Verdigris|null|Warpaints Fanatic Wash|97|184|155|![#61B89B](https://placehold.co/15x15/61B89B/61B89B.png) `#61B89B`|
|Viking Blue|WP1462|Warpaints|28|91|152|![#1C5B98](https://placehold.co/15x15/1C5B98/1C5B98.png) `#1C5B98`|
|Violent Vermillion|null|Warpaints Fanatic|243|121|100|![#F37964](https://placehold.co/15x15/F37964/F37964.png) `#F37964`|
|Violet Coven|null|Warpaints Fanatic|169|153|199|![#A999C7](https://placehold.co/15x15/A999C7/A999C7.png) `#A999C7`|
|Violet Volt|null|Warpaints Air|118|66|135|![#764287](https://placehold.co/15x15/764287/764287.png) `#764287`|
|Viper Brown|null|Warpaints Air|155|95|76|![#9B5F4C](https://placehold.co/15x15/9B5F4C/9B5F4C.png) `#9B5F4C`|
|Vivid Volt|null|Warpaints Fanatic|207|220|81|![#CFDC51](https://placehold.co/15x15/CFDC51/CFDC51.png) `#CFDC51`|
|Voidshield Blue|WP1452|Warpaints|91|188|215|![#5BBCD7](https://placehold.co/15x15/5BBCD7/5BBCD7.png) `#5BBCD7`|
|Warlock Magenta|null|Warpaints Fanatic|131|77|159|![#834D9F](https://placehold.co/15x15/834D9F/834D9F.png) `#834D9F`|
|Warlock Purple|WP1451|Warpaints|195|77|129|![#C34D81](https://placehold.co/15x15/C34D81/C34D81.png) `#C34D81`|
|Warlock Purple|null|Warpaints Air|140|52|92|![#8C345C](https://placehold.co/15x15/8C345C/8C345C.png) `#8C345C`|
|Warpaints Mixing Medium|null|Skin Tones Paint Set|239|241|240|![#EFF1F0](https://placehold.co/15x15/EFF1F0/EFF1F0.png) `#EFF1F0`|
|Warpaints Mixing Medium|WP1475|Warpaints|239|239|239|![#EFEFEF](https://placehold.co/15x15/EFEFEF/EFEFEF.png) `#EFEFEF`|
|Warped Yellow|null|Warpaints Fanatic|254|213|72|![#FED548](https://placehold.co/15x15/FED548/FED548.png) `#FED548`|
|Warrior Skin|null|Speedpaint Set 2.0|163|112|81|![#A37051](https://placehold.co/15x15/A37051/A37051.png) `#A37051`|
|Wash Medium|null|Warpaints Fanatic Wash|177|179|180|![#B1B3B4](https://placehold.co/15x15/B1B3B4/B1B3B4.png) `#B1B3B4`|
|Wasteland Clay|null|Warpaints Fanatic|163|135|85|![#A38755](https://placehold.co/15x15/A38755/A38755.png) `#A38755`|
|Wasteland Soil|WP1463|Warpaints|132|72|87|![#844857](https://placehold.co/15x15/844857/844857.png) `#844857`|
|Weapon Bronze|null|Warpaints Fanatic|149|86|16|![#955610](https://placehold.co/15x15/955610/955610.png) `#955610`|
|Weapon Bronze|WP1133|Warpaints|228|117|51|![#E47533](https://placehold.co/15x15/E47533/E47533.png) `#E47533`|
|Weapon Bronze|null|Warpaints Air|173|91|51|![#AD5B33](https://placehold.co/15x15/AD5B33/AD5B33.png) `#AD5B33`|
|Weird Elixir|null|Warpaints Fanatic|224|146|191|![#E092BF](https://placehold.co/15x15/E092BF/E092BF.png) `#E092BF`|
|Werewolf Fur|WP1464|Warpaints|121|99|82|![#796352](https://placehold.co/15x15/796352/796352.png) `#796352`|
|Wet Mud|WP1478|Warpaints|158|62|53|![#9E3E35](https://placehold.co/15x15/9E3E35/9E3E35.png) `#9E3E35`|
|Wicked Pink|null|Warpaints Fanatic|206|8|134|![#CE0886](https://placehold.co/15x15/CE0886/CE0886.png) `#CE0886`|
|Wild Green|null|Warpaints Fanatic|70|183|88|![#46B758](https://placehold.co/15x15/46B758/46B758.png) `#46B758`|
|Wildling Flesh|null|Warpaints Air|222|147|123|![#DE937B](https://placehold.co/15x15/DE937B/DE937B.png) `#DE937B`|
|Wilted Rose|null|Warpaints Fanatic|236|197|215|![#ECC5D7](https://placehold.co/15x15/ECC5D7/ECC5D7.png) `#ECC5D7`|
|Witch Brew|WP1465|Warpaints|145|150|52|![#919634](https://placehold.co/15x15/919634/919634.png) `#919634`|
|Witchbane Plum|null|Warpaints Air|96|24|65|![#601841](https://placehold.co/15x15/601841/601841.png) `#601841`|
|Wizards Orb|null|Warpaints Air|42|106|91|![#2A6A5B](https://placehold.co/15x15/2A6A5B/2A6A5B.png) `#2A6A5B`|
|Wizards Orb|WP1466|Warpaints|15|114|96|![#0F7260](https://placehold.co/15x15/0F7260/0F7260.png) `#0F7260`|
|Wolf Grey|CP3021|Warpaints Primer|81|115|131|![#517383](https://placehold.co/15x15/517383/517383.png) `#517383`|
|Wolf Grey|null|Warpaints Air|87|111|126|![#576F7E](https://placehold.co/15x15/576F7E/576F7E.png) `#576F7E`|
|Wolf Grey|WP1119|Warpaints|94|127|159|![#5E7F9F](https://placehold.co/15x15/5E7F9F/5E7F9F.png) `#5E7F9F`|
|Wolf Grey|null|Warpaints Fanatic|79|120|163|![#4F78A3](https://placehold.co/15x15/4F78A3/4F78A3.png) `#4F78A3`|
|Woodland Camo|null|Warpaints Fanatic|75|97|73|![#4B6149](https://placehold.co/15x15/4B6149/4B6149.png) `#4B6149`|
|Worn Stone|null|Warpaints Fanatic|196|191|177|![#C4BFB1](https://placehold.co/15x15/C4BFB1/C4BFB1.png) `#C4BFB1`|
|Wraith Black|null|D&D Undead Set|60|63|80|![#3C3F50](https://placehold.co/15x15/3C3F50/3C3F50.png) `#3C3F50`|
|Wyrmling Red|null|Warpaints Air|180|54|70|![#B43646](https://placehold.co/15x15/B43646/B43646.png) `#B43646`|
|Wyvern Fury|null|Warpaints Fanatic|153|50|67|![#993243](https://placehold.co/15x15/993243/993243.png) `#993243`|
|Xanathar Blue|null|D&D Underdark Set|46|181|176|![#2EB5B0](https://placehold.co/15x15/2EB5B0/2EB5B0.png) `#2EB5B0`|
|Yellow Dune|null|Warpaints Air|194|153|77|![#C2994D](https://placehold.co/15x15/C2994D/C2994D.png) `#C2994D`|
|Yeti White|null|Warpaints Air|183|186|191|![#B7BABF](https://placehold.co/15x15/B7BABF/B7BABF.png) `#B7BABF`|
|Zealot Yellow|null|Speedpaint Set 2.0|244|208|8|![#F4D008](https://placehold.co/15x15/F4D008/F4D008.png) `#F4D008`|
|Zealot Yellow|null|Speedpaint Set|241|209|47|![#F1D12F](https://placehold.co/15x15/F1D12F/F1D12F.png) `#F1D12F`|
|Zephyr Pink|null|Metallic Colours Paint Set|180|64|111|![#B4406F](https://placehold.co/15x15/B4406F/B4406F.png) `#B4406F`|
|Zephyr Pink|null|Warpaints Air|107|48|77|![#6B304D](https://placehold.co/15x15/6B304D/6B304D.png) `#6B304D`|
|Zombie Flesh|null|D&D Nolzur's Marvelous Pigments|176|193|148|![#B0C194](https://placehold.co/15x15/B0C194/B0C194.png) `#B0C194`|
|Zombie Flesh|null|Warpaints Air|175|179|149|![#AFB395](https://placehold.co/15x15/AFB395/AFB395.png) `#AFB395`|
<p align="center"><img src="../logos/logo_rnd.png" height="70" /></p>
<p align="center">Made available by <a href="https://miniaturepainterpro.app/">Miniature Painter Pro</a></p>
<p align="center">
<a href="https://play.google.com/store/apps/details?id=com.rfsp.paintmaster"> <img src="../logos/Android.png" height="30" /></a>
<a href="https://apps.apple.com/us/app/miniature-painter-pro/id1495938928"> <img src="../logos/iOS.png" height="30" /></a>
</p>
