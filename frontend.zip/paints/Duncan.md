# Duncan
![Duncan](../logos/Duncan.png "Duncan")

|Name|Set|R|G|B|Hex|
|---|---|---|---|---|---|
|Abyss Blue|Wave 2|51|74|102|![#334A66](https://placehold.co/15x15/334A66/334A66.png) `#334A66`|
|Ambush Yellow|Wave 3|227|204|115|![#E3CC73](https://placehold.co/15x15/E3CC73/E3CC73.png) `#E3CC73`|
|Amethyst Rayne|Wave 1|82|65|105|![#524169](https://placehold.co/15x15/524169/524169.png) `#524169`|
|Amphora Red|Wave 3|72|33|36|![#482124](https://placehold.co/15x15/482124/482124.png) `#482124`|
|Amulet Purple|Wave 2|190|172|210|![#BEACD2](https://placehold.co/15x15/BEACD2/BEACD2.png) `#BEACD2`|
|Ancient Forest|Wave 1|113|91|82|![#715B52](https://placehold.co/15x15/715B52/715B52.png) `#715B52`|
|Ancient Gold|Wave 3|119|103|66|![#776742](https://placehold.co/15x15/776742/776742.png) `#776742`|
|Antiquity Green|Wave 3|54|125|122|![#367D7A](https://placehold.co/15x15/367D7A/367D7A.png) `#367D7A`|
|Apocalypse Sky|Wave 3|227|78|63|![#E34E3F](https://placehold.co/15x15/E34E3F/E34E3F.png) `#E34E3F`|
|Archaic Sepia Wash|Wave 1|164|135|115|![#A48773](https://placehold.co/15x15/A48773/A48773.png) `#A48773`|
|Ares Flesh|Wave 2|222|194|135|![#DEC287](https://placehold.co/15x15/DEC287/DEC287.png) `#DEC287`|
|Argonaut Skin|Wave 2|167|142|108|![#A78E6C](https://placehold.co/15x15/A78E6C/A78E6C.png) `#A78E6C`|
|Ashen Grey|Wave 2|78|82|72|![#4E5248](https://placehold.co/15x15/4E5248/4E5248.png) `#4E5248`|
|Asmodeus Red|Wave 2|142|72|71|![#8E4847](https://placehold.co/15x15/8E4847/8E4847.png) `#8E4847`|
|Aztec Turquoise Wash|Wave 3|147|158|160|![#939EA0](https://placehold.co/15x15/939EA0/939EA0.png) `#939EA0`|
|Barbarian Brawn|Wave 1|143|94|84|![#8F5E54](https://placehold.co/15x15/8F5E54/8F5E54.png) `#8F5E54`|
|Bard Skin|Wave 2|149|111|97|![#956F61](https://placehold.co/15x15/956F61/956F61.png) `#956F61`|
|Batle Axe Brass|Wave 2|212|169|125|![#D4A97D](https://placehold.co/15x15/D4A97D/D4A97D.png) `#D4A97D`|
|Battle Mud Wash|Wave 1|121|106|93|![#796A5D](https://placehold.co/15x15/796A5D/796A5D.png) `#796A5D`|
|Berserker Red|Wave 1|77|26|21|![#4D1A15](https://placehold.co/15x15/4D1A15/4D1A15.png) `#4D1A15`|
|Blue Glaze|Wave 2|90|121|188|![#5A79BC](https://placehold.co/15x15/5A79BC/5A79BC.png) `#5A79BC`|
|Blue Steel|Wave 3|127|140|139|![#7F8C8B](https://placehold.co/15x15/7F8C8B/7F8C8B.png) `#7F8C8B`|
|Boar Hide|Wave 1|114|68|56|![#724438](https://placehold.co/15x15/724438/724438.png) `#724438`|
|Bone Wash|Wave 3|182|168|169|![#B6A8A9](https://placehold.co/15x15/B6A8A9/B6A8A9.png) `#B6A8A9`|
|Boot Strap Brown|Wave 3|142|103|75|![#8E674B](https://placehold.co/15x15/8E674B/8E674B.png) `#8E674B`|
|Carapace Green|Wave 3|79|149|90|![#4F955A](https://placehold.co/15x15/4F955A/4F955A.png) `#4F955A`|
|Carcharodon Grey|Wave 1|149|148|150|![#959496](https://placehold.co/15x15/959496/959496.png) `#959496`|
|Celestial Blue|Wave 1|105|145|192|![#6991C0](https://placehold.co/15x15/6991C0/6991C0.png) `#6991C0`|
|Centurion Red|Wave 3|230|49|50|![#E63132](https://placehold.co/15x15/E63132/E63132.png) `#E63132`|
|Cerberus Brown|Wave 2|223|173|88|![#DFAD58](https://placehold.co/15x15/DFAD58/DFAD58.png) `#DFAD58`|
|Chaos Bronze|Wave 3|166|139|109|![#A68B6D](https://placehold.co/15x15/A68B6D/A68B6D.png) `#A68B6D`|
|Cold Corpse Blue|Wave 1|80|85|92|![#50555C](https://placehold.co/15x15/50555C/50555C.png) `#50555C`|
|Contagion Green|Wave 3|139|158|123|![#8B9E7B](https://placehold.co/15x15/8B9E7B/8B9E7B.png) `#8B9E7B`|
|Craven Yellow|Wave 2|236|235|105|![#ECEB69](https://placehold.co/15x15/ECEB69/ECEB69.png) `#ECEB69`|
|Cuirass Leather|Wave 1|81|66|57|![#514239](https://placehold.co/15x15/514239/514239.png) `#514239`|
|Cursed Blue|Wave 2|65|153|179|![#4199B3](https://placehold.co/15x15/4199B3/4199B3.png) `#4199B3`|
|Cyber Pink|Wave 3|198|75|138|![#C64B8A](https://placehold.co/15x15/C64B8A/C64B8A.png) `#C64B8A`|
|Dark Sun Yellow|Wave 1|195|134|57|![#C38639](https://placehold.co/15x15/C38639/C38639.png) `#C38639`|
|Death Metal|Wave 3|105|101|93|![#69655D](https://placehold.co/15x15/69655D/69655D.png) `#69655D`|
|Death Reaper|Wave 1|67|65|66|![#434142](https://placehold.co/15x15/434142/434142.png) `#434142`|
|Decadent Purple|Wave 3|193|190|211|![#C1BED3](https://placehold.co/15x15/C1BED3/C1BED3.png) `#C1BED3`|
|Demon Red|Wave 1|210|17|22|![#D21116](https://placehold.co/15x15/D21116/D21116.png) `#D21116`|
|Doom Death Black|Wave 1|60|57|54|![#3C3936](https://placehold.co/15x15/3C3936/3C3936.png) `#3C3936`|
|Dragon Fang|Wave 1|158|132|97|![#9E8461](https://placehold.co/15x15/9E8461/9E8461.png) `#9E8461`|
|Dragon's Gold|Wave 1|205|162|78|![#CDA24E](https://placehold.co/15x15/CDA24E/CDA24E.png) `#CDA24E`|
|Dread Red|Wave 2|110|62|62|![#6E3E3E](https://placehold.co/15x15/6E3E3E/6E3E3E.png) `#6E3E3E`|
|Druid Flesh|Wave 2|83|61|51|![#533D33](https://placehold.co/15x15/533D33/533D33.png) `#533D33`|
|Dry Rust Brown|Wave 2|186|119|63|![#BA773F](https://placehold.co/15x15/BA773F/BA773F.png) `#BA773F`|
|Dungeon Stone Grey|Wave 1|92|94|95|![#5C5E5F](https://placehold.co/15x15/5C5E5F/5C5E5F.png) `#5C5E5F`|
|Dust Bowl|Wave 1|125|99|73|![#7D6349](https://placehold.co/15x15/7D6349/7D6349.png) `#7D6349`|
|Dwarven Iron|Wave 2|137|136|132|![#898884](https://placehold.co/15x15/898884/898884.png) `#898884`|
|Dwarven Skin|Wave 1|176|124|98|![#B07C62](https://placehold.co/15x15/B07C62/B07C62.png) `#B07C62`|
|Eidolon Grey|Wave 2|83|85|72|![#535548](https://placehold.co/15x15/535548/535548.png) `#535548`|
|Elder Robe|Wave 3|34|89|160|![#2259A0](https://placehold.co/15x15/2259A0/2259A0.png) `#2259A0`|
|Elixir Green|Wave 3|126|198|143|![#7EC68F](https://placehold.co/15x15/7EC68F/7EC68F.png) `#7EC68F`|
|Elven Skin|Wave 1|196|151|116|![#C49774](https://placehold.co/15x15/C49774/C49774.png) `#C49774`|
|Elysium Blue|Wave 1|81|121|171|![#5179AB](https://placehold.co/15x15/5179AB/5179AB.png) `#5179AB`|
|Emperor Red|Wave 3|160|49|64|![#A03140](https://placehold.co/15x15/A03140/A03140.png) `#A03140`|
|Emperor's Purple|Wave 3|122|96|137|![#7A6089](https://placehold.co/15x15/7A6089/7A6089.png) `#7A6089`|
|Enchantment Blue|Wave 3|52|125|170|![#347DAA](https://placehold.co/15x15/347DAA/347DAA.png) `#347DAA`|
|Enchantress Purple|Wave 3|89|54|98|![#593662](https://placehold.co/15x15/593662/593662.png) `#593662`|
|Enticing Purple|Wave 3|127|122|139|![#7F7A8B](https://placehold.co/15x15/7F7A8B/7F7A8B.png) `#7F7A8B`|
|Ethereal Green|Wave 1|86|127|45|![#567F2D](https://placehold.co/15x15/567F2D/567F2D.png) `#567F2D`|
|Evil Eye Red|Wave 2|193|93|79|![#C15D4F](https://placehold.co/15x15/C15D4F/C15D4F.png) `#C15D4F`|
|Fanatic Orange|Wave 1|217|74|46|![#D94A2E](https://placehold.co/15x15/D94A2E/D94A2E.png) `#D94A2E`|
|Faust Blue|Wave 3|69|81|91|![#45515B](https://placehold.co/15x15/45515B/45515B.png) `#45515B`|
|Field Grey|Wave 2|108|113|94|![#6C715E](https://placehold.co/15x15/6C715E/6C715E.png) `#6C715E`|
|Fire Opal|Wave 3|195|110|74|![#C36E4A](https://placehold.co/15x15/C36E4A/C36E4A.png) `#C36E4A`|
|Flak Gun Yellow|Wave 3|197|170|90|![#C5AA5A](https://placehold.co/15x15/C5AA5A/C5AA5A.png) `#C5AA5A`|
|Flaming Forge Orange|Wave 2|233|165|68|![#E9A544](https://placehold.co/15x15/E9A544/E9A544.png) `#E9A544`|
|Flesh Wash|Wave 1|196|166|120|![#C4A678](https://placehold.co/15x15/C4A678/C4A678.png) `#C4A678`|
|Frost Blue|Wave 3|120|150|157|![#78969D](https://placehold.co/15x15/78969D/78969D.png) `#78969D`|
|Fury Green|Wave 2|108|107|75|![#6C6B4B](https://placehold.co/15x15/6C6B4B/6C6B4B.png) `#6C6B4B`|
|Ghoul Green|Wave 2|82|189|151|![#52BD97](https://placehold.co/15x15/52BD97/52BD97.png) `#52BD97`|
|Gigawatt Blue|Wave 2|87|183|232|![#57B7E8](https://placehold.co/15x15/57B7E8/57B7E8.png) `#57B7E8`|
|Glistening Gold|Wave 1|155|134|100|![#9B8664](https://placehold.co/15x15/9B8664/9B8664.png) `#9B8664`|
|Glistening Gums|Wave 1|153|87|121|![#995779](https://placehold.co/15x15/995779/995779.png) `#995779`|
|Gloss Varnish|Wave 3|165|165|164|![#A5A5A4](https://placehold.co/15x15/A5A5A4/A5A5A4.png) `#A5A5A4`|
|Goblinoid Green|Wave 2|137|183|106|![#89B76A](https://placehold.co/15x15/89B76A/89B76A.png) `#89B76A`|
|Gravestone Blue|Wave 1|122|136|150|![#7A8896](https://placehold.co/15x15/7A8896/7A8896.png) `#7A8896`|
|Green Beret|Wave 2|171|171|135|![#ABAB87](https://placehold.co/15x15/ABAB87/ABAB87.png) `#ABAB87`|
|Green Glaze|Wave 2|149|203|116|![#95CB74](https://placehold.co/15x15/95CB74/95CB74.png) `#95CB74`|
|Griffon Claw|Wave 1|158|144|132|![#9E9084](https://placehold.co/15x15/9E9084/9E9084.png) `#9E9084`|
|Gung-ho Green|Wave 2|168|162|100|![#A8A264](https://placehold.co/15x15/A8A264/A8A264.png) `#A8A264`|
|Gyzmo Fur|Wave 2|210|137|80|![#D28950](https://placehold.co/15x15/D28950/D28950.png) `#D28950`|
|Hazard Yellow Wash|Wave 3|229|192|180|![#E5C0B4](https://placehold.co/15x15/E5C0B4/E5C0B4.png) `#E5C0B4`|
|Heirloom Gold|Wave 3|198|156|83|![#C69C53](https://placehold.co/15x15/C69C53/C69C53.png) `#C69C53`|
|Helion Red Wash|Wave 2|134|84|83|![#865453](https://placehold.co/15x15/865453/865453.png) `#865453`|
|Hellspawn Red|Wave 2|190|57|46|![#BE392E](https://placehold.co/15x15/BE392E/BE392E.png) `#BE392E`|
|Hot Pink|Wave 2|225|132|165|![#E184A5](https://placehold.co/15x15/E184A5/E184A5.png) `#E184A5`|
|Hydra Green|Wave 2|52|75|77|![#344B4D](https://placehold.co/15x15/344B4D/344B4D.png) `#344B4D`|
|Incubus Purple|Wave 3|106|105|108|![#6A696C](https://placehold.co/15x15/6A696C/6A696C.png) `#6A696C`|
|Inferno Orange|Wave 3|206|74|50|![#CE4A32](https://placehold.co/15x15/CE4A32/CE4A32.png) `#CE4A32`|
|Ion Blue|Wave 3|183|213|216|![#B7D5D8](https://placehold.co/15x15/B7D5D8/B7D5D8.png) `#B7D5D8`|
|Ivory Tusk|Wave 1|210|199|191|![#D2C7BF](https://placehold.co/15x15/D2C7BF/D2C7BF.png) `#D2C7BF`|
|Jade Green|Wave 2|46|121|104|![#2E7968](https://placehold.co/15x15/2E7968/2E7968.png) `#2E7968`|
|Keleton Legion|Wave 1|175|150|108|![#AF966C](https://placehold.co/15x15/AF966C/AF966C.png) `#AF966C`|
|Kobold Grey|Wave 2|133|139|117|![#858B75](https://placehold.co/15x15/858B75/858B75.png) `#858B75`|
|Kronos Flesh|Wave 2|191|154|111|![#BF9A6F](https://placehold.co/15x15/BF9A6F/BF9A6F.png) `#BF9A6F`|
|Legion Green|Wave 3|42|106|102|![#2A6A66](https://placehold.co/15x15/2A6A66/2A6A66.png) `#2A6A66`|
|Leviathan Blue|Wave 2|58|123|191|![#3A7BBF](https://placehold.co/15x15/3A7BBF/3A7BBF.png) `#3A7BBF`|
|Magi Purple Wash|Wave 2|79|51|80|![#4F3350](https://placehold.co/15x15/4F3350/4F3350.png) `#4F3350`|
|Manticore Ochre|Wave 2|214|151|68|![#D69744](https://placehold.co/15x15/D69744/D69744.png) `#D69744`|
|Marine Blue|Wave 1|67|73|111|![#43496F](https://placehold.co/15x15/43496F/43496F.png) `#43496F`|
|Matt Varnish|Wave 3|220|220|221|![#DCDCDD](https://placehold.co/15x15/DCDCDD/DCDCDD.png) `#DCDCDD`|
|Merald Green|Wave 1|60|92|67|![#3C5C43](https://placehold.co/15x15/3C5C43/3C5C43.png) `#3C5C43`|
|Mythic Turquoise|Wave 3|89|158|156|![#599E9C](https://placehold.co/15x15/599E9C/599E9C.png) `#599E9C`|
|Mythril Blade|Wave 1|125|127|127|![#7D7F7F](https://placehold.co/15x15/7D7F7F/7D7F7F.png) `#7D7F7F`|
|Necrosis Green Wash|Wave 1|123|138|105|![#7B8A69](https://placehold.co/15x15/7B8A69/7B8A69.png) `#7B8A69`|
|Neo Pink|Wave 2|243|188|215|![#F3BCD7](https://placehold.co/15x15/F3BCD7/F3BCD7.png) `#F3BCD7`|
|Noble Steed Brown|Wave 2|117|83|57|![#755339](https://placehold.co/15x15/755339/755339.png) `#755339`|
|Oblivion Black Wash|Wave 1|69|67|68|![#454344](https://placehold.co/15x15/454344/454344.png) `#454344`|
|Omega Blue|Wave 3|88|185|182|![#58B9B6](https://placehold.co/15x15/58B9B6/58B9B6.png) `#58B9B6`|
|Orange Flare|Wave 1|235|113|64|![#EB7140](https://placehold.co/15x15/EB7140/EB7140.png) `#EB7140`|
|Orange Glaze|Wave 2|248|159|91|![#F89F5B](https://placehold.co/15x15/F89F5B/F89F5B.png) `#F89F5B`|
|Orc Hide|Wave 2|123|155|104|![#7B9B68](https://placehold.co/15x15/7B9B68/7B9B68.png) `#7B9B68`|
|Overlord Brass|Wave 2|214|175|131|![#D6AF83](https://placehold.co/15x15/D6AF83/D6AF83.png) `#D6AF83`|
|Oxidation Green|Wave 3|52|68|76|![#34444C](https://placehold.co/15x15/34444C/34444C.png) `#34444C`|
|Paladin Flesh|Wave 2|118|86|75|![#76564B](https://placehold.co/15x15/76564B/76564B.png) `#76564B`|
|Pale Skin|Wave 3|202|170|122|![#CAAA7A](https://placehold.co/15x15/CAAA7A/CAAA7A.png) `#CAAA7A`|
|Panzer Yellow|Wave 3|165|142|66|![#A58E42](https://placehold.co/15x15/A58E42/A58E42.png) `#A58E42`|
|Perisher Pink|Wave 2|186|99|104|![#BA6368](https://placehold.co/15x15/BA6368/BA6368.png) `#BA6368`|
|Pestilence Green|Wave 3|211|223|149|![#D3DF95](https://placehold.co/15x15/D3DF95/D3DF95.png) `#D3DF95`|
|Plate Armour|Wave 1|120|121|121|![#787979](https://placehold.co/15x15/787979/787979.png) `#787979`|
|Platinum Crown|Wave 2|206|194|164|![#CEC2A4](https://placehold.co/15x15/CEC2A4/CEC2A4.png) `#CEC2A4`|
|Purple Glaze|Wave 2|182|121|170|![#B679AA](https://placehold.co/15x15/B679AA/B679AA.png) `#B679AA`|
|RC Flesh Wash|Wave 1|82|133|76|![#52854C](https://placehold.co/15x15/52854C/52854C.png) `#52854C`|
|Ranger Cloak|Wave 2|125|131|81|![#7D8351](https://placehold.co/15x15/7D8351/7D8351.png) `#7D8351`|
|Ray Gun Glow|Wave 2|71|176|194|![#47B0C2](https://placehold.co/15x15/47B0C2/47B0C2.png) `#47B0C2`|
|Red Glaze|Wave 2|243|131|102|![#F38366](https://placehold.co/15x15/F38366/F38366.png) `#F38366`|
|Red Rage|Wave 3|106|52|42|![#6A342A](https://placehold.co/15x15/6A342A/6A342A.png) `#6A342A`|
|Relic Blue|Wave 3|43|127|187|![#2B7FBB](https://placehold.co/15x15/2B7FBB/2B7FBB.png) `#2B7FBB`|
|Ritz O'Tin|Wave 3|150|130|115|![#968273](https://placehold.co/15x15/968273/968273.png) `#968273`|
|Rodent Grey|Wave 2|112|114|99|![#707263](https://placehold.co/15x15/707263/707263.png) `#707263`|
|Royal Cloak|Wave 1|91|66|73|![#5B4249](https://placehold.co/15x15/5B4249/5B4249.png) `#5B4249`|
|Runic Purple|Wave 1|155|141|180|![#9B8DB4](https://placehold.co/15x15/9B8DB4/9B8DB4.png) `#9B8DB4`|
|Rust Orange|Wave 1|185|77|55|![#B94D37](https://placehold.co/15x15/B94D37/B94D37.png) `#B94D37`|
|Sandstone|Wave 1|146|123|104|![#927B68](https://placehold.co/15x15/927B68/927B68.png) `#927B68`|
|Sanguine Scarlet|Wave 1|150|23|20|![#961714](https://placehold.co/15x15/961714/961714.png) `#961714`|
|Satyr Brown|Wave 2|213|150|87|![#D59657](https://placehold.co/15x15/D59657/D59657.png) `#D59657`|
|Scabbard Brown|Wave 3|123|94|70|![#7B5E46](https://placehold.co/15x15/7B5E46/7B5E46.png) `#7B5E46`|
|Scarab Red|Wave 3|176|64|69|![#B04045](https://placehold.co/15x15/B04045/B04045.png) `#B04045`|
|Scorched Earth|Wave 1|89|76|72|![#594C48](https://placehold.co/15x15/594C48/594C48.png) `#594C48`|
|Seafarer Blue|Wave 3|74|156|199|![#4A9CC7](https://placehold.co/15x15/4A9CC7/4A9CC7.png) `#4A9CC7`|
|Sentient Turquoise|Wave 2|58|131|160|![#3A83A0](https://placehold.co/15x15/3A83A0/3A83A0.png) `#3A83A0`|
|Septric Green|Wave 3|171|179|55|![#ABB337](https://placehold.co/15x15/ABB337/ABB337.png) `#ABB337`|
|Serpent Eye Yellow|Wave 3|245|209|13|![#F5D10D](https://placehold.co/15x15/F5D10D/F5D10D.png) `#F5D10D`|
|Shadow Blue|Wave 3|79|100|107|![#4F646B](https://placehold.co/15x15/4F646B/4F646B.png) `#4F646B`|
|Sir Coates Silver|Wave 1|77|79|79|![#4D4F4F](https://placehold.co/15x15/4D4F4F/4D4F4F.png) `#4D4F4F`|
|Skulker Yellow|Wave 1|244|158|0|![#F49E00](https://placehold.co/15x15/F49E00/F49E00.png) `#F49E00`|
|Smoke Grey Wash|Wave 3|251|252|251|![#FBFCFB](https://placehold.co/15x15/FBFCFB/FBFCFB.png) `#FBFCFB`|
|Solar Flare|Wave 3|238|127|33|![#EE7F21](https://placehold.co/15x15/EE7F21/EE7F21.png) `#EE7F21`|
|Sorceror's Cloak|Wave 1|120|88|141|![#78588D](https://placehold.co/15x15/78588D/78588D.png) `#78588D`|
|Spartan Bronze|Wave 1|100|69|52|![#644534](https://placehold.co/15x15/644534/644534.png) `#644534`|
|Spectral Purple|Wave 3|153|90|154|![#995A9A](https://placehold.co/15x15/995A9A/995A9A.png) `#995A9A`|
|Steampunk Copper|Wave 2|181|98|60|![#B5623C](https://placehold.co/15x15/B5623C/B5623C.png) `#B5623C`|
|Sun Bleach Yellow|Wave 3|245|227|80|![#F5E350](https://placehold.co/15x15/F5E350/F5E350.png) `#F5E350`|
|Sword Hilt Burgundy|Wave 1|119|61|74|![#773D4A](https://placehold.co/15x15/773D4A/773D4A.png) `#773D4A`|
|Talisman Green|Wave 2|121|192|66|![#79C042](https://placehold.co/15x15/79C042/79C042.png) `#79C042`|
|Tempest Blue Wash|Wave 2|62|81|101|![#3E5165](https://placehold.co/15x15/3E5165/3E5165.png) `#3E5165`|
|Temple Stone|Wave 1|163|145|121|![#A39179](https://placehold.co/15x15/A39179/A39179.png) `#A39179`|
|Top Brass|Wave 2|181|145|85|![#B59155](https://placehold.co/15x15/B59155/B59155.png) `#B59155`|
|Traitor Green|Wave 3|47|83|79|![#2F534F](https://placehold.co/15x15/2F534F/2F534F.png) `#2F534F`|
|Troll Snot Green|Wave 2|156|197|117|![#9CC575](https://placehold.co/15x15/9CC575/9CC575.png) `#9CC575`|
|Trooper White|Wave 1|236|234|223|![#ECEADF](https://placehold.co/15x15/ECEADF/ECEADF.png) `#ECEADF`|
|Twin Suns Yellow|Wave 3|229|230|172|![#E5E6AC](https://placehold.co/15x15/E5E6AC/E5E6AC.png) `#E5E6AC`|
|Ur Cloak|Wave 1|145|82|77|![#91524D](https://placehold.co/15x15/91524D/91524D.png) `#91524D`|
|Vambrace Brown|Wave 3|156|116|92|![#9C745C](https://placehold.co/15x15/9C745C/9C745C.png) `#9C745C`|
|Vampire Fang|Wave 1|203|184|155|![#CBB89B](https://placehold.co/15x15/CBB89B/CBB89B.png) `#CBB89B`|
|Von Evile Pimple|Wave 3|34|1|46|![#22012E](https://placehold.co/15x15/22012E/22012E.png) `#22012E`|
|War Master Green|Wave 3|58|65|64|![#3A4140](https://placehold.co/15x15/3A4140/3A4140.png) `#3A4140`|
|Wasteland Brown|Wave 1|133|108|92|![#856C5C](https://placehold.co/15x15/856C5C/856C5C.png) `#856C5C`|
|White Star|Wave 1|249|249|249|![#F9F9F9](https://placehold.co/15x15/F9F9F9/F9F9F9.png) `#F9F9F9`|
|Witching Hour Blue|Wave 2|50|106|179|![#326AB3](https://placehold.co/15x15/326AB3/326AB3.png) `#326AB3`|
|Wizard Grey|Wave 1|109|107|108|![#6D6B6C](https://placehold.co/15x15/6D6B6C/6D6B6C.png) `#6D6B6C`|
|Wolf Grey|Wave 1|98|117|135|![#627587](https://placehold.co/15x15/627587/627587.png) `#627587`|
|Wyvern Green|Wave 1|64|73|66|![#404942](https://placehold.co/15x15/404942/404942.png) `#404942`|
|Yellow Flame|Wave 1|248|175|43|![#F8AF2B](https://placehold.co/15x15/F8AF2B/F8AF2B.png) `#F8AF2B`|
|Yellow Glaze|Wave 2|242|240|117|![#F2F075](https://placehold.co/15x15/F2F075/F2F075.png) `#F2F075`|
|Zombie Rot|Wave 3|177|182|121|![#B1B679](https://placehold.co/15x15/B1B679/B1B679.png) `#B1B679`|
<p align="center"><img src="../logos/logo_rnd.png" height="70" /></p>
<p align="center">Made available by <a href="https://miniaturepainterpro.app/">Miniature Painter Pro</a></p>
<p align="center">
<a href="https://play.google.com/store/apps/details?id=com.rfsp.paintmaster"> <img src="../logos/Android.png" height="30" /></a>
<a href="https://apps.apple.com/us/app/miniature-painter-pro/id1495938928"> <img src="../logos/iOS.png" height="30" /></a>
</p>
