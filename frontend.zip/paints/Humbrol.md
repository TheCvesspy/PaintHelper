# Humbrol
![Humbrol](../logos/Humbrol.png "Humbrol")

|Name|Code|Set|R|G|B|Hex|
|---|---|---|---|---|---|---|
|Aluminium|56|Humbrol Acrylics - Metallics|202|209|215|![#CAD1D7](https://placehold.co/15x15/CAD1D7/CAD1D7.png) `#CAD1D7`|
|Aluminium|S56|Humbrol Aerosol Sprays|191|201|210|![#BFC9D2](https://placehold.co/15x15/BFC9D2/BFC9D2.png) `#BFC9D2`|
|Antique Bronze|171|Humbrol Acrylics - Metallics|161|103|66|![#A16742](https://placehold.co/15x15/A16742/A16742.png) `#A16742`|
|Army Green|102|Humbrol Acrylics - Matt|105|115|81|![#697351](https://placehold.co/15x15/697351/697351.png) `#697351`|
|Beige Green|S90|Humbrol Aerosol Sprays - Matt|218|233|194|![#DAE9C2](https://placehold.co/15x15/DAE9C2/DAE9C2.png) `#DAE9C2`|
|Black|85|Humbrol Acrylics - Satin|23|19|16|![#171310](https://placehold.co/15x15/171310/171310.png) `#171310`|
|Black|21|Humbrol Acrylics - Gloss|0|0|0|![#000000](https://placehold.co/15x15/000000/000000.png) `#000000`|
|Black|33|Humbrol Acrylics - Matt|0|0|0|![#000000](https://placehold.co/15x15/000000/000000.png) `#000000`|
|Black Gloss|S21|Humbrol Aerosol Sprays|0|0|0|![#000000](https://placehold.co/15x15/000000/000000.png) `#000000`|
|Black Matt|S33|Humbrol Aerosol Sprays|33|32|33|![#212021](https://placehold.co/15x15/212021/212021.png) `#212021`|
|Black Satin|S85|Humbrol Aerosol Sprays|41|37|38|![#292526](https://placehold.co/15x15/292526/292526.png) `#292526`|
|Blue|25|Humbrol Acrylics - Matt|34|56|129|![#223881](https://placehold.co/15x15/223881/223881.png) `#223881`|
|Brass|S54|Humbrol Aerosol Sprays|223|146|40|![#DF9228](https://placehold.co/15x15/DF9228/DF9228.png) `#DF9228`|
|Brass Metallic|54|Humbrol Acrylics - Metallics|226|146|7|![#E29207](https://placehold.co/15x15/E29207/E29207.png) `#E29207`|
|Bright Green|37|Humbrol Acrylics - Matt|90|170|49|![#5AAA31](https://placehold.co/15x15/5AAA31/5AAA31.png) `#5AAA31`|
|Bronze Metallic|55|Humbrol Acrylics - Metallics|180|88|21|![#B45815](https://placehold.co/15x15/B45815/B45815.png) `#B45815`|
|Brown|186|Humbrol Acrylics - Matt|135|83|59|![#87533B](https://placehold.co/15x15/87533B/87533B.png) `#87533B`|
|Brunswick Green|3|Humbrol Acrylics - Matt|33|60|29|![#213C1D](https://placehold.co/15x15/213C1D/213C1D.png) `#213C1D`|
|Brunswick Green|S3|Humbrol Aerosol Sprays|18|59|29|![#123B1D](https://placehold.co/15x15/123B1D/123B1D.png) `#123B1D`|
|Chocolate|98|Humbrol Acrylics - Matt|119|81|60|![#77513C](https://placehold.co/15x15/77513C/77513C.png) `#77513C`|
|Chrome Silver|191|Humbrol Acrylics - Metallics|229|233|236|![#E5E9EC](https://placehold.co/15x15/E5E9EC/E5E9EC.png) `#E5E9EC`|
|Chrome Silver|S191|Humbrol Aerosol Sprays|228|235|241|![#E4EBF1](https://placehold.co/15x15/E4EBF1/E4EBF1.png) `#E4EBF1`|
|Copper|12|Humbrol Acrylics - Metallics|164|79|24|![#A44F18](https://placehold.co/15x15/A44F18/A44F18.png) `#A44F18`|
|Cream|103|Humbrol Acrylics - Matt|236|214|138|![#ECD68A](https://placehold.co/15x15/ECD68A/ECD68A.png) `#ECD68A`|
|Crimson|20|Humbrol Acrylics - Gloss|147|22|30|![#93161E](https://placehold.co/15x15/93161E/93161E.png) `#93161E`|
|Dark Brown|S29|Humbrol Aerosol Sprays|236|219|203|![#ECDBCB](https://placehold.co/15x15/ECDBCB/ECDBCB.png) `#ECDBCB`|
|Dark Camouflage Grey Satin|156|Humbrol Acrylics - Gloss|130|119|115|![#827773](https://placehold.co/15x15/827773/827773.png) `#827773`|
|Dark Earth|29|Humbrol Acrylics - Matt|132|102|78|![#84664E](https://placehold.co/15x15/84664E/84664E.png) `#84664E`|
|Dark Green|S163|Humbrol Aerosol Sprays - Satin|28|29|21|![#1C1D15](https://placehold.co/15x15/1C1D15/1C1D15.png) `#1C1D15`|
|Dark Green|S30|Humbrol Aerosol Sprays|26|105|73|![#1A6949](https://placehold.co/15x15/1A6949/1A6949.png) `#1A6949`|
|Dark Green|30|Humbrol Acrylics - Matt|30|104|71|![#1E6847](https://placehold.co/15x15/1E6847/1E6847.png) `#1E6847`|
|Dark Green|163|Humbrol Acrylics - Gloss|35|43|19|![#232B13](https://placehold.co/15x15/232B13/232B13.png) `#232B13`|
|Dark Grey|32|Humbrol Acrylics - Matt|65|68|75|![#41444B](https://placehold.co/15x15/41444B/41444B.png) `#41444B`|
|Desert Tan|S237|Humbrol Aerosol Sprays|183|168|137|![#B7A889](https://placehold.co/15x15/B7A889/B7A889.png) `#B7A889`|
|Desert Yellow|S93|Humbrol Aerosol Sprays|191|147|82|![#BF9352](https://placehold.co/15x15/BF9352/BF9352.png) `#BF9352`|
|Desert Yellow|93|Humbrol Acrylics - Matt|198|151|73|![#C69749](https://placehold.co/15x15/C69749/C69749.png) `#C69749`|
|Duck Egg Blue|23|Humbrol Acrylics - Matt|213|236|228|![#D5ECE4](https://placehold.co/15x15/D5ECE4/D5ECE4.png) `#D5ECE4`|
|Emerald Green|2|Humbrol Acrylics - Gloss|3|124|53|![#037C35](https://placehold.co/15x15/037C35/037C35.png) `#037C35`|
|Extra Dark Sea Grey|123|Humbrol Acrylics - Gloss|110|109|117|![#6E6D75](https://placehold.co/15x15/6E6D75/6E6D75.png) `#6E6D75`|
|Fire Orange|209|Humbrol Acrylics - Gloss|224|24|27|![#E0181B](https://placehold.co/15x15/E0181B/E0181B.png) `#E0181B`|
|Flesh|61|Humbrol Acrylics - Matt|236|143|84|![#EC8F54](https://placehold.co/15x15/EC8F54/EC8F54.png) `#EC8F54`|
|Fluorescent Signal Green|208|Humbrol Acrylics - Gloss|90|170|49|![#5AAA31](https://placehold.co/15x15/5AAA31/5AAA31.png) `#5AAA31`|
|French Blue|14|Humbrol Acrylics - Gloss|14|69|149|![#0E4595](https://placehold.co/15x15/0E4595/0E4595.png) `#0E4595`|
|German Camouflage Red|160|Humbrol Acrylics - Matt|98|51|25|![#623319](https://placehold.co/15x15/623319/623319.png) `#623319`|
|Gloss Purple|S68|Humbrol Aerosol Sprays|72|58|94|![#483A5E](https://placehold.co/15x15/483A5E/483A5E.png) `#483A5E`|
|Gloss Varnish|35|Humbrol Acrylics - Gloss|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Gold|S16|Humbrol Aerosol Sprays|224|172|37|![#E0AC25](https://placehold.co/15x15/E0AC25/E0AC25.png) `#E0AC25`|
|Gold|16|Humbrol Acrylics - Metallics|226|174|0|![#E2AE00](https://placehold.co/15x15/E2AE00/E2AE00.png) `#E2AE00`|
|Grass Green|80|Humbrol Acrylics - Matt|106|113|69|![#6A7145](https://placehold.co/15x15/6A7145/6A7145.png) `#6A7145`|
|Grass Green|S80|Humbrol Aerosol Sprays|103|111|72|![#676F48](https://placehold.co/15x15/676F48/676F48.png) `#676F48`|
|Grey|S64|Humbrol Aerosol Sprays|153|156|163|![#999CA3](https://placehold.co/15x15/999CA3/999CA3.png) `#999CA3`|
|Gun Metal|S53|Humbrol Aerosol Sprays|42|43|27|![#2A2B1B](https://placehold.co/15x15/2A2B1B/2A2B1B.png) `#2A2B1B`|
|Gunmetal|53|Humbrol Acrylics - Metallics|42|42|42|![#2A2A2A](https://placehold.co/15x15/2A2A2A/2A2A2A.png) `#2A2A2A`|
|Insignia Red|153|Humbrol Acrylics - Matt|178|31|37|![#B21F25](https://placehold.co/15x15/B21F25/B21F25.png) `#B21F25`|
|Insignia Yellow|154|Humbrol Acrylics - Matt|249|180|0|![#F9B400](https://placehold.co/15x15/F9B400/F9B400.png) `#F9B400`|
|Italian Racing Red|S220|Humbrol Aerosol Sprays|195|32|37|![#C32025](https://placehold.co/15x15/C32025/C32025.png) `#C32025`|
|Ivory|41|Humbrol Acrylics - Gloss|248|244|199|![#F8F4C7](https://placehold.co/15x15/F8F4C7/F8F4C7.png) `#F8F4C7`|
|Khaki|26|Humbrol Acrylics - Matt|155|104|23|![#9B6817](https://placehold.co/15x15/9B6817/9B6817.png) `#9B6817`|
|Khaki Drill|72|Humbrol Acrylics - Matt|173|147|122|![#AD937A](https://placehold.co/15x15/AD937A/AD937A.png) `#AD937A`|
|Leather|62|Humbrol Acrylics - Matt|173|81|40|![#AD5128](https://placehold.co/15x15/AD5128/AD5128.png) `#AD5128`|
|Lemon|99|Humbrol Acrylics - Matt|248|224|0|![#F8E000](https://placehold.co/15x15/F8E000/F8E000.png) `#F8E000`|
|Light Grey|64|Humbrol Acrylics - Matt|207|208|210|![#CFD0D2](https://placehold.co/15x15/CFD0D2/CFD0D2.png) `#CFD0D2`|
|Light Olive|S86|Humbrol Aerosol Sprays|102|92|64|![#665C40](https://placehold.co/15x15/665C40/665C40.png) `#665C40`|
|Lime|38|Humbrol Acrylics - Gloss|126|173|43|![#7EAD2B](https://placehold.co/15x15/7EAD2B/7EAD2B.png) `#7EAD2B`|
|Lime Green|S38|Humbrol Aerosol Sprays|192|208|161|![#C0D0A1](https://placehold.co/15x15/C0D0A1/C0D0A1.png) `#C0D0A1`|
|Magenta|58|Humbrol Acrylics - Matt|188|73|150|![#BC4996](https://placehold.co/15x15/BC4996/BC4996.png) `#BC4996`|
|Matt Olive Drab|155|Humbrol Acrylics - Matt|82|81|35|![#525123](https://placehold.co/15x15/525123/525123.png) `#525123`|
|Matt Tank Grey|67|Humbrol Acrylics - Matt|43|58|61|![#2B3A3D](https://placehold.co/15x15/2B3A3D/2B3A3D.png) `#2B3A3D`|
|Mediterranean Blue|48|Humbrol Acrylics - Gloss|50|138|176|![#328AB0](https://placehold.co/15x15/328AB0/328AB0.png) `#328AB0`|
|Medium Sea Grey|S165|Humbrol Aerosol Sprays - Satin|155|162|170|![#9BA2AA](https://placehold.co/15x15/9BA2AA/9BA2AA.png) `#9BA2AA`|
|Middle Blue|89|Humbrol Acrylics - Matt|69|152|192|![#4598C0](https://placehold.co/15x15/4598C0/4598C0.png) `#4598C0`|
|Midnight Blue|15|Humbrol Acrylics - Gloss|33|47|94|![#212F5E](https://placehold.co/15x15/212F5E/212F5E.png) `#212F5E`|
|Midnight Blue|S15|Humbrol Aerosol Sprays|29|49|99|![#1D3163](https://placehold.co/15x15/1D3163/1D3163.png) `#1D3163`|
|Natural Wood|110|Humbrol Acrylics - Matt|153|103|70|![#996746](https://placehold.co/15x15/996746/996746.png) `#996746`|
|Oak|71|Humbrol Acrylics - Satin|242|223|183|![#F2DFB7](https://placehold.co/15x15/F2DFB7/F2DFB7.png) `#F2DFB7`|
|Ocean Grey|106|Humbrol Acrylics - Matt|110|115|83|![#6E7353](https://placehold.co/15x15/6E7353/6E7353.png) `#6E7353`|
|Olive Drab|S155|Humbrol Aerosol Sprays - Matt|76|78|38|![#4C4E26](https://placehold.co/15x15/4C4E26/4C4E26.png) `#4C4E26`|
|Olive Green|86|Humbrol Acrylics - Matt|111|95|62|![#6F5F3E](https://placehold.co/15x15/6F5F3E/6F5F3E.png) `#6F5F3E`|
|Orange|18|Humbrol Acrylics - Gloss|231|101|13|![#E7650D](https://placehold.co/15x15/E7650D/E7650D.png) `#E7650D`|
|Orange|S18|Humbrol Aerosol Sprays|228|110|40|![#E46E28](https://placehold.co/15x15/E46E28/E46E28.png) `#E46E28`|
|Pastel Blue|44|Humbrol Acrylics - Matt|194|215|242|![#C2D7F2](https://placehold.co/15x15/C2D7F2/C2D7F2.png) `#C2D7F2`|
|Pastel Green|36|Humbrol Acrylics - Matt|202|226|166|![#CAE2A6](https://placehold.co/15x15/CAE2A6/CAE2A6.png) `#CAE2A6`|
|Pastel Violet|42|Humbrol Acrylics - Matt|205|169|207|![#CDA9CF](https://placehold.co/15x15/CDA9CF/CDA9CF.png) `#CDA9CF`|
|Pink|57|Humbrol Acrylics - Matt|239|174|180|![#EFAEB4](https://placehold.co/15x15/EFAEB4/EFAEB4.png) `#EFAEB4`|
|Primer|1|Humbrol Acrylics - Matt|87|91|90|![#575B5A](https://placehold.co/15x15/575B5A/575B5A.png) `#575B5A`|
|Primer|S1|Humbrol Aerosol Sprays|82|93|87|![#525D57](https://placehold.co/15x15/525D57/525D57.png) `#525D57`|
|Purple|68|Humbrol Acrylics - Gloss|42|23|68|![#2A1744](https://placehold.co/15x15/2A1744/2A1744.png) `#2A1744`|
|RAF Blue|96|Humbrol Acrylics - Matt|103|114|144|![#677290](https://placehold.co/15x15/677290/677290.png) `#677290`|
|Red|19|Humbrol Acrylics - Gloss|216|13|32|![#D80D20](https://placehold.co/15x15/D80D20/D80D20.png) `#D80D20`|
|Red|S19|Humbrol Aerosol Sprays|222|29|46|![#DE1D2E](https://placehold.co/15x15/DE1D2E/DE1D2E.png) `#DE1D2E`|
|Rust|113|Humbrol Acrylics - Matt|174|106|87|![#AE6A57](https://placehold.co/15x15/AE6A57/AE6A57.png) `#AE6A57`|
|Sand|63|Humbrol Acrylics - Matt|214|156|74|![#D69C4A](https://placehold.co/15x15/D69C4A/D69C4A.png) `#D69C4A`|
|Sand|S63|Humbrol Aerosol Sprays|209|150|81|![#D19651](https://placehold.co/15x15/D19651/D19651.png) `#D19651`|
|Satin Varnish|135|Humbrol Acrylics - Gloss|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Scarlet|60|Humbrol Acrylics - Matt|186|24|22|![#BA1816](https://placehold.co/15x15/BA1816/BA1816.png) `#BA1816`|
|Sea Grey|S27|Humbrol Aerosol Sprays|80|86|84|![#505654](https://placehold.co/15x15/505654/505654.png) `#505654`|
|Sea Grey|27|Humbrol Acrylics - Matt|88|89|84|![#585954](https://placehold.co/15x15/585954/585954.png) `#585954`|
|Service Brown|10|Humbrol Acrylics - Gloss|67|51|35|![#433323](https://placehold.co/15x15/433323/433323.png) `#433323`|
|Signal Red|174|Humbrol Acrylics - Gloss|211|44|25|![#D32C19](https://placehold.co/15x15/D32C19/D32C19.png) `#D32C19`|
|Silver|S11|Humbrol Aerosol Sprays|208|209|211|![#D0D1D3](https://placehold.co/15x15/D0D1D3/D0D1D3.png) `#D0D1D3`|
|Silver|11|Humbrol Acrylics - Metallics|218|218|218|![#DADADA](https://placehold.co/15x15/DADADA/DADADA.png) `#DADADA`|
|Tan|9|Humbrol Acrylics - Gloss|176|83|24|![#B05318](https://placehold.co/15x15/B05318/B05318.png) `#B05318`|
|Tank Grey|S67|Humbrol Aerosol Sprays|36|56|63|![#24383F](https://placehold.co/15x15/24383F/24383F.png) `#24383F`|
|Trainer Yellow|24|Humbrol Acrylics - Matt|248|193|41|![#F8C129](https://placehold.co/15x15/F8C129/F8C129.png) `#F8C129`|
|US Ghost Grey|127|Humbrol Acrylics - Satin|173|191|201|![#ADBFC9](https://placehold.co/15x15/ADBFC9/ADBFC9.png) `#ADBFC9`|
|US Light Green|117|Humbrol Acrylics - Matt|86|100|65|![#566441](https://placehold.co/15x15/566441/566441.png) `#566441`|
|US Tan|118|Humbrol Acrylics - Matt|180|126|88|![#B47E58](https://placehold.co/15x15/B47E58/B47E58.png) `#B47E58`|
|WWI Blue|109|Humbrol Acrylics - Matt|93|127|175|![#5D7FAF](https://placehold.co/15x15/5D7FAF/5D7FAF.png) `#5D7FAF`|
|White|22|Humbrol Acrylics - Gloss|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|White|34|Humbrol Acrylics - Matt|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|White|130|Humbrol Acrylics - Gloss|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|White Gloss|S22|Humbrol Aerosol Sprays|243|239|238|![#F3EFEE](https://placehold.co/15x15/F3EFEE/F3EFEE.png) `#F3EFEE`|
|White Matt|S34|Humbrol Aerosol Sprays|50|50|50|![#323232](https://placehold.co/15x15/323232/323232.png) `#323232`|
|Yellow|69|Humbrol Acrylics - Gloss|252|219|0|![#FCDB00](https://placehold.co/15x15/FCDB00/FCDB00.png) `#FCDB00`|
|Yellow|S69|Humbrol Aerosol Sprays|252|218|6|![#FCDA06](https://placehold.co/15x15/FCDA06/FCDA06.png) `#FCDA06`|
<p align="center"><img src="../logos/logo_rnd.png" height="70" /></p>
<p align="center">Made available by <a href="https://miniaturepainterpro.app/">Miniature Painter Pro</a></p>
<p align="center">
<a href="https://play.google.com/store/apps/details?id=com.rfsp.paintmaster"> <img src="../logos/Android.png" height="30" /></a>
<a href="https://apps.apple.com/us/app/miniature-painter-pro/id1495938928"> <img src="../logos/iOS.png" height="30" /></a>
</p>
