# Liquitex
![Liquitex](../logos/Liquitex.png "Liquitex")

|Name|Code|Set|R|G|B|Hex|
|---|---|---|---|---|---|---|
|Alizarin Crimson Hue Permanent|116|Liquitex Heavy Body Acrylix|252|254|253|![#FCFEFD](https://placehold.co/15x15/FCFEFD/FCFEFD.png) `#FCFEFD`|
|Bright Aqua Green|660|Liquitex Heavy Body Acrylix|90|172|124|![#5AAC7C](https://placehold.co/15x15/5AAC7C/5AAC7C.png) `#5AAC7C`|
|Brilliant Blue|570|Liquitex Heavy Body Acrylix|3|123|201|![#037BC9](https://placehold.co/15x15/037BC9/037BC9.png) `#037BC9`|
|Brilliant Purple|590|Liquitex Heavy Body Acrylix|137|97|167|![#8961A7](https://placehold.co/15x15/8961A7/8961A7.png) `#8961A7`|
|Brilliant Yellow Green|840|Liquitex Heavy Body Acrylix|183|207|85|![#B7CF55](https://placehold.co/15x15/B7CF55/B7CF55.png) `#B7CF55`|
|Bronze Yellow|530|Liquitex Heavy Body Acrylix|129|108|51|![#816C33](https://placehold.co/15x15/816C33/816C33.png) `#816C33`|
|Burnt Sienna|127|Liquitex Heavy Body Acrylix|241|241|243|![#F1F1F3](https://placehold.co/15x15/F1F1F3/F1F1F3.png) `#F1F1F3`|
|Burnt Umber|128|Liquitex Heavy Body Acrylix|241|241|241|![#F1F1F1](https://placehold.co/15x15/F1F1F1/F1F1F1.png) `#F1F1F1`|
|Cadmium-free Orange|892|Liquitex Heavy Body Acrylix|232|116|39|![#E87427](https://placehold.co/15x15/E87427/E87427.png) `#E87427`|
|Cadmium-free Red Deep|895|Liquitex Heavy Body Acrylix|125|30|38|![#7D1E26](https://placehold.co/15x15/7D1E26/7D1E26.png) `#7D1E26`|
|Cadmium-free Red Light|893|Liquitex Heavy Body Acrylix|224|65|43|![#E0412B](https://placehold.co/15x15/E0412B/E0412B.png) `#E0412B`|
|Cadmium-free Red Medium|894|Liquitex Heavy Body Acrylix|177|43|44|![#B12B2C](https://placehold.co/15x15/B12B2C/B12B2C.png) `#B12B2C`|
|Cadmium-free Yellow Deep|891|Liquitex Heavy Body Acrylix|232|149|9|![#E89509](https://placehold.co/15x15/E89509/E89509.png) `#E89509`|
|Cadmium-free Yellow Light|889|Liquitex Heavy Body Acrylix|252|205|67|![#FCCD43](https://placehold.co/15x15/FCCD43/FCCD43.png) `#FCCD43`|
|Cadmium-free Yellow Medium|890|Liquitex Heavy Body Acrylix|222|163|1|![#DEA301](https://placehold.co/15x15/DEA301/DEA301.png) `#DEA301`|
|Cerulean Blue|164|Liquitex Heavy Body Acrylix|35|78|123|![#234E7B](https://placehold.co/15x15/234E7B/234E7B.png) `#234E7B`|
|Cerulean Blue Hue|470|Liquitex Heavy Body Acrylix|28|94|120|![#1C5E78](https://placehold.co/15x15/1C5E78/1C5E78.png) `#1C5E78`|
|Chromium Oxide Green|166|Liquitex Heavy Body Acrylix|92|110|52|![#5C6E34](https://placehold.co/15x15/5C6E34/5C6E34.png) `#5C6E34`|
|Deep Magenta|300|Liquitex Heavy Body Acrylix|74|26|40|![#4A1A28](https://placehold.co/15x15/4A1A28/4A1A28.png) `#4A1A28`|
|Deep Violet|115|Liquitex Heavy Body Acrylix|44|3|33|![#2C0321](https://placehold.co/15x15/2C0321/2C0321.png) `#2C0321`|
|Dioxazine Purple|186|Liquitex Heavy Body Acrylix|243|243|245|![#F3F3F5](https://placehold.co/15x15/F3F3F5/F3F3F5.png) `#F3F3F5`|
|Emerald Green|450|Liquitex Heavy Body Acrylix|50|111|42|![#326F2A](https://placehold.co/15x15/326F2A/326F2A.png) `#326F2A`|
|Fluorescent Blue|984|Liquitex Heavy Body Acrylix|0|160|251|![#00A0FB](https://placehold.co/15x15/00A0FB/00A0FB.png) `#00A0FB`|
|Fluorescent Green|985|Liquitex Heavy Body Acrylix|47|189|115|![#2FBD73](https://placehold.co/15x15/2FBD73/2FBD73.png) `#2FBD73`|
|Fluorescent Orange|982|Liquitex Heavy Body Acrylix|254|141|1|![#FE8D01](https://placehold.co/15x15/FE8D01/FE8D01.png) `#FE8D01`|
|Fluorescent Pink|987|Liquitex Heavy Body Acrylix|254|77|105|![#FE4D69](https://placehold.co/15x15/FE4D69/FE4D69.png) `#FE4D69`|
|Fluorescent Red|983|Liquitex Heavy Body Acrylix|255|76|54|![#FF4C36](https://placehold.co/15x15/FF4C36/FF4C36.png) `#FF4C36`|
|Fluorescent Yellow|981|Liquitex Heavy Body Acrylix|225|237|109|![#E1ED6D](https://placehold.co/15x15/E1ED6D/E1ED6D.png) `#E1ED6D`|
|Green Deep Permanent|350|Liquitex Heavy Body Acrylix|11|68|23|![#0B4417](https://placehold.co/15x15/0B4417/0B4417.png) `#0B4417`|
|Green Gold|325|Liquitex Heavy Body Acrylix|65|57|21|![#413915](https://placehold.co/15x15/413915/413915.png) `#413915`|
|Hooker’s Green Deep Hue Permanent|225|Liquitex Heavy Body Acrylix|19|39|30|![#13271E](https://placehold.co/15x15/13271E/13271E.png) `#13271E`|
|Hooker’s Green Hue Permanent|224|Liquitex Heavy Body Acrylix|223|223|223|![#DFDFDF](https://placehold.co/15x15/DFDFDF/DFDFDF.png) `#DFDFDF`|
|Indantherene Blue|322|Liquitex Heavy Body Acrylix|45|36|57|![#2D2439](https://placehold.co/15x15/2D2439/2D2439.png) `#2D2439`|
|Indian Yellow|324|Liquitex Heavy Body Acrylix|195|129|17|![#C38111](https://placehold.co/15x15/C38111/C38111.png) `#C38111`|
|Indigo|208|Liquitex Heavy Body Acrylix|32|27|34|![#201B22](https://placehold.co/15x15/201B22/201B22.png) `#201B22`|
|Iridescent Antique Gold|237|Liquitex Heavy Body Acrylix|149|129|70|![#958146](https://placehold.co/15x15/958146/958146.png) `#958146`|
|Iridescent Black|338|Liquitex Heavy Body Acrylix|37|35|40|![#252328](https://placehold.co/15x15/252328/252328.png) `#252328`|
|Iridescent Bright Gold|234|Liquitex Heavy Body Acrylix|244|245|249|![#F4F5F9](https://placehold.co/15x15/F4F5F9/F4F5F9.png) `#F4F5F9`|
|Iridescent Bright Silver|236|Liquitex Heavy Body Acrylix|156|158|157|![#9C9E9D](https://placehold.co/15x15/9C9E9D/9C9E9D.png) `#9C9E9D`|
|Iridescent Rich Bronze|229|Liquitex Heavy Body Acrylix|114|70|35|![#724623](https://placehold.co/15x15/724623/724623.png) `#724623`|
|Iridescent Rich Copper|230|Liquitex Heavy Body Acrylix|147|83|55|![#935337](https://placehold.co/15x15/935337/935337.png) `#935337`|
|Iridescent Rich Gold|235|Liquitex Heavy Body Acrylix|140|105|49|![#8C6931](https://placehold.co/15x15/8C6931/8C6931.png) `#8C6931`|
|Iridescent Rich Silver|239|Liquitex Heavy Body Acrylix|241|243|242|![#F1F3F2](https://placehold.co/15x15/F1F3F2/F1F3F2.png) `#F1F3F2`|
|Iridescent Rose Gold|227|Liquitex Heavy Body Acrylix|186|86|88|![#BA5658](https://placehold.co/15x15/BA5658/BA5658.png) `#BA5658`|
|Iridescent White|238|Liquitex Heavy Body Acrylix|217|214|207|![#D9D6CF](https://placehold.co/15x15/D9D6CF/D9D6CF.png) `#D9D6CF`|
|Ivory Black|244|Liquitex Heavy Body Acrylix|34|35|37|![#222325](https://placehold.co/15x15/222325/222325.png) `#222325`|
|Light Bismuth Yellow|156|Liquitex Heavy Body Acrylix|227|219|172|![#E3DBAC](https://placehold.co/15x15/E3DBAC/E3DBAC.png) `#E3DBAC`|
|Light Blue Permanent|770|Liquitex Heavy Body Acrylix|138|197|193|![#8AC5C1](https://placehold.co/15x15/8AC5C1/8AC5C1.png) `#8AC5C1`|
|Light Blue Violet|680|Liquitex Heavy Body Acrylix|132|134|195|![#8486C3](https://placehold.co/15x15/8486C3/8486C3.png) `#8486C3`|
|Light Emerald Green|650|Liquitex Heavy Body Acrylix|91|162|58|![#5BA23A](https://placehold.co/15x15/5BA23A/5BA23A.png) `#5BA23A`|
|Light Green Permanent|312|Liquitex Heavy Body Acrylix|54|127|45|![#367F2D](https://placehold.co/15x15/367F2D/367F2D.png) `#367F2D`|
|Light Phthalocyanine Green|313|Liquitex Heavy Body Acrylix|142|219|225|![#8EDBE1](https://placehold.co/15x15/8EDBE1/8EDBE1.png) `#8EDBE1`|
|Light Pink|810|Liquitex Heavy Body Acrylix|242|244|243|![#F2F4F3](https://placehold.co/15x15/F2F4F3/F2F4F3.png) `#F2F4F3`|
|Manganese Blue Hue|275|Liquitex Heavy Body Acrylix|22|80|104|![#165068](https://placehold.co/15x15/165068/165068.png) `#165068`|
|Mars Black|276|Liquitex Heavy Body Acrylix|35|35|37|![#232325](https://placehold.co/15x15/232325/232325.png) `#232325`|
|Medium Magenta|500|Liquitex Heavy Body Acrylix|181|58|104|![#B53A68](https://placehold.co/15x15/B53A68/B53A68.png) `#B53A68`|
|Muted Green|501|Liquitex Heavy Body Acrylix|37|71|55|![#254737](https://placehold.co/15x15/254737/254737.png) `#254737`|
|Muted Grey|505|Liquitex Heavy Body Acrylix|52|52|52|![#343434](https://placehold.co/15x15/343434/343434.png) `#343434`|
|Muted Pink|504|Liquitex Heavy Body Acrylix|82|53|49|![#523531](https://placehold.co/15x15/523531/523531.png) `#523531`|
|Muted Turquoise|503|Liquitex Heavy Body Acrylix|40|51|57|![#283339](https://placehold.co/15x15/283339/283339.png) `#283339`|
|Muted Violet|502|Liquitex Heavy Body Acrylix|58|41|49|![#3A2931](https://placehold.co/15x15/3A2931/3A2931.png) `#3A2931`|
|Naphthol Crimson|292|Liquitex Heavy Body Acrylix|149|7|29|![#95071D](https://placehold.co/15x15/95071D/95071D.png) `#95071D`|
|Naphthol Red Light|294|Liquitex Heavy Body Acrylix|196|44|33|![#C42C21](https://placehold.co/15x15/C42C21/C42C21.png) `#C42C21`|
|Naples Yellow Hue|601|Liquitex Heavy Body Acrylix|213|150|70|![#D59646](https://placehold.co/15x15/D59646/D59646.png) `#D59646`|
|Neutral Gray 5|599|Liquitex Heavy Body Acrylix|111|104|94|![#6F685E](https://placehold.co/15x15/6F685E/6F685E.png) `#6F685E`|
|Parchment|436|Liquitex Heavy Body Acrylix|216|212|177|![#D8D4B1](https://placehold.co/15x15/D8D4B1/D8D4B1.png) `#D8D4B1`|
|Payne's Gray|310|Liquitex Heavy Body Acrylix|244|246|245|![#F4F6F5](https://placehold.co/15x15/F4F6F5/F4F6F5.png) `#F4F6F5`|
|Phthalocyanine Blue Green Shade|316|Liquitex Heavy Body Acrylix|238|238|240|![#EEEEF0](https://placehold.co/15x15/EEEEF0/EEEEF0.png) `#EEEEF0`|
|Phthalocyanine Blue Red Shade|314|Liquitex Heavy Body Acrylix|34|31|58|![#221F3A](https://placehold.co/15x15/221F3A/221F3A.png) `#221F3A`|
|Phthalocyanine Green Blue Shade|317|Liquitex Heavy Body Acrylix|245|245|247|![#F5F5F7](https://placehold.co/15x15/F5F5F7/F5F5F7.png) `#F5F5F7`|
|Phthalocyanine Green Yellow Shade|319|Liquitex Heavy Body Acrylix|3|77|44|![#034D2C](https://placehold.co/15x15/034D2C/034D2C.png) `#034D2C`|
|Prism Violet|391|Liquitex Heavy Body Acrylix|46|33|53|![#2E2135](https://placehold.co/15x15/2E2135/2E2135.png) `#2E2135`|
|Prussian Blue Hue|320|Liquitex Heavy Body Acrylix|25|39|52|![#192734](https://placehold.co/15x15/192734/192734.png) `#192734`|
|Pyrrole Crimson|326|Liquitex Heavy Body Acrylix|112|32|41|![#702029](https://placehold.co/15x15/702029/702029.png) `#702029`|
|Pyrrole Orange|323|Liquitex Heavy Body Acrylix|212|77|22|![#D44D16](https://placehold.co/15x15/D44D16/D44D16.png) `#D44D16`|
|Pyrrole Red|321|Liquitex Heavy Body Acrylix|166|24|22|![#A61816](https://placehold.co/15x15/A61816/A61816.png) `#A61816`|
|Quinacridone Blue Violet|118|Liquitex Heavy Body Acrylix|51|28|46|![#331C2E](https://placehold.co/15x15/331C2E/331C2E.png) `#331C2E`|
|Quinacridone Crimson|110|Liquitex Heavy Body Acrylix|121|28|38|![#791C26](https://placehold.co/15x15/791C26/791C26.png) `#791C26`|
|Quinacridone Magenta|114|Liquitex Heavy Body Acrylix|93|39|53|![#5D2735](https://placehold.co/15x15/5D2735/5D2735.png) `#5D2735`|
|Quinacridone Red|112|Liquitex Heavy Body Acrylix|161|59|44|![#A13B2C](https://placehold.co/15x15/A13B2C/A13B2C.png) `#A13B2C`|
|Quinacridone Red-orange|109|Liquitex Heavy Body Acrylix|112|24|36|![#701824](https://placehold.co/15x15/701824/701824.png) `#701824`|
|Raw Sienna|330|Liquitex Heavy Body Acrylix|241|243|242|![#F1F3F2](https://placehold.co/15x15/F1F3F2/F1F3F2.png) `#F1F3F2`|
|Raw Umber|331|Liquitex Heavy Body Acrylix|244|246|245|![#F4F6F5](https://placehold.co/15x15/F4F6F5/F4F6F5.png) `#F4F6F5`|
|Red Oxide|335|Liquitex Heavy Body Acrylix|134|66|45|![#86422D](https://placehold.co/15x15/86422D/86422D.png) `#86422D`|
|Sap Green Permanent|315|Liquitex Heavy Body Acrylix|43|50|17|![#2B3211](https://placehold.co/15x15/2B3211/2B3211.png) `#2B3211`|
|Titanium White|432|Liquitex Heavy Body Acrylix|240|242|241|![#F0F2F1](https://placehold.co/15x15/F0F2F1/F0F2F1.png) `#F0F2F1`|
|Transparent Burnt Sienna|129|Liquitex Heavy Body Acrylix|73|35|24|![#492318](https://placehold.co/15x15/492318/492318.png) `#492318`|
|Transparent Burnt Umber|130|Liquitex Heavy Body Acrylix|48|34|25|![#302219](https://placehold.co/15x15/302219/302219.png) `#302219`|
|Transparent Orange|035|Liquitex Heavy Body Acrylix|206|10|14|![#CE0A0E](https://placehold.co/15x15/CE0A0E/CE0A0E.png) `#CE0A0E`|
|Transparent Raw Sienna|332|Liquitex Heavy Body Acrylix|155|90|32|![#9B5A20](https://placehold.co/15x15/9B5A20/9B5A20.png) `#9B5A20`|
|Transparent Raw Umber|333|Liquitex Heavy Body Acrylix|64|51|35|![#403323](https://placehold.co/15x15/403323/403323.png) `#403323`|
|Transparent Viridian Hue|327|Liquitex Heavy Body Acrylix|2|103|73|![#026749](https://placehold.co/15x15/026749/026749.png) `#026749`|
|Turner’s Yellow|730|Liquitex Heavy Body Acrylix|205|135|23|![#CD8717](https://placehold.co/15x15/CD8717/CD8717.png) `#CD8717`|
|Turquoise Deep|561|Liquitex Heavy Body Acrylix|30|45|50|![#1E2D32](https://placehold.co/15x15/1E2D32/1E2D32.png) `#1E2D32`|
|Ultramarine Blue Green Shade|380|Liquitex Heavy Body Acrylix|29|31|88|![#1D1F58](https://placehold.co/15x15/1D1F58/1D1F58.png) `#1D1F58`|
|Ultramarine Blue Red Shade|382|Liquitex Heavy Body Acrylix|45|42|95|![#2D2A5F](https://placehold.co/15x15/2D2A5F/2D2A5F.png) `#2D2A5F`|
|Unbleached Titanium|434|Liquitex Heavy Body Acrylix|243|244|246|![#F3F4F6](https://placehold.co/15x15/F3F4F6/F3F4F6.png) `#F3F4F6`|
|Van Dyke Red|392|Liquitex Heavy Body Acrylix|54|40|37|![#362825](https://placehold.co/15x15/362825/362825.png) `#362825`|
|Viridian Hue Permanent|398|Liquitex Heavy Body Acrylix|15|60|40|![#0F3C28](https://placehold.co/15x15/0F3C28/0F3C28.png) `#0F3C28`|
|Vivid Lime Green|740|Liquitex Heavy Body Acrylix|175|187|27|![#AFBB1B](https://placehold.co/15x15/AFBB1B/AFBB1B.png) `#AFBB1B`|
|Vivid Red Orange|620|Liquitex Heavy Body Acrylix|215|94|25|![#D75E19](https://placehold.co/15x15/D75E19/D75E19.png) `#D75E19`|
|Yellow Light Hansa|411|Liquitex Heavy Body Acrylix|255|209|62|![#FFD13E](https://placehold.co/15x15/FFD13E/FFD13E.png) `#FFD13E`|
|Yellow Medium Azo|412|Liquitex Heavy Body Acrylix|242|183|43|![#F2B72B](https://placehold.co/15x15/F2B72B/F2B72B.png) `#F2B72B`|
|Yellow Orange Azo|414|Liquitex Heavy Body Acrylix|243|142|0|![#F38E00](https://placehold.co/15x15/F38E00/F38E00.png) `#F38E00`|
|Yellow Oxide|416|Liquitex Heavy Body Acrylix|192|133|33|![#C08521](https://placehold.co/15x15/C08521/C08521.png) `#C08521`|
<p align="center"><img src="../logos/logo_rnd.png" height="70" /></p>
<p align="center">Made available by <a href="https://miniaturepainterpro.app/">Miniature Painter Pro</a></p>
<p align="center">
<a href="https://play.google.com/store/apps/details?id=com.rfsp.paintmaster"> <img src="../logos/Android.png" height="30" /></a>
<a href="https://apps.apple.com/us/app/miniature-painter-pro/id1495938928"> <img src="../logos/iOS.png" height="30" /></a>
</p>
