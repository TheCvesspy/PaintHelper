# Revell
![Revell](../logos/Revell.png "Revell")

|Name|Set|R|G|B|Hex|
|---|---|---|---|---|---|
|Africa Brown|Email Color - Matt|212|156|97|![#D49C61](https://placehold.co/15x15/D49C61/D49C61.png) `#D49C61`|
|Aluminium|Email Color - Metallic|186|191|194|![#BABFC2](https://placehold.co/15x15/BABFC2/BABFC2.png) `#BABFC2`|
|Anthracite Grey|Email Color - Matt|46|47|52|![#2E2F34](https://placehold.co/15x15/2E2F34/2E2F34.png) `#2E2F34`|
|Beige|Email Color - Matt|167|147|123|![#A7937B](https://placehold.co/15x15/A7937B/A7937B.png) `#A7937B`|
|Beige|Email Color - Silk|207|180|135|![#CFB487](https://placehold.co/15x15/CFB487/CFB487.png) `#CFB487`|
|Black|Email Color - Gloss|23|24|28|![#17181C](https://placehold.co/15x15/17181C/17181C.png) `#17181C`|
|Black|Email Color - Silk|20|21|25|![#141519](https://placehold.co/15x15/141519/141519.png) `#141519`|
|Black|Email Color - Matt|33|32|38|![#212026](https://placehold.co/15x15/212026/212026.png) `#212026`|
|Black Green|Email Color - Matt|1|56|50|![#013832](https://placehold.co/15x15/013832/013832.png) `#013832`|
|Blue|Email Color - Matt|0|112|180|![#0070B4](https://placehold.co/15x15/0070B4/0070B4.png) `#0070B4`|
|Blue|Email Color - Gloss|1|68|138|![#01448A](https://placehold.co/15x15/01448A/01448A.png) `#01448A`|
|Brass|Email Color - Metallic|190|143|3|![#BE8F03](https://placehold.co/15x15/BE8F03/BE8F03.png) `#BE8F03`|
|Bronze|Email Color - Metallic|156|101|60|![#9C653C](https://placehold.co/15x15/9C653C/9C653C.png) `#9C653C`|
|Bronze Green|Email Color - Matt|74|86|62|![#4A563E](https://placehold.co/15x15/4A563E/4A563E.png) `#4A563E`|
|Brown|Email Color - Silk|118|92|77|![#765C4D](https://placehold.co/15x15/765C4D/765C4D.png) `#765C4D`|
|Brown|Email Color - Matt|164|93|51|![#A45D33](https://placehold.co/15x15/A45D33/A45D33.png) `#A45D33`|
|Carmine Red|Email Color - Matt|153|21|35|![#991523](https://placehold.co/15x15/991523/991523.png) `#991523`|
|Clear|Email Color - Gloss|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Clear|Email Color - Matt|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Clear Blue|Email Color - Gloss|168|222|248|![#A8DEF8](https://placehold.co/15x15/A8DEF8/A8DEF8.png) `#A8DEF8`|
|Clear Orange|Email Color - Gloss|254|140|69|![#FE8C45](https://placehold.co/15x15/FE8C45/FE8C45.png) `#FE8C45`|
|Clear Red|Email Color - Gloss|254|98|85|![#FE6255](https://placehold.co/15x15/FE6255/FE6255.png) `#FE6255`|
|Copper|Email Color - Metallic|179|116|81|![#B37451](https://placehold.co/15x15/B37451/B37451.png) `#B37451`|
|Dark Blue|Email Color - Silk|31|45|82|![#1F2D52](https://placehold.co/15x15/1F2D52/1F2D52.png) `#1F2D52`|
|Dark Earth (RAF)|Email Color - Matt|140|103|59|![#8C673B](https://placehold.co/15x15/8C673B/8C673B.png) `#8C673B`|
|Dark Green|Email Color - Silk|57|71|54|![#394736](https://placehold.co/15x15/394736/394736.png) `#394736`|
|Dark Green|Email Color - Matt|28|90|69|![#1C5A45](https://placehold.co/15x15/1C5A45/1C5A45.png) `#1C5A45`|
|Dark Green (RAF)|Email Color - Matt|39|72|55|![#274837](https://placehold.co/15x15/274837/274837.png) `#274837`|
|Dark Grey|Email Color - Silk|86|94|97|![#565E61](https://placehold.co/15x15/565E61/565E61.png) `#565E61`|
|Dust Grey|Email Color - Matt|86|94|97|![#565E61](https://placehold.co/15x15/565E61/565E61.png) `#565E61`|
|Earth Brown|Email Color - Matt|118|106|92|![#766A5C](https://placehold.co/15x15/766A5C/766A5C.png) `#766A5C`|
|Emerald Green|Email Color - Gloss|1|110|68|![#016E44](https://placehold.co/15x15/016E44/016E44.png) `#016E44`|
|Fiery Red|Email Color - Gloss|159|41|39|![#9F2927](https://placehold.co/15x15/9F2927/9F2927.png) `#9F2927`|
|Fiery Red|Email Color - Silk|160|38|37|![#A02625](https://placehold.co/15x15/A02625/A02625.png) `#A02625`|
|Flesh|Email Color - Matt|239|168|124|![#EFA87C](https://placehold.co/15x15/EFA87C/EFA87C.png) `#EFA87C`|
|Gold|Email Color - Metallic|205|178|133|![#CDB285](https://placehold.co/15x15/CDB285/CDB285.png) `#CDB285`|
|Granite Grey|Email Color - Matt|53|64|68|![#354044](https://placehold.co/15x15/354044/354044.png) `#354044`|
|Green|Email Color - Silk|86|115|61|![#56733D](https://placehold.co/15x15/56733D/56733D.png) `#56733D`|
|Greenish Grey|Email Color - Matt|88|93|86|![#585D56](https://placehold.co/15x15/585D56/585D56.png) `#585D56`|
|Grey|Email Color - Matt|121|135|144|![#798790](https://placehold.co/15x15/798790/798790.png) `#798790`|
|Grey|Email Color - Silk|140|150|159|![#8C969F](https://placehold.co/15x15/8C969F/8C969F.png) `#8C969F`|
|Grey (USAF)|Email Color - Matt|136|144|147|![#889093](https://placehold.co/15x15/889093/889093.png) `#889093`|
|Greyish Blue|Email Color - Matt|91|104|112|![#5B6870](https://placehold.co/15x15/5B6870/5B6870.png) `#5B6870`|
|Greyish Green|Email Color - Silk|118|118|90|![#76765A](https://placehold.co/15x15/76765A/76765A.png) `#76765A`|
|Gunship Grey|Email Color - Matt|94|99|105|![#5E6369](https://placehold.co/15x15/5E6369/5E6369.png) `#5E6369`|
|Italian Red|Email Color - Gloss|200|2|37|![#C80225](https://placehold.co/15x15/C80225/C80225.png) `#C80225`|
|Leaf Green|Email Color - Silk|39|109|59|![#276D3B](https://placehold.co/15x15/276D3B/276D3B.png) `#276D3B`|
|Leather Brown|Email Color - Matt|88|62|65|![#583E41](https://placehold.co/15x15/583E41/583E41.png) `#583E41`|
|Light Blue|Email Color - Gloss|40|129|187|![#2881BB](https://placehold.co/15x15/2881BB/2881BB.png) `#2881BB`|
|Light Blue|Email Color - Matt|134|185|180|![#86B9B4](https://placehold.co/15x15/86B9B4/86B9B4.png) `#86B9B4`|
|Light Green|Email Color - Matt|118|186|187|![#76BABB](https://placehold.co/15x15/76BABB/76BABB.png) `#76BABB`|
|Light Grey|Email Color - Silk|196|202|202|![#C4CACA](https://placehold.co/15x15/C4CACA/C4CACA.png) `#C4CACA`|
|Light Grey (USAF)|Email Color - Matt|157|162|166|![#9DA2A6](https://placehold.co/15x15/9DA2A6/9DA2A6.png) `#9DA2A6`|
|Light Olive|Email Color - Matt|121|121|109|![#79796D](https://placehold.co/15x15/79796D/79796D.png) `#79796D`|
|Luminous Orange|Email Color - Matt|250|2|0|![#FA0200](https://placehold.co/15x15/FA0200/FA0200.png) `#FA0200`|
|Luminous Red|Email Color - Silk|191|17|27|![#BF111B](https://placehold.co/15x15/BF111B/BF111B.png) `#BF111B`|
|Luminous Yellow|Email Color - Silk|236|234|64|![#ECEA40](https://placehold.co/15x15/ECEA40/ECEA40.png) `#ECEA40`|
|Mouse Grey|Email Color - Matt|108|112|111|![#6C706F](https://placehold.co/15x15/6C706F/6C706F.png) `#6C706F`|
|Mud Brown|Email Color - Gloss|129|83|49|![#815331](https://placehold.co/15x15/815331/815331.png) `#815331`|
|NATO Olive|Email Color - Matt|86|82|70|![#565246](https://placehold.co/15x15/565246/565246.png) `#565246`|
|Night Blue|Email Color - Gloss|40|40|94|![#28285E](https://placehold.co/15x15/28285E/28285E.png) `#28285E`|
|Ochre Brown|Email Color - Matt|174|133|81|![#AE8551](https://placehold.co/15x15/AE8551/AE8551.png) `#AE8551`|
|Olive Brown|Email Color - Matt|117|101|68|![#756544](https://placehold.co/15x15/756544/756544.png) `#756544`|
|Olive Green|Email Color - Silk|79|84|61|![#4F543D](https://placehold.co/15x15/4F543D/4F543D.png) `#4F543D`|
|Olive Grey|Email Color - Matt|86|88|87|![#565857](https://placehold.co/15x15/565857/565857.png) `#565857`|
|Olive Yellow|Email Color - Matt|66|67|53|![#424335](https://placehold.co/15x15/424335/424335.png) `#424335`|
|Orange|Email Color - Gloss|229|85|15|![#E5550F](https://placehold.co/15x15/E5550F/E5550F.png) `#E5550F`|
|Patina Green|Email Color - Silk|49|118|99|![#317663](https://placehold.co/15x15/317663/317663.png) `#317663`|
|Purple Red|Email Color - Silk|107|26|41|![#6B1A29](https://placehold.co/15x15/6B1A29/6B1A29.png) `#6B1A29`|
|Reddish Brown|Email Color - Matt|108|49|43|![#6C312B](https://placehold.co/15x15/6C312B/6C312B.png) `#6C312B`|
|Rust|Email Color - Matt|137|78|74|![#894E4A](https://placehold.co/15x15/894E4A/894E4A.png) `#894E4A`|
|Sandy Yellow|Email Color - Matt|184|150|79|![#B8964F](https://placehold.co/15x15/B8964F/B8964F.png) `#B8964F`|
|Sea Green|Email Color - Gloss|74|86|62|![#4A563E](https://placehold.co/15x15/4A563E/4A563E.png) `#4A563E`|
|Sea Green|Email Color - Matt|44|84|76|![#2C544C](https://placehold.co/15x15/2C544C/2C544C.png) `#2C544C`|
|Silver|Email Color - Metallic|166|169|174|![#A6A9AE](https://placehold.co/15x15/A6A9AE/A6A9AE.png) `#A6A9AE`|
|Sky (RAF)|Email Color - Matt|195|212|178|![#C3D4B2](https://placehold.co/15x15/C3D4B2/C3D4B2.png) `#C3D4B2`|
|Steel|Email Color - Metallic|117|122|128|![#757A80](https://placehold.co/15x15/757A80/757A80.png) `#757A80`|
|Stone Grey|Email Color - Matt|144|144|136|![#909088](https://placehold.co/15x15/909088/909088.png) `#909088`|
|Tank Grey|Email Color - Matt|72|75|82|![#484B52](https://placehold.co/15x15/484B52/484B52.png) `#484B52`|
|Tar Black|Email Color - Matt|37|36|41|![#252429](https://placehold.co/15x15/252429/252429.png) `#252429`|
|Ultramarine Blue|Email Color - Gloss|24|47|123|![#182F7B](https://placehold.co/15x15/182F7B/182F7B.png) `#182F7B`|
|White|Email Color - Matt|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|White|Email Color - Silk|186|191|194|![#BABFC2](https://placehold.co/15x15/BABFC2/BABFC2.png) `#BABFC2`|
|White|Email Color - Gloss|243|242|237|![#F3F2ED](https://placehold.co/15x15/F3F2ED/F3F2ED.png) `#F3F2ED`|
|Wood Brown|Email Color - Silk|156|104|54|![#9C6836](https://placehold.co/15x15/9C6836/9C6836.png) `#9C6836`|
|Yellow|Email Color - Gloss|253|218|56|![#FDDA38](https://placehold.co/15x15/FDDA38/FDDA38.png) `#FDDA38`|
|Yellow|Email Color - Matt|252|217|55|![#FCD937](https://placehold.co/15x15/FCD937/FCD937.png) `#FCD937`|
|Yellow|Email Color - Silk|254|165|0|![#FEA500](https://placehold.co/15x15/FEA500/FEA500.png) `#FEA500`|
<p align="center"><img src="../logos/logo_rnd.png" height="70" /></p>
<p align="center">Made available by <a href="https://miniaturepainterpro.app/">Miniature Painter Pro</a></p>
<p align="center">
<a href="https://play.google.com/store/apps/details?id=com.rfsp.paintmaster"> <img src="../logos/Android.png" height="30" /></a>
<a href="https://apps.apple.com/us/app/miniature-painter-pro/id1495938928"> <img src="../logos/iOS.png" height="30" /></a>
</p>
