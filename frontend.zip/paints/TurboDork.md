# Turbo Dork
![TurboDork](../logos/TurboDork.png "TurboDork")

|Name|Set|R|G|B|Hex|
|---|---|---|---|---|---|
|Absinthe|Turbo Dork|64|195|133|![#40C385](https://placehold.co/15x15/40C385/40C385.png) `#40C385`|
|All That Glitters|Turbo Dork|214|179|79|![#D6B34F](https://placehold.co/15x15/D6B34F/D6B34F.png) `#D6B34F`|
|Appleseed|Turbo Dork|68|204|108|![#44CC6C](https://placehold.co/15x15/44CC6C/44CC6C.png) `#44CC6C`|
|Bees Knees|Turbo Dork|255|225|69|![#FFE145](https://placehold.co/15x15/FFE145/FFE145.png) `#FFE145`|
|Black Ice|Turbo Dork|93|97|100|![#5D6164](https://placehold.co/15x15/5D6164/5D6164.png) `#5D6164`|
|Blue Steel|Turbo Dork|105|147|170|![#6993AA](https://placehold.co/15x15/6993AA/6993AA.png) `#6993AA`|
|Box Wine|Turbo Dork|181|91|87|![#B55B57](https://placehold.co/15x15/B55B57/B55B57.png) `#B55B57`|
|Bullion|Turbo Dork|255|195|98|![#FFC362](https://placehold.co/15x15/FFC362/FFC362.png) `#FFC362`|
|Cartridge Family|Turbo Dork|247|154|71|![#F79A47](https://placehold.co/15x15/F79A47/F79A47.png) `#F79A47`|
|Cool Ranch|Turbo Dork|73|94|168|![#495EA8](https://placehold.co/15x15/495EA8/495EA8.png) `#495EA8`|
|Curacao|Turbo Dork|76|204|213|![#4CCCD5](https://placehold.co/15x15/4CCCD5/4CCCD5.png) `#4CCCD5`|
|Da Ba Dee|Turbo Dork|75|148|203|![#4B94CB](https://placehold.co/15x15/4B94CB/4B94CB.png) `#4B94CB`|
|Death By|Turbo Dork|128|93|73|![#805D49](https://placehold.co/15x15/805D49/805D49.png) `#805D49`|
|Dork|Turbo Dork|72|214|255|![#48D6FF](https://placehold.co/15x15/48D6FF/48D6FF.png) `#48D6FF`|
|Fahrenheit|Turbo Dork|253|108|79|![#FD6C4F](https://placehold.co/15x15/FD6C4F/FD6C4F.png) `#FD6C4F`|
|Gold Rush|Turbo Dork|244|188|100|![#F4BC64](https://placehold.co/15x15/F4BC64/F4BC64.png) `#F4BC64`|
|Gordian Knot|Turbo Dork|123|170|120|![#7BAA78](https://placehold.co/15x15/7BAA78/7BAA78.png) `#7BAA78`|
|Hotline|Turbo Dork|255|106|186|![#FF6ABA](https://placehold.co/15x15/FF6ABA/FF6ABA.png) `#FF6ABA`|
|Life On Mars|Turbo Dork|158|76|63|![#9E4C3F](https://placehold.co/15x15/9E4C3F/9E4C3F.png) `#9E4C3F`|
|Maguro|Turbo Dork|144|221|254|![#90DDFE](https://placehold.co/15x15/90DDFE/90DDFE.png) `#90DDFE`|
|Malum Malus|Turbo Dork|84|200|95|![#54C85F](https://placehold.co/15x15/54C85F/54C85F.png) `#54C85F`|
|Multipass|Turbo Dork|255|130|81|![#FF8251](https://placehold.co/15x15/FF8251/FF8251.png) `#FF8251`|
|Orange You Glad|Turbo Dork|255|210|70|![#FFD246](https://placehold.co/15x15/FFD246/FFD246.png) `#FFD246`|
|Pearly Gates|Turbo Dork|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|People Eater|Turbo Dork|147|90|175|![#935AAF](https://placehold.co/15x15/935AAF/935AAF.png) `#935AAF`|
|Pucker|Turbo Dork|253|232|82|![#FDE852](https://placehold.co/15x15/FDE852/FDE852.png) `#FDE852`|
|Purl Grey|Turbo Dork|158|151|217|![#9E97D9](https://placehold.co/15x15/9E97D9/9E97D9.png) `#9E97D9`|
|Red Queen|Turbo Dork|180|76|77|![#B44C4D](https://placehold.co/15x15/B44C4D/B44C4D.png) `#B44C4D`|
|Redrum|Turbo Dork|217|78|80|![#D94E50](https://placehold.co/15x15/D94E50/D94E50.png) `#D94E50`|
|Sakura|Turbo Dork|255|176|203|![#FFB0CB](https://placehold.co/15x15/FFB0CB/FFB0CB.png) `#FFB0CB`|
|Silver Fox|Turbo Dork|181|185|188|![#B5B9BC](https://placehold.co/15x15/B5B9BC/B5B9BC.png) `#B5B9BC`|
|Six Shooter|Turbo Dork|117|126|130|![#757E82](https://placehold.co/15x15/757E82/757E82.png) `#757E82`|
|Sparkle Motion|Turbo Dork|207|201|194|![#CFC9C2](https://placehold.co/15x15/CFC9C2/CFC9C2.png) `#CFC9C2`|
|Spicy Meatball|Turbo Dork|212|79|88|![#D44F58](https://placehold.co/15x15/D44F58/D44F58.png) `#D44F58`|
|Summoning Sickness|Turbo Dork|178|185|84|![#B2B954](https://placehold.co/15x15/B2B954/B2B954.png) `#B2B954`|
|Syringa|Turbo Dork|206|139|175|![#CE8BAF](https://placehold.co/15x15/CE8BAF/CE8BAF.png) `#CE8BAF`|
|Taro|Turbo Dork|220|185|229|![#DCB9E5](https://placehold.co/15x15/DCB9E5/DCB9E5.png) `#DCB9E5`|
|Tin Star|Turbo Dork|191|202|207|![#BFCACF](https://placehold.co/15x15/BFCACF/BFCACF.png) `#BFCACF`|
|Turbo|Turbo Dork|255|173|204|![#FFADCC](https://placehold.co/15x15/FFADCC/FFADCC.png) `#FFADCC`|
|Two Cents|Turbo Dork|228|133|88|![#E48558](https://placehold.co/15x15/E48558/E48558.png) `#E48558`|
<p align="center"><img src="../logos/logo_rnd.png" height="70" /></p>
<p align="center">Made available by <a href="https://miniaturepainterpro.app/">Miniature Painter Pro</a></p>
<p align="center">
<a href="https://play.google.com/store/apps/details?id=com.rfsp.paintmaster"> <img src="../logos/Android.png" height="30" /></a>
<a href="https://apps.apple.com/us/app/miniature-painter-pro/id1495938928"> <img src="../logos/iOS.png" height="30" /></a>
</p>
