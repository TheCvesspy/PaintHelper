# Vallejo
![Vallejo](../logos/Vallejo.png "Vallejo")

|Name|Code|Set|R|G|B|Hex|
|---|---|---|---|---|---|---|
|3B Russian Green|71.281|Model Air|71|73|70|![#474946](https://placehold.co/15x15/474946/474946.png) `#474946`|
|6K Russian Brown|71.282|Model Air|77|76|74|![#4D4C4A](https://placehold.co/15x15/4D4C4A/4D4C4A.png) `#4D4C4A`|
|7K Russian Tan|71.283|Model Air|120|112|89|![#787059](https://placehold.co/15x15/787059/787059.png) `#787059`|
|A-14 Steel Grey|71.336|Model Air|105|114|113|![#697271](https://placehold.co/15x15/697271/697271.png) `#697271`|
|A-24M Camouflage Green|71.303|Model Air|87|89|68|![#575944](https://placehold.co/15x15/575944/575944.png) `#575944`|
|A-28M Greyish Blue|71.319|Model Air|113|159|146|![#719F92](https://placehold.co/15x15/719F92/719F92.png) `#719F92`|
|AII SV. Gol Light Blue|71.317|Model Air|124|197|214|![#7CC5D6](https://placehold.co/15x15/7CC5D6/7CC5D6.png) `#7CC5D6`|
|AMT-1 Light Grey Brown|71.320|Model Air|149|139|129|![#958B81](https://placehold.co/15x15/958B81/958B81.png) `#958B81`|
|AMT-11 Blue Grey|71.304|Model Air|90|97|107|![#5A616B](https://placehold.co/15x15/5A616B/5A616B.png) `#5A616B`|
|AMT-12 Dark Grey|71.308|Model Air|67|72|76|![#43484C](https://placehold.co/15x15/43484C/43484C.png) `#43484C`|
|AMT-4 Camouflage Green|71.301|Model Air|100|93|64|![#645D40](https://placehold.co/15x15/645D40/645D40.png) `#645D40`|
|AMT-7 Greyish Blue|71.318|Model Air|98|139|159|![#628B9F](https://placehold.co/15x15/628B9F/628B9F.png) `#628B9F`|
|Abyssal Turquoise|76.120|Game Air|27|62|84|![#1B3E54](https://placehold.co/15x15/1B3E54/1B3E54.png) `#1B3E54`|
|Abyssal Turquoise|72.120|Game Color|27|62|84|![#1B3E54](https://placehold.co/15x15/1B3E54/1B3E54.png) `#1B3E54`|
|Acid|72.607|Game Color Special FX|83|158|93|![#539E5D](https://placehold.co/15x15/539E5D/539E5D.png) `#539E5D`|
|Afrikakorps Tank Crew|70.336|Panzer Aces|110|112|91|![#6E705B](https://placehold.co/15x15/6E705B/6E705B.png) `#6E705B`|
|Afrikakorps Tank Crew Highlights|70.340|Panzer Aces|169|157|117|![#A99D75](https://placehold.co/15x15/A99D75/A99D75.png) `#A99D75`|
|Aged White|71.132|Model Air|227|211|175|![#E3D3AF](https://placehold.co/15x15/E3D3AF/E3D3AF.png) `#E3D3AF`|
|Aggressor Gray|71.274|Model Air|123|124|126|![#7B7C7E](https://placehold.co/15x15/7B7C7E/7B7C7E.png) `#7B7C7E`|
|Alien Purple|72.776|Game Air|109|98|166|![#6D62A6](https://placehold.co/15x15/6D62A6/6D62A6.png) `#6D62A6`|
|Alien Purple|72.076|Game Color|113|97|168|![#7161A8](https://placehold.co/15x15/7161A8/7161A8.png) `#7161A8`|
|Alien Purple|76.076|Game Air|113|97|168|![#7161A8](https://placehold.co/15x15/7161A8/7161A8.png) `#7161A8`|
|Alien Purple|28.025|Hobby Paint|113|97|168|![#7161A8](https://placehold.co/15x15/7161A8/7161A8.png) `#7161A8`|
|Aluminium|77.701|Metal Color|174|174|174|![#AEAEAE](https://placehold.co/15x15/AEAEAE/AEAEAE.png) `#AEAEAE`|
|Aluminum (Metallic)|71.062|Model Air|172|172|182|![#ACACB6](https://placehold.co/15x15/ACACB6/ACACB6.png) `#ACACB6`|
|Amaranth Red|70.829|Model Color|209|78|48|![#D14E30](https://placehold.co/15x15/D14E30/D14E30.png) `#D14E30`|
|Amethyst|74.027|Nocturna Models|112|42|129|![#702A81](https://placehold.co/15x15/702A81/702A81.png) `#702A81`|
|Andrea Blue|70.841|Model Color|2|112|175|![#0270AF](https://placehold.co/15x15/0270AF/0270AF.png) `#0270AF`|
|Angel Green|72.123|Game Color|50|77|44|![#324D2C](https://placehold.co/15x15/324D2C/324D2C.png) `#324D2C`|
|Angel Green|76.123|Game Air|50|77|44|![#324D2C](https://placehold.co/15x15/324D2C/324D2C.png) `#324D2C`|
|Anthracite Grey|71.052|Model Air|78|79|84|![#4E4F54](https://placehold.co/15x15/4E4F54/4E4F54.png) `#4E4F54`|
|Antique Gold|85.015|Arte Deco|133|106|59|![#856A3B](https://placehold.co/15x15/856A3B/856A3B.png) `#856A3B`|
|Antique Ochre|85.175|Arte Deco|205|157|55|![#CD9D37](https://placehold.co/15x15/CD9D37/CD9D37.png) `#CD9D37`|
|Antique White|85.002|Arte Deco|252|253|237|![#FCFDED](https://placehold.co/15x15/FCFDED/FCFDED.png) `#FCFDED`|
|Apple Green|85.082|Arte Deco|153|218|132|![#99DA84](https://placehold.co/15x15/99DA84/99DA84.png) `#99DA84`|
|Aquamarine|72.119|Game Color|0|124|116|![#007C74](https://placehold.co/15x15/007C74/007C74.png) `#007C74`|
|Arctic Blue (Metallic)|71.071|Model Air|55|60|79|![#373C4F](https://placehold.co/15x15/373C4F/373C4F.png) `#373C4F`|
|Arctic White|72.002|Game Color|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Arena Sand|85.012|Arte Deco|254|232|217|![#FEE8D9](https://placehold.co/15x15/FEE8D9/FEE8D9.png) `#FEE8D9`|
|Armor Green|72.466|Xpress Color|30|70|43|![#1E462B](https://placehold.co/15x15/1E462B/1E462B.png) `#1E462B`|
|Armour Brown|71.041|Model Air|79|65|64|![#4F4140](https://placehold.co/15x15/4F4140/4F4140.png) `#4F4140`|
|Athena Skin|72.107|Game Color|200|91|84|![#C85B54](https://placehold.co/15x15/C85B54/C85B54.png) `#C85B54`|
|Athena Skin|76.107|Game Air|200|91|84|![#C85B54](https://placehold.co/15x15/C85B54/C85B54.png) `#C85B54`|
|Autumn Red|85.176|Arte Deco|131|51|49|![#833331](https://placehold.co/15x15/833331/833331.png) `#833331`|
|Azure|70.902|Model Color|91|107|158|![#5B6B9E](https://placehold.co/15x15/5B6B9E/5B6B9E.png) `#5B6B9E`|
|BC Dark Brown|70.768|Model Color|118|86|61|![#76563D](https://placehold.co/15x15/76563D/76563D.png) `#76563D`|
|BS Dark Earth|71.323|Model Air|108|91|65|![#6C5B41](https://placehold.co/15x15/6C5B41/6C5B41.png) `#6C5B41`|
|BS Dark Green|71.324|Model Air|68|70|49|![#444631](https://placehold.co/15x15/444631/444631.png) `#444631`|
|BS Medium Sea Grey|71.307|Model Air|128|136|139|![#80888B](https://placehold.co/15x15/80888B/80888B.png) `#80888B`|
|Baby Blue|85.061|Arte Deco|188|206|236|![#BCCEEC](https://placehold.co/15x15/BCCEEC/BCCEEC.png) `#BCCEEC`|
|Baby Pink|85.046|Arte Deco|254|168|214|![#FEA8D6](https://placehold.co/15x15/FEA8D6/FEA8D6.png) `#FEA8D6`|
|Bag of Bones|72.450|Xpress Color|193|161|110|![#C1A16E](https://placehold.co/15x15/C1A16E/C1A16E.png) `#C1A16E`|
|Barbarian Flesh|72.771|Game Air|161|124|98|![#A17C62](https://placehold.co/15x15/A17C62/A17C62.png) `#A17C62`|
|Barbarian Skin|72.071|Game Color|146|102|65|![#926641](https://placehold.co/15x15/926641/926641.png) `#926641`|
|Barbarian Skin|76.071|Game Air|146|102|65|![#926641](https://placehold.co/15x15/926641/926641.png) `#926641`|
|Basalt Grey|70.869|Model Color|92|90|93|![#5C5A5D](https://placehold.co/15x15/5C5A5D/5C5A5D.png) `#5C5A5D`|
|Base Flesh|74.004|Nocturna Models|132|103|89|![#846759](https://placehold.co/15x15/846759/846759.png) `#846759`|
|Basic Blue|62.010|Premium Airbrush Color|1|152|205|![#0198CD](https://placehold.co/15x15/0198CD/0198CD.png) `#0198CD`|
|Basic Green|62.013|Premium Airbrush Color|0|110|71|![#006E47](https://placehold.co/15x15/006E47/006E47.png) `#006E47`|
|Basic Skin Tone|70.815|Model Color|233|172|141|![#E9AC8D](https://placehold.co/15x15/E9AC8D/E9AC8D.png) `#E9AC8D`|
|Basic Yellow|62.003|Premium Airbrush Color|254|195|3|![#FEC303](https://placehold.co/15x15/FEC303/FEC303.png) `#FEC303`|
|Battledress Brown|72.473|Xpress Color|93|76|50|![#5D4C32](https://placehold.co/15x15/5D4C32/5D4C32.png) `#5D4C32`|
|Beasty Brown|76.043|Game Air|124|82|34|![#7C5222](https://placehold.co/15x15/7C5222/7C5222.png) `#7C5222`|
|Beasty Brown|72.043|Game Color|127|85|37|![#7F5525](https://placehold.co/15x15/7F5525/7F5525.png) `#7F5525`|
|Beasty Brown|72.743|Game Air|122|84|61|![#7A543D](https://placehold.co/15x15/7A543D/7A543D.png) `#7A543D`|
|Beasty Brown|28.019|Hobby Paint|120|88|65|![#785841](https://placehold.co/15x15/785841/785841.png) `#785841`|
|Beige|70.917|Model Color|223|190|111|![#DFBE6F](https://placehold.co/15x15/DFBE6F/DFBE6F.png) `#DFBE6F`|
|Beige|71.074|Model Air|228|192|130|![#E4C082](https://placehold.co/15x15/E4C082/E4C082.png) `#E4C082`|
|Beige Brown|70.875|Model Color|129|96|65|![#816041](https://placehold.co/15x15/816041/816041.png) `#816041`|
|Beige Red|70.804|Model Color|176|110|75|![#B06E4B](https://placehold.co/15x15/B06E4B/B06E4B.png) `#B06E4B`|
|Berry Red|85.038|Arte Deco|168|25|21|![#A81915](https://placehold.co/15x15/A81915/A81915.png) `#A81915`|
|Bile|72.606|Game Color Special FX|164|198|0|![#A4C600](https://placehold.co/15x15/A4C600/A4C600.png) `#A4C600`|
|Bile Green|76.122|Game Air|213|217|0|![#D5D900](https://placehold.co/15x15/D5D900/D5D900.png) `#D5D900`|
|Bile Green|72.122|Game Color|213|217|0|![#D5D900](https://placehold.co/15x15/D5D900/D5D900.png) `#D5D900`|
|Black|76.051|Game Air|0|0|0|![#000000](https://placehold.co/15x15/000000/000000.png) `#000000`|
|Black|72.751|Game Air|1|1|1|![#010101](https://placehold.co/15x15/010101/010101.png) `#010101`|
|Black|71.057|Model Air|45|46|48|![#2D2E30](https://placehold.co/15x15/2D2E30/2D2E30.png) `#2D2E30`|
|Black|28.012|Hobby Paint|0|0|0|![#000000](https://placehold.co/15x15/000000/000000.png) `#000000`|
|Black|70.602|Surface Primer|6|6|6|![#060606](https://placehold.co/15x15/060606/060606.png) `#060606`|
|Black|72.051|Game Color|0|0|0|![#000000](https://placehold.co/15x15/000000/000000.png) `#000000`|
|Black|76.518|Wash FX|50|48|49|![#323031](https://placehold.co/15x15/323031/323031.png) `#323031`|
|Black|70.642|Mecha Color|1|1|1|![#010101](https://placehold.co/15x15/010101/010101.png) `#010101`|
|Black|72.094|Game Color|0|0|0|![#000000](https://placehold.co/15x15/000000/000000.png) `#000000`|
|Black|62.020|Premium Airbrush Color|1|1|1|![#010101](https://placehold.co/15x15/010101/010101.png) `#010101`|
|Black|85.120|Arte Deco|2|2|2|![#020202](https://placehold.co/15x15/020202/020202.png) `#020202`|
|Black|70.950|Model Color|35|29|29|![#231D1D](https://placehold.co/15x15/231D1D/231D1D.png) `#231D1D`|
|Black (Metallic)|71.073|Model Air|98|94|108|![#625E6C](https://placehold.co/15x15/625E6C/625E6C.png) `#625E6C`|
|Black Glaze|70.855|Model Color|56|56|56|![#383838](https://placehold.co/15x15/383838/383838.png) `#383838`|
|Black Green|70.980|Model Color|42|52|43|![#2A342B](https://placehold.co/15x15/2A342B/2A342B.png) `#2A342B`|
|Black Green|72.090|Game Color|61|99|74|![#3D634A](https://placehold.co/15x15/3D634A/3D634A.png) `#3D634A`|
|Black Green|71.018|Model Air|68|77|76|![#444D4C](https://placehold.co/15x15/444D4C/444D4C.png) `#444D4C`|
|Black Green|85.163|Arte Deco|30|57|48|![#1E3930](https://placehold.co/15x15/1E3930/1E3930.png) `#1E3930`|
|Black Green RLM70|71.021|Model Air|68|70|69|![#444645](https://placehold.co/15x15/444645/444645.png) `#444645`|
|Black Grey|70.862|Model Color|48|39|34|![#302722](https://placehold.co/15x15/302722/302722.png) `#302722`|
|Black Grey RLM66|71.055|Model Air|80|81|83|![#505153](https://placehold.co/15x15/505153/505153.png) `#505153`|
|Black Lotus|72.423|Xpress Color|48|38|39|![#302627](https://placehold.co/15x15/302627/302627.png) `#302627`|
|Black Red|70.859|Model Color|85|47|44|![#552F2C](https://placehold.co/15x15/552F2C/552F2C.png) `#552F2C`|
|Black Splash Mud|73.806|Weathering FX|39|38|43|![#27262B](https://placehold.co/15x15/27262B/27262B.png) `#27262B`|
|Black Thick Mud|73.812|Weathering FX|38|38|38|![#262626](https://placehold.co/15x15/262626/262626.png) `#262626`|
|Black Violet|70.751|Model Color|57|42|49|![#392A31](https://placehold.co/15x15/392A31/392A31.png) `#392A31`|
|Black Wash|69.518|Mecha Color|1|1|1|![#010101](https://placehold.co/15x15/010101/010101.png) `#010101`|
|Black Wash|73.301|Game Color Wash|14|13|14|![#0E0D0E](https://placehold.co/15x15/0E0D0E/0E0D0E.png) `#0E0D0E`|
|Black Wash|73.201|Game Color Wash|52|50|53|![#343235](https://placehold.co/15x15/343235/343235.png) `#343235`|
|Bloody Red|28.023|Hobby Paint|191|27|51|![#BF1B33](https://placehold.co/15x15/BF1B33/BF1B33.png) `#BF1B33`|
|Bloody Red|70.632|Surface Primer|172|44|41|![#AC2C29](https://placehold.co/15x15/AC2C29/AC2C29.png) `#AC2C29`|
|Bloody Red|72.710|Game Air|205|50|48|![#CD3230](https://placehold.co/15x15/CD3230/CD3230.png) `#CD3230`|
|Bloody Red|72.010|Game Color|212|28|28|![#D41C1C](https://placehold.co/15x15/D41C1C/D41C1C.png) `#D41C1C`|
|Bloody Red|76.010|Game Air|212|28|28|![#D41C1C](https://placehold.co/15x15/D41C1C/D41C1C.png) `#D41C1C`|
|Blue|72.088|Game Color|0|82|142|![#00528E](https://placehold.co/15x15/00528E/00528E.png) `#00528E`|
|Blue|69.019|Mecha Color|68|104|156|![#44689C](https://placehold.co/15x15/44689C/44689C.png) `#44689C`|
|Blue|71.004|Model Air|44|64|99|![#2C4063](https://placehold.co/15x15/2C4063/2C4063.png) `#2C4063`|
|Blue|70.925|Model Color|55|44|76|![#372C4C](https://placehold.co/15x15/372C4C/372C4C.png) `#372C4C`|
|Blue Fluorescent|70.736|Model Color|3|112|177|![#0370B1](https://placehold.co/15x15/0370B1/0370B1.png) `#0370B1`|
|Blue Green|70.808|Model Color|0|122|137|![#007A89](https://placehold.co/15x15/007A89/007A89.png) `#007A89`|
|Blue Green|62.012|Premium Airbrush Color|1|117|116|![#017574](https://placehold.co/15x15/017574/017574.png) `#017574`|
|Blue Grey|76.524|Wash FX|145|162|169|![#91A2A9](https://placehold.co/15x15/91A2A9/91A2A9.png) `#91A2A9`|
|Blue Grey|69.015|Mecha Color|106|135|149|![#6A8795](https://placehold.co/15x15/6A8795/6A8795.png) `#6A8795`|
|Blue Grey|71.115|Model Air|69|73|82|![#454952](https://placehold.co/15x15/454952/454952.png) `#454952`|
|Blue Grey Mist|85.072|Arte Deco|106|162|159|![#6AA29F](https://placehold.co/15x15/6AA29F/6AA29F.png) `#6AA29F`|
|Blue Grey Pale|70.905|Model Color|128|134|134|![#808686](https://placehold.co/15x15/808686/808686.png) `#808686`|
|Blue Maze|85.073|Arte Deco|59|93|106|![#3B5D6A](https://placehold.co/15x15/3B5D6A/3B5D6A.png) `#3B5D6A`|
|Blue Violet|70.811|Model Color|89|70|126|![#59467E](https://placehold.co/15x15/59467E/59467E.png) `#59467E`|
|Blue Wash|73.207|Game Color Wash|26|91|155|![#1A5B9B](https://placehold.co/15x15/1A5B9B/1A5B9B.png) `#1A5B9B`|
|Blueberry|85.064|Arte Deco|27|46|106|![#1B2E6A](https://placehold.co/15x15/1B2E6A/1B2E6A.png) `#1B2E6A`|
|Blueberry|74.031|Nocturna Models|108|117|184|![#6C75B8](https://placehold.co/15x15/6C75B8/6C75B8.png) `#6C75B8`|
|Bluegrass Green|85.080|Arte Deco|0|123|89|![#007B59](https://placehold.co/15x15/007B59/007B59.png) `#007B59`|
|Bone White|72.734|Game Air|195|184|156|![#C3B89C](https://placehold.co/15x15/C3B89C/C3B89C.png) `#C3B89C`|
|Bone White|28.013|Hobby Paint|212|190|153|![#D4BE99](https://placehold.co/15x15/D4BE99/D4BE99.png) `#D4BE99`|
|Bone White|76.034|Game Air|190|163|116|![#BEA374](https://placehold.co/15x15/BEA374/BEA374.png) `#BEA374`|
|Bone White|72.034|Game Color|190|163|116|![#BEA374](https://placehold.co/15x15/BEA374/BEA374.png) `#BEA374`|
|Bougainvillea|85.049|Arte Deco|172|45|132|![#AC2D84](https://placehold.co/15x15/AC2D84/AC2D84.png) `#AC2D84`|
|Boysenberry Pink|85.024|Arte Deco|219|69|132|![#DB4584](https://placehold.co/15x15/DB4584/DB4584.png) `#DB4584`|
|Brandywine|85.042|Arte Deco|123|28|22|![#7B1C16](https://placehold.co/15x15/7B1C16/7B1C16.png) `#7B1C16`|
|Brass|70.801|Model Color|100|59|29|![#643B1D](https://placehold.co/15x15/643B1D/643B1D.png) `#643B1D`|
|Brassy Brass|72.758|Game Air|161|83|35|![#A15323](https://placehold.co/15x15/A15323/A15323.png) `#A15323`|
|Brassy Brass|72.058|Game Color|233|215|203|![#E9D7CB](https://placehold.co/15x15/E9D7CB/E9D7CB.png) `#E9D7CB`|
|Bright Brass (Metallic)|71.067|Model Air|159|143|91|![#9F8F5B](https://placehold.co/15x15/9F8F5B/9F8F5B.png) `#9F8F5B`|
|Bright Bronze|72.057|Game Color|231|213|191|![#E7D5BF](https://placehold.co/15x15/E7D5BF/E7D5BF.png) `#E7D5BF`|
|Bright Bronze|72.757|Game Air|149|102|76|![#95664C](https://placehold.co/15x15/95664C/95664C.png) `#95664C`|
|Bright Green|85.091|Arte Deco|97|196|78|![#61C44E](https://placehold.co/15x15/61C44E/61C44E.png) `#61C44E`|
|Bright Orange|70.851|Model Color|224|89|33|![#E05921](https://placehold.co/15x15/E05921/E05921.png) `#E05921`|
|Bright Red|62.005|Premium Airbrush Color|157|39|35|![#9D2723](https://placehold.co/15x15/9D2723/9D2723.png) `#9D2723`|
|British Tank Crew|70.317|Panzer Aces|117|109|86|![#756D56](https://placehold.co/15x15/756D56/756D56.png) `#756D56`|
|British Tank Crew Highlights|70.321|Panzer Aces|234|194|132|![#EAC284](https://placehold.co/15x15/EAC284/EAC284.png) `#EAC284`|
|Bronze|69.062|Mecha Color|118|107|53|![#766B35](https://placehold.co/15x15/766B35/766B35.png) `#766B35`|
|Bronze|70.998|Model Color|83|60|29|![#533C1D](https://placehold.co/15x15/533C1D/533C1D.png) `#533C1D`|
|Bronze|81.123|Arte Deco|109|76|33|![#6D4C21](https://placehold.co/15x15/6D4C21/6D4C21.png) `#6D4C21`|
|Bronze Brown|76.036|Game Air|177|105|33|![#B16921](https://placehold.co/15x15/B16921/B16921.png) `#B16921`|
|Bronze Brown|72.036|Game Color|177|105|33|![#B16921](https://placehold.co/15x15/B16921/B16921.png) `#B16921`|
|Bronze Flesh Tone|72.736|Game Air|239|152|73|![#EF9849](https://placehold.co/15x15/EF9849/EF9849.png) `#EF9849`|
|Bronze Green|71.250|Model Air|84|86|72|![#545648](https://placehold.co/15x15/545648/545648.png) `#545648`|
|Bronze Green|70.897|Model Color|49|58|41|![#313A29](https://placehold.co/15x15/313A29/313A29.png) `#313A29`|
|Brown|69.034|Mecha Color|123|103|78|![#7B674E](https://placehold.co/15x15/7B674E/7B674E.png) `#7B674E`|
|Brown|76.513|Wash FX|123|95|71|![#7B5F47](https://placehold.co/15x15/7B5F47/7B5F47.png) `#7B5F47`|
|Brown|72.092|Game Color|154|99|42|![#9A632A](https://placehold.co/15x15/9A632A/9A632A.png) `#9A632A`|
|Brown Engine Soot|73.818|Weathering FX|88|78|69|![#584E45](https://placehold.co/15x15/584E45/584E45.png) `#584E45`|
|Brown Engine Soot (Matt)|69.818|Mecha Color|95|53|31|![#5F351F](https://placehold.co/15x15/5F351F/5F351F.png) `#5F351F`|
|Brown Glaze|70.854|Model Color|78|64|61|![#4E403D](https://placehold.co/15x15/4E403D/4E403D.png) `#4E403D`|
|Brown Green|71.030|Model Air|144|111|78|![#906F4E](https://placehold.co/15x15/906F4E/906F4E.png) `#906F4E`|
|Brown Grey|71.248|Model Air|98|97|95|![#62615F](https://placehold.co/15x15/62615F/62615F.png) `#62615F`|
|Brown RLM26|71.105|Model Air|132|65|56|![#844138](https://placehold.co/15x15/844138/844138.png) `#844138`|
|Brown Rose|70.803|Model Color|156|101|96|![#9C6560](https://placehold.co/15x15/9C6560/9C6560.png) `#9C6560`|
|Brown Sand|70.876|Model Color|144|97|69|![#906145](https://placehold.co/15x15/906145/906145.png) `#906145`|
|Brown Splash Mud|73.805|Weathering FX|52|42|41|![#342A29](https://placehold.co/15x15/342A29/342A29.png) `#342A29`|
|Brown Thick Mud|73.811|Weathering FX|70|65|62|![#46413E](https://placehold.co/15x15/46413E/46413E.png) `#46413E`|
|Brown Violet RLM81|71.264|Model Air|99|90|73|![#635A49](https://placehold.co/15x15/635A49/635A49.png) `#635A49`|
|Buff|70.976|Model Color|215|175|77|![#D7AF4D](https://placehold.co/15x15/D7AF4D/D7AF4D.png) `#D7AF4D`|
|Burgundy|85.037|Arte Deco|196|20|34|![#C41422](https://placehold.co/15x15/C41422/C41422.png) `#C41422`|
|Burned Flesh|72.770|Game Air|162|102|65|![#A26641](https://placehold.co/15x15/A26641/A26641.png) `#A26641`|
|Burned Flesh|74.002|Nocturna Models|97|71|70|![#614746](https://placehold.co/15x15/614746/614746.png) `#614746`|
|Burnt Iron|77.721|Metal Color|125|125|123|![#7D7D7B](https://placehold.co/15x15/7D7D7B/7D7D7B.png) `#7D7D7B`|
|Burnt Orange|85.030|Arte Deco|217|38|37|![#D92625](https://placehold.co/15x15/D92625/D92625.png) `#D92625`|
|Burnt Red|70.814|Model Color|118|60|58|![#763C3A](https://placehold.co/15x15/763C3A/763C3A.png) `#763C3A`|
|Burnt Sienna|85.116|Arte Deco|103|44|40|![#672C28](https://placehold.co/15x15/672C28/672C28.png) `#672C28`|
|Burnt Umber|85.117|Arte Deco|75|71|62|![#4B473E](https://placehold.co/15x15/4B473E/4B473E.png) `#4B473E`|
|Burnt Umber|70.941|Model Color|81|59|46|![#513B2E](https://placehold.co/15x15/513B2E/513B2E.png) `#513B2E`|
|Burnt Umber|71.040|Model Air|72|62|52|![#483E34](https://placehold.co/15x15/483E34/483E34.png) `#483E34`|
|Buttermilk|85.003|Arte Deco|255|253|226|![#FFFDE2](https://placehold.co/15x15/FFFDE2/FFFDE2.png) `#FFFDE2`|
|Calico Red|85.033|Arte Deco|226|15|22|![#E20F16](https://placehold.co/15x15/E20F16/E20F16.png) `#E20F16`|
|Camouflage Black Brown|70.822|Model Color|64|52|54|![#403436](https://placehold.co/15x15/403436/403436.png) `#403436`|
|Camouflage Black Green|70.741|Model Color|49|49|41|![#313129](https://placehold.co/15x15/313129/313129.png) `#313129`|
|Camouflage Brown|71.117|Model Air|174|144|110|![#AE906E](https://placehold.co/15x15/AE906E/AE906E.png) `#AE906E`|
|Camouflage Dark Green|70.979|Model Color|38|48|37|![#263025](https://placehold.co/15x15/263025/263025.png) `#263025`|
|Camouflage Dark Green|71.019|Model Air|75|78|71|![#4B4E47](https://placehold.co/15x15/4B4E47/4B4E47.png) `#4B4E47`|
|Camouflage Gray|71.280|Model Air|106|108|105|![#6A6C69](https://placehold.co/15x15/6A6C69/6A6C69.png) `#6A6C69`|
|Camouflage Green|72.467|Xpress Color|96|93|50|![#605D32](https://placehold.co/15x15/605D32/605D32.png) `#605D32`|
|Camouflage Green|76.031|Game Air|139|119|50|![#8B7732](https://placehold.co/15x15/8B7732/8B7732.png) `#8B7732`|
|Camouflage Green|72.031|Game Color|139|119|50|![#8B7732](https://placehold.co/15x15/8B7732/8B7732.png) `#8B7732`|
|Camouflage Grey|71.118|Model Air|134|121|102|![#867966](https://placehold.co/15x15/867966/867966.png) `#867966`|
|Camouflage Grey Green|71.116|Model Air|122|105|75|![#7A694B](https://placehold.co/15x15/7A694B/7A694B.png) `#7A694B`|
|Camouflage Medium Brown|71.038|Model Air|95|78|62|![#5F4E3E](https://placehold.co/15x15/5F4E3E/5F4E3E.png) `#5F4E3E`|
|Camouflage Middle Brown|70.740|Model Color|81|62|32|![#513E20](https://placehold.co/15x15/513E20/513E20.png) `#513E20`|
|Camouflage Olive Green|70.894|Model Color|60|61|47|![#3C3D2F](https://placehold.co/15x15/3C3D2F/3C3D2F.png) `#3C3D2F`|
|Camouflage Pale Brown|71.035|Model Air|121|100|83|![#796453](https://placehold.co/15x15/796453/796453.png) `#796453`|
|Candy Black|62.079|Premium Airbrush Color|76|65|63|![#4C413F](https://placehold.co/15x15/4C413F/4C413F.png) `#4C413F`|
|Candy Brown|62.078|Premium Airbrush Color|206|182|172|![#CEB6AC](https://placehold.co/15x15/CEB6AC/CEB6AC.png) `#CEB6AC`|
|Candy Dark Yellow|62.072|Premium Airbrush Color|248|176|117|![#F8B075](https://placehold.co/15x15/F8B075/F8B075.png) `#F8B075`|
|Candy Magenta|62.075|Premium Airbrush Color|225|126|170|![#E17EAA](https://placehold.co/15x15/E17EAA/E17EAA.png) `#E17EAA`|
|Candy Orange|62.073|Premium Airbrush Color|245|169|117|![#F5A975](https://placehold.co/15x15/F5A975/F5A975.png) `#F5A975`|
|Candy Racing Blue|62.076|Premium Airbrush Color|122|166|215|![#7AA6D7](https://placehold.co/15x15/7AA6D7/7AA6D7.png) `#7AA6D7`|
|Candy Racing Green|62.077|Premium Airbrush Color|162|213|208|![#A2D5D0](https://placehold.co/15x15/A2D5D0/A2D5D0.png) `#A2D5D0`|
|Candy Red|62.074|Premium Airbrush Color|229|136|119|![#E58877](https://placehold.co/15x15/E58877/E58877.png) `#E58877`|
|Candy Yellow|62.071|Premium Airbrush Color|252|227|126|![#FCE37E](https://placehold.co/15x15/FCE37E/FCE37E.png) `#FCE37E`|
|Canvas|70.314|Panzer Aces|110|101|84|![#6E6554](https://placehold.co/15x15/6E6554/6E6554.png) `#6E6554`|
|Canvas|70.763|Model Color|77|62|31|![#4D3E1F](https://placehold.co/15x15/4D3E1F/4D3E1F.png) `#4D3E1F`|
|Cardinal Purple|72.408|Xpress Color|200|25|40|![#C81928](https://placehold.co/15x15/C81928/C81928.png) `#C81928`|
|Caribbean Turquoise|72.414|Xpress Color|0|89|97|![#005961](https://placehold.co/15x15/005961/005961.png) `#005961`|
|Carmine|62.006|Premium Airbrush Color|172|46|50|![#AC2E32](https://placehold.co/15x15/AC2E32/AC2E32.png) `#AC2E32`|
|Carmine Red|70.908|Model Color|151|33|31|![#97211F](https://placehold.co/15x15/97211F/97211F.png) `#97211F`|
|Cashmere Beige|85.107|Arte Deco|254|189|181|![#FEBDB5](https://placehold.co/15x15/FEBDB5/FEBDB5.png) `#FEBDB5`|
|Cavalry Brown|70.982|Model Color|132|68|58|![#84443A](https://placehold.co/15x15/84443A/84443A.png) `#84443A`|
|Cayman Green|72.067|Game Color|89|84|42|![#59542A](https://placehold.co/15x15/59542A/59542A.png) `#59542A`|
|Cement Grey|71.045|Model Air|145|148|139|![#91948B](https://placehold.co/15x15/91948B/91948B.png) `#91948B`|
|Chain Mail Silver|72.753|Game Air|174|174|174|![#AEAEAE](https://placehold.co/15x15/AEAEAE/AEAEAE.png) `#AEAEAE`|
|Chainmail|72.053|Game Color|228|229|233|![#E4E5E9](https://placehold.co/15x15/E4E5E9/E4E5E9.png) `#E4E5E9`|
|Chalice Red|74.017|Nocturna Models|69|56|76|![#45384C](https://placehold.co/15x15/45384C/45384C.png) `#45384C`|
|Chameleon Orange|72.455|Xpress Color|206|101|46|![#CE652E](https://placehold.co/15x15/CE652E/CE652E.png) `#CE652E`|
|Charcoal|72.155|Game Color|54|54|56|![#363638](https://placehold.co/15x15/363638/363638.png) `#363638`|
|Charcoal Grey|85.119|Arte Deco|37|51|56|![#253338](https://placehold.co/15x15/253338/253338.png) `#253338`|
|Charred Brown|72.045|Game Color|66|42|38|![#422A26](https://placehold.co/15x15/422A26/422A26.png) `#422A26`|
|Charred Brown|72.745|Game Air|77|69|66|![#4D4542](https://placehold.co/15x15/4D4542/4D4542.png) `#4D4542`|
|Charred Brown|76.045|Game Air|66|42|38|![#422A26](https://placehold.co/15x15/422A26/422A26.png) `#422A26`|
|Chestnut Brown|70.746|Model Color|96|63|54|![#603F36](https://placehold.co/15x15/603F36/603F36.png) `#603F36`|
|Chipping Brown|69.035|Mecha Color|72|66|66|![#484242](https://placehold.co/15x15/484242/484242.png) `#484242`|
|Chocolate Brown|70.872|Model Color|88|68|61|![#58443D](https://placehold.co/15x15/58443D/58443D.png) `#58443D`|
|Chrome|77.707|Metal Color|175|175|175|![#AFAFAF](https://placehold.co/15x15/AFAFAF/AFAFAF.png) `#AFAFAF`|
|Chrome (Metallic)|71.064|Model Air|168|168|178|![#A8A8B2](https://placehold.co/15x15/A8A8B2/A8A8B2.png) `#A8A8B2`|
|Cleaner|62.067|Premium Airbrush Color|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Clear Base|62.068|Premium Airbrush Color|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Clear Orange|70.956|Model Color|204|69|39|![#CC4527](https://placehold.co/15x15/CC4527/CC4527.png) `#CC4527`|
|Cobalt Blue|62.009|Premium Airbrush Color|52|87|143|![#34578F](https://placehold.co/15x15/34578F/34578F.png) `#34578F`|
|Cobra Leather|72.740|Game Air|133|92|38|![#855C26](https://placehold.co/15x15/855C26/855C26.png) `#855C26`|
|Cockpit Emerald Green “Faded”|71.331|Model Air|70|133|122|![#46857A](https://placehold.co/15x15/46857A/46857A.png) `#46857A`|
|Cold Flesh|74.014|Nocturna Models|131|133|145|![#838591](https://placehold.co/15x15/838591/838591.png) `#838591`|
|Cold Grey|72.750|Game Air|130|131|133|![#828385](https://placehold.co/15x15/828385/828385.png) `#828385`|
|Cold White|70.919|Model Color|246|246|248|![#F6F6F8](https://placehold.co/15x15/F6F6F8/F6F6F8.png) `#F6F6F8`|
|Colonial Green|85.074|Arte Deco|79|131|132|![#4F8384](https://placehold.co/15x15/4F8384/4F8384.png) `#4F8384`|
|Commando Green|72.468|Xpress Color|62|79|60|![#3E4F3C](https://placehold.co/15x15/3E4F3C/3E4F3C.png) `#3E4F3C`|
|Concrete|71.131|Model Air|119|109|97|![#776D61](https://placehold.co/15x15/776D61/776D61.png) `#776D61`|
|Continental Blue|70.754|Model Color|37|36|42|![#25242A](https://placehold.co/15x15/25242A/25242A.png) `#25242A`|
|Cool Neutral Tone|85.103|Arte Deco|178|164|143|![#B2A48F](https://placehold.co/15x15/B2A48F/B2A48F.png) `#B2A48F`|
|Copper|77.710|Metal Color|156|143|135|![#9C8F87](https://placehold.co/15x15/9C8F87/9C8F87.png) `#9C8F87`|
|Copper|69.061|Mecha Color|154|91|58|![#9A5B3A](https://placehold.co/15x15/9A5B3A/9A5B3A.png) `#9A5B3A`|
|Copper|62.050|Premium Airbrush Color|233|219|210|![#E9DBD2](https://placehold.co/15x15/E9DBD2/E9DBD2.png) `#E9DBD2`|
|Copper|70.797|Liquid Gold|231|207|197|![#E7CFC5](https://placehold.co/15x15/E7CFC5/E7CFC5.png) `#E7CFC5`|
|Copper|81.171|Arte Deco|187|72|18|![#BB4812](https://placehold.co/15x15/BB4812/BB4812.png) `#BB4812`|
|Copper|70.999|Model Color|128|52|39|![#803427](https://placehold.co/15x15/803427/803427.png) `#803427`|
|Copper (Metallic)|71.068|Model Air|140|92|72|![#8C5C48](https://placehold.co/15x15/8C5C48/8C5C48.png) `#8C5C48`|
|Copper Brown|72.421|Xpress Color|83|44|37|![#532C25](https://placehold.co/15x15/532C25/532C25.png) `#532C25`|
|Coral Rose|85.025|Arte Deco|237|117|144|![#ED7590](https://placehold.co/15x15/ED7590/ED7590.png) `#ED7590`|
|Cork Brown|70.843|Model Color|161|111|78|![#A16F4E](https://placehold.co/15x15/A16F4E/A16F4E.png) `#A16F4E`|
|Corrosion|72.608|Game Color Special FX|87|41|34|![#572922](https://placehold.co/15x15/572922/572922.png) `#572922`|
|Country Blue|85.056|Arte Deco|147|158|214|![#939ED6](https://placehold.co/15x15/939ED6/939ED6.png) `#939ED6`|
|Country Red|85.034|Arte Deco|159|27|25|![#9F1B19](https://placehold.co/15x15/9F1B19/9F1B19.png) `#9F1B19`|
|Crackle Medium|84.160|Arte Deco|248|245|229|![#F8F5E5](https://placehold.co/15x15/F8F5E5/F8F5E5.png) `#F8F5E5`|
|Cranberry|85.043|Arte Deco|74|40|40|![#4A2828](https://placehold.co/15x15/4A2828/4A2828.png) `#4A2828`|
|Cream White|70.766|Model Color|227|209|195|![#E3D1C3](https://placehold.co/15x15/E3D1C3/E3D1C3.png) `#E3D1C3`|
|Crimson|74.018|Nocturna Models|101|38|62|![#65263E](https://placehold.co/15x15/65263E/65263E.png) `#65263E`|
|Crimson Tide|85.039|Arte Deco|131|63|88|![#833F58](https://placehold.co/15x15/833F58/833F58.png) `#833F58`|
|Crushed Grass|73.825|Weathering FX|142|144|107|![#8E906B](https://placehold.co/15x15/8E906B/8E906B.png) `#8E906B`|
|Dark Aluminium|77.703|Metal Color|148|148|150|![#949496](https://placehold.co/15x15/949496/949496.png) `#949496`|
|Dark Blue|72.017|Game Color|70|71|117|![#464775](https://placehold.co/15x15/464775/464775.png) `#464775`|
|Dark Blue|69.021|Mecha Color|64|91|120|![#405B78](https://placehold.co/15x15/405B78/405B78.png) `#405B78`|
|Dark Blue|62.011|Premium Airbrush Color|57|55|79|![#39374F](https://placehold.co/15x15/39374F/39374F.png) `#39374F`|
|Dark Blue|70.930|Model Color|39|52|97|![#273461](https://placehold.co/15x15/273461/273461.png) `#273461`|
|Dark Blue Grey|70.904|Model Color|109|133|137|![#6D8589](https://placehold.co/15x15/6D8589/6D8589.png) `#6D8589`|
|Dark Blue Grey|70.867|Model Color|66|67|69|![#424345](https://placehold.co/15x15/424345/424345.png) `#424345`|
|Dark Blue RLM24|71.266|Model Air|46|72|97|![#2E4861](https://placehold.co/15x15/2E4861/2E4861.png) `#2E4861`|
|Dark Brown|76.514|Wash FX|109|80|74|![#6D504A](https://placehold.co/15x15/6D504A/6D504A.png) `#6D504A`|
|Dark Brown RLM61|71.042|Model Air|72|71|69|![#484745](https://placehold.co/15x15/484745/484745.png) `#484745`|
|Dark Chocolate|85.118|Arte Deco|82|39|33|![#522721](https://placehold.co/15x15/522721/522721.png) `#522721`|
|Dark Earth|71.029|Model Air|94|85|68|![#5E5544](https://placehold.co/15x15/5E5544/5E5544.png) `#5E5544`|
|Dark Flesh|70.927|Model Color|211|147|59|![#D3933B](https://placehold.co/15x15/D3933B/D3933B.png) `#D3933B`|
|Dark Flesh Tone|72.744|Game Air|91|72|68|![#5B4844](https://placehold.co/15x15/5B4844/5B4844.png) `#5B4844`|
|Dark Fleshtone|72.044|Game Color|96|52|41|![#603429](https://placehold.co/15x15/603429/603429.png) `#603429`|
|Dark Ghost Gray|71.120|Model Air|138|151|160|![#8A97A0](https://placehold.co/15x15/8A97A0/8A97A0.png) `#8A97A0`|
|Dark Gray RLM42|71.123|Model Air|81|83|82|![#515352](https://placehold.co/15x15/515352/515352.png) `#515352`|
|Dark Green|72.028|Game Color|31|55|39|![#1F3727](https://placehold.co/15x15/1F3727/1F3727.png) `#1F3727`|
|Dark Green|76.512|Wash FX|116|113|42|![#74712A](https://placehold.co/15x15/74712A/74712A.png) `#74712A`|
|Dark Green|28.026|Hobby Paint|60|70|62|![#3C463E](https://placehold.co/15x15/3C463E/3C463E.png) `#3C463E`|
|Dark Green|72.728|Game Air|39|78|57|![#274E39](https://placehold.co/15x15/274E39/274E39.png) `#274E39`|
|Dark Green|69.030|Mecha Color|82|83|69|![#525345](https://placehold.co/15x15/525345/525345.png) `#525345`|
|Dark Green|62.014|Premium Airbrush Color|50|67|59|![#32433B](https://placehold.co/15x15/32433B/32433B.png) `#32433B`|
|Dark Green|71.012|Model Air|93|94|86|![#5D5E56](https://placehold.co/15x15/5D5E56/5D5E56.png) `#5D5E56`|
|Dark Green RLM71|71.015|Model Air|84|76|63|![#544C3F](https://placehold.co/15x15/544C3F/544C3F.png) `#544C3F`|
|Dark Green RLM83|71.011|Model Air|78|78|70|![#4E4E46](https://placehold.co/15x15/4E4E46/4E4E46.png) `#4E4E46`|
|Dark Grey|70.994|Model Color|49|47|50|![#312F32](https://placehold.co/15x15/312F32/312F32.png) `#312F32`|
|Dark Grey|71.110|Model Air|83|90|100|![#535A64](https://placehold.co/15x15/535A64/535A64.png) `#535A64`|
|Dark Grey|76.517|Wash FX|82|81|79|![#52514F](https://placehold.co/15x15/52514F/52514F.png) `#52514F`|
|Dark Grey Blue|71.054|Model Air|72|77|81|![#484D51](https://placehold.co/15x15/484D51/484D51.png) `#484D51`|
|Dark Grey Green|69.041|Mecha Color|80|82|81|![#505251](https://placehold.co/15x15/505251/505251.png) `#505251`|
|Dark Gull Gray|71.277|Model Air|130|131|133|![#828385](https://placehold.co/15x15/828385/828385.png) `#828385`|
|Dark Gunmetal|72.054|Game Color|218|218|218|![#DADADA](https://placehold.co/15x15/DADADA/DADADA.png) `#DADADA`|
|Dark Khaki Green|76.520|Wash FX|140|114|79|![#8C724F](https://placehold.co/15x15/8C724F/8C724F.png) `#8C724F`|
|Dark Mediterranean Blue|71.313|Model Air|42|53|81|![#2A3551](https://placehold.co/15x15/2A3551/2A3551.png) `#2A3551`|
|Dark Mud|70.316|Panzer Aces|104|95|78|![#685F4E](https://placehold.co/15x15/685F4E/685F4E.png) `#685F4E`|
|Dark Ochre|62.016|Premium Airbrush Color|156|97|63|![#9C613F](https://placehold.co/15x15/9C613F/9C613F.png) `#9C613F`|
|Dark Orange|85.028|Arte Deco|229|55|28|![#E5371C](https://placehold.co/15x15/E5371C/E5371C.png) `#E5371C`|
|Dark Orchid|85.048|Arte Deco|175|31|92|![#AF1F5C](https://placehold.co/15x15/AF1F5C/AF1F5C.png) `#AF1F5C`|
|Dark Pine|85.084|Arte Deco|0|93|64|![#005D40](https://placehold.co/15x15/005D40/005D40.png) `#005D40`|
|Dark Prussian Blue|70.899|Model Color|55|39|65|![#372741](https://placehold.co/15x15/372741/372741.png) `#372741`|
|Dark Purple|70.749|Model Color|69|39|51|![#452733](https://placehold.co/15x15/452733/452733.png) `#452733`|
|Dark Red|70.946|Model Color|105|47|36|![#692F24](https://placehold.co/15x15/692F24/692F24.png) `#692F24`|
|Dark Red|69.011|Mecha Color|147|38|44|![#93262C](https://placehold.co/15x15/93262C/93262C.png) `#93262C`|
|Dark Rose|70.745|Model Color|128|82|82|![#805252](https://placehold.co/15x15/805252/805252.png) `#805252`|
|Dark Rosewood|85.174|Arte Deco|66|25|34|![#421922](https://placehold.co/15x15/421922/421922.png) `#421922`|
|Dark Rubber|70.306|Panzer Aces|80|81|83|![#505153](https://placehold.co/15x15/505153/505153.png) `#505153`|
|Dark Rust|70.771|Model Color|59|38|37|![#3B2625](https://placehold.co/15x15/3B2625/3B2625.png) `#3B2625`|
|Dark Rust|76.507|Wash FX|182|90|69|![#B65A45](https://placehold.co/15x15/B65A45/B65A45.png) `#B65A45`|
|Dark Rust|70.302|Panzer Aces|79|68|66|![#4F4442](https://placehold.co/15x15/4F4442/4F4442.png) `#4F4442`|
|Dark Rust Wash|69.507|Mecha Color|224|91|16|![#E05B10](https://placehold.co/15x15/E05B10/E05B10.png) `#E05B10`|
|Dark Sand|70.847|Model Color|203|168|104|![#CBA868](https://placehold.co/15x15/CBA868/CBA868.png) `#CBA868`|
|Dark Sea Blue|70.898|Model Color|38|44|56|![#262C38](https://placehold.co/15x15/262C38/262C38.png) `#262C38`|
|Dark Sea Gray|71.053|Model Air|76|83|93|![#4C535D](https://placehold.co/15x15/4C535D/4C535D.png) `#4C535D`|
|Dark Sea Green|70.868|Model Color|75|69|69|![#4B4545](https://placehold.co/15x15/4B4545/4B4545.png) `#4B4545`|
|Dark Sea Grey|70.991|Model Color|108|107|105|![#6C6B69](https://placehold.co/15x15/6C6B69/6C6B69.png) `#6C6B69`|
|Dark Slate Grey|71.309|Model Air|93|94|86|![#5D5E56](https://placehold.co/15x15/5D5E56/5D5E56.png) `#5D5E56`|
|Dark Steel|69.065|Mecha Color|115|116|118|![#737476](https://placehold.co/15x15/737476/737476.png) `#737476`|
|Dark Turquoise|72.084|Game Color|1|112|139|![#01708B](https://placehold.co/15x15/01708B/01708B.png) `#01708B`|
|Dark Vermilion|70.947|Model Color|181|42|39|![#B52A27](https://placehold.co/15x15/B52A27/B52A27.png) `#B52A27`|
|Dark Yellow|76.503|Wash FX|203|177|38|![#CBB126](https://placehold.co/15x15/CBB126/CBB126.png) `#CBB126`|
|Dark Yellow|70.978|Model Color|144|135|58|![#90873A](https://placehold.co/15x15/90873A/90873A.png) `#90873A`|
|Dark Yellow|71.025|Model Air|149|122|69|![#957A45](https://placehold.co/15x15/957A45/957A45.png) `#957A45`|
|Dark Yellow|85.009|Arte Deco|249|177|5|![#F9B105](https://placehold.co/15x15/F9B105/F9B105.png) `#F9B105`|
|Dead Flesh|28.022|Hobby Paint|182|162|111|![#B6A26F](https://placehold.co/15x15/B6A26F/B6A26F.png) `#B6A26F`|
|Dead Flesh|76.035|Game Air|195|170|77|![#C3AA4D](https://placehold.co/15x15/C3AA4D/C3AA4D.png) `#C3AA4D`|
|Dead Flesh|72.035|Game Color|195|170|77|![#C3AA4D](https://placehold.co/15x15/C3AA4D/C3AA4D.png) `#C3AA4D`|
|Dead Flesh|72.735|Game Air|200|188|138|![#C8BC8A](https://placehold.co/15x15/C8BC8A/C8BC8A.png) `#C8BC8A`|
|Dead White|72.001|Game Color|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Dead White|72.701|Game Air|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Dead White|76.001|Game Air|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Deck Tan|70.986|Model Color|171|163|144|![#ABA390](https://placehold.co/15x15/ABA390/ABA390.png) `#ABA390`|
|Deep Blue|69.018|Mecha Color|12|151|194|![#0C97C2](https://placehold.co/15x15/0C97C2/0C97C2.png) `#0C97C2`|
|Deep Forest Skin|74.009|Nocturna Models|62|74|74|![#3E4A4A](https://placehold.co/15x15/3E4A4A/3E4A4A.png) `#3E4A4A`|
|Deep Green|70.970|Model Color|27|75|51|![#1B4B33](https://placehold.co/15x15/1B4B33/1B4B33.png) `#1B4B33`|
|Deep Green|69.029|Mecha Color|112|121|58|![#70793A](https://placehold.co/15x15/70793A/70793A.png) `#70793A`|
|Deep Magenta|72.113|Game Color|98|38|64|![#622640](https://placehold.co/15x15/622640/622640.png) `#622640`|
|Deep Purple|72.409|Xpress Color|111|43|66|![#6F2B42](https://placehold.co/15x15/6F2B42/6F2B42.png) `#6F2B42`|
|Deep Sky|71.090|Model Air|53|65|91|![#35415B](https://placehold.co/15x15/35415B/35415B.png) `#35415B`|
|Deep Sky Blue|70.844|Model Color|77|149|197|![#4D95C5](https://placehold.co/15x15/4D95C5/4D95C5.png) `#4D95C5`|
|Deep Teal|85.075|Arte Deco|1|147|126|![#01937E](https://placehold.co/15x15/01937E/01937E.png) `#01937E`|
|Deep Yellow|70.915|Model Color|241|199|1|![#F1C701](https://placehold.co/15x15/F1C701/F1C701.png) `#F1C701`|
|Demon Blood|72.603|Game Color Special FX|102|71|126|![#66477E](https://placehold.co/15x15/66477E/66477E.png) `#66477E`|
|Demonic Skin|72.458|Xpress Color|150|92|88|![#965C58](https://placehold.co/15x15/965C58/965C58.png) `#965C58`|
|Desert Brown|70.767|Model Color|171|133|86|![#AB8556](https://placehold.co/15x15/AB8556/AB8556.png) `#AB8556`|
|Desert Dust|76.522|Wash FX|227|205|164|![#E3CDA4](https://placehold.co/15x15/E3CDA4/E3CDA4.png) `#E3CDA4`|
|Desert Dust Wash|69.522|Mecha Color|216|187|129|![#D8BB81](https://placehold.co/15x15/D8BB81/D8BB81.png) `#D8BB81`|
|Desert Ochre|72.454|Xpress Color|157|103|41|![#9D6729](https://placehold.co/15x15/9D6729/9D6729.png) `#9D6729`|
|Desert Sand|85.011|Arte Deco|237|235|198|![#EDEBC6](https://placehold.co/15x15/EDEBC6/EDEBC6.png) `#EDEBC6`|
|Desert Tan|70.613|Surface Primer|209|190|158|![#D1BE9E](https://placehold.co/15x15/D1BE9E/D1BE9E.png) `#D1BE9E`|
|Desert Turquoise|85.078|Arte Deco|1|141|140|![#018D8C](https://placehold.co/15x15/018D8C/018D8C.png) `#018D8C`|
|Desert Yellow|76.063|Game Air|153|103|50|![#996732](https://placehold.co/15x15/996732/996732.png) `#996732`|
|Desert Yellow|70.977|Model Color|182|133|74|![#B6854A](https://placehold.co/15x15/B6854A/B6854A.png) `#B6854A`|
|Desert Yellow|72.063|Game Color|153|103|50|![#996732](https://placehold.co/15x15/996732/996732.png) `#996732`|
|Desert Yellow|28.015|Hobby Paint|157|125|74|![#9D7D4A](https://placehold.co/15x15/9D7D4A/9D7D4A.png) `#9D7D4A`|
|Desert Yellow|72.763|Game Air|167|132|78|![#A7844E](https://placehold.co/15x15/A7844E/A7844E.png) `#A7844E`|
|Devil Red|74.019|Nocturna Models|146|18|81|![#921251](https://placehold.co/15x15/921251/921251.png) `#921251`|
|Diesel Stains|73.816|Weathering FX|164|76|52|![#A44C34](https://placehold.co/15x15/A44C34/A44C34.png) `#A44C34`|
|Dirt|71.133|Model Air|122|98|64|![#7A6240](https://placehold.co/15x15/7A6240/7A6240.png) `#7A6240`|
|Dirty Grey|72.145|Game Color|103|95|48|![#675F30](https://placehold.co/15x15/675F30/675F30.png) `#675F30`|
|Dove Grey|85.101|Arte Deco|236|236|236|![#ECECEC](https://placehold.co/15x15/ECECEC/ECECEC.png) `#ECECEC`|
|Dreadnought Yellow|72.477|Xpress Color Intense|211|136|33|![#D38821](https://placehold.co/15x15/D38821/D38821.png) `#D38821`|
|Dried Blood|72.133|Game Color|98|42|29|![#622A1D](https://placehold.co/15x15/622A1D/622A1D.png) `#622A1D`|
|Dry Rust|72.136|Game Color|94|51|45|![#5E332D](https://placehold.co/15x15/5E332D/5E332D.png) `#5E332D`|
|Dull Aluminium|77.717|Metal Color|187|187|187|![#BBBBBB](https://placehold.co/15x15/BBBBBB/BBBBBB.png) `#BBBBBB`|
|Duraluminium|77.702|Metal Color|164|164|164|![#A4A4A4](https://placehold.co/15x15/A4A4A4/A4A4A4.png) `#A4A4A4`|
|Dusty Rose|85.020|Arte Deco|252|137|146|![#FC8992](https://placehold.co/15x15/FC8992/FC8992.png) `#FC8992`|
|Dwarf Skin|72.041|Game Color|217|145|105|![#D99169](https://placehold.co/15x15/D99169/D99169.png) `#D99169`|
|Dwarf Skin|72.741|Game Air|217|145|105|![#D99169](https://placehold.co/15x15/D99169/D99169.png) `#D99169`|
|Dwarf Skin|72.402|Xpress Color|131|62|47|![#833E2F](https://placehold.co/15x15/833E2F/833E2F.png) `#833E2F`|
|Earth|76.062|Game Air|119|87|48|![#775730](https://placehold.co/15x15/775730/775730.png) `#775730`|
|Earth|72.062|Game Color|119|87|48|![#775730](https://placehold.co/15x15/775730/775730.png) `#775730`|
|Earth|72.762|Game Air|123|104|72|![#7B6848](https://placehold.co/15x15/7B6848/7B6848.png) `#7B6848`|
|Earth Green (Early)|70.611|Surface Primer|97|88|55|![#615837](https://placehold.co/15x15/615837/615837.png) `#615837`|
|Eau de Nil “Duck Egg Green”|71.009|Model Air|194|200|156|![#C2C89C](https://placehold.co/15x15/C2C89C/C2C89C.png) `#C2C89C`|
|Electric Blue|76.023|Game Air|67|153|178|![#4399B2](https://placehold.co/15x15/4399B2/4399B2.png) `#4399B2`|
|Electric Blue|69.020|Mecha Color|3|112|177|![#0370B1](https://placehold.co/15x15/0370B1/0370B1.png) `#0370B1`|
|Electric Blue|72.023|Game Color|67|153|178|![#4399B2](https://placehold.co/15x15/4399B2/4399B2.png) `#4399B2`|
|Electric Blue|72.723|Game Air|46|149|180|![#2E95B4](https://placehold.co/15x15/2E95B4/2E95B4.png) `#2E95B4`|
|Elf Skin Tone|72.004|Game Color|202|136|84|![#CA8854](https://placehold.co/15x15/CA8854/CA8854.png) `#CA8854`|
|Elf Skin Tone|76.004|Game Air|202|136|84|![#CA8854](https://placehold.co/15x15/CA8854/CA8854.png) `#CA8854`|
|Elf Skin Tone|72.704|Game Air|231|174|129|![#E7AE81](https://placehold.co/15x15/E7AE81/E7AE81.png) `#E7AE81`|
|Elfic Blue|72.117|Game Color|80|97|125|![#50617D](https://placehold.co/15x15/50617D/50617D.png) `#50617D`|
|Elfic Flesh|72.098|Game Color|234|215|185|![#EAD7B9](https://placehold.co/15x15/EAD7B9/EAD7B9.png) `#EAD7B9`|
|Emerald|70.838|Model Color|0|98|75|![#00624B](https://placehold.co/15x15/00624B/00624B.png) `#00624B`|
|Engine Gray|71.048|Model Air|85|89|98|![#555962](https://placehold.co/15x15/555962/555962.png) `#555962`|
|Engine Grime|73.815|Weathering FX|96|90|90|![#605A5A](https://placehold.co/15x15/605A5A/605A5A.png) `#605A5A`|
|English Uniform|70.921|Model Color|111|83|43|![#6F532B](https://placehold.co/15x15/6F532B/6F532B.png) `#6F532B`|
|English Uniform|28.008|Hobby Paint|117|93|65|![#755D41](https://placehold.co/15x15/755D41/755D41.png) `#755D41`|
|European Dust|76.523|Wash FX|140|107|74|![#8C6B4A](https://placehold.co/15x15/8C6B4A/8C6B4A.png) `#8C6B4A`|
|European Splash Mud|73.801|Weathering FX|86|63|55|![#563F37](https://placehold.co/15x15/563F37/563F37.png) `#563F37`|
|European Thick Mud|73.807|Weathering FX|66|57|48|![#423930](https://placehold.co/15x15/423930/423930.png) `#423930`|
|Evergreen|85.090|Arte Deco|30|57|48|![#1E3930](https://placehold.co/15x15/1E3930/1E3930.png) `#1E3930`|
|Evil Red|72.112|Game Color|70|30|38|![#461E26](https://placehold.co/15x15/461E26/461E26.png) `#461E26`|
|Exhaust Manifold|77.723|Metal Color|125|125|123|![#7D7D7B](https://placehold.co/15x15/7D7D7B/7D7D7B.png) `#7D7D7B`|
|Extra Dark Green|70.896|Model Color|40|42|20|![#282A14](https://placehold.co/15x15/282A14/282A14.png) `#282A14`|
|Faded P.R.U. Blue|71.109|Model Air|73|101|112|![#496570](https://placehold.co/15x15/496570/496570.png) `#496570`|
|Fairy Flesh|74.007|Nocturna Models|245|172|137|![#F5AC89](https://placehold.co/15x15/F5AC89/F5AC89.png) `#F5AC89`|
|Fairy Skin|72.457|Xpress Color|202|135|116|![#CA8774](https://placehold.co/15x15/CA8774/CA8774.png) `#CA8774`|
|Fern Green|70.833|Model Color|71|84|54|![#475436](https://placehold.co/15x15/475436/475436.png) `#475436`|
|Ferrari Red|71.085|Model Air|175|53|50|![#AF3532](https://placehold.co/15x15/AF3532/AF3532.png) `#AF3532`|
|Field Blue|70.964|Model Color|77|82|86|![#4D5256](https://placehold.co/15x15/4D5256/4D5256.png) `#4D5256`|
|Filthy Brown|72.037|Game Color|233|147|0|![#E99300](https://placehold.co/15x15/E99300/E99300.png) `#E99300`|
|Fire Flame|74.024|Nocturna Models|196|31|61|![#C41F3D](https://placehold.co/15x15/C41F3D/C41F3D.png) `#C41F3D`|
|Fire Red|71.084|Model Air|134|62|48|![#863E30](https://placehold.co/15x15/863E30/863E30.png) `#863E30`|
|Fire Red|85.029|Arte Deco|226|15|22|![#E20F16](https://placehold.co/15x15/E20F16/E20F16.png) `#E20F16`|
|Flanker Blue|71.337|Model Air|145|174|180|![#91AEB4](https://placehold.co/15x15/91AEB4/91AEB4.png) `#91AEB4`|
|Flanker Light Blue|71.334|Model Air|177|196|200|![#B1C4C8](https://placehold.co/15x15/B1C4C8/B1C4C8.png) `#B1C4C8`|
|Flanker Light Gray|71.335|Model Air|157|166|165|![#9DA6A5](https://placehold.co/15x15/9DA6A5/9DA6A5.png) `#9DA6A5`|
|Flat Blue|70.962|Model Color|63|72|115|![#3F4873](https://placehold.co/15x15/3F4873/3F4873.png) `#3F4873`|
|Flat Brown|70.984|Model Color|112|63|56|![#703F38](https://placehold.co/15x15/703F38/703F38.png) `#703F38`|
|Flat Earth|70.983|Model Color|105|68|42|![#69442A](https://placehold.co/15x15/69442A/69442A.png) `#69442A`|
|Flat Flesh|70.955|Model Color|224|153|89|![#E09959](https://placehold.co/15x15/E09959/E09959.png) `#E09959`|
|Flat Green|70.968|Model Color|55|75|47|![#374B2F](https://placehold.co/15x15/374B2F/374B2F.png) `#374B2F`|
|Flat Red|70.957|Model Color|161|43|41|![#A12B29](https://placehold.co/15x15/A12B29/A12B29.png) `#A12B29`|
|Flat Yellow|70.953|Model Color|246|186|54|![#F6BA36](https://placehold.co/15x15/F6BA36/F6BA36.png) `#F6BA36`|
|Flesh|72.769|Game Air|246|189|144|![#F6BD90](https://placehold.co/15x15/F6BD90/F6BD90.png) `#F6BD90`|
|Flesh|85.016|Arte Deco|254|210|216|![#FED2D8](https://placehold.co/15x15/FED2D8/FED2D8.png) `#FED2D8`|
|Flesh Base|70.341|Panzer Aces|164|83|30|![#A4531E](https://placehold.co/15x15/A4531E/A4531E.png) `#A4531E`|
|Flesh Blood|72.601|Game Color Special FX|242|116|102|![#F27466](https://placehold.co/15x15/F27466/F27466.png) `#F27466`|
|Flesh Highlights|70.342|Panzer Aces|252|210|168|![#FCD2A8](https://placehold.co/15x15/FCD2A8/FCD2A8.png) `#FCD2A8`|
|Flesh Shadows|70.343|Panzer Aces|85|19|5|![#551305](https://placehold.co/15x15/551305/551305.png) `#551305`|
|Flesh Tone no. 2|85.018|Arte Deco|238|195|178|![#EEC3B2](https://placehold.co/15x15/EEC3B2/EEC3B2.png) `#EEC3B2`|
|Flesh Wash|73.204|Game Color Wash|182|124|120|![#B67C78](https://placehold.co/15x15/B67C78/B67C78.png) `#B67C78`|
|Fluid Pink|72.459|Xpress Color|192|103|147|![#C06793](https://placehold.co/15x15/C06793/C06793.png) `#C06793`|
|Fluorescent Blue|62.038|Premium Airbrush Color|67|153|214|![#4399D6](https://placehold.co/15x15/4399D6/4399D6.png) `#4399D6`|
|Fluorescent Blue|72.160|Game Color|0|130|205|![#0082CD](https://placehold.co/15x15/0082CD/0082CD.png) `#0082CD`|
|Fluorescent Cold Green|72.161|Game Color|0|112|116|![#007074](https://placehold.co/15x15/007074/007074.png) `#007074`|
|Fluorescent Golden Yellow|62.032|Premium Airbrush Color|251|187|53|![#FBBB35](https://placehold.co/15x15/FBBB35/FBBB35.png) `#FBBB35`|
|Fluorescent Green|62.039|Premium Airbrush Color|105|182|66|![#69B642](https://placehold.co/15x15/69B642/69B642.png) `#69B642`|
|Fluorescent Green|72.104|Game Color|116|183|44|![#74B72C](https://placehold.co/15x15/74B72C/74B72C.png) `#74B72C`|
|Fluorescent Magenta|72.158|Game Color|232|52|141|![#E8348D](https://placehold.co/15x15/E8348D/E8348D.png) `#E8348D`|
|Fluorescent Magenta|62.036|Premium Airbrush Color|211|59|144|![#D33B90](https://placehold.co/15x15/D33B90/D33B90.png) `#D33B90`|
|Fluorescent Orange|62.033|Premium Airbrush Color|241|126|1|![#F17E01](https://placehold.co/15x15/F17E01/F17E01.png) `#F17E01`|
|Fluorescent Orange|72.156|Game Color|232|78|16|![#E84E10](https://placehold.co/15x15/E84E10/E84E10.png) `#E84E10`|
|Fluorescent Red|72.157|Game Color|221|47|82|![#DD2F52](https://placehold.co/15x15/DD2F52/DD2F52.png) `#DD2F52`|
|Fluorescent Red|71.082|Model Air|234|98|76|![#EA624C](https://placehold.co/15x15/EA624C/EA624C.png) `#EA624C`|
|Fluorescent Rose|62.035|Premium Airbrush Color|231|62|143|![#E73E8F](https://placehold.co/15x15/E73E8F/E73E8F.png) `#E73E8F`|
|Fluorescent Scarlet|62.034|Premium Airbrush Color|236|79|96|![#EC4F60](https://placehold.co/15x15/EC4F60/EC4F60.png) `#EC4F60`|
|Fluorescent Violet|62.037|Premium Airbrush Color|105|62|118|![#693E76](https://placehold.co/15x15/693E76/693E76.png) `#693E76`|
|Fluorescent Violet|72.159|Game Color|111|37|122|![#6F257A](https://placehold.co/15x15/6F257A/6F257A.png) `#6F257A`|
|Fluorescent Yellow|62.031|Premium Airbrush Color|242|229|0|![#F2E500](https://placehold.co/15x15/F2E500/F2E500.png) `#F2E500`|
|Fluorescent Yellow|72.103|Game Color|240|230|57|![#F0E639](https://placehold.co/15x15/F0E639/F0E639.png) `#F0E639`|
|Forest Green|85.089|Arte Deco|5|93|43|![#055D2B](https://placehold.co/15x15/055D2B/055D2B.png) `#055D2B`|
|Forest Green|72.465|Xpress Color|17|102|45|![#11662D](https://placehold.co/15x15/11662D/11662D.png) `#11662D`|
|Forest Skin|74.013|Nocturna Models|134|117|98|![#867562](https://placehold.co/15x15/867562/867562.png) `#867562`|
|Foul Green|72.025|Game Color|0|162|125|![#00A27D](https://placehold.co/15x15/00A27D/00A27D.png) `#00A27D`|
|French Blue|85.066|Arte Deco|63|106|138|![#3F6A8A](https://placehold.co/15x15/3F6A8A/3F6A8A.png) `#3F6A8A`|
|French Blue|71.088|Model Air|31|78|122|![#1F4E7A](https://placehold.co/15x15/1F4E7A/1F4E7A.png) `#1F4E7A`|
|French Mirage Blue|70.900|Model Color|95|103|114|![#5F6772](https://placehold.co/15x15/5F6772/5F6772.png) `#5F6772`|
|French Tank Crew|70.320|Panzer Aces|117|109|86|![#756D56](https://placehold.co/15x15/756D56/756D56.png) `#756D56`|
|French Tank Crew Highlights|70.324|Panzer Aces|137|124|115|![#897C73](https://placehold.co/15x15/897C73/897C73.png) `#897C73`|
|Fresh Blood|72.132|Game Color|126|43|25|![#7E2B19](https://placehold.co/15x15/7E2B19/7E2B19.png) `#7E2B19`|
|Frost|72.604|Game Color Special FX|138|201|227|![#8AC9E3](https://placehold.co/15x15/8AC9E3/8AC9E3.png) `#8AC9E3`|
|Frozen Flesh|74.010|Nocturna Models|87|85|91|![#57555B](https://placehold.co/15x15/57555B/57555B.png) `#57555B`|
|Fuel Stains|73.814|Weathering FX|141|93|57|![#8D5D39](https://placehold.co/15x15/8D5D39/8D5D39.png) `#8D5D39`|
|Fuel Stains (Gloss)|69.814|Mecha Color|160|98|23|![#A06217](https://placehold.co/15x15/A06217/A06217.png) `#A06217`|
|Galvanic Corrosion|72.610|Game Color Special FX|238|174|118|![#EEAE76](https://placehold.co/15x15/EEAE76/EEAE76.png) `#EEAE76`|
|Georgia Clay|85.031|Arte Deco|190|62|23|![#BE3E17](https://placehold.co/15x15/BE3E17/BE3E17.png) `#BE3E17`|
|German Beige WWII|70.821|Model Color|121|105|80|![#796950](https://placehold.co/15x15/796950/796950.png) `#796950`|
|German Dark Yellow|70.604|Surface Primer|137|116|97|![#897461](https://placehold.co/15x15/897461/897461.png) `#897461`|
|German Field Grey|28.006|Hobby Paint|98|98|90|![#62625A](https://placehold.co/15x15/62625A/62625A.png) `#62625A`|
|German Fieldgrey WWII|70.830|Model Color|88|82|60|![#58523C](https://placehold.co/15x15/58523C/58523C.png) `#58523C`|
|German Green Brown|70.606|Surface Primer|124|100|72|![#7C6448](https://placehold.co/15x15/7C6448/7C6448.png) `#7C6448`|
|German Green Tail Light|70.308|Panzer Aces|61|83|71|![#3D5347](https://placehold.co/15x15/3D5347/3D5347.png) `#3D5347`|
|German Grey|71.268|Model Air|70|73|66|![#464942](https://placehold.co/15x15/464942/464942.png) `#464942`|
|German Grey|70.995|Model Color|46|46|44|![#2E2E2C](https://placehold.co/15x15/2E2E2C/2E2E2C.png) `#2E2E2C`|
|German Orange|70.805|Model Color|186|98|84|![#BA6254](https://placehold.co/15x15/BA6254/BA6254.png) `#BA6254`|
|German Panzer Grey|70.603|Surface Primer|64|64|66|![#404042](https://placehold.co/15x15/404042/404042.png) `#404042`|
|German Red Brown|70.605|Surface Primer|98|67|65|![#624341](https://placehold.co/15x15/624341/624341.png) `#624341`|
|German Red Brown|71.271|Model Air|103|66|57|![#674239](https://placehold.co/15x15/674239/674239.png) `#674239`|
|German Red Tail Light|70.307|Panzer Aces|80|52|40|![#503428](https://placehold.co/15x15/503428/503428.png) `#503428`|
|German Tank Crew|70.759|Model Color|84|74|62|![#544A3E](https://placehold.co/15x15/544A3E/544A3E.png) `#544A3E`|
|German Tank Crew|70.333|Panzer Aces|67|73|73|![#434949](https://placehold.co/15x15/434949/434949.png) `#434949`|
|German Tank Crew Highlights|70.337|Panzer Aces|60|38|24|![#3C2618](https://placehold.co/15x15/3C2618/3C2618.png) `#3C2618`|
|German Tank Crew Highlights I|70.338|Panzer Aces|91|117|114|![#5B7572](https://placehold.co/15x15/5B7572/5B7572.png) `#5B7572`|
|German Tank Crew Highlights II|70.339|Panzer Aces|148|121|94|![#94795E](https://placehold.co/15x15/94795E/94795E.png) `#94795E`|
|German Tank Crew I|70.334|Panzer Aces|1|62|44|![#013E2C](https://placehold.co/15x15/013E2C/013E2C.png) `#013E2C`|
|German Tank Crew II|70.335|Panzer Aces|71|60|38|![#473C26](https://placehold.co/15x15/473C26/473C26.png) `#473C26`|
|German Uniform|70.920|Model Color|67|77|66|![#434D42](https://placehold.co/15x15/434D42/434D42.png) `#434D42`|
|German White Tank Crew|70.344|Panzer Aces|224|223|219|![#E0DFDB](https://placehold.co/15x15/E0DFDB/E0DFDB.png) `#E0DFDB`|
|German Yellow|70.806|Model Color|206|182|94|![#CEB65E](https://placehold.co/15x15/CEB65E/CEB65E.png) `#CEB65E`|
|German Yellow Brown|71.272|Model Air|132|110|73|![#846E49](https://placehold.co/15x15/846E49/846E49.png) `#846E49`|
|Ghost Green|72.121|Game Color|131|193|146|![#83C192](https://placehold.co/15x15/83C192/83C192.png) `#83C192`|
|Ghost Green|76.121|Game Air|131|193|146|![#83C192](https://placehold.co/15x15/83C192/83C192.png) `#83C192`|
|Ghost Grey|72.046|Game Color|194|203|212|![#C2CBD4](https://placehold.co/15x15/C2CBD4/C2CBD4.png) `#C2CBD4`|
|Glacier Blue|72.095|Game Color|205|217|241|![#CDD9F1](https://placehold.co/15x15/CDD9F1/CDD9F1.png) `#CDD9F1`|
|Gloomy Violet|72.410|Xpress Color|64|47|89|![#402F59](https://placehold.co/15x15/402F59/402F59.png) `#402F59`|
|Glorious Gold|72.056|Game Color|244|227|197|![#F4E3C5](https://placehold.co/15x15/F4E3C5/F4E3C5.png) `#F4E3C5`|
|Glorious Gold|72.756|Game Air|196|144|94|![#C4905E](https://placehold.co/15x15/C4905E/C4905E.png) `#C4905E`|
|Gloss Black|77.660|Surface Primer|6|6|6|![#060606](https://placehold.co/15x15/060606/060606.png) `#060606`|
|Gloss Metal Varnish|77.657|Metal Color|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Gloss Varnish|62.064|Premium Airbrush Color|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Gloss Varnish|84.154|Arte Deco|229|229|229|![#E5E5E5](https://placehold.co/15x15/E5E5E5/E5E5E5.png) `#E5E5E5`|
|Gloss White|70.842|Model Color|245|243|244|![#F5F3F4](https://placehold.co/15x15/F5F3F4/F5F3F4.png) `#F5F3F4`|
|Glossy Black|70.861|Model Color|36|30|30|![#241E1E](https://placehold.co/15x15/241E1E/241E1E.png) `#241E1E`|
|Glossy Sea Blue|71.300|Model Air|36|43|53|![#242B35](https://placehold.co/15x15/242B35/242B35.png) `#242B35`|
|Goblin Green|72.030|Game Color|87|96|51|![#576033](https://placehold.co/15x15/576033/576033.png) `#576033`|
|Goblin Green|28.027|Hobby Paint|108|116|69|![#6C7445](https://placehold.co/15x15/6C7445/6C7445.png) `#6C7445`|
|Goblin Green|72.730|Game Air|107|115|66|![#6B7342](https://placehold.co/15x15/6B7342/6B7342.png) `#6B7342`|
|Gold|70.996|Model Color|153|103|40|![#996728](https://placehold.co/15x15/996728/996728.png) `#996728`|
|Gold|69.059|Mecha Color|172|132|36|![#AC8424](https://placehold.co/15x15/AC8424/AC8424.png) `#AC8424`|
|Gold|81.122|Arte Deco|228|178|57|![#E4B239](https://placehold.co/15x15/E4B239/E4B239.png) `#E4B239`|
|Gold|77.725|Metal Color|170|161|132|![#AAA184](https://placehold.co/15x15/AAA184/AAA184.png) `#AAA184`|
|Gold|70.791|Liquid Gold|238|230|227|![#EEE6E3](https://placehold.co/15x15/EEE6E3/EEE6E3.png) `#EEE6E3`|
|Gold|62.049|Premium Airbrush Color|240|227|210|![#F0E3D2](https://placehold.co/15x15/F0E3D2/F0E3D2.png) `#F0E3D2`|
|Gold (Metallic)|71.066|Model Air|158|129|85|![#9E8155](https://placehold.co/15x15/9E8155/9E8155.png) `#9E8155`|
|Gold Brown|70.877|Model Color|191|135|60|![#BF873C](https://placehold.co/15x15/BF873C/BF873C.png) `#BF873C`|
|Gold Yellow|72.707|Game Air|241|154|0|![#F19A00](https://placehold.co/15x15/F19A00/F19A00.png) `#F19A00`|
|Gold Yellow|72.007|Game Color|214|116|25|![#D67419](https://placehold.co/15x15/D67419/D67419.png) `#D67419`|
|Gold Yellow|76.007|Game Air|214|116|25|![#D67419](https://placehold.co/15x15/D67419/D67419.png) `#D67419`|
|Golden Brown|71.032|Model Air|135|99|67|![#876343](https://placehold.co/15x15/876343/876343.png) `#876343`|
|Golden Ochre|85.110|Arte Deco|200|115|86|![#C87356](https://placehold.co/15x15/C87356/C87356.png) `#C87356`|
|Golden Olive|70.857|Model Color|128|129|69|![#808145](https://placehold.co/15x15/808145/808145.png) `#808145`|
|Golden Yellow|70.948|Model Color|248|167|52|![#F8A734](https://placehold.co/15x15/F8A734/F8A734.png) `#F8A734`|
|Gooseberry Pink|85.023|Arte Deco|220|104|136|![#DC6888](https://placehold.co/15x15/DC6888/DC6888.png) `#DC6888`|
|Gorgon Brown|72.124|Game Color|90|46|35|![#5A2E23](https://placehold.co/15x15/5A2E23/5A2E23.png) `#5A2E23`|
|Gory Red|28.029|Hobby Paint|120|60|60|![#783C3C](https://placehold.co/15x15/783C3C/783C3C.png) `#783C3C`|
|Gory Red|72.711|Game Air|105|59|61|![#693B3D](https://placehold.co/15x15/693B3D/693B3D.png) `#693B3D`|
|Gory Red|72.011|Game Color|125|31|31|![#7D1F1F](https://placehold.co/15x15/7D1F1F/7D1F1F.png) `#7D1F1F`|
|Gray Blue RLM84|71.103|Model Air|162|163|155|![#A2A39B](https://placehold.co/15x15/A2A39B/A2A39B.png) `#A2A39B`|
|Gray Green RLM74|71.258|Model Air|83|85|84|![#535554](https://placehold.co/15x15/535554/535554.png) `#535554`|
|Gray Violet|71.128|Model Air|100|102|99|![#646663](https://placehold.co/15x15/646663/646663.png) `#646663`|
|Greasy Black|72.476|Xpress Color|65|55|54|![#413736](https://placehold.co/15x15/413736/413736.png) `#413736`|
|Green|69.026|Mecha Color|164|167|146|![#A4A792](https://placehold.co/15x15/A4A792/A4A792.png) `#A4A792`|
|Green|85.088|Arte Deco|0|139|79|![#008B4F](https://placehold.co/15x15/008B4F/008B4F.png) `#008B4F`|
|Green|71.329|Model Air|113|116|107|![#71746B](https://placehold.co/15x15/71746B/71746B.png) `#71746B`|
|Green|72.089|Game Color|0|113|51|![#007133](https://placehold.co/15x15/007133/007133.png) `#007133`|
|Green Blue|69.027|Mecha Color|138|159|128|![#8A9F80](https://placehold.co/15x15/8A9F80/8A9F80.png) `#8A9F80`|
|Green Brown|71.020|Model Air|80|75|69|![#504B45](https://placehold.co/15x15/504B45/504B45.png) `#504B45`|
|Green Brown|70.879|Model Color|129|109|50|![#816D32](https://placehold.co/15x15/816D32/816D32.png) `#816D32`|
|Green Fluorescent|69.057|Mecha Color|168|201|88|![#A8C958](https://placehold.co/15x15/A8C958/A8C958.png) `#A8C958`|
|Green Fluorescent|70.737|Model Color|168|201|88|![#A8C958](https://placehold.co/15x15/A8C958/A8C958.png) `#A8C958`|
|Green Gold|70.795|Liquid Gold|227|216|196|![#E3D8C4](https://placehold.co/15x15/E3D8C4/E3D8C4.png) `#E3D8C4`|
|Green Grey|70.971|Model Color|181|182|174|![#B5B6AE](https://placehold.co/15x15/B5B6AE/B5B6AE.png) `#B5B6AE`|
|Green Grey|70.886|Model Color|101|98|79|![#65624F](https://placehold.co/15x15/65624F/65624F.png) `#65624F`|
|Green Grey|71.341|Model Air|88|98|87|![#586257](https://placehold.co/15x15/586257/586257.png) `#586257`|
|Green Ochre|70.914|Model Color|161|127|53|![#A17F35](https://placehold.co/15x15/A17F35/A17F35.png) `#A17F35`|
|Green RLM62|71.104|Model Air|89|92|71|![#595C47](https://placehold.co/15x15/595C47/595C47.png) `#595C47`|
|Green RLM72|71.263|Model Air|71|73|72|![#474948](https://placehold.co/15x15/474948/474948.png) `#474948`|
|Green RLM73|71.256|Model Air|68|77|76|![#444D4C](https://placehold.co/15x15/444D4C/444D4C.png) `#444D4C`|
|Green Rush|72.605|Game Color Special FX|140|197|178|![#8CC5B2](https://placehold.co/15x15/8CC5B2/8CC5B2.png) `#8CC5B2`|
|Green Sky|70.974|Model Color|122|145|101|![#7A9165](https://placehold.co/15x15/7A9165/7A9165.png) `#7A9165`|
|Green Wash|73.205|Game Color Wash|114|178|91|![#72B25B](https://placehold.co/15x15/72B25B/72B25B.png) `#72B25B`|
|Green Yellow|70.881|Model Color|110|101|60|![#6E653C](https://placehold.co/15x15/6E653C/6E653C.png) `#6E653C`|
|Green Zinc Chromate|71.094|Model Air|86|93|59|![#565D3B](https://placehold.co/15x15/565D3B/565D3B.png) `#565D3B`|
|Grey|71.047|Model Air|85|92|102|![#555C66](https://placehold.co/15x15/555C66/555C66.png) `#555C66`|
|Grey|62.019|Premium Airbrush Color|137|137|149|![#898995](https://placehold.co/15x15/898995/898995.png) `#898995`|
|Grey|69.037|Mecha Color|138|151|160|![#8A97A0](https://placehold.co/15x15/8A97A0/8A97A0.png) `#8A97A0`|
|Grey|70.601|Surface Primer|192|192|194|![#C0C0C2](https://placehold.co/15x15/C0C0C2/C0C0C2.png) `#C0C0C2`|
|Grey|70.641|Mecha Color|197|198|200|![#C5C6C8](https://placehold.co/15x15/C5C6C8/C5C6C8.png) `#C5C6C8`|
|Grey|28.011|Hobby Paint|231|231|231|![#E7E7E7](https://placehold.co/15x15/E7E7E7/E7E7E7.png) `#E7E7E7`|
|Grey Blue|70.943|Model Color|89|109|133|![#596D85](https://placehold.co/15x15/596D85/596D85.png) `#596D85`|
|Grey Blue|71.005|Model Air|66|72|84|![#424854](https://placehold.co/15x15/424854/424854.png) `#424854`|
|Grey Brown|70.762|Model Color|91|73|35|![#5B4923](https://placehold.co/15x15/5B4923/5B4923.png) `#5B4923`|
|Grey Green|70.866|Model Color|65|64|62|![#41403E](https://placehold.co/15x15/41403E/41403E.png) `#41403E`|
|Grey Green|71.340|Model Air|120|126|122|![#787E7A](https://placehold.co/15x15/787E7A/787E7A.png) `#787E7A`|
|Grey Green|69.014|Mecha Color|109|133|137|![#6D8589](https://placehold.co/15x15/6D8589/6D8589.png) `#6D8589`|
|Grey RLM02|71.044|Model Air|122|124|103|![#7A7C67](https://placehold.co/15x15/7A7C67/7A7C67.png) `#7A7C67`|
|Grey Sand|69.031|Mecha Color|186|159|114|![#BA9F72](https://placehold.co/15x15/BA9F72/BA9F72.png) `#BA9F72`|
|Grey Sky|85.102|Arte Deco|197|180|168|![#C5B4A8](https://placehold.co/15x15/C5B4A8/C5B4A8.png) `#C5B4A8`|
|Grey Violet RLM75|71.259|Model Air|97|99|98|![#616362](https://placehold.co/15x15/616362/616362.png) `#616362`|
|Grey Z|69.039|Mecha Color|122|123|125|![#7A7B7D](https://placehold.co/15x15/7A7B7D/7A7B7D.png) `#7A7B7D`|
|Grunge Brown|76.115|Game Air|134|67|38|![#864326](https://placehold.co/15x15/864326/864326.png) `#864326`|
|Grunge Brown|72.115|Game Color|134|67|38|![#864326](https://placehold.co/15x15/864326/864326.png) `#864326`|
|Gunmetal|72.754|Game Air|110|111|113|![#6E6F71](https://placehold.co/15x15/6E6F71/6E6F71.png) `#6E6F71`|
|Gunmetal|70.863|Model Color|53|42|46|![#352A2E](https://placehold.co/15x15/352A2E/352A2E.png) `#352A2E`|
|Gunmetal|62.052|Premium Airbrush Color|209|207|210|![#D1CFD2](https://placehold.co/15x15/D1CFD2/D1CFD2.png) `#D1CFD2`|
|Gunmetal|28.031|Hobby Paint|101|100|106|![#65646A](https://placehold.co/15x15/65646A/65646A.png) `#65646A`|
|Gunmetal|69.058|Mecha Color|100|103|96|![#646760](https://placehold.co/15x15/646760/646760.png) `#646760`|
|Gunmetal (Metallic)|71.072|Model Air|122|123|128|![#7A7B80](https://placehold.co/15x15/7A7B80/7A7B80.png) `#7A7B80`|
|Gunmetal Blue|70.800|Model Color|40|40|52|![#282834](https://placehold.co/15x15/282834/282834.png) `#282834`|
|Gunmetal Grey|77.720|Metal Color|115|115|115|![#737373](https://placehold.co/15x15/737373/737373.png) `#737373`|
|Gunship Green|71.014|Model Air|85|95|84|![#555F54](https://placehold.co/15x15/555F54/555F54.png) `#555F54`|
|Gunship Green|70.895|Model Color|76|88|64|![#4C5840](https://placehold.co/15x15/4C5840/4C5840.png) `#4C5840`|
|Hammered Copper|72.059|Game Color|220|207|199|![#DCCFC7](https://placehold.co/15x15/DCCFC7/DCCFC7.png) `#DCCFC7`|
|Harvest Yellow|85.013|Arte Deco|254|187|57|![#FEBB39](https://placehold.co/15x15/FEBB39/FEBB39.png) `#FEBB39`|
|Heavy Black Green|72.147|Game Color|62|73|67|![#3E4943](https://placehold.co/15x15/3E4943/3E4943.png) `#3E4943`|
|Heavy Blue|72.143|Game Color|64|91|120|![#405B78](https://placehold.co/15x15/405B78/405B78.png) `#405B78`|
|Heavy Bluegrey|72.144|Game Color|203|202|200|![#CBCAC8](https://placehold.co/15x15/CBCAC8/CBCAC8.png) `#CBCAC8`|
|Heavy Brown|72.153|Game Color|123|103|78|![#7B674E](https://placehold.co/15x15/7B674E/7B674E.png) `#7B674E`|
|Heavy Gold Brown|72.151|Game Color|182|134|68|![#B68644](https://placehold.co/15x15/B68644/B68644.png) `#B68644`|
|Heavy Green|72.146|Game Color|86|102|55|![#566637](https://placehold.co/15x15/566637/566637.png) `#566637`|
|Heavy Kakhi|72.149|Game Color|180|159|80|![#B49F50](https://placehold.co/15x15/B49F50/B49F50.png) `#B49F50`|
|Heavy Ochre|72.150|Game Color|174|119|39|![#AE7727](https://placehold.co/15x15/AE7727/AE7727.png) `#AE7727`|
|Heavy Orange|72.152|Game Color|234|94|15|![#EA5E0F](https://placehold.co/15x15/EA5E0F/EA5E0F.png) `#EA5E0F`|
|Heavy Red|72.141|Game Color|141|54|60|![#8D363C](https://placehold.co/15x15/8D363C/8D363C.png) `#8D363C`|
|Heavy Siena|72.154|Game Color|94|72|59|![#5E483B](https://placehold.co/15x15/5E483B/5E483B.png) `#5E483B`|
|Heavy Skin Tone|72.140|Game Color|173|132|104|![#AD8468](https://placehold.co/15x15/AD8468/AD8468.png) `#AD8468`|
|Heavy Violet|72.142|Game Color|72|64|105|![#484069](https://placehold.co/15x15/484069/484069.png) `#484069`|
|Hemp|71.023|Model Air|129|121|100|![#817964](https://placehold.co/15x15/817964/817964.png) `#817964`|
|Heretic Turquoise|72.481|Xpress Color Intense|19|81|75|![#13514B](https://placehold.co/15x15/13514B/13514B.png) `#13514B`|
|Hexed Lichen|72.715|Game Air|57|55|58|![#39373A](https://placehold.co/15x15/39373A/39373A.png) `#39373A`|
|Hexed Lichen|72.015|Game Color|75|39|83|![#4B2753](https://placehold.co/15x15/4B2753/4B2753.png) `#4B2753`|
|Highlight Skin|74.008|Nocturna Models|240|212|190|![#F0D4BE](https://placehold.co/15x15/F0D4BE/F0D4BE.png) `#F0D4BE`|
|Holly Green|85.094|Arte Deco|0|74|57|![#004A39](https://placehold.co/15x15/004A39/004A39.png) `#004A39`|
|Hospitallier Black|72.484|Xpress Color Intense|37|37|39|![#252527](https://placehold.co/15x15/252527/252527.png) `#252527`|
|Hot Orange|72.709|Game Air|230|76|42|![#E64C2A](https://placehold.co/15x15/E64C2A/E64C2A.png) `#E64C2A`|
|Hot Orange|72.009|Game Color|226|57|34|![#E23922](https://placehold.co/15x15/E23922/E23922.png) `#E23922`|
|Hull Red|70.985|Model Color|92|56|60|![#5C383C](https://placehold.co/15x15/5C383C/5C383C.png) `#5C383C`|
|Hull Red|71.039|Model Air|72|61|57|![#483D39](https://placehold.co/15x15/483D39/483D39.png) `#483D39`|
|Hyacinth Blue|85.055|Arte Deco|152|107|184|![#986BB8](https://placehold.co/15x15/986BB8/986BB8.png) `#986BB8`|
|Hyacinth Rose|85.021|Arte Deco|211|150|153|![#D39699](https://placehold.co/15x15/D39699/D39699.png) `#D39699`|
|IAF Sand|71.327|Model Air|196|178|154|![#C4B29A](https://placehold.co/15x15/C4B29A/C4B29A.png) `#C4B29A`|
|IDF Blue|71.113|Model Air|89|117|138|![#59758A](https://placehold.co/15x15/59758A/59758A.png) `#59758A`|
|IDF Israeli Sand Grey (61-73)|70.614|Surface Primer|121|110|104|![#796E68](https://placehold.co/15x15/796E68/796E68.png) `#796E68`|
|IDF Sand Grey 73|71.141|Model Air|170|159|131|![#AA9F83](https://placehold.co/15x15/AA9F83/AA9F83.png) `#AA9F83`|
|IDF Sinai Grey 82|71.142|Model Air|123|114|109|![#7B726D](https://placehold.co/15x15/7B726D/7B726D.png) `#7B726D`|
|IDF/IAF Green|71.126|Model Air|121|134|108|![#79866C](https://placehold.co/15x15/79866C/79866C.png) `#79866C`|
|IJA Chrome Yellow|71.135|Model Air|244|169|0|![#F4A900](https://placehold.co/15x15/F4A900/F4A900.png) `#F4A900`|
|IJA Dark Green|71.285|Model Air|82|84|63|![#52543F](https://placehold.co/15x15/52543F/52543F.png) `#52543F`|
|IJA Earth Brown|71.136|Model Air|120|100|75|![#78644B](https://placehold.co/15x15/78644B/78644B.png) `#78644B`|
|IJA Grey Green|71.326|Model Air|187|179|158|![#BBB39E](https://placehold.co/15x15/BBB39E/BBB39E.png) `#BBB39E`|
|IJA Khaki Brown|71.287|Model Air|105|89|64|![#695940](https://placehold.co/15x15/695940/695940.png) `#695940`|
|IJA Light Grey Green|71.321|Model Air|165|170|147|![#A5AA93](https://placehold.co/15x15/A5AA93/A5AA93.png) `#A5AA93`|
|IJA Midouri Green|71.134|Model Air|62|72|61|![#3E483D](https://placehold.co/15x15/3E483D/3E483D.png) `#3E483D`|
|IJA Olive Green|71.286|Model Air|84|76|63|![#544C3F](https://placehold.co/15x15/544C3F/544C3F.png) `#544C3F`|
|IJN Ash Grey|71.311|Model Air|137|129|108|![#89816C](https://placehold.co/15x15/89816C/89816C.png) `#89816C`|
|IJN Black Green|71.322|Model Air|62|72|61|![#3E483D](https://placehold.co/15x15/3E483D/3E483D.png) `#3E483D`|
|IJN Dark Black Green|71.325|Model Air|67|69|66|![#434542](https://placehold.co/15x15/434542/434542.png) `#434542`|
|IJN Deep Dark Green|71.310|Model Air|54|80|77|![#36504D](https://placehold.co/15x15/36504D/36504D.png) `#36504D`|
|IJN Medium Grey|71.312|Model Air|185|176|171|![#B9B0AB](https://placehold.co/15x15/B9B0AB/B9B0AB.png) `#B9B0AB`|
|Ice Yellow|70.858|Model Color|238|207|114|![#EECF72](https://placehold.co/15x15/EECF72/EECF72.png) `#EECF72`|
|Iceberg Grey|72.463|Xpress Color|66|87|108|![#42576C](https://placehold.co/15x15/42576C/42576C.png) `#42576C`|
|Imperial Blue|72.720|Game Air|4|49|106|![#04316A](https://placehold.co/15x15/04316A/04316A.png) `#04316A`|
|Imperial Blue|72.020|Game Color|38|42|71|![#262A47](https://placehold.co/15x15/262A47/262A47.png) `#262A47`|
|Imperial Blue|76.020|Game Air|38|42|71|![#262A47](https://placehold.co/15x15/262A47/262A47.png) `#262A47`|
|Imperial Purple|74.025|Nocturna Models|78|45|121|![#4E2D79](https://placehold.co/15x15/4E2D79/4E2D79.png) `#4E2D79`|
|Imperial Yellow|72.403|Xpress Color|245|159|46|![#F59F2E](https://placehold.co/15x15/F59F2E/F59F2E.png) `#F59F2E`|
|Indian Turquoise|85.071|Arte Deco|155|213|217|![#9BD5D9](https://placehold.co/15x15/9BD5D9/9BD5D9.png) `#9BD5D9`|
|Industrial Splash Mud|73.803|Weathering FX|115|116|110|![#73746E](https://placehold.co/15x15/73746E/73746E.png) `#73746E`|
|Industrial Thick Mud|73.809|Weathering FX|83|86|77|![#53564D](https://placehold.co/15x15/53564D/53564D.png) `#53564D`|
|Infantry Blue|70.752|Model Color|37|33|47|![#25212F](https://placehold.co/15x15/25212F/25212F.png) `#25212F`|
|Inferno Red|74.022|Nocturna Models|221|50|58|![#DD323A](https://placehold.co/15x15/DD323A/DD323A.png) `#DD323A`|
|Insignia White|71.279|Model Air|227|227|219|![#E3E3DB](https://placehold.co/15x15/E3E3DB/E3E3DB.png) `#E3E3DB`|
|Interior Green|71.010|Model Air|100|93|64|![#645D40](https://placehold.co/15x15/645D40/645D40.png) `#645D40`|
|Interior Grey Green|71.305|Model Air|150|162|138|![#96A28A](https://placehold.co/15x15/96A28A/96A28A.png) `#96A28A`|
|Intermediate Blue|70.903|Model Color|100|109|118|![#646D76](https://placehold.co/15x15/646D76/646D76.png) `#646D76`|
|Intermediate Blue|71.299|Model Air|94|112|126|![#5E707E](https://placehold.co/15x15/5E707E/5E707E.png) `#5E707E`|
|Intermediate Green|70.891|Model Color|80|101|68|![#506544](https://placehold.co/15x15/506544/506544.png) `#506544`|
|Iraqi Sand|70.819|Model Color|180|147|96|![#B49360](https://placehold.co/15x15/B49360/B49360.png) `#B49360`|
|Italian Tank Crew|70.327|Panzer Aces|75|70|28|![#4B461C](https://placehold.co/15x15/4B461C/4B461C.png) `#4B461C`|
|Italian Tank Crew Highlights|70.331|Panzer Aces|158|177|147|![#9EB193](https://placehold.co/15x15/9EB193/9EB193.png) `#9EB193`|
|Ivory|70.643|Mecha Color|244|239|210|![#F4EFD2](https://placehold.co/15x15/F4EFD2/F4EFD2.png) `#F4EFD2`|
|Ivory|71.075|Model Air|193|175|137|![#C1AF89](https://placehold.co/15x15/C1AF89/C1AF89.png) `#C1AF89`|
|Ivory|70.918|Model Color|235|226|209|![#EBE2D1](https://placehold.co/15x15/EBE2D1/EBE2D1.png) `#EBE2D1`|
|Ivory RLM05|71.106|Model Air|200|178|105|![#C8B269](https://placehold.co/15x15/C8B269/C8B269.png) `#C8B269`|
|JGSD Brown 3606|71.297|Model Air|112|102|92|![#70665C](https://placehold.co/15x15/70665C/70665C.png) `#70665C`|
|Jade Green|85.083|Arte Deco|119|180|138|![#77B48A](https://placehold.co/15x15/77B48A/77B48A.png) `#77B48A`|
|Jade Green|76.026|Game Air|0|113|85|![#007155](https://placehold.co/15x15/007155/007155.png) `#007155`|
|Jade Green|72.026|Game Color|0|113|85|![#007155](https://placehold.co/15x15/007155/007155.png) `#007155`|
|Japanese Tank Crew|70.328|Panzer Aces|92|86|50|![#5C5632](https://placehold.co/15x15/5C5632/5C5632.png) `#5C5632`|
|Japanese Tank Crew Highlights|70.332|Panzer Aces|170|163|145|![#AAA391](https://placehold.co/15x15/AAA391/AAA391.png) `#AAA391`|
|Japanese Uniform WWII|70.923|Model Color|159|127|42|![#9F7F2A](https://placehold.co/15x15/9F7F2A/9F7F2A.png) `#9F7F2A`|
|Jet Exhaust|77.713|Metal Color|121|121|121|![#797979](https://placehold.co/15x15/797979/797979.png) `#797979`|
|Kelly Green|85.092|Arte Deco|0|142|77|![#008E4D](https://placehold.co/15x15/008E4D/008E4D.png) `#008E4D`|
|Khaki|72.061|Game Color|154|123|76|![#9A7B4C](https://placehold.co/15x15/9A7B4C/9A7B4C.png) `#9A7B4C`|
|Khaki|72.761|Game Air|170|157|115|![#AA9D73](https://placehold.co/15x15/AA9D73/AA9D73.png) `#AA9D73`|
|Khaki|70.988|Model Color|111|95|59|![#6F5F3B](https://placehold.co/15x15/6F5F3B/6F5F3B.png) `#6F5F3B`|
|Khaki Brown|71.024|Model Air|145|121|87|![#917957](https://placehold.co/15x15/917957/917957.png) `#917957`|
|Khaki Drill|72.451|Xpress Color|199|148|91|![#C7945B](https://placehold.co/15x15/C7945B/C7945B.png) `#C7945B`|
|Khaki Green Num.3|71.330|Model Air|97|94|75|![#615E4B](https://placehold.co/15x15/615E4B/615E4B.png) `#615E4B`|
|Khaki Grey|70.880|Model Color|126|99|56|![#7E6338](https://placehold.co/15x15/7E6338/7E6338.png) `#7E6338`|
|Landser Grey|72.469|Xpress Color|82|79|72|![#524F48](https://placehold.co/15x15/524F48/524F48.png) `#524F48`|
|Lavender|85.054|Arte Deco|126|57|140|![#7E398C](https://placehold.co/15x15/7E398C/7E398C.png) `#7E398C`|
|Lavender Grey|70.774|Model Color|127|111|111|![#7F6F6F](https://placehold.co/15x15/7F6F6F/7F6F6F.png) `#7F6F6F`|
|Leaf Green|85.098|Arte Deco|0|110|55|![#006E37](https://placehold.co/15x15/006E37/006E37.png) `#006E37`|
|Leather Belt|70.312|Panzer Aces|102|82|73|![#665249](https://placehold.co/15x15/665249/665249.png) `#665249`|
|Leather Brown|76.040|Game Air|141|94|42|![#8D5E2A](https://placehold.co/15x15/8D5E2A/8D5E2A.png) `#8D5E2A`|
|Leather Brown|70.871|Model Color|89|67|53|![#594335](https://placehold.co/15x15/594335/594335.png) `#594335`|
|Leather Brown|70.626|Surface Primer|124|96|82|![#7C6052](https://placehold.co/15x15/7C6052/7C6052.png) `#7C6052`|
|Leather Brown|28.014|Hobby Paint|135|100|60|![#87643C](https://placehold.co/15x15/87643C/87643C.png) `#87643C`|
|Leather Brown|72.040|Game Color|141|94|42|![#8D5E2A](https://placehold.co/15x15/8D5E2A/8D5E2A.png) `#8D5E2A`|
|Legacy Blue|72.480|Xpress Color Intense|39|41|97|![#272961](https://placehold.co/15x15/272961/272961.png) `#272961`|
|Lemon Yellow|85.007|Arte Deco|254|236|64|![#FEEC40](https://placehold.co/15x15/FEEC40/FEEC40.png) `#FEEC40`|
|Lemon Yellow|70.952|Model Color|228|210|2|![#E4D202](https://placehold.co/15x15/E4D202/E4D202.png) `#E4D202`|
|Light Avocado|85.096|Arte Deco|93|169|122|![#5DA97A](https://placehold.co/15x15/5DA97A/5DA97A.png) `#5DA97A`|
|Light Blue|69.016|Mecha Color|107|141|187|![#6B8DBB](https://placehold.co/15x15/6B8DBB/6B8DBB.png) `#6B8DBB`|
|Light Blue|71.328|Model Air|198|201|192|![#C6C9C0](https://placehold.co/15x15/C6C9C0/C6C9C0.png) `#C6C9C0`|
|Light Blue RLM65|71.255|Model Air|137|157|156|![#899D9C](https://placehold.co/15x15/899D9C/899D9C.png) `#899D9C`|
|Light Blue RLM76|71.257|Model Air|150|171|164|![#96ABA4](https://placehold.co/15x15/96ABA4/96ABA4.png) `#96ABA4`|
|Light Blue RLM78|71.101|Model Air|128|149|144|![#809590](https://placehold.co/15x15/809590/809590.png) `#809590`|
|Light Brown|71.027|Model Air|174|145|105|![#AE9169](https://placehold.co/15x15/AE9169/AE9169.png) `#AE9169`|
|Light Brown|70.929|Model Color|162|91|49|![#A25B31](https://placehold.co/15x15/A25B31/A25B31.png) `#A25B31`|
|Light Brown Mud|73.810|Weathering FX|129|131|118|![#818376](https://placehold.co/15x15/818376/818376.png) `#818376`|
|Light Brown Splash Mud|73.804|Weathering FX|199|187|175|![#C7BBAF](https://placehold.co/15x15/C7BBAF/C7BBAF.png) `#C7BBAF`|
|Light Flesh|69.005|Mecha Color|248|216|201|![#F8D8C9](https://placehold.co/15x15/F8D8C9/F8D8C9.png) `#F8D8C9`|
|Light Flesh|70.928|Model Color|243|212|184|![#F3D4B8](https://placehold.co/15x15/F3D4B8/F3D4B8.png) `#F3D4B8`|
|Light Gray|71.050|Model Air|140|144|155|![#8C909B](https://placehold.co/15x15/8C909B/8C909B.png) `#8C909B`|
|Light Green|70.942|Model Color|0|121|67|![#007943](https://placehold.co/15x15/007943/007943.png) `#007943`|
|Light Green|69.025|Mecha Color|198|201|192|![#C6C9C0](https://placehold.co/15x15/C6C9C0/C6C9C0.png) `#C6C9C0`|
|Light Green Blue|70.972|Model Color|134|149|142|![#86958E](https://placehold.co/15x15/86958E/86958E.png) `#86958E`|
|Light Green Chromate|71.006|Model Air|95|102|68|![#5F6644](https://placehold.co/15x15/5F6644/5F6644.png) `#5F6644`|
|Light Green RLM25|71.267|Model Air|73|120|104|![#497868](https://placehold.co/15x15/497868/497868.png) `#497868`|
|Light Green RLM82|71.022|Model Air|75|79|62|![#4B4F3E](https://placehold.co/15x15/4B4F3E/4B4F3E.png) `#4B4F3E`|
|Light Grey|76.515|Wash FX|195|195|193|![#C3C3C1](https://placehold.co/15x15/C3C3C1/C3C3C1.png) `#C3C3C1`|
|Light Grey|70.990|Model Color|145|146|148|![#919294](https://placehold.co/15x15/919294/919294.png) `#919294`|
|Light Grey|69.036|Mecha Color|150|157|165|![#969DA5](https://placehold.co/15x15/969DA5/969DA5.png) `#969DA5`|
|Light Grey RLM63|71.260|Model Air|107|111|96|![#6B6F60](https://placehold.co/15x15/6B6F60/6B6F60.png) `#6B6F60`|
|Light Grey Wash|69.515|Mecha Color|201|201|199|![#C9C9C7](https://placehold.co/15x15/C9C9C7/C9C9C7.png) `#C9C9C7`|
|Light Gull Gray|71.121|Model Air|169|170|162|![#A9AAA2](https://placehold.co/15x15/A9AAA2/A9AAA2.png) `#A9AAA2`|
|Light Livery Green|72.733|Game Air|146|189|22|![#92BD16](https://placehold.co/15x15/92BD16/92BD16.png) `#92BD16`|
|Light Magenta|85.047|Arte Deco|250|104|184|![#FA68B8](https://placehold.co/15x15/FA68B8/FA68B8.png) `#FA68B8`|
|Light Mud|70.315|Panzer Aces|172|163|122|![#ACA37A](https://placehold.co/15x15/ACA37A/ACA37A.png) `#ACA37A`|
|Light Mud|70.760|Model Color|124|116|93|![#7C745D](https://placehold.co/15x15/7C745D/7C745D.png) `#7C745D`|
|Light Olive|71.247|Model Air|104|96|77|![#68604D](https://placehold.co/15x15/68604D/68604D.png) `#68604D`|
|Light Orange|70.911|Model Color|238|114|40|![#EE7228](https://placehold.co/15x15/EE7228/EE7228.png) `#EE7228`|
|Light Red|71.086|Model Air|224|70|34|![#E04622](https://placehold.co/15x15/E04622/E04622.png) `#E04622`|
|Light Rubber|70.305|Panzer Aces|131|131|129|![#838381](https://placehold.co/15x15/838381/838381.png) `#838381`|
|Light Rust|70.301|Panzer Aces|135|67|30|![#87431E](https://placehold.co/15x15/87431E/87431E.png) `#87431E`|
|Light Rust|76.505|Wash FX|201|121|50|![#C97932](https://placehold.co/15x15/C97932/C97932.png) `#C97932`|
|Light Rust|71.129|Model Air|145|94|67|![#915E43](https://placehold.co/15x15/915E43/915E43.png) `#915E43`|
|Light Rust Wash|69.505|Mecha Color|235|121|25|![#EB7919](https://placehold.co/15x15/EB7919/EB7919.png) `#EB7919`|
|Light Sea Blue|71.089|Model Air|2|164|213|![#02A4D5](https://placehold.co/15x15/02A4D5/02A4D5.png) `#02A4D5`|
|Light Sea Grey|70.973|Model Color|161|177|177|![#A1B1B1](https://placehold.co/15x15/A1B1B1/A1B1B1.png) `#A1B1B1`|
|Light Steel|69.064|Mecha Color|205|214|211|![#CDD6D3](https://placehold.co/15x15/CDD6D3/CDD6D3.png) `#CDD6D3`|
|Light Turquoise|70.840|Model Color|0|105|137|![#006989](https://placehold.co/15x15/006989/006989.png) `#006989`|
|Light Violet|70.750|Model Color|168|147|188|![#A893BC](https://placehold.co/15x15/A893BC/A893BC.png) `#A893BC`|
|Light Yellow|70.949|Model Color|248|211|71|![#F8D347](https://placehold.co/15x15/F8D347/F8D347.png) `#F8D347`|
|Lila|85.051|Arte Deco|221|171|217|![#DDABD9](https://placehold.co/15x15/DDABD9/DDABD9.png) `#DDABD9`|
|Lime Green|70.827|Model Color|127|148|53|![#7F9435](https://placehold.co/15x15/7F9435/7F9435.png) `#7F9435`|
|Lipstick|74.029|Nocturna Models|130|18|90|![#82125A](https://placehold.co/15x15/82125A/82125A.png) `#82125A`|
|Livery Green|72.033|Game Color|157|196|81|![#9DC451](https://placehold.co/15x15/9DC451/9DC451.png) `#9DC451`|
|Lizard Green|72.418|Xpress Color|34|58|44|![#223A2C](https://placehold.co/15x15/223A2C/223A2C.png) `#223A2C`|
|Loam Beige|71.245|Model Air|152|136|100|![#988864](https://placehold.co/15x15/988864/988864.png) `#988864`|
|London Grey|70.836|Model Color|105|99|99|![#696363](https://placehold.co/15x15/696363/696363.png) `#696363`|
|Lt Cinnamon|85.115|Arte Deco|162|119|132|![#A27784](https://placehold.co/15x15/A27784/A27784.png) `#A27784`|
|Luftwaffe Green|70.823|Model Color|57|63|37|![#393F25](https://placehold.co/15x15/393F25/393F25.png) `#393F25`|
|Luftwaffe Uniform WWII|70.816|Model Color|68|64|78|![#44404E](https://placehold.co/15x15/44404E/44404E.png) `#44404E`|
|Lustful Purple|76.114|Game Air|183|139|188|![#B78BBC](https://placehold.co/15x15/B78BBC/B78BBC.png) `#B78BBC`|
|Lustful Purple|72.114|Game Color|183|139|188|![#B78BBC](https://placehold.co/15x15/B78BBC/B78BBC.png) `#B78BBC`|
|M495 Light Gray|71.298|Model Air|156|153|138|![#9C998A](https://placehold.co/15x15/9C998A/9C998A.png) `#9C998A`|
|Magenta|69.010|Mecha Color|193|17|38|![#C11126](https://placehold.co/15x15/C11126/C11126.png) `#C11126`|
|Magenta|62.007|Premium Airbrush Color|165|46|100|![#A52E64](https://placehold.co/15x15/A52E64/A52E64.png) `#A52E64`|
|Magenta|70.945|Model Color|144|49|83|![#903153](https://placehold.co/15x15/903153/903153.png) `#903153`|
|Magenta|72.083|Game Color|166|35|85|![#A62355](https://placehold.co/15x15/A62355/A62355.png) `#A62355`|
|Magenta Blood|74.021|Nocturna Models|170|32|56|![#AA2038](https://placehold.co/15x15/AA2038/AA2038.png) `#AA2038`|
|Magenta Fluorescent|70.735|Model Color|230|65|141|![#E6418D](https://placehold.co/15x15/E6418D/E6418D.png) `#E6418D`|
|Magenta Fluorescent|69.056|Mecha Color|231|65|141|![#E7418D](https://placehold.co/15x15/E7418D/E7418D.png) `#E7418D`|
|Magic Blue|76.021|Game Air|0|105|170|![#0069AA](https://placehold.co/15x15/0069AA/0069AA.png) `#0069AA`|
|Magic Blue|72.021|Game Color|0|105|170|![#0069AA](https://placehold.co/15x15/0069AA/0069AA.png) `#0069AA`|
|Magic Blue|72.721|Game Air|2|110|182|![#026EB6](https://placehold.co/15x15/026EB6/026EB6.png) `#026EB6`|
|Magic Blue|28.030|Hobby Paint|18|109|180|![#126DB4](https://placehold.co/15x15/126DB4/126DB4.png) `#126DB4`|
|Magnesium|77.711|Metal Color|133|133|133|![#858585](https://placehold.co/15x15/858585/858585.png) `#858585`|
|Mahogany|72.472|Xpress Color|90|57|48|![#5A3930](https://placehold.co/15x15/5A3930/5A3930.png) `#5A3930`|
|Mahogany|71.036|Model Air|74|59|56|![#4A3B38](https://placehold.co/15x15/4A3B38/4A3B38.png) `#4A3B38`|
|Mahogany Brown|70.846|Model Color|121|80|74|![#79504A](https://placehold.co/15x15/79504A/79504A.png) `#79504A`|
|Mahogany Ink|70.828|Model Color|103|70|65|![#674641](https://placehold.co/15x15/674641/674641.png) `#674641`|
|Malefic Flesh|74.012|Nocturna Models|105|96|97|![#696061](https://placehold.co/15x15/696061/696061.png) `#696061`|
|Martian Orange|72.405|Xpress Color|205|70|25|![#CD4619](https://placehold.co/15x15/CD4619/CD4619.png) `#CD4619`|
|Matt Varnish|62.062|Premium Airbrush Color|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Matt Varnish|84.155|Arte Deco|220|220|220|![#DCDCDC](https://placehold.co/15x15/DCDCDC/DCDCDC.png) `#DCDCDC`|
|Mauve|85.041|Arte Deco|159|79|94|![#9F4F5E](https://placehold.co/15x15/9F4F5E/9F4F5E.png) `#9F4F5E`|
|Mecha Gloss Varnish|69.701|Mecha Color|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Mecha Matt Varnish|69.702|Mecha Color|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Mecha Satin Varnish|69.703|Mecha Color|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Medium Blue|70.963|Model Color|22|65|108|![#16416C](https://placehold.co/15x15/16416C/16416C.png) `#16416C`|
|Medium Blue|85.063|Arte Deco|41|64|154|![#29409A](https://placehold.co/15x15/29409A/29409A.png) `#29409A`|
|Medium Brown|70.826|Model Color|91|72|58|![#5B483A](https://placehold.co/15x15/5B483A/5B483A.png) `#5B483A`|
|Medium Flesh|74.005|Nocturna Models|233|136|119|![#E98877](https://placehold.co/15x15/E98877/E98877.png) `#E98877`|
|Medium Flesh|85.017|Arte Deco|250|208|209|![#FAD0D1](https://placehold.co/15x15/FAD0D1/FAD0D1.png) `#FAD0D1`|
|Medium Fleshtone|70.860|Model Color|176|121|64|![#B07940](https://placehold.co/15x15/B07940/B07940.png) `#B07940`|
|Medium Gray|71.114|Model Air|104|126|139|![#687E8B](https://placehold.co/15x15/687E8B/687E8B.png) `#687E8B`|
|Medium Grey|69.038|Mecha Color|130|131|133|![#828385](https://placehold.co/15x15/828385/828385.png) `#828385`|
|Medium Grey|70.987|Model Color|134|114|89|![#867259](https://placehold.co/15x15/867259/867259.png) `#867259`|
|Medium Grey Blue|70.772|Model Color|119|157|146|![#779D92](https://placehold.co/15x15/779D92/779D92.png) `#779D92`|
|Medium Gunship Gray|71.097|Model Air|90|97|107|![#5A616B](https://placehold.co/15x15/5A616B/5A616B.png) `#5A616B`|
|Medium Olive|71.092|Model Air|80|84|67|![#505443](https://placehold.co/15x15/505443/505443.png) `#505443`|
|Medium Olive|70.850|Model Color|65|78|50|![#414E32](https://placehold.co/15x15/414E32/414E32.png) `#414E32`|
|Medium Sea Grey|70.870|Model Color|125|123|124|![#7D7B7C](https://placehold.co/15x15/7D7B7C/7D7B7C.png) `#7D7B7C`|
|Medium Xpress|72.448|Xpress Color|255|251|248|![#FFFBF8](https://placehold.co/15x15/FFFBF8/FFFBF8.png) `#FFFBF8`|
|Medium Yellow|71.002|Model Air|249|178|2|![#F9B202](https://placehold.co/15x15/F9B202/F9B202.png) `#F9B202`|
|Metallic Black|62.053|Premium Airbrush Color|190|186|187|![#BEBABB](https://placehold.co/15x15/BEBABB/BEBABB.png) `#BEBABB`|
|Metallic Blue|62.046|Premium Airbrush Color|208|215|233|![#D0D7E9](https://placehold.co/15x15/D0D7E9/D0D7E9.png) `#D0D7E9`|
|Metallic Blue|69.067|Mecha Color|55|60|79|![#373C4F](https://placehold.co/15x15/373C4F/373C4F.png) `#373C4F`|
|Metallic Green|69.068|Mecha Color|27|146|127|![#1B927F](https://placehold.co/15x15/1B927F/1B927F.png) `#1B927F`|
|Metallic Green|62.047|Premium Airbrush Color|219|235|225|![#DBEBE1](https://placehold.co/15x15/DBEBE1/DBEBE1.png) `#DBEBE1`|
|Metallic Medium|62.041|Premium Airbrush Color|250|247|240|![#FAF7F0](https://placehold.co/15x15/FAF7F0/FAF7F0.png) `#FAF7F0`|
|Metallic Orange|62.043|Premium Airbrush Color|246|222|218|![#F6DEDA](https://placehold.co/15x15/F6DEDA/F6DEDA.png) `#F6DEDA`|
|Metallic Red|69.066|Mecha Color|203|89|112|![#CB5970](https://placehold.co/15x15/CB5970/CB5970.png) `#CB5970`|
|Metallic Red|62.044|Premium Airbrush Color|240|211|213|![#F0D3D5](https://placehold.co/15x15/F0D3D5/F0D3D5.png) `#F0D3D5`|
|Metallic Violet|62.045|Premium Airbrush Color|219|215|238|![#DBD7EE](https://placehold.co/15x15/DBD7EE/DBD7EE.png) `#DBD7EE`|
|Metallic Yellow|62.042|Premium Airbrush Color|251|237|211|![#FBEDD3](https://placehold.co/15x15/FBEDD3/FBEDD3.png) `#FBEDD3`|
|Middle Stone|70.882|Model Color|147|127|66|![#937F42](https://placehold.co/15x15/937F42/937F42.png) `#937F42`|
|Middle Stone|71.031|Model Air|153|124|80|![#997C50](https://placehold.co/15x15/997C50/997C50.png) `#997C50`|
|Midnight Blue|85.070|Arte Deco|1|45|44|![#012D2C](https://placehold.co/15x15/012D2C/012D2C.png) `#012D2C`|
|Midnight Purple|76.116|Game Air|45|30|51|![#2D1E33](https://placehold.co/15x15/2D1E33/2D1E33.png) `#2D1E33`|
|Midnight Purple|72.116|Game Color|45|30|51|![#2D1E33](https://placehold.co/15x15/2D1E33/2D1E33.png) `#2D1E33`|
|Military Green|70.975|Model Color|67|68|52|![#434434](https://placehold.co/15x15/434434/434434.png) `#434434`|
|Military Yellow|70.764|Model Color|147|118|38|![#937626](https://placehold.co/15x15/937626/937626.png) `#937626`|
|Military Yellow|72.453|Xpress Color|128|94|48|![#805E30](https://placehold.co/15x15/805E30/805E30.png) `#805E30`|
|Mink Tan|85.108|Arte Deco|181|123|105|![#B57B69](https://placehold.co/15x15/B57B69/B57B69.png) `#B57B69`|
|Mint Julep|85.077|Arte Deco|166|203|170|![#A6CBAA](https://placehold.co/15x15/A6CBAA/A6CBAA.png) `#A6CBAA`|
|Mistletoe|85.093|Arte Deco|52|118|69|![#347645](https://placehold.co/15x15/347645/347645.png) `#347645`|
|Mocha|85.112|Arte Deco|251|138|124|![#FB8A7C](https://placehold.co/15x15/FB8A7C/FB8A7C.png) `#FB8A7C`|
|Monastic Green|72.482|Xpress Color Intense|0|75|55|![#004B37](https://placehold.co/15x15/004B37/004B37.png) `#004B37`|
|Moon Yellow|76.005|Game Air|238|184|0|![#EEB800](https://placehold.co/15x15/EEB800/EEB800.png) `#EEB800`|
|Moon Yellow|72.705|Game Air|252|188|2|![#FCBC02](https://placehold.co/15x15/FCBC02/FCBC02.png) `#FCBC02`|
|Moon Yellow|85.006|Arte Deco|254|232|176|![#FEE8B0](https://placehold.co/15x15/FEE8B0/FEE8B0.png) `#FEE8B0`|
|Moon Yellow|72.005|Game Color|238|184|0|![#EEB800](https://placehold.co/15x15/EEB800/EEB800.png) `#EEB800`|
|Moss and Lichen|73.827|Weathering FX|189|156|59|![#BD9C3B](https://placehold.co/15x15/BD9C3B/BD9C3B.png) `#BD9C3B`|
|Moss and Lichen|72.611|Game Color Special FX|218|215|108|![#DAD76C](https://placehold.co/15x15/DAD76C/DAD76C.png) `#DAD76C`|
|Mud Brown|71.037|Model Air|141|100|72|![#8D6448](https://placehold.co/15x15/8D6448/8D6448.png) `#8D6448`|
|Mud and Grass|73.826|Weathering FX|76|76|68|![#4C4C44](https://placehold.co/15x15/4C4C44/4C4C44.png) `#4C4C44`|
|Muddy Ground|72.475|Xpress Color|69|46|40|![#452E28](https://placehold.co/15x15/452E28/452E28.png) `#452E28`|
|Mummy White|72.449|Xpress Color|207|180|150|![#CFB496](https://placehold.co/15x15/CFB496/CFB496.png) `#CFB496`|
|Mustard Brown|70.769|Model Color|157|113|74|![#9D714A](https://placehold.co/15x15/9D714A/9D714A.png) `#9D714A`|
|Mutation Green|72.105|Game Color|76|118|80|![#4C7650](https://placehold.co/15x15/4C7650/4C7650.png) `#4C7650`|
|Mystic Blue|72.411|Xpress Color|0|74|135|![#004A87](https://placehold.co/15x15/004A87/004A87.png) `#004A87`|
|NATO Black|71.251|Model Air|56|56|58|![#38383A](https://placehold.co/15x15/38383A/38383A.png) `#38383A`|
|NATO Brown|71.249|Model Air|92|78|69|![#5C4E45](https://placehold.co/15x15/5C4E45/5C4E45.png) `#5C4E45`|
|NATO Green|71.093|Model Air|82|90|79|![#525A4F](https://placehold.co/15x15/525A4F/525A4F.png) `#525A4F`|
|NATO Green|70.612|Surface Primer|74|85|69|![#4A5545](https://placehold.co/15x15/4A5545/4A5545.png) `#4A5545`|
|Naphthol Red|85.032|Arte Deco|198|24|25|![#C61819](https://placehold.co/15x15/C61819/C61819.png) `#C61819`|
|Natural Flesh|74.006|Nocturna Models|192|148|123|![#C0947B](https://placehold.co/15x15/C0947B/C0947B.png) `#C0947B`|
|Natural Steel|70.864|Model Color|83|82|88|![#535258](https://placehold.co/15x15/535258/535258.png) `#535258`|
|Natural Wood Grain|70.834|Model Color|234|164|50|![#EAA432](https://placehold.co/15x15/EAA432/EAA432.png) `#EAA432`|
|Navy Blue|85.069|Arte Deco|46|33|79|![#2E214F](https://placehold.co/15x15/2E214F/2E214F.png) `#2E214F`|
|Neon Blue|85.137|Arte Deco Colores Fluoresecents|6|38|109|![#06266D](https://placehold.co/15x15/06266D/06266D.png) `#06266D`|
|Neon Green|85.138|Arte Deco Colores Fluoresecents|0|147|49|![#009331](https://placehold.co/15x15/009331/009331.png) `#009331`|
|Neon Magenta|85.136|Arte Deco Colores Fluoresecents|230|0|104|![#E60068](https://placehold.co/15x15/E60068/E60068.png) `#E60068`|
|Neon Pink|85.135|Arte Deco Colores Fluoresecents|229|0|88|![#E50058](https://placehold.co/15x15/E50058/E50058.png) `#E50058`|
|Neon Red|85.134|Arte Deco Colores Fluoresecents|235|78|34|![#EB4E22](https://placehold.co/15x15/EB4E22/EB4E22.png) `#EB4E22`|
|Neon Yellow|85.132|Arte Deco Colores Fluoresecents|255|241|112|![#FFF170](https://placehold.co/15x15/FFF170/FFF170.png) `#FFF170`|
|Neutral Gray|71.051|Model Air|112|119|127|![#70777F](https://placehold.co/15x15/70777F/70777F.png) `#70777F`|
|Neutral Grey|72.050|Game Color|111|109|97|![#6F6D61](https://placehold.co/15x15/6F6D61/6F6D61.png) `#6F6D61`|
|Neutral Grey|70.992|Model Color|97|97|95|![#61615F](https://placehold.co/15x15/61615F/61615F.png) `#61615F`|
|Neutral Grey|85.100|Arte Deco|113|112|107|![#71706B](https://placehold.co/15x15/71706B/71706B.png) `#71706B`|
|New Wood|70.770|Model Color|138|99|60|![#8A633C](https://placehold.co/15x15/8A633C/8A633C.png) `#8A633C`|
|New Wood|70.311|Panzer Aces|137|101|69|![#896545](https://placehold.co/15x15/896545/896545.png) `#896545`|
|Night Blue|72.019|Game Color|32|36|48|![#202430](https://placehold.co/15x15/202430/202430.png) `#202430`|
|Night Blue|76.019|Game Air|32|36|48|![#202430](https://placehold.co/15x15/202430/202430.png) `#202430`|
|Nocturna Shadow|74.001|Nocturna Models|67|70|70|![#434646](https://placehold.co/15x15/434646/434646.png) `#434646`|
|Nocturnal Red|76.111|Game Air|85|28|34|![#551C22](https://placehold.co/15x15/551C22/551C22.png) `#551C22`|
|Nocturnal Red|72.111|Game Color|85|28|34|![#551C22](https://placehold.co/15x15/551C22/551C22.png) `#551C22`|
|Nuclear Yellow|72.404|Xpress Color|221|146|19|![#DD9213](https://placehold.co/15x15/DD9213/DD9213.png) `#DD9213`|
|Num. 41 Dark Olive Drab|71.316|Model Air|84|76|63|![#544C3F](https://placehold.co/15x15/544C3F/544C3F.png) `#544C3F`|
|Ocean Gray|71.273|Model Air|110|117|127|![#6E757F](https://placehold.co/15x15/6E757F/6E757F.png) `#6E757F`|
|Ochre|71.081|Model Air|119|105|58|![#77693A](https://placehold.co/15x15/77693A/77693A.png) `#77693A`|
|Ochre|85.109|Arte Deco|182|128|42|![#B6802A](https://placehold.co/15x15/B6802A/B6802A.png) `#B6802A`|
|Ochre Brown|70.856|Model Color|170|121|62|![#AA793E](https://placehold.co/15x15/AA793E/AA793E.png) `#AA793E`|
|Off-Grey|76.516|Wash FX|101|101|99|![#656563](https://placehold.co/15x15/656563/656563.png) `#656563`|
|Off-White|72.101|Game Color|254|243|221|![#FEF3DD](https://placehold.co/15x15/FEF3DD/FEF3DD.png) `#FEF3DD`|
|Off-White|69.003|Mecha Color|235|235|227|![#EBEBE3](https://placehold.co/15x15/EBEBE3/EBEBE3.png) `#EBEBE3`|
|Off-White|70.820|Model Color|245|236|231|![#F5ECE7](https://placehold.co/15x15/F5ECE7/F5ECE7.png) `#F5ECE7`|
|Off-White|71.270|Model Air|232|216|190|![#E8D8BE](https://placehold.co/15x15/E8D8BE/E8D8BE.png) `#E8D8BE`|
|Oil Stains|73.813|Weathering FX|110|80|46|![#6E502E](https://placehold.co/15x15/6E502E/6E502E.png) `#6E502E`|
|Oil Stains (Gloss)|69.813|Mecha Color|115|83|26|![#73531A](https://placehold.co/15x15/73531A/73531A.png) `#73531A`|
|Oiled Earth|76.521|Wash FX|102|92|83|![#665C53](https://placehold.co/15x15/665C53/665C53.png) `#665C53`|
|Oiled Earth Wash|69.521|Mecha Color|110|92|82|![#6E5C52](https://placehold.co/15x15/6E5C52/6E5C52.png) `#6E5C52`|
|Oily Steel|70.865|Model Color|72|66|70|![#484246](https://placehold.co/15x15/484246/484246.png) `#484246`|
|Old Gold|70.792|Liquid Gold|242|236|202|![#F2ECCA](https://placehold.co/15x15/F2ECCA/F2ECCA.png) `#F2ECCA`|
|Old Gold|69.060|Mecha Color|156|132|72|![#9C8448](https://placehold.co/15x15/9C8448/9C8448.png) `#9C8448`|
|Old Gold|70.878|Model Color|85|55|29|![#55371D](https://placehold.co/15x15/55371D/55371D.png) `#55371D`|
|Old Rose|70.944|Model Color|188|109|112|![#BC6D70](https://placehold.co/15x15/BC6D70/BC6D70.png) `#BC6D70`|
|Old Silver|81.124|Arte Deco|204|189|186|![#CCBDBA](https://placehold.co/15x15/CCBDBA/CCBDBA.png) `#CCBDBA`|
|Old Wood|70.310|Panzer Aces|173|156|112|![#AD9C70](https://placehold.co/15x15/AD9C70/AD9C70.png) `#AD9C70`|
|Olive Brown|70.889|Model Color|63|49|38|![#3F3126](https://placehold.co/15x15/3F3126/3F3126.png) `#3F3126`|
|Olive Green|76.519|Wash FX|69|88|69|![#455845](https://placehold.co/15x15/455845/455845.png) `#455845`|
|Olive Green|85.097|Arte Deco|16|75|37|![#104B25](https://placehold.co/15x15/104B25/104B25.png) `#104B25`|
|Olive Green|69.028|Mecha Color|95|110|69|![#5F6E45](https://placehold.co/15x15/5F6E45/5F6E45.png) `#5F6E45`|
|Olive Green|70.967|Model Color|82|97|56|![#526138](https://placehold.co/15x15/526138/526138.png) `#526138`|
|Olive Green|71.007|Model Air|52|58|56|![#343A38](https://placehold.co/15x15/343A38/343A38.png) `#343A38`|
|Olive Green RLM80|71.265|Model Air|76|79|58|![#4C4F3A](https://placehold.co/15x15/4C4F3A/4C4F3A.png) `#4C4F3A`|
|Olive Grey|70.888|Model Color|64|66|45|![#40422D](https://placehold.co/15x15/40422D/40422D.png) `#40422D`|
|Olive Grey|71.096|Model Air|108|99|94|![#6C635E](https://placehold.co/15x15/6C635E/6C635E.png) `#6C635E`|
|Omega Blue|72.413|Xpress Color|58|54|91|![#3A365B](https://placehold.co/15x15/3A365B/3A365B.png) `#3A365B`|
|Orange|69.007|Mecha Color|233|96|44|![#E9602C](https://placehold.co/15x15/E9602C/E9602C.png) `#E9602C`|
|Orange|62.004|Premium Airbrush Color|234|91|23|![#EA5B17](https://placehold.co/15x15/EA5B17/EA5B17.png) `#EA5B17`|
|Orange|71.083|Model Air|225|76|36|![#E14C24](https://placehold.co/15x15/E14C24/E14C24.png) `#E14C24`|
|Orange Brown|70.981|Model Color|173|98|58|![#AD623A](https://placehold.co/15x15/AD623A/AD623A.png) `#AD623A`|
|Orange Fire|72.708|Game Air|234|99|43|![#EA632B](https://placehold.co/15x15/EA632B/EA632B.png) `#EA632B`|
|Orange Fire|76.008|Game Air|235|91|30|![#EB5B1E](https://placehold.co/15x15/EB5B1E/EB5B1E.png) `#EB5B1E`|
|Orange Fire|72.008|Game Color|235|91|30|![#EB5B1E](https://placehold.co/15x15/EB5B1E/EB5B1E.png) `#EB5B1E`|
|Orange Fluorescent|69.055|Mecha Color|232|96|22|![#E86016](https://placehold.co/15x15/E86016/E86016.png) `#E86016`|
|Orange Fluorescent|70.733|Model Color|232|96|22|![#E86016](https://placehold.co/15x15/E86016/E86016.png) `#E86016`|
|Orange Ochre|70.824|Model Color|172|128|53|![#AC8035](https://placehold.co/15x15/AC8035/AC8035.png) `#AC8035`|
|Orange Pearl|85.133|Arte Deco Colores Fluoresecents|245|136|65|![#F58841](https://placehold.co/15x15/F58841/F58841.png) `#F58841`|
|Orange Pink|62.002|Premium Airbrush Color|251|203|157|![#FBCB9D](https://placehold.co/15x15/FBCB9D/FBCB9D.png) `#FBCB9D`|
|Orange Red|70.910|Model Color|220|67|25|![#DC4319](https://placehold.co/15x15/DC4319/DC4319.png) `#DC4319`|
|Orange Rust|71.130|Model Air|199|104|50|![#C76832](https://placehold.co/15x15/C76832/C76832.png) `#C76832`|
|Orc Skin|72.415|Xpress Color|94|117|45|![#5E752D](https://placehold.co/15x15/5E752D/5E752D.png) `#5E752D`|
|Orchid|85.052|Arte Deco|221|151|207|![#DD97CF](https://placehold.co/15x15/DD97CF/DD97CF.png) `#DD97CF`|
|Orchid Light|74.032|Nocturna Models|158|156|205|![#9E9CCD](https://placehold.co/15x15/9E9CCD/9E9CCD.png) `#9E9CCD`|
|Oxford Blue|70.807|Model Color|62|58|83|![#3E3A53](https://placehold.co/15x15/3E3A53/3E3A53.png) `#3E3A53`|
|Pale Blue|70.906|Model Color|144|163|169|![#90A3A9](https://placehold.co/15x15/90A3A9/90A3A9.png) `#90A3A9`|
|Pale Blue|71.008|Model Air|117|148|150|![#759496](https://placehold.co/15x15/759496/759496.png) `#759496`|
|Pale Blue Grey|71.046|Model Air|150|157|165|![#969DA5](https://placehold.co/15x15/969DA5/969DA5.png) `#969DA5`|
|Pale Brown|70.825|Model Color|159|131|117|![#9F8375](https://placehold.co/15x15/9F8375/9F8375.png) `#9F8375`|
|Pale Burnt Metal|77.704|Metal Color|169|169|169|![#A9A9A9](https://placehold.co/15x15/A9A9A9/A9A9A9.png) `#A9A9A9`|
|Pale Flesh|74.015|Nocturna Models|176|163|154|![#B0A39A](https://placehold.co/15x15/B0A39A/B0A39A.png) `#B0A39A`|
|Pale Flesh|76.003|Game Air|203|163|127|![#CBA37F](https://placehold.co/15x15/CBA37F/CBA37F.png) `#CBA37F`|
|Pale Flesh|28.024|Hobby Paint|236|189|169|![#ECBDA9](https://placehold.co/15x15/ECBDA9/ECBDA9.png) `#ECBDA9`|
|Pale Flesh|72.703|Game Air|250|218|207|![#FADACF](https://placehold.co/15x15/FADACF/FADACF.png) `#FADACF`|
|Pale Flesh|72.003|Game Color|203|163|127|![#CBA37F](https://placehold.co/15x15/CBA37F/CBA37F.png) `#CBA37F`|
|Pale Green|71.095|Model Air|117|132|91|![#75845B](https://placehold.co/15x15/75845B/75845B.png) `#75845B`|
|Pale Grey Blue|70.907|Model Color|167|182|179|![#A7B6B3](https://placehold.co/15x15/A7B6B3/A7B6B3.png) `#A7B6B3`|
|Pale Grey Wash|73.202|Game Color Wash|202|202|210|![#CACAD2](https://placehold.co/15x15/CACAD2/CACAD2.png) `#CACAD2`|
|Pale Lavender|85.053|Arte Deco|202|100|182|![#CA64B6](https://placehold.co/15x15/CA64B6/CA64B6.png) `#CA64B6`|
|Pale Sand|70.837|Model Color|227|194|143|![#E3C28F](https://placehold.co/15x15/E3C28F/E3C28F.png) `#E3C28F`|
|Pale Yellow|72.097|Game Color|235|206|126|![#EBCE7E](https://placehold.co/15x15/EBCE7E/EBCE7E.png) `#EBCE7E`|
|Panzer Dark Gray|71.056|Model Air|67|69|68|![#434544](https://placehold.co/15x15/434544/434544.png) `#434544`|
|Panzer Grey|28.002|Hobby Paint|75|76|80|![#4B4C50](https://placehold.co/15x15/4B4C50/4B4C50.png) `#4B4C50`|
|Panzer Yellow|28.001|Hobby Paint|148|133|78|![#94854E](https://placehold.co/15x15/94854E/94854E.png) `#94854E`|
|Parasite Brown|76.042|Game Air|163|92|30|![#A35C1E](https://placehold.co/15x15/A35C1E/A35C1E.png) `#A35C1E`|
|Parasite Brown|72.042|Game Color|163|92|30|![#A35C1E](https://placehold.co/15x15/A35C1E/A35C1E.png) `#A35C1E`|
|Parched Grass (Late)|70.610|Surface Primer|113|104|89|![#716859](https://placehold.co/15x15/716859/716859.png) `#716859`|
|Park Green Flat|70.969|Model Color|33|98|74|![#21624A](https://placehold.co/15x15/21624A/21624A.png) `#21624A`|
|Pastel Blue|70.901|Model Color|96|122|147|![#607A93](https://placehold.co/15x15/607A93/607A93.png) `#607A93`|
|Pastel Green|70.885|Model Color|147|152|112|![#939870](https://placehold.co/15x15/939870/939870.png) `#939870`|
|Peaches|85.019|Arte Deco|252|166|180|![#FCA6B4](https://placehold.co/15x15/FCA6B4/FCA6B4.png) `#FCA6B4`|
|Pearl Medium|84.158|Arte Deco|194|194|194|![#C2C2C2](https://placehold.co/15x15/C2C2C2/C2C2C2.png) `#C2C2C2`|
|Periscopes|70.309|Panzer Aces|59|77|91|![#3B4D5B](https://placehold.co/15x15/3B4D5B/3B4D5B.png) `#3B4D5B`|
|Permanent Rose|85.173|Arte Deco|148|13|59|![#940D3B](https://placehold.co/15x15/940D3B/940D3B.png) `#940D3B`|
|Petrol Spills|73.817|Weathering FX|33|31|34|![#211F22](https://placehold.co/15x15/211F22/211F22.png) `#211F22`|
|Petrol Spills (Gloss)|69.817|Mecha Color|20|28|31|![#141C1F](https://placehold.co/15x15/141C1F/141C1F.png) `#141C1F`|
|Phantom Grey|69.040|Mecha Color|83|87|98|![#535762](https://placehold.co/15x15/535762/535762.png) `#535762`|
|Phoenix Orange|72.478|Xpress Color Intense|177|64|30|![#B1401E](https://placehold.co/15x15/B1401E/B1401E.png) `#B1401E`|
|Phosphorescent|62.040|Premium Airbrush Color|233|234|226|![#E9EAE2](https://placehold.co/15x15/E9EAE2/E9EAE2.png) `#E9EAE2`|
|Pineapple|85.005|Arte Deco|222|239|144|![#DEEF90](https://placehold.co/15x15/DEEF90/DEEF90.png) `#DEEF90`|
|Pink|70.958|Model Color|176|79|124|![#B04F7C](https://placehold.co/15x15/B04F7C/B04F7C.png) `#B04F7C`|
|Pink|69.006|Mecha Color|208|132|116|![#D08474](https://placehold.co/15x15/D08474/D08474.png) `#D08474`|
|Plague Brown|72.039|Game Color|171|113|49|![#AB7131](https://placehold.co/15x15/AB7131/AB7131.png) `#AB7131`|
|Plague Green|72.419|Xpress Color|76|77|46|![#4C4D2E](https://placehold.co/15x15/4C4D2E/4C4D2E.png) `#4C4D2E`|
|Plantation Pine|85.085|Arte Deco|32|109|47|![#206D2F](https://placehold.co/15x15/206D2F/206D2F.png) `#206D2F`|
|Plasma Red|72.406|Xpress Color|165|40|34|![#A52822](https://placehold.co/15x15/A52822/A52822.png) `#A52822`|
|Plate Mail Metal|70.628|Surface Primer|152|153|158|![#98999E](https://placehold.co/15x15/98999E/98999E.png) `#98999E`|
|Polished Gold|72.055|Game Color|248|236|194|![#F8ECC2](https://placehold.co/15x15/F8ECC2/F8ECC2.png) `#F8ECC2`|
|Polished Gold|72.755|Game Air|235|174|0|![#EBAE00](https://placehold.co/15x15/EBAE00/EBAE00.png) `#EBAE00`|
|Prussian Blue|70.965|Model Color|60|64|93|![#3C405D](https://placehold.co/15x15/3C405D/3C405D.png) `#3C405D`|
|Pumpkin|85.027|Arte Deco|246|65|40|![#F64128](https://placehold.co/15x15/F64128/F64128.png) `#F64128`|
|Pure Black|69.042|Mecha Color|1|1|1|![#010101](https://placehold.co/15x15/010101/010101.png) `#010101`|
|Pure Red|70.624|Surface Primer|195|50|45|![#C3322D](https://placehold.co/15x15/C3322D/C3322D.png) `#C3322D`|
|Pure White|69.001|Mecha Color|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Purple|85.045|Arte Deco|72|35|89|![#482359](https://placehold.co/15x15/482359/482359.png) `#482359`|
|Purple|70.959|Model Color|83|49|82|![#533152](https://placehold.co/15x15/533152/533152.png) `#533152`|
|Purple|69.012|Mecha Color|173|141|188|![#AD8DBC](https://placehold.co/15x15/AD8DBC/AD8DBC.png) `#AD8DBC`|
|Purple Hex|74.026|Nocturna Models|106|41|127|![#6A297F](https://placehold.co/15x15/6A297F/6A297F.png) `#6A297F`|
|Purple Shadow|74.011|Nocturna Models|88|72|82|![#584852](https://placehold.co/15x15/584852/584852.png) `#584852`|
|Rain Marks|73.819|Weathering FX|109|99|90|![#6D635A](https://placehold.co/15x15/6D635A/6D635A.png) `#6D635A`|
|Raspberry|85.036|Arte Deco|148|56|86|![#943856](https://placehold.co/15x15/943856/943856.png) `#943856`|
|Raw Sienna|62.017|Premium Airbrush Color|130|75|68|![#824B44](https://placehold.co/15x15/824B44/824B44.png) `#824B44`|
|Raw Sienna|85.113|Arte Deco|172|119|87|![#AC7757](https://placehold.co/15x15/AC7757/AC7757.png) `#AC7757`|
|Red|71.269|Model Air|159|61|52|![#9F3D34](https://placehold.co/15x15/9F3D34/9F3D34.png) `#9F3D34`|
|Red|72.086|Game Color|205|19|22|![#CD1316](https://placehold.co/15x15/CD1316/CD1316.png) `#CD1316`|
|Red|71.102|Model Air|179|42|52|![#B32A34](https://placehold.co/15x15/B32A34/B32A34.png) `#B32A34`|
|Red|70.926|Model Color|121|40|37|![#792825](https://placehold.co/15x15/792825/792825.png) `#792825`|
|Red|69.008|Mecha Color|188|64|64|![#BC4040](https://placehold.co/15x15/BC4040/BC4040.png) `#BC4040`|
|Red Gold|70.794|Liquid Gold|243|226|200|![#F3E2C8](https://placehold.co/15x15/F3E2C8/F3E2C8.png) `#F3E2C8`|
|Red Iron Oxide|85.040|Arte Deco|116|41|22|![#742916](https://placehold.co/15x15/742916/742916.png) `#742916`|
|Red Leather|70.818|Model Color|149|84|62|![#95543E](https://placehold.co/15x15/95543E/95543E.png) `#95543E`|
|Red RLM23|71.003|Model Air|199|31|28|![#C71F1C](https://placehold.co/15x15/C71F1C/C71F1C.png) `#C71F1C`|
|Red Terracotta|72.772|Game Air|121|66|61|![#79423D](https://placehold.co/15x15/79423D/79423D.png) `#79423D`|
|Red Wash|73.206|Game Color Wash|213|94|134|![#D55E86](https://placehold.co/15x15/D55E86/D55E86.png) `#D55E86`|
|Reddish Flesh|74.003|Nocturna Models|158|101|105|![#9E6569](https://placehold.co/15x15/9E6569/9E6569.png) `#9E6569`|
|Reducer|62.066|Premium Airbrush Color|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Refractive Green|70.890|Model Color|71|74|53|![#474A35](https://placehold.co/15x15/474A35/474A35.png) `#474A35`|
|Retarder|62.065|Premium Airbrush Color|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Rich Gold|70.793|Liquid Gold|233|222|194|![#E9DEC2](https://placehold.co/15x15/E9DEC2/E9DEC2.png) `#E9DEC2`|
|Rookwood Red|85.044|Arte Deco|102|51|48|![#663330](https://placehold.co/15x15/663330/663330.png) `#663330`|
|Rose Red|85.035|Arte Deco|232|43|109|![#E82B6D](https://placehold.co/15x15/E82B6D/E82B6D.png) `#E82B6D`|
|Rosy Flesh|72.100|Game Color|229|138|107|![#E58A6B](https://placehold.co/15x15/E58A6B/E58A6B.png) `#E58A6B`|
|Rosy Flesh|76.100|Game Air|229|138|107|![#E58A6B](https://placehold.co/15x15/E58A6B/E58A6B.png) `#E58A6B`|
|Rotten Flesh|72.452|Xpress Color|137|118|59|![#89763B](https://placehold.co/15x15/89763B/89763B.png) `#89763B`|
|Rotten White|72.130|Game Color|240|238|239|![#F0EEEF](https://placehold.co/15x15/F0EEEF/F0EEEF.png) `#F0EEEF`|
|Royal Blue|70.809|Model Color|26|66|125|![#1A427D](https://placehold.co/15x15/1A427D/1A427D.png) `#1A427D`|
|Royal Purple|70.810|Model Color|77|39|64|![#4D2740](https://placehold.co/15x15/4D2740/4D2740.png) `#4D2740`|
|Royal Purple|76.016|Game Air|48|35|55|![#302337](https://placehold.co/15x15/302337/302337.png) `#302337`|
|Royal Purple|72.016|Game Color|48|35|55|![#302337](https://placehold.co/15x15/302337/302337.png) `#302337`|
|Russian AF Blue|71.333|Model Air|0|142|180|![#008EB4](https://placehold.co/15x15/008EB4/008EB4.png) `#008EB4`|
|Russian AF Dark Green|71.347|Model Air|75|72|53|![#4B4835](https://placehold.co/15x15/4B4835/4B4835.png) `#4B4835`|
|Russian AF Grey Blue|71.338|Model Air|163|172|171|![#A3ACAB](https://placehold.co/15x15/A3ACAB/A3ACAB.png) `#A3ACAB`|
|Russian AF Grey N.3|71.339|Model Air|133|142|141|![#858E8D](https://placehold.co/15x15/858E8D/858E8D.png) `#858E8D`|
|Russian AF Grey N.4|71.346|Model Air|170|167|148|![#AAA794](https://placehold.co/15x15/AAA794/AAA794.png) `#AAA794`|
|Russian AF Grey N.7|71.343|Model Air|115|156|176|![#739CB0](https://placehold.co/15x15/739CB0/739CB0.png) `#739CB0`|
|Russian AF Grey N.8|71.345|Model Air|161|181|190|![#A1B5BE](https://placehold.co/15x15/A1B5BE/A1B5BE.png) `#A1B5BE`|
|Russian AF Grey Protective Coat|71.344|Model Air|179|203|215|![#B3CBD7](https://placehold.co/15x15/B3CBD7/B3CBD7.png) `#B3CBD7`|
|Russian AF Light Blue|71.342|Model Air|170|201|196|![#AAC9C4](https://placehold.co/15x15/AAC9C4/AAC9C4.png) `#AAC9C4`|
|Russian Green 4BO|70.609|Surface Primer|75|76|68|![#4B4C44](https://placehold.co/15x15/4B4C44/4B4C44.png) `#4B4C44`|
|Russian Green 4BO|71.017|Model Air|82|84|63|![#52543F](https://placehold.co/15x15/52543F/52543F.png) `#52543F`|
|Russian Green 4BO|28.003|Hobby Paint|87|85|70|![#575546](https://placehold.co/15x15/575546/575546.png) `#575546`|
|Russian Splash Mud|73.802|Weathering FX|61|51|52|![#3D3334](https://placehold.co/15x15/3D3334/3D3334.png) `#3D3334`|
|Russian Tank Crew Highlights I|70.329|Panzer Aces|155|171|170|![#9BABAA](https://placehold.co/15x15/9BABAA/9BABAA.png) `#9BABAA`|
|Russian Tank Crew Highlights II|70.330|Panzer Aces|113|117|56|![#717538](https://placehold.co/15x15/717538/717538.png) `#717538`|
|Russian Tank Crew I|70.325|Panzer Aces|76|93|103|![#4C5D67](https://placehold.co/15x15/4C5D67/4C5D67.png) `#4C5D67`|
|Russian Tank Crew II|70.326|Panzer Aces|106|98|79|![#6A624F](https://placehold.co/15x15/6A624F/6A624F.png) `#6A624F`|
|Russian Thick Mud|73.808|Weathering FX|52|52|52|![#343434](https://placehold.co/15x15/343434/343434.png) `#343434`|
|Russian Uniform|28.007|Hobby Paint|107|100|82|![#6B6452](https://placehold.co/15x15/6B6452/6B6452.png) `#6B6452`|
|Russian Uniform WWII|70.924|Model Color|88|83|54|![#585336](https://placehold.co/15x15/585336/585336.png) `#585336`|
|Rust|72.131|Game Color|228|83|20|![#E45314](https://placehold.co/15x15/E45314/E45314.png) `#E45314`|
|Rust|72.609|Game Color Special FX|100|80|75|![#64504B](https://placehold.co/15x15/64504B/64504B.png) `#64504B`|
|Rust|71.080|Model Air|117|84|75|![#75544B](https://placehold.co/15x15/75544B/75544B.png) `#75544B`|
|Rust|76.506|Wash FX|208|125|91|![#D07D5B](https://placehold.co/15x15/D07D5B/D07D5B.png) `#D07D5B`|
|Rust (Metallic)|71.069|Model Air|117|84|69|![#755445](https://placehold.co/15x15/755445/755445.png) `#755445`|
|Rust Texture|73.821|Weathering FX|70|60|58|![#463C3A](https://placehold.co/15x15/463C3A/463C3A.png) `#463C3A`|
|Rust Texture (Matt)|69.821|Mecha Color|105|50|43|![#69322B](https://placehold.co/15x15/69322B/69322B.png) `#69322B`|
|Sable Brown|85.114|Arte Deco|145|94|72|![#915E48](https://placehold.co/15x15/915E48/915E48.png) `#915E48`|
|Saddle Brown|70.940|Model Color|140|100|92|![#8C645C](https://placehold.co/15x15/8C645C/8C645C.png) `#8C645C`|
|Salem Blue|85.062|Arte Deco|90|126|159|![#5A7E9F](https://placehold.co/15x15/5A7E9F/5A7E9F.png) `#5A7E9F`|
|Salmon Rose|70.835|Model Color|226|143|127|![#E28F7F](https://placehold.co/15x15/E28F7F/E28F7F.png) `#E28F7F`|
|Sanctuary Red|74.020|Nocturna Models|152|25|55|![#981937](https://placehold.co/15x15/981937/981937.png) `#981937`|
|Sand|71.112|Model Air|158|136|122|![#9E887A](https://placehold.co/15x15/9E887A/9E887A.png) `#9E887A`|
|Sand|70.644|Mecha Color|218|196|149|![#DAC495](https://placehold.co/15x15/DAC495/DAC495.png) `#DAC495`|
|Sand Beige|71.244|Model Air|181|164|138|![#B5A48A](https://placehold.co/15x15/B5A48A/B5A48A.png) `#B5A48A`|
|Sand Brown|71.034|Model Air|148|107|79|![#946B4F](https://placehold.co/15x15/946B4F/946B4F.png) `#946B4F`|
|Sand Yellow|71.028|Model Air|164|141|110|![#A48D6E](https://placehold.co/15x15/A48D6E/A48D6E.png) `#A48D6E`|
|Sand Yellow|69.033|Mecha Color|228|184|111|![#E4B86F](https://placehold.co/15x15/E4B86F/E4B86F.png) `#E4B86F`|
|Sand Yellow|70.916|Model Color|234|191|86|![#EABF56](https://placehold.co/15x15/EABF56/EABF56.png) `#EABF56`|
|Sand Yellow RLM79|71.278|Model Air|151|116|78|![#97744E](https://placehold.co/15x15/97744E/97744E.png) `#97744E`|
|Sapphire Blue|85.059|Arte Deco|36|73|151|![#244997](https://placehold.co/15x15/244997/244997.png) `#244997`|
|Satin Varnish|62.063|Premium Airbrush Color|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Satin Varnish|84.169|Arte Deco|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Scarlet|70.817|Model Color|194|61|46|![#C23D2E](https://placehold.co/15x15/C23D2E/C23D2E.png) `#C23D2E`|
|Scarlet Blood|72.106|Game Color|194|34|34|![#C22222](https://placehold.co/15x15/C22222/C22222.png) `#C22222`|
|Scarlet Red|72.012|Game Color|118|30|29|![#761E1D](https://placehold.co/15x15/761E1D/761E1D.png) `#761E1D`|
|Scarlet Red|76.012|Game Air|118|30|29|![#761E1D](https://placehold.co/15x15/761E1D/761E1D.png) `#761E1D`|
|Scarlet Red|72.712|Game Air|156|18|44|![#9C122C](https://placehold.co/15x15/9C122C/9C122C.png) `#9C122C`|
|Scarlet Red|28.016|Hobby Paint|170|57|53|![#AA3935](https://placehold.co/15x15/AA3935/AA3935.png) `#AA3935`|
|Scorpy Green|72.032|Game Color|79|132|54|![#4F8436](https://placehold.co/15x15/4F8436/4F8436.png) `#4F8436`|
|Scorpy Green|72.732|Game Air|128|175|73|![#80AF49](https://placehold.co/15x15/80AF49/80AF49.png) `#80AF49`|
|Scorpy Green|76.032|Game Air|79|132|54|![#4F8436](https://placehold.co/15x15/4F8436/4F8436.png) `#4F8436`|
|Scrofulous Brown|72.038|Game Color|167|105|28|![#A7691C](https://placehold.co/15x15/A7691C/A7691C.png) `#A7691C`|
|Scurvy Green|76.027|Game Air|31|77|67|![#1F4D43](https://placehold.co/15x15/1F4D43/1F4D43.png) `#1F4D43`|
|Scurvy Green|72.027|Game Color|31|77|67|![#1F4D43](https://placehold.co/15x15/1F4D43/1F4D43.png) `#1F4D43`|
|Sea Aqua|85.076|Arte Deco|133|202|199|![#85CAC7](https://placehold.co/15x15/85CAC7/85CAC7.png) `#85CAC7`|
|Sea Grey|71.049|Model Air|99|104|108|![#63686C](https://placehold.co/15x15/63686C/63686C.png) `#63686C`|
|Seaplane Gray|71.314|Model Air|85|87|86|![#555756](https://placehold.co/15x15/555756/555756.png) `#555756`|
|Semi Matt Aluminium|77.716|Metal Color|192|193|195|![#C0C1C3](https://placehold.co/15x15/C0C1C3/C0C1C3.png) `#C0C1C3`|
|Sepia|62.018|Premium Airbrush Color|80|52|40|![#503428](https://placehold.co/15x15/503428/503428.png) `#503428`|
|Sepia|72.091|Game Color|86|61|39|![#563D27](https://placehold.co/15x15/563D27/563D27.png) `#563D27`|
|Sepia Wash|73.200|Game Color Wash|139|98|44|![#8B622C](https://placehold.co/15x15/8B622C/8B622C.png) `#8B622C`|
|Sepia Wash|73.300|Game Color Wash|116|67|0|![#744300](https://placehold.co/15x15/744300/744300.png) `#744300`|
|Seraph Red|72.479|Xpress Color Intense|107|20|17|![#6B1411](https://placehold.co/15x15/6B1411/6B1411.png) `#6B1411`|
|Sick Green|72.029|Game Color|64|96|55|![#406037](https://placehold.co/15x15/406037/406037.png) `#406037`|
|Sick Green|72.729|Game Air|36|107|73|![#246B49](https://placehold.co/15x15/246B49/246B49.png) `#246B49`|
|Sick Green|28.028|Hobby Paint|78|112|85|![#4E7055](https://placehold.co/15x15/4E7055/4E7055.png) `#4E7055`|
|Signal Blue|71.091|Model Air|56|54|65|![#383641](https://placehold.co/15x15/383641/383641.png) `#383641`|
|Signal Red (Metallic)|71.070|Model Air|203|89|112|![#CB5970](https://placehold.co/15x15/CB5970/CB5970.png) `#CB5970`|
|Silver|81.121|Arte Deco|200|202|201|![#C8CAC9](https://placehold.co/15x15/C8CAC9/C8CAC9.png) `#C8CAC9`|
|Silver|72.052|Game Color|235|237|236|![#EBEDEC](https://placehold.co/15x15/EBEDEC/EBEDEC.png) `#EBEDEC`|
|Silver|77.724|Metal Color|160|160|160|![#A0A0A0](https://placehold.co/15x15/A0A0A0/A0A0A0.png) `#A0A0A0`|
|Silver|70.997|Model Color|147|146|144|![#939290](https://placehold.co/15x15/939290/939290.png) `#939290`|
|Silver|28.021|Hobby Paint|166|170|179|![#A6AAB3](https://placehold.co/15x15/A6AAB3/A6AAB3.png) `#A6AAB3`|
|Silver|70.790|Liquid Gold|245|246|248|![#F5F6F8](https://placehold.co/15x15/F5F6F8/F5F6F8.png) `#F5F6F8`|
|Silver|72.752|Game Air|167|172|176|![#A7ACB0](https://placehold.co/15x15/A7ACB0/A7ACB0.png) `#A7ACB0`|
|Silver|62.048|Premium Airbrush Color|236|236|238|![#ECECEE](https://placehold.co/15x15/ECECEE/ECECEE.png) `#ECECEE`|
|Silver Grey|70.883|Model Color|216|205|201|![#D8CDC9](https://placehold.co/15x15/D8CDC9/D8CDC9.png) `#D8CDC9`|
|Silver RLM01 (Metallic)|71.063|Model Air|173|173|185|![#ADADB9](https://placehold.co/15x15/ADADB9/ADADB9.png) `#ADADB9`|
|Skeleton Bone|70.627|Surface Primer|186|167|137|![#BAA789](https://placehold.co/15x15/BAA789/BAA789.png) `#BAA789`|
|Skin|72.093|Game Color|92|45|39|![#5C2D27](https://placehold.co/15x15/5C2D27/5C2D27.png) `#5C2D27`|
|Skin Tone|71.076|Model Air|248|196|146|![#F8C492](https://placehold.co/15x15/F8C492/F8C492.png) `#F8C492`|
|Skin Tone|72.099|Game Color|229|171|133|![#E5AB85](https://placehold.co/15x15/E5AB85/E5AB85.png) `#E5AB85`|
|Sky Blue|71.306|Model Air|194|213|217|![#C2D5D9](https://placehold.co/15x15/C2D5D9/C2D5D9.png) `#C2D5D9`|
|Sky Blue|69.017|Mecha Color|122|202|235|![#7ACAEB](https://placehold.co/15x15/7ACAEB/7ACAEB.png) `#7ACAEB`|
|Sky Blue|70.961|Model Color|116|184|207|![#74B8CF](https://placehold.co/15x15/74B8CF/74B8CF.png) `#74B8CF`|
|Sky Grey|70.989|Model Color|170|171|173|![#AAABAD](https://placehold.co/15x15/AAABAD/AAABAD.png) `#AAABAD`|
|Sky Type S|71.302|Model Air|162|164|140|![#A2A48C](https://placehold.co/15x15/A2A48C/A2A48C.png) `#A2A48C`|
|Slate Grey|85.104|Arte Deco|180|179|174|![#B4B3AE](https://placehold.co/15x15/B4B3AE/B4B3AE.png) `#B4B3AE`|
|Slimy Grime Dark|73.822|Weathering FX|72|75|58|![#484B3A](https://placehold.co/15x15/484B3A/484B3A.png) `#484B3A`|
|Smoke Ink|70.939|Model Color|92|72|71|![#5C4847](https://placehold.co/15x15/5C4847/5C4847.png) `#5C4847`|
|Smokey Ink|72.068|Game Color|73|54|50|![#493632](https://placehold.co/15x15/493632/493632.png) `#493632`|
|Snake Green|72.417|Xpress Color|1|90|70|![#015A46](https://placehold.co/15x15/015A46/015A46.png) `#015A46`|
|Snow|73.820|Weathering FX|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Sombre Grey|72.748|Game Air|87|104|120|![#576878](https://placehold.co/15x15/576878/576878.png) `#576878`|
|Sombre Grey|72.048|Game Color|83|93|105|![#535D69](https://placehold.co/15x15/535D69/535D69.png) `#535D69`|
|Sombre Grey|76.048|Game Air|83|93|105|![#535D69](https://placehold.co/15x15/535D69/535D69.png) `#535D69`|
|Space Grey|72.422|Xpress Color|45|90|93|![#2D5A5D](https://placehold.co/15x15/2D5A5D/2D5A5D.png) `#2D5A5D`|
|Spice Pink|85.022|Arte Deco|244|165|171|![#F4A5AB](https://placehold.co/15x15/F4A5AB/F4A5AB.png) `#F4A5AB`|
|Splinter Blotches I|70.346|Panzer Aces|1|99|60|![#01633C](https://placehold.co/15x15/01633C/01633C.png) `#01633C`|
|Splinter Blotches II|70.347|Panzer Aces|60|43|36|![#3C2B24](https://placehold.co/15x15/3C2B24/3C2B24.png) `#3C2B24`|
|Splinter Camouflage Base|70.345|Panzer Aces|157|158|152|![#9D9E98](https://placehold.co/15x15/9D9E98/9D9E98.png) `#9D9E98`|
|Splinter Green|70.756|Model Color|69|99|65|![#456341](https://placehold.co/15x15/456341/456341.png) `#456341`|
|Splinter Strips|70.348|Panzer Aces|79|104|75|![#4F684B](https://placehold.co/15x15/4F684B/4F684B.png) `#4F684B`|
|Spring Green|85.086|Arte Deco|222|242|202|![#DEF2CA](https://placehold.co/15x15/DEF2CA/DEF2CA.png) `#DEF2CA`|
|Spring Yellow|85.081|Arte Deco|188|215|49|![#BCD731](https://placehold.co/15x15/BCD731/BCD731.png) `#BCD731`|
|Squid Pink|72.013|Game Color|199|120|165|![#C778A5](https://placehold.co/15x15/C778A5/C778A5.png) `#C778A5`|
|Squid Pink|76.013|Game Air|199|120|165|![#C778A5](https://placehold.co/15x15/C778A5/C778A5.png) `#C778A5`|
|Squid Pink|72.713|Game Air|218|136|184|![#DA88B8](https://placehold.co/15x15/DA88B8/DA88B8.png) `#DA88B8`|
|Starship Steel|72.462|Xpress Color|81|115|117|![#517375](https://placehold.co/15x15/517375/517375.png) `#517375`|
|Steel|69.063|Mecha Color|137|138|130|![#898A82](https://placehold.co/15x15/898A82/898A82.png) `#898A82`|
|Steel|62.051|Premium Airbrush Color|223|223|223|![#DFDFDF](https://placehold.co/15x15/DFDFDF/DFDFDF.png) `#DFDFDF`|
|Steel|77.712|Metal Color|117|117|115|![#757573](https://placehold.co/15x15/757573/757573.png) `#757573`|
|Steel (Metallic)|71.065|Model Air|187|187|199|![#BBBBC7](https://placehold.co/15x15/BBBBC7/BBBBC7.png) `#BBBBC7`|
|Steel Blue|71.087|Model Air|25|87|112|![#195770](https://placehold.co/15x15/195770/195770.png) `#195770`|
|Steel Grey|70.630|Surface Primer|116|133|140|![#74858C](https://placehold.co/15x15/74858C/74858C.png) `#74858C`|
|Steel Grey|72.102|Game Color|123|146|162|![#7B92A2](https://placehold.co/15x15/7B92A2/7B92A2.png) `#7B92A2`|
|Stencil|70.313|Panzer Aces|224|224|216|![#E0E0D8](https://placehold.co/15x15/E0E0D8/E0E0D8.png) `#E0E0D8`|
|Stone Grey|70.884|Model Color|140|124|99|![#8C7C63](https://placehold.co/15x15/8C7C63/8C7C63.png) `#8C7C63`|
|Stone Grey|69.024|Mecha Color|161|177|177|![#A1B1B1](https://placehold.co/15x15/A1B1B1/A1B1B1.png) `#A1B1B1`|
|Stone Wall Grey|72.749|Game Air|161|162|164|![#A1A2A4](https://placehold.co/15x15/A1A2A4/A1A2A4.png) `#A1A2A4`|
|Stonewall Grey|72.049|Game Color|156|147|132|![#9C9384](https://placehold.co/15x15/9C9384/9C9384.png) `#9C9384`|
|Stonewall Grey|76.049|Game Air|156|147|132|![#9C9384](https://placehold.co/15x15/9C9384/9C9384.png) `#9C9384`|
|Storm Blue|72.412|Xpress Color|48|58|127|![#303A7F](https://placehold.co/15x15/303A7F/303A7F.png) `#303A7F`|
|Stormy Blue|72.018|Game Color|65|63|87|![#413F57](https://placehold.co/15x15/413F57/413F57.png) `#413F57`|
|Succubus Skin|72.108|Game Color|147|61|70|![#933D46](https://placehold.co/15x15/933D46/933D46.png) `#933D46`|
|Sun Yellow|72.706|Game Air|246|180|34|![#F6B422](https://placehold.co/15x15/F6B422/F6B422.png) `#F6B422`|
|Sun Yellow|28.018|Hobby Paint|245|156|0|![#F59C00](https://placehold.co/15x15/F59C00/F59C00.png) `#F59C00`|
|Sun Yellow|72.006|Game Color|246|163|0|![#F6A300](https://placehold.co/15x15/F6A300/F6A300.png) `#F6A300`|
|Sun Yellow|76.006|Game Air|246|163|0|![#F6A300](https://placehold.co/15x15/F6A300/F6A300.png) `#F6A300`|
|Sunny Skin Tone|70.845|Model Color|237|150|70|![#ED9646](https://placehold.co/15x15/ED9646/ED9646.png) `#ED9646`|
|Sunrise Blue|72.118|Game Color|115|201|236|![#73C9EC](https://placehold.co/15x15/73C9EC/73C9EC.png) `#73C9EC`|
|Sunrise Blue|76.118|Game Air|115|201|236|![#73C9EC](https://placehold.co/15x15/73C9EC/73C9EC.png) `#73C9EC`|
|Sunset Orange|72.110|Game Color|244|151|58|![#F4973A](https://placehold.co/15x15/F4973A/F4973A.png) `#F4973A`|
|Sunset Red|70.802|Model Color|192|43|73|![#C02B49](https://placehold.co/15x15/C02B49/C02B49.png) `#C02B49`|
|Sz Red|69.009|Mecha Color|179|55|55|![#B33737](https://placehold.co/15x15/B33737/B33737.png) `#B33737`|
|Taffy Cream|85.004|Arte Deco|238|242|205|![#EEF2CD](https://placehold.co/15x15/EEF2CD/EEF2CD.png) `#EEF2CD`|
|Tan|72.066|Game Color|149|96|78|![#95604E](https://placehold.co/15x15/95604E/95604E.png) `#95604E`|
|Tan Earth|70.874|Model Color|153|116|87|![#997457](https://placehold.co/15x15/997457/997457.png) `#997457`|
|Tan Earth|71.079|Model Air|166|129|103|![#A68167](https://placehold.co/15x15/A68167/A68167.png) `#A68167`|
|Tan Glaze|70.831|Model Color|213|147|53|![#D59335](https://placehold.co/15x15/D59335/D59335.png) `#D59335`|
|Tan Yellow|70.912|Model Color|193|155|110|![#C19B6E](https://placehold.co/15x15/C19B6E/C19B6E.png) `#C19B6E`|
|Tangerine|85.026|Arte Deco|251|113|41|![#FB7129](https://placehold.co/15x15/FB7129/FB7129.png) `#FB7129`|
|Tanned Skin|72.471|Xpress Color|129|69|45|![#81452D](https://placehold.co/15x15/81452D/81452D.png) `#81452D`|
|Taupe|85.105|Arte Deco|211|123|130|![#D37B82](https://placehold.co/15x15/D37B82/D37B82.png) `#D37B82`|
|Teal Green|85.099|Arte Deco|69|126|109|![#457E6D](https://placehold.co/15x15/457E6D/457E6D.png) `#457E6D`|
|Templar White|72.401|Xpress Color|204|206|205|![#CCCECD](https://placehold.co/15x15/CCCECD/CCCECD.png) `#CCCECD`|
|Terracotta|72.065|Game Color|105|62|56|![#693E38](https://placehold.co/15x15/693E38/693E38.png) `#693E38`|
|Textile Medium|84.159|Arte Deco|236|236|236|![#ECECEC](https://placehold.co/15x15/ECECEC/ECECEC.png) `#ECECEC`|
|Thick Blood|72.602|Game Color Special FX|149|78|67|![#954E43](https://placehold.co/15x15/954E43/954E43.png) `#954E43`|
|Tinny Tin|72.060|Game Color|213|199|198|![#D5C7C6](https://placehold.co/15x15/D5C7C6/D5C7C6.png) `#D5C7C6`|
|Tire Black|71.315|Model Air|80|81|83|![#505153](https://placehold.co/15x15/505153/505153.png) `#505153`|
|Titan Blue|69.013|Mecha Color|77|77|111|![#4D4D6F](https://placehold.co/15x15/4D4D6F/4D4D6F.png) `#4D4D6F`|
|Titan Dark Blue|69.022|Mecha Color|65|69|78|![#41454E](https://placehold.co/15x15/41454E/41454E.png) `#41454E`|
|Toffee|85.111|Arte Deco|250|209|177|![#FAD1B1](https://placehold.co/15x15/FAD1B1/FAD1B1.png) `#FAD1B1`|
|Toxic Yellow|76.109|Game Air|232|212|87|![#E8D457](https://placehold.co/15x15/E8D457/E8D457.png) `#E8D457`|
|Toxic Yellow|72.109|Game Color|232|212|87|![#E8D457](https://placehold.co/15x15/E8D457/E8D457.png) `#E8D457`|
|Track Primer|70.304|Panzer Aces|91|86|82|![#5B5652](https://placehold.co/15x15/5B5652/5B5652.png) `#5B5652`|
|Transparent Blue|70.938|Model Color|50|61|93|![#323D5D](https://placehold.co/15x15/323D5D/323D5D.png) `#323D5D`|
|Transparent Green|70.936|Model Color|0|121|67|![#007943](https://placehold.co/15x15/007943/007943.png) `#007943`|
|Transparent Orange|70.935|Model Color|234|101|26|![#EA651A](https://placehold.co/15x15/EA651A/EA651A.png) `#EA651A`|
|Transparent Red|70.934|Model Color|182|35|54|![#B62336](https://placehold.co/15x15/B62336/B62336.png) `#B62336`|
|Transparent Yellow|70.937|Model Color|247|165|1|![#F7A501](https://placehold.co/15x15/F7A501/F7A501.png) `#F7A501`|
|Troll Green|72.416|Xpress Color|1|94|50|![#015E32](https://placehold.co/15x15/015E32/015E32.png) `#015E32`|
|True Blue|85.058|Arte Deco|1|76|141|![#014C8D](https://placehold.co/15x15/014C8D/014C8D.png) `#014C8D`|
|True Violet|85.050|Arte Deco|65|43|108|![#412B6C](https://placehold.co/15x15/412B6C/412B6C.png) `#412B6C`|
|Tulip Yellow|85.010|Arte Deco|253|218|154|![#FDDA9A](https://placehold.co/15x15/FDDA9A/FDDA9A.png) `#FDDA9A`|
|Turquoise|70.966|Model Color|12|66|90|![#0C425A](https://placehold.co/15x15/0C425A/0C425A.png) `#0C425A`|
|Turquoise|85.079|Arte Deco|0|98|121|![#006279](https://placehold.co/15x15/006279/006279.png) `#006279`|
|Turquoise|69.023|Mecha Color|0|155|159|![#009B9F](https://placehold.co/15x15/009B9F/009B9F.png) `#009B9F`|
|Turquoise|72.024|Game Color|1|97|96|![#016160](https://placehold.co/15x15/016160/016160.png) `#016160`|
|Turquoise|76.024|Game Air|1|97|96|![#016160](https://placehold.co/15x15/016160/016160.png) `#016160`|
|Twilight Rose|72.460|Xpress Color|119|71|85|![#774755](https://placehold.co/15x15/774755/774755.png) `#774755`|
|UK Azure Blue|71.108|Model Air|114|140|173|![#728CAD](https://placehold.co/15x15/728CAD/728CAD.png) `#728CAD`|
|UK Bronze Green|28.004|Hobby Paint|83|85|84|![#535554](https://placehold.co/15x15/535554/535554.png) `#535554`|
|UK Bronze Green|70.607|Surface Primer|60|62|61|![#3C3E3D](https://placehold.co/15x15/3C3E3D/3C3E3D.png) `#3C3E3D`|
|UK Light Mud|71.284|Model Air|135|128|110|![#87806E](https://placehold.co/15x15/87806E/87806E.png) `#87806E`|
|UK Light Stone|71.143|Model Air|178|155|105|![#B29B69](https://placehold.co/15x15/B29B69/B29B69.png) `#B29B69`|
|US Army Tank Crew|70.318|Panzer Aces|121|104|78|![#79684E](https://placehold.co/15x15/79684E/79684E.png) `#79684E`|
|US Army Tank Crew Highlights|70.322|Panzer Aces|169|154|133|![#A99A85](https://placehold.co/15x15/A99A85/A99A85.png) `#A99A85`|
|US Dark Green|70.893|Model Color|73|75|54|![#494B36](https://placehold.co/15x15/494B36/494B36.png) `#494B36`|
|US Dark Green|71.289|Model Air|87|89|68|![#575944](https://placehold.co/15x15/575944/575944.png) `#575944`|
|US Desert Armour 686|71.122|Model Air|174|155|125|![#AE9B7D](https://placehold.co/15x15/AE9B7D/AE9B7D.png) `#AE9B7D`|
|US Desert Sand|71.140|Model Air|169|142|121|![#A98E79](https://placehold.co/15x15/A98E79/A98E79.png) `#A98E79`|
|US Earth Brown|71.290|Model Air|101|89|77|![#65594D](https://placehold.co/15x15/65594D/65594D.png) `#65594D`|
|US Earth Red|71.293|Model Air|123|96|79|![#7B604F](https://placehold.co/15x15/7B604F/7B604F.png) `#7B604F`|
|US Earth Yellow|71.291|Model Air|186|145|93|![#BA915D](https://placehold.co/15x15/BA915D/BA915D.png) `#BA915D`|
|US Field Drab|71.139|Model Air|105|89|64|![#695940](https://placehold.co/15x15/695940/695940.png) `#695940`|
|US Field Drab|70.873|Model Color|130|101|69|![#826545](https://placehold.co/15x15/826545/826545.png) `#826545`|
|US Flat Brown|71.026|Model Air|142|106|74|![#8E6A4A](https://placehold.co/15x15/8E6A4A/8E6A4A.png) `#8E6A4A`|
|US Forest Green|71.294|Model Air|84|84|76|![#54544C](https://placehold.co/15x15/54544C/54544C.png) `#54544C`|
|US Interior Yellow|71.107|Model Air|203|165|82|![#CBA552](https://placehold.co/15x15/CBA552/CBA552.png) `#CBA552`|
|US Khaki|28.009|Hobby Paint|134|120|94|![#86785E](https://placehold.co/15x15/86785E/86785E.png) `#86785E`|
|US Light Green|71.137|Model Air|103|99|62|![#67633E](https://placehold.co/15x15/67633E/67633E.png) `#67633E`|
|US Loam|71.292|Model Air|86|87|81|![#565751](https://placehold.co/15x15/565751/565751.png) `#565751`|
|US Olive Drab|71.043|Model Air|89|79|67|![#594F43](https://placehold.co/15x15/594F43/594F43.png) `#594F43`|
|US Olive Drab|28.005|Hobby Paint|99|92|76|![#635C4C](https://placehold.co/15x15/635C4C/635C4C.png) `#635C4C`|
|US Olive Drab|70.887|Model Color|89|81|60|![#59513C](https://placehold.co/15x15/59513C/59513C.png) `#59513C`|
|US Sand|71.138|Model Air|150|134|109|![#96866D](https://placehold.co/15x15/96866D/96866D.png) `#96866D`|
|USA Olive Drab|70.608|Surface Primer|100|93|83|![#645D53](https://placehold.co/15x15/645D53/645D53.png) `#645D53`|
|USAAF Light Gray|71.296|Model Air|188|188|180|![#BCBCB4](https://placehold.co/15x15/BCBCB4/BCBCB4.png) `#BCBCB4`|
|USAF Brown|71.125|Model Air|138|113|91|![#8A715B](https://placehold.co/15x15/8A715B/8A715B.png) `#8A715B`|
|USAF Green|71.124|Model Air|76|91|88|![#4C5B58](https://placehold.co/15x15/4C5B58/4C5B58.png) `#4C5B58`|
|USAF Light Blue|71.111|Model Air|82|103|120|![#526778](https://placehold.co/15x15/526778/526778.png) `#526778`|
|USAF Light Gray|71.276|Model Air|195|197|194|![#C3C5C2](https://placehold.co/15x15/C3C5C2/C3C5C2.png) `#C3C5C2`|
|USAF Medium Gray|71.275|Model Air|130|131|133|![#828385](https://placehold.co/15x15/828385/828385.png) `#828385`|
|USAF Olive Drab|71.016|Model Air|99|91|70|![#635B46](https://placehold.co/15x15/635B46/635B46.png) `#635B46`|
|USAF Tan|71.348|Model Air|190|152|105|![#BE9869](https://placehold.co/15x15/BE9869/BE9869.png) `#BE9869`|
|USMC Tank Crew|70.319|Panzer Aces|29|87|62|![#1D573E](https://placehold.co/15x15/1D573E/1D573E.png) `#1D573E`|
|USMC Tank Crew Highlights|70.323|Panzer Aces|164|178|165|![#A4B2A5](https://placehold.co/15x15/A4B2A5/A4B2A5.png) `#A4B2A5`|
|USN Light Ghost Grey|70.615|Surface Primer|146|153|159|![#92999F](https://placehold.co/15x15/92999F/92999F.png) `#92999F`|
|USN Sea Blue|71.295|Model Air|67|72|76|![#43484C](https://placehold.co/15x15/43484C/43484C.png) `#43484C`|
|Uk BSC 64 Portland Stone|71.288|Model Air|204|189|150|![#CCBD96](https://placehold.co/15x15/CCBD96/CCBD96.png) `#CCBD96`|
|Ultra Blue Deep|85.060|Arte Deco|46|41|121|![#2E2979](https://placehold.co/15x15/2E2979/2E2979.png) `#2E2979`|
|Ultramarine|70.839|Model Color|45|85|157|![#2D559D](https://placehold.co/15x15/2D559D/2D559D.png) `#2D559D`|
|Ultramarine|70.625|Surface Primer|51|54|87|![#333657](https://placehold.co/15x15/333657/333657.png) `#333657`|
|Ultramarine Blue|76.022|Game Air|56|57|103|![#383967](https://placehold.co/15x15/383967/383967.png) `#383967`|
|Ultramarine Blue|72.022|Game Color|56|57|103|![#383967](https://placehold.co/15x15/383967/383967.png) `#383967`|
|Ultramarine Blue|28.017|Hobby Paint|76|89|144|![#4C5990](https://placehold.co/15x15/4C5990/4C5990.png) `#4C5990`|
|Ultramarine Blue|72.722|Game Air|29|84|138|![#1D548A](https://placehold.co/15x15/1D548A/1D548A.png) `#1D548A`|
|Umber Wash|73.203|Game Color Wash|118|96|83|![#766053](https://placehold.co/15x15/766053/766053.png) `#766053`|
|Underside Blue “Faded”|71.332|Model Air|196|212|209|![#C4D4D1](https://placehold.co/15x15/C4D4D1/C4D4D1.png) `#C4D4D1`|
|Uniform Blue|85.068|Arte Deco|54|49|83|![#363153](https://placehold.co/15x15/363153/363153.png) `#363153`|
|Uniform Green|70.922|Model Color|75|82|48|![#4B5230](https://placehold.co/15x15/4B5230/4B5230.png) `#4B5230`|
|Vampiric Purple|72.461|Xpress Color|73|40|87|![#492857](https://placehold.co/15x15/492857/492857.png) `#492857`|
|Velvet Red|72.407|Xpress Color|129|40|46|![#81282E](https://placehold.co/15x15/81282E/81282E.png) `#81282E`|
|Verdigris|72.135|Game Color|145|203|204|![#91CBCC](https://placehold.co/15x15/91CBCC/91CBCC.png) `#91CBCC`|
|Verdigris|72.096|Game Color|134|199|169|![#86C7A9](https://placehold.co/15x15/86C7A9/86C7A9.png) `#86C7A9`|
|Verdigris Glaze|70.832|Model Color|153|208|202|![#99D0CA](https://placehold.co/15x15/99D0CA/99D0CA.png) `#99D0CA`|
|Vermilion|70.909|Model Color|196|42|40|![#C42A28](https://placehold.co/15x15/C42A28/C42A28.png) `#C42A28`|
|Victorian Blue|85.067|Arte Deco|53|87|141|![#35578D](https://placehold.co/15x15/35578D/35578D.png) `#35578D`|
|Viking Grey|72.483|Xpress Color Intense|69|81|93|![#45515D](https://placehold.co/15x15/45515D/45515D.png) `#45515D`|
|Viking Grey|72.483|Xpress Color Intense|55|72|85|![#374855](https://placehold.co/15x15/374855/374855.png) `#374855`|
|Violet|62.008|Premium Airbrush Color|83|64|120|![#534078](https://placehold.co/15x15/534078/534078.png) `#534078`|
|Violet|70.960|Model Color|60|44|73|![#3C2C49](https://placehold.co/15x15/3C2C49/3C2C49.png) `#3C2C49`|
|Violet|72.087|Game Color|110|61|116|![#6E3D74](https://placehold.co/15x15/6E3D74/6E3D74.png) `#6E3D74`|
|Violet Grey|70.773|Model Color|90|89|87|![#5A5957](https://placehold.co/15x15/5A5957/5A5957.png) `#5A5957`|
|Violet Red|70.812|Model Color|100|53|63|![#64353F](https://placehold.co/15x15/64353F/64353F.png) `#64353F`|
|Violet Vamp|74.030|Nocturna Models|94|77|122|![#5E4D7A](https://placehold.co/15x15/5E4D7A/5E4D7A.png) `#5E4D7A`|
|Violeta Wash|73.209|Game Color|136|108|167|![#886CA7](https://placehold.co/15x15/886CA7/886CA7.png) `#886CA7`|
|Viridian Green|85.095|Arte Deco|5|108|65|![#056C41](https://placehold.co/15x15/056C41/056C41.png) `#056C41`|
|Vomit|72.600|Game Color Special FX|250|172|66|![#FAAC42](https://placehold.co/15x15/FAAC42/FAAC42.png) `#FAAC42`|
|Vomit|72.134|Game Color|132|124|51|![#847C33](https://placehold.co/15x15/847C33/847C33.png) `#847C33`|
|Wagram Blue|72.464|Xpress Color|1|68|97|![#014461](https://placehold.co/15x15/014461/014461.png) `#014461`|
|Warlord Purple|72.714|Game Air|176|55|109|![#B0376D](https://placehold.co/15x15/B0376D/B0376D.png) `#B0376D`|
|Warlord Purple|76.014|Game Air|132|30|77|![#841E4D](https://placehold.co/15x15/841E4D/841E4D.png) `#841E4D`|
|Warlord Purple|72.014|Game Color|134|35|81|![#862351](https://placehold.co/15x15/862351/862351.png) `#862351`|
|Warm Grey|72.148|Game Color|178|158|157|![#B29E9D](https://placehold.co/15x15/B29E9D/B29E9D.png) `#B29E9D`|
|Warm Neutral Tone|85.106|Arte Deco|243|156|129|![#F39C81](https://placehold.co/15x15/F39C81/F39C81.png) `#F39C81`|
|Wasteland Brown|72.420|Xpress Color|104|69|39|![#684527](https://placehold.co/15x15/684527/684527.png) `#684527`|
|Wedgewood Blue|85.065|Arte Deco|50|76|101|![#324C65](https://placehold.co/15x15/324C65/324C65.png) `#324C65`|
|Wet Effects|73.828|Weathering FX|189|186|167|![#BDBAA7](https://placehold.co/15x15/BDBAA7/BDBAA7.png) `#BDBAA7`|
|White|85.001|Arte Deco|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|White|70.951|Model Color|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|White|76.501|Wash FX|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|White|62.001|Premium Airbrush Color|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|White|28.010|Hobby Paint|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|White|70.640|Mecha Color|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|White|71.001|Model Air|249|249|247|![#F9F9F7](https://placehold.co/15x15/F9F9F7/F9F9F7.png) `#F9F9F7`|
|White|72.082|Game Color|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|White|70.600|Surface Primer|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|White Aluminium|77.706|Metal Color|186|185|190|![#BAB9BE](https://placehold.co/15x15/BAB9BE/BAB9BE.png) `#BAB9BE`|
|White Flesh|74.016|Nocturna Models|245|215|204|![#F5D7CC](https://placehold.co/15x15/F5D7CC/F5D7CC.png) `#F5D7CC`|
|White Glaze|70.853|Model Color|244|244|246|![#F4F4F6](https://placehold.co/15x15/F4F4F6/F4F4F6.png) `#F4F4F6`|
|White Gold|70.796|Liquid Gold|246|246|246|![#F6F6F6](https://placehold.co/15x15/F6F6F6/F6F6F6.png) `#F6F6F6`|
|White Grey|69.002|Mecha Color|240|235|229|![#F0EBE5](https://placehold.co/15x15/F0EBE5/F0EBE5.png) `#F0EBE5`|
|White Grey|71.119|Model Air|218|214|202|![#DAD6CA](https://placehold.co/15x15/DAD6CA/DAD6CA.png) `#DAD6CA`|
|White Grey|70.993|Model Color|227|226|224|![#E3E2E0](https://placehold.co/15x15/E3E2E0/E3E2E0.png) `#E3E2E0`|
|White Primer|62.061|Premium Airbrush Color|255|255|255|![#FFFFFF](https://placehold.co/15x15/FFFFFF/FFFFFF.png) `#FFFFFF`|
|Wicked Purple|72.456|Xpress Color|117|101|102|![#756566](https://placehold.co/15x15/756566/756566.png) `#756566`|
|Williamsburg Blue|85.057|Arte Deco|95|119|157|![#5F779D](https://placehold.co/15x15/5F779D/5F779D.png) `#5F779D`|
|Willow Bark|72.474|Xpress Color|57|43|39|![#392B27](https://placehold.co/15x15/392B27/392B27.png) `#392B27`|
|Witch Purple|74.028|Nocturna Models|128|29|109|![#801D6D](https://placehold.co/15x15/801D6D/801D6D.png) `#801D6D`|
|Wolf Grey|72.047|Game Color|195|209|209|![#C3D1D1](https://placehold.co/15x15/C3D1D1/C3D1D1.png) `#C3D1D1`|
|Wolf Grey|76.047|Game Air|195|209|209|![#C3D1D1](https://placehold.co/15x15/C3D1D1/C3D1D1.png) `#C3D1D1`|
|Wolf Grey|28.020|Hobby Paint|176|192|208|![#B0C0D0](https://placehold.co/15x15/B0C0D0/B0C0D0.png) `#B0C0D0`|
|Wolf Grey|72.747|Game Air|172|189|205|![#ACBDCD](https://placehold.co/15x15/ACBDCD/ACBDCD.png) `#ACBDCD`|
|Wood|71.077|Model Air|171|116|59|![#AB743B](https://placehold.co/15x15/AB743B/AB743B.png) `#AB743B`|
|Worn Red|74.023|Nocturna Models|199|30|73|![#C71E49](https://placehold.co/15x15/C71E49/C71E49.png) `#C71E49`|
|Yellow|69.004|Mecha Color|233|164|1|![#E9A401](https://placehold.co/15x15/E9A401/E9A401.png) `#E9A401`|
|Yellow|85.008|Arte Deco|255|225|93|![#FFE15D](https://placehold.co/15x15/FFE15D/FFE15D.png) `#FFE15D`|
|Yellow|72.085|Game Color|235|169|12|![#EBA90C](https://placehold.co/15x15/EBA90C/EBA90C.png) `#EBA90C`|
|Yellow Brown|71.246|Model Air|151|134|116|![#978674](https://placehold.co/15x15/978674/978674.png) `#978674`|
|Yellow Fluorescent|70.730|Model Color|239|230|65|![#EFE641](https://placehold.co/15x15/EFE641/EFE641.png) `#EFE641`|
|Yellow Fluorescent|69.054|Mecha Color|239|230|65|![#EFE641](https://placehold.co/15x15/EFE641/EFE641.png) `#EFE641`|
|Yellow Green|85.087|Arte Deco|151|196|91|![#97C45B](https://placehold.co/15x15/97C45B/97C45B.png) `#97C45B`|
|Yellow Green|70.954|Model Color|222|222|38|![#DEDE26](https://placehold.co/15x15/DEDE26/DEDE26.png) `#DEDE26`|
|Yellow Ochre|70.913|Model Color|222|170|71|![#DEAA47](https://placehold.co/15x15/DEAA47/DEAA47.png) `#DEAA47`|
|Yellow Ochre|85.014|Arte Deco|225|167|136|![#E1A788](https://placehold.co/15x15/E1A788/E1A788.png) `#E1A788`|
|Yellow Ochre|71.033|Model Air|216|147|46|![#D8932E](https://placehold.co/15x15/D8932E/D8932E.png) `#D8932E`|
|Yellow Ochre|62.015|Premium Airbrush Color|201|136|54|![#C98836](https://placehold.co/15x15/C98836/C98836.png) `#C98836`|
|Yellow Ochre|69.032|Mecha Color|234|164|50|![#EAA432](https://placehold.co/15x15/EAA432/EAA432.png) `#EAA432`|
|Yellow Olive|71.013|Model Air|67|69|66|![#434542](https://placehold.co/15x15/434542/434542.png) `#434542`|
|Yellow Olive|72.064|Game Color|30|79|57|![#1E4F39](https://placehold.co/15x15/1E4F39/1E4F39.png) `#1E4F39`|
|Yellow Olive|70.892|Model Color|56|59|50|![#383B32](https://placehold.co/15x15/383B32/383B32.png) `#383B32`|
|Yellow RLM04|71.078|Model Air|231|162|33|![#E7A221](https://placehold.co/15x15/E7A221/E7A221.png) `#E7A221`|
|Yellow Wash|73.208|Game Color|233|232|92|![#E9E85C](https://placehold.co/15x15/E9E85C/E9E85C.png) `#E9E85C`|
|Yellowish Rust|70.303|Panzer Aces|190|139|94|![#BE8B5E](https://placehold.co/15x15/BE8B5E/BE8B5E.png) `#BE8B5E`|
|Zombie Flesh|72.470|Xpress Color|133|107|90|![#856B5A](https://placehold.co/15x15/856B5A/856B5A.png) `#856B5A`|
<p align="center"><img src="../logos/logo_rnd.png" height="70" /></p>
<p align="center">Made available by <a href="https://miniaturepainterpro.app/">Miniature Painter Pro</a></p>
<p align="center">
<a href="https://play.google.com/store/apps/details?id=com.rfsp.paintmaster"> <img src="../logos/Android.png" height="30" /></a>
<a href="https://apps.apple.com/us/app/miniature-painter-pro/id1495938928"> <img src="../logos/iOS.png" height="30" /></a>
</p>
